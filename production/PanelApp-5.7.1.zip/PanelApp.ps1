#Requires -Version 5.1
param([switch]$PhaseB, [switch]$UpgradeResume)

Set-StrictMode -Off
$ErrorActionPreference = 'Stop'

# -- STA check (WPF requires STA) --
if ([System.Threading.Thread]::CurrentThread.ApartmentState -ne 'STA') {
    $argList = "-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File `"$PSCommandPath`""
    if ($PhaseB) { $argList += ' -PhaseB' }
    if ($UpgradeResume) { $argList += ' -UpgradeResume' }
    Start-Process powershell -ArgumentList $argList; exit
}

# -- Self-elevation --
$script:currentPrincipal = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $script:currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    $argList = "-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File `"$PSCommandPath`""
    if ($PhaseB) { $argList += ' -PhaseB' }
    if ($UpgradeResume) { $argList += ' -UpgradeResume' }
    Start-Process powershell -ArgumentList $argList -Verb RunAs; exit
}

Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase,System.Windows.Forms

# ================================================================
#  CONSTANTS & CONFIGURATION
# ================================================================
$script:ScriptVersion = '5.7.1' # Production hotfix: readiness exceptions remain open without blocking the required device workflow.
$script:RequiredBackendBuildId = 'v5.7-mt43-mt63-20260915c' # Exact field-tested backend required by this release.
                              # Inherits the v5.5.1 reliability/data-integrity hardening unchanged.
                              # Keep Config!B1 at the prior floor until the 5.7 production smoke test passes.
# v5.5 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§5/ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§7: the server revision this client last saw, and which project it belongs to.
$script:ProjectStateRevisionFor = ''
$script:ActiveSenderSync        = $null   # live runspace sync, merged back on each main-thread send
# r5 finding #3: projects with queued work. While a project is listed, later events for it are
# written straight to the queue so a live post cannot reach the backend BEFORE the queued one.
$script:PendingQueuedProjects   = @{}
$script:LastRejection           = $null
$script:ScriptDir  = Split-Path -Parent $PSCommandPath
$script:ConfigPath = Join-Path $script:ScriptDir 'config.json'
$script:LogFile    = Join-Path $env:TEMP "PanelApp_$(Get-Date -f 'yyyyMMdd_HHmmss').log"
$script:ErrorLog   = Join-Path $script:ScriptDir 'AppErrors.log'
$script:RunFlags   = [hashtable]::Synchronized(@{ HadError = $false })

try {
    $script:Config = Get-Content $script:ConfigPath -Raw | ConvertFrom-Json
} catch {
    [System.Windows.MessageBox]::Show("Cannot load config.json:`n$_", 'APS Panel App - Fatal Error', 'OK', 'Error') | Out-Null
    exit 1
}
$script:ProvisioningDir = $script:Config.ProvisioningDir

# -- Runtime state --
$script:TechName            = ''
$script:CurrentMode         = 0
$script:ModeLabel           = ''
$script:SchoolCode          = ''
$script:SchoolName          = ''
$script:Manufacturer        = ''
$script:MfrCode             = ''
$script:MountType           = ''
$script:RoomNumber          = ''
$script:RawRoomEntry        = ''
# v5.5.1 ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§5/ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§11: the assessment-time hostname and the provisioning RESULT are kept apart from
# the pre-provisioning domain observation, so a completed project shows the CURRENT endpoint.
$script:AssessmentHostname          = ''
$script:DomainJoinTargetDomain      = ''
$script:DomainJoinCompletedAt       = ''
$script:PostJoinMembershipStatus    = ''
$script:PostJoinSecureChannelStatus = ''
$script:AssessmentType      = 'Initial Assessment'
$script:ReassessmentReason  = ''
$script:PreviousProjectRunId = ''
$script:InventoryCycleId = $(if ($script:Config.SummerInventoryCycleId) { "$($script:Config.SummerInventoryCycleId)" } else { '' })
$script:SummerOfficialRebaselineEnabled = $false
try { $script:SummerOfficialRebaselineEnabled = [bool]$script:Config.SummerOfficialRebaselineEnabled } catch {}
$script:PanelSerial         = ''
# v5.7 missing/unreadable panel-serial workflow. PanelSerial remains blank until the real
# chassis identity is known; reconciliation evidence must never be substituted into PanelSerial.
$script:PanelSerialStickerStatus       = ''   # Present | Missing or Unreadable
$script:PanelSerialSource              = ''   # Chassis Sticker / Barcode | Promethean Android Settings | Pending Reconciliation
$script:PanelSerialVerificationStatus  = ''   # Verified | Pending Reconciliation
$script:PanelObservationId             = ''
$script:IdentityResolutionRequired     = $false
$script:PanelIdentityResolutionStatus  = ''   # Resolved | Pending
$script:IIQAssetTag                    = ''
$script:NDMSName                       = ''
$script:NDMSDeviceId                   = ''
$script:NDMSTags                       = ''
$script:OPSSerial           = ''
$script:OldOPSSerial        = ''
# -- OPS serial detection debug/validation (v5.3 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§6) --
$script:OPSSerial_BIOS       = ''
$script:OPSSerial_Product    = ''
$script:OPSSerial_BaseBoard  = ''
$script:OPSSerial_Registry   = ''
$script:SelectedOPSSerialSource     = ''
$script:SelectedOPSSerialConfidence = ''
$script:OPSSerialValidationStatus   = ''
$script:OPSSerialValidationNote     = ''
$script:Hostname            = ''
$script:OPSTruncationNote   = ''
$script:M3OldOPSDisposition = ''
$script:M5HostnameCorrect   = $true
# v5.6 unified RMA workflow: one technician-facing mode, with routing based on the actual OPS/domain/hostname state.
$script:RMAAction                  = ''   # InventoryOnly | RenameOnly | FullProvision
$script:RMAPreviousPanelSerial     = ''
$script:RMAReassignmentConfirmed   = $false
$script:RMAInventoryLookup         = $null
# v5.6 general OPS reassignment context. RMA is one reason; ordinary moves and temporary
# classroom coverage use the same guarded backend path. TestingOnly never changes current pairing.
$script:InventoryReassignmentConfirmed = $false
$script:InventoryReassignmentType      = ''   # RMAReplacement | PermanentOPSMove | TemporaryOperationalSwap | TestingOnly
$script:InventoryReassignmentReason    = ''
$script:InventoryPreviousPanelSerial   = ''
$script:TemporaryAssignment            = $false
$script:FollowUpRequired               = $false
$script:TestingObservationOnly         = $false
$script:InventoryReassignmentLookup    = $null
$script:InstallSubType      = ''
$script:ProvPath            = ''   # 'Standard' | 'PostRedo' (Full Provisioning sub-path, v5.3)
# -- Summer 2026 Day One readiness + project lifecycle (v5.2) --
$script:ProjectRunId        = ''
$script:DayOne_Display      = $false
$script:DayOne_Touch        = $false
$script:DayOne_Sound        = $false
$script:DayOne_Cables       = $false
$script:DayOne_Network      = $false
$script:DayOne_NDMS         = $false
$script:NetworkType         = ''
$script:DayOneStatus        = ''
$script:ReadinessIssueCategory = ''
$script:ReadinessIssueNote  = ''
# -- Summer continuation (reimage mode) + exceptions/offline (v5.2 Phase 3/4) --
$script:SummerContinuation      = $false
$script:RelatedSummerRunId      = ''
$script:SummerImageProfile      = ''
$script:SummerRedoFile          = ''
$script:SummerOriginalOPS       = ''
$script:SummerOriginalDayOne    = ''
$script:OPSReplacementConfirmed = ''
$script:SummerMatches           = @()
$script:IssueReturnScreen       = ''
$script:IssueContextPhase       = ''
$script:UsbRoot                 = ''   # removable-media launch path (captured before ProgramData copy)
$script:RunId                   = ''
$script:CloseoutIssueReported   = $false
$script:AndroidEthernetExceptionReported = $false
$script:AndroidEthernetExceptionEventId  = ''
$script:EndpointRepairAction            = ''   # RenameOnly | DomainJoinOnly | RenameAndJoin
$script:EndpointRepairStage             = ''   # VerifyRename | DomainAction | VerifyDomain
$script:EndpointRepairOriginalHostname  = ''
$script:EndpointRepairExpectedHostname  = ''
$script:EndpointRepairDomainState       = ''
# r13 finding #1 (field test, King Middle 1410): the closeout handler runs the POST, the state
# write and the cleanup on the WPF UI thread, so the window greys out and Windows paints it as
# "Not Responding". The technician clicked Finish and Reboot a second time and a SECOND
# FinalCloseoutCompleted was minted with its own EventId - EventId dedupe cannot catch that, so
# both applied, appending two PanelLog rows and taking the project to revision 5.
$script:CloseoutSubmissionInProgress = $false
$script:CloseoutCommitted            = $false
$script:OPSRequestSubmissionInProgress = $false
$script:SummerExpectedFolder    = ''
# -- v5.3.1 review fixes: hostname audit + check gating --
$script:PreviousHostname        = ''
$script:PreviousHostnameSource  = ''
$script:HostnameCheckStatus     = 'NotChecked'   # NotChecked|Available|AlternateSelected|DNSAvailableADUnavailable|Conflict
$script:OldHostnameCheckResult  = ''
$script:NewHostnameCheckResult  = ''
$script:PrefilledOldHostname    = ''
$script:SelectedHostnameSuffix  = ''
$script:ResumeCloseoutPending   = $false
# -- v5.3.2 new-replacement-panel detection + routing --
$script:InstallType                 = ''   # Existing Panel | New Replacement Install | Warranty Replacement | Unknown
$script:DomainMembershipStatus      = ''   # Domain Joined | Not Domain Joined | Unknown
$script:DetectedDomain              = ''
$script:DomainCheckAt               = ''
$script:SecureChannelStatus         = ''   # Healthy | Failed | Not Tested | Not Applicable | Unknown
$script:ProvisioningPathRecommended = ''
$script:ProvisioningPathSelected    = ''
$script:ProvisioningRecommendationReason = ''
$script:NewInstallConfirmedBy       = ''
$script:NewInstallConfirmedAt       = ''
$script:NewInstallProvisioning      = $false
# TRUE only when the CURRENT provisioning run is post-RedoRescue recovery work. Existing panels
# that merely needed domain/provisioning repair stay FALSE (review issue #3).
$script:RecoveryProvisioning        = $false
$script:ApprovedImageOK             = $false
$script:ApprovedImageReason         = ''
# v5.4 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§2.G structured image decision (carried onto the Summer/PanelLog rows)
$script:WindowsVersionStatus        = ''
$script:ImageStatus                 = ''
$script:ImageDecisionReason         = ''
$script:RemediationMethod           = ''
$script:ReimageReason               = ''
$script:ApprovedImageOSName         = ''
$script:ApprovedImageMinimum        = '24H2'
$script:ApprovedImagePreferred      = '25H2'
$script:FirmwareConfigurationRequired = $false
$script:WindowsUpdateRequired       = $false
$script:PendingRestartDetected      = $false
$script:PendingRestartReasons       = ''
$script:RedoRescueAllowed           = $false
$script:RedoRescueRequired          = $false
$script:RecoveryRequired            = $false
$script:InfrastructureUpdateEligible = $false
$script:ProvRecAction               = ''
$script:ProvRecIssueCategory        = ''
# -- v5.3.3 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§3 Room Type (standardized display values). "Other" reveals OtherRoomType;
#    "Unknown" is a valid temporary value when the tech cannot verify the room this visit. --
$script:RoomType                    = ''
$script:OtherRoomType               = ''
# v5.4 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§4-16 inventory-correction mode state
$script:InvEditing                  = $false
$script:InvLookupType               = ''
$script:InvLookupValue              = ''
$script:RoomTypeValues = @(
    'Classroom','Media Center','Office','Conference Room','Computer Lab','Science Lab','Specialty Lab',
    'Auditorium','Cafeteria','Gymnasium','Music Room','Art Room','Multipurpose Room','Common Area',
    'Hallway','Mobile Classroom','Storage','Other','Unknown'
)
$script:PanelModel          = ''
$script:StorageGB           = ''
# v5.7 endpoint telemetry: observed Windows/system-volume values. Existing storage fields remain.
$script:StorageTotalGB      = ''
$script:StorageUsedGB       = ''
$script:StorageFreeGB       = ''
$script:StorageTelemetryCaptured = $false
# v5.7 automated Windows 11 in-place upgrade state. This is intentionally separate from
# Phase A/Phase B provisioning state so an OS upgrade can never be mistaken for a reimage/domain workflow.
$script:WindowsUpgradeStage        = ''
$script:WindowsUpgradeCompatResult = ''
$script:WindowsUpgradeCompatCode   = ''
$script:WindowsUpgradeSetupPath    = ''
$script:WindowsUpgradeOPSClass     = ''
$script:WindowsUpgradeTarget       = ''
$script:WindowsUpgradeRunspaceSync = $null
$script:ProgressAction             = ''
$script:ReviewNotes         = ''
$script:IsNetworkAvailable  = $false
# v5.6.1: this boolean now means the PanelApp BACKEND is usable, not merely that the NIC can
# reach the internet. Authentication/invalid-response failures queue safely instead of being
# mislabeled as "No network".
$script:BackendStatus          = 'Unknown'   # Available | BackendUpdateRequired | AuthenticationRequired | InvalidResponse | Unavailable | Unconfigured
$script:BackendStatusDetail    = ''
$script:BackendMinimumVersion  = ''
$script:BackendBuildId         = ''
$script:BackendLastCheckedAt   = ''
$script:LastSyncedCloseout     = $null
# Temporary local provisioning-account preflight. This is intentionally technician-transparent.
$script:ProvisioningAccountName                 = $(if ($script:Config.ProvisioningAccountName) { "$($script:Config.ProvisioningAccountName)" } else { 'user' })
$script:ProvisioningAccountPreflight             = 'Not Checked'
$script:ProvisioningAccountEnabled               = ''
$script:ProvisioningAccountPasswordNeverExpires  = ''
$script:ProvisioningAccountCheckedAt             = ''

# ================================================================
#  LOGGING
# ================================================================
function Write-Log {
    param([string]$Message, [ValidateSet('INFO','WARN','ERROR','STEP')][string]$Level = 'INFO')
    $ts = Get-Date -Format 'HH:mm:ss'
    $e  = "[$ts][$Level] $Message"
    try { Add-Content -Path $script:LogFile  -Value $e -Encoding UTF8 } catch {}
    if ($Level -eq 'ERROR') {
        $script:RunFlags.HadError = $true
        try { Add-Content -Path $script:ErrorLog -Value $e -Encoding UTF8 } catch {}
    }
    if ($script:UI -and $script:UI['txtProgressLog']) {
        try { $script:UI['txtProgressLog'].Dispatcher.Invoke([Action]{
            $script:UI['txtProgressLog'].AppendText("$e`n")
            $script:UI['txtProgressLog'].ScrollToEnd() }) } catch {}
    }
}
function Set-Status { param([string]$Text)
    try { $script:UI['lblStatus'].Dispatcher.Invoke([Action]{ $script:UI['lblStatus'].Text = $Text }) } catch {}
    Write-Log $Text
}
function Update-ProgressStatus { param([string]$Text)
    try { $script:UI['lblProgressStatus'].Dispatcher.Invoke([Action]{ $script:UI['lblProgressStatus'].Text = $Text }) } catch {}
    Set-Status $Text
}

# ================================================================
#  OPS SERIAL AUTO-PULL
# ================================================================
# v5.3.4: the PHYSICAL serial prefix does NOT resemble the WMI model name. The BigFix district
# report (1,148 usable serials) shows a stable serial-prefix -> normalized-class relationship, and
# a separate model-name -> class relationship. PanelApp classifies each independently and compares
# the NORMALIZED classes - it must NOT compare the literal serial text against the literal model.
# Physical serial prefix (e.g. OP72I) -> normalized OPS class.
$script:OPSSerialPrefixMap = [ordered]@{
    'MT21I' = 'MT21'; 'MT43I' = 'MT43'; 'MT63I' = 'MT63'
    'OP62I' = 'OPS62'; 'OP72I' = 'OPS72'
    'G256S' = 'OPS3'; 'H256S' = 'OPS4'
}
# WMI model / baseboard patterns (e.g. OPS72A-SHA) -> normalized OPS class.
$script:OPSModelClassMap = [ordered]@{
    'OPS72A-SHA' = 'OPS72'; 'OPS62A-SHA' = 'OPS62'
    'MT63A-SHA'  = 'MT63';  'MT43A-JHA'  = 'MT43'
    'MT21B-ZWZN' = 'MT21';  'ZWZN-MT21-B' = 'MT21'; 'MT11-ZWZN' = 'MT11'
    'OPS4-'      = 'OPS4';   'OPS3-'      = 'OPS3'
}
# Legacy stored prefixes (older records) -> class, so resume/reporting still normalizes correctly.
$script:OPSLegacyPrefixClass = @{
    'OPS72A'='OPS72'; 'OPS72I'='OPS72'; 'OPS72'='OPS72'; 'OPS62A'='OPS62'; 'OPS62'='OPS62'
    'MT21'='MT21'; 'MT43'='MT43'; 'MT63'='MT63'; 'OPS3'='OPS3'; 'OPS4'='OPS4'
}
# Return the actual PHYSICAL serial prefix (e.g. OP72I) from a candidate serial. Longest-first.
function Get-OPSPrefixMatch { param([string]$Value)
    $u = "$Value".ToUpper()
    foreach ($p in ($script:OPSSerialPrefixMap.Keys | Sort-Object { $_.Length } -Descending)) {
        if ($u.StartsWith($p)) { return $p }
    }
    return ''
}
# Normalize a serial prefix (physical or legacy stored) to its OPS class. '' if unknown.
function Get-OPSClassFromSerialPrefix { param([string]$Prefix)
    $p = "$Prefix".ToUpper()
    if ($script:OPSSerialPrefixMap.Contains($p)) { return $script:OPSSerialPrefixMap[$p] }
    if ($script:OPSLegacyPrefixClass.ContainsKey($p)) { return $script:OPSLegacyPrefixClass[$p] }
    return ''
}
# Normalize a WMI model/baseboard/BIOS string to its OPS class. '' if unrecognized.
function Get-OPSClassFromModel { param([string]$ModelString)
    $m = "$ModelString".ToUpper()
    foreach ($pat in $script:OPSModelClassMap.Keys) {
        if ($m -like "*$pat*") { return $script:OPSModelClassMap[$pat] }
    }
    return ''
}
# Reporting family for an OPS class OR a serial prefix. OPSFamily = the panel generations that use
# that OPS family (not just the OPS hardware generation name).
function Get-OPSFamily { param([string]$ClassOrPrefix)
    $c = "$ClassOrPrefix".ToUpper()
    $cls = Get-OPSClassFromSerialPrefix $c; if ($cls) { $c = $cls }   # accept a physical/legacy prefix
    switch -Regex ($c) {
        '^MT(11|21|43|63)$' { return 'Boxlight Gen 2/3 (MT)' }
        '^OPS(62|72)$'      { return 'Boxlight Gen 1, 4, Max 2, Pro Series 3' }
        '^OPS(3|4)$'        { return 'Promethean AP7/9/10' }
        default             { return 'Unknown' }
    }
}
# Hardware class used by the Windows-remediation matrix. Prefer the physical OPS serial prefix;
# fall back to WMI computer/baseboard model so MT11 can still be classified when its serial prefix
# is not in the district prefix map. The PANEL MODEL is intentionally not used for OS eligibility.
function Get-CurrentOPSClass {
    param([string]$Serial = $script:OPSSerial)
    try {
        $prefix = Get-OPSPrefixMatch "$Serial"
        $cls = Get-OPSClassFromSerialPrefix $prefix
        if ($cls) { return $cls }
    } catch {}
    try {
        $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop
        $cls = Get-OPSClassFromModel "$($cs.Model)"
        if ($cls) { return $cls }
    } catch {}
    try {
        $bb = Get-CimInstance Win32_BaseBoard -ErrorAction Stop
        $cls = Get-OPSClassFromModel "$($bb.Product)"
        if ($cls) { return $cls }
    } catch {}
    return ''
}

# Score serial candidates by known-physical-prefix match (not "longest wins"), then validate by
# comparing the serial's normalized class against the model's normalized class.
function Get-OPSSerialData {
    $noise = @('To be filled by O.E.M.','Default string','None','00000000','0','Default',
               'Not Applicable','System Serial Number','','To Be Filled By O.E.M.')
    $r = @{ BIOS = ''; Product = ''; Board = ''; Registry = '' }
    try { $r.BIOS     = "$((Get-WmiObject Win32_BIOS).SerialNumber)".Trim() } catch {}
    try { $r.Product  = "$((Get-WmiObject Win32_ComputerSystemProduct).IdentifyingNumber)".Trim() } catch {}
    try { $r.Board    = "$((Get-WmiObject Win32_BaseBoard).SerialNumber)".Trim() } catch {}
    try {
        $reg = Get-ItemProperty 'HKLM:\HARDWARE\DESCRIPTION\System\BIOS' -Name 'SystemSerialNumber' -ErrorAction Stop
        $r.Registry = "$($reg.SystemSerialNumber)".Trim()
    } catch {}

    # Model class from Win32_ComputerSystem.Model / BaseBoard.Product / BIOS version (fallback).
    $modelStr = ''
    try { $modelStr = ("$((Get-WmiObject Win32_ComputerSystem).Model) $((Get-WmiObject Win32_BaseBoard).Product) $((Get-WmiObject Win32_BIOS).SMBIOSBIOSVersion)").ToUpper() } catch {}
    $modelClass = Get-OPSClassFromModel $modelStr

    $cands = @(
        [pscustomobject]@{ Source='BIOS';      Value=$r.BIOS }
        [pscustomobject]@{ Source='Product';   Value=$r.Product }
        [pscustomobject]@{ Source='BaseBoard'; Value=$r.Board }
        [pscustomobject]@{ Source='Registry';  Value=$r.Registry }
    ) | Where-Object { $_.Value -and ($_.Value -notin $noise) }

    $scored = foreach ($c in $cands) {
        $sc = 0
        if (Get-OPSPrefixMatch $c.Value) { $sc += 1000 }        # a known physical prefix dominates
        $len = $c.Value.Length
        if ($len -ge 8 -and $len -le 40) { $sc += 100 } elseif ($len -lt 6) { $sc -= 200 }
        if ($c.Value -match '[^A-Za-z0-9\-\.]') { $sc -= 50 }   # $, spaces etc. look non-serial
        [pscustomobject]@{ Source=$c.Source; Value=$c.Value; Score=$sc }
    }
    $best = $scored | Sort-Object Score, @{Expression={$_.Value.Length}} -Descending | Select-Object -First 1

    $r['Best']           = if ($best) { $best.Value } else { '' }
    $r['BestSource']     = if ($best) { $best.Source } else { 'None' }
    $bestPrefix          = if ($best) { Get-OPSPrefixMatch $best.Value } else { '' }
    $serialClass         = Get-OPSClassFromSerialPrefix $bestPrefix
    $r['OPSPrefix']      = $bestPrefix                                   # physical prefix (e.g. OP72I)
    $r['OPSClass']       = $serialClass                                  # normalized (e.g. OPS72)
    $r['ModelClass']     = $modelClass
    $r['ExpectedPrefix'] = if ($modelClass) { $modelClass } else { '' }  # model's class, for display
    $r['OPSFamily']      = if ($serialClass) { Get-OPSFamily $serialClass } elseif ($modelClass) { Get-OPSFamily $modelClass } else { 'Unknown' }

    # v5.3.4: compare NORMALIZED classes (serial vs model). Sticker verification is forced only for a
    # genuine class conflict or an unrecognized/malformed serial - NOT for OP72I vs OPS72A-SHA.
    if (-not $best) {
        $r['Confidence']='None'; $r['ValidationStatus']='Unknown'; $r['ValidationNote']='No usable serial detected from WMI/registry.'
    } elseif ($serialClass -and $modelClass -and $serialClass -eq $modelClass) {
        $r['Confidence']='High'; $r['ValidationStatus']='OK'; $r['ValidationNote']="Serial prefix $bestPrefix maps to $serialClass and matches the computer model class ($modelClass)."
    } elseif ($serialClass -and $modelClass) {
        $r['Confidence']='Low'; $r['ValidationStatus']='Suspicious'; $r['ValidationNote']="Serial prefix $bestPrefix ($serialClass) does not match the computer model class ($modelClass). Verify the OPS serial from the sticker."
    } elseif ($serialClass) {
        $r['Confidence']='Medium'; $r['ValidationStatus']='OK'; $r['ValidationNote']="Serial prefix $bestPrefix maps to $serialClass; computer model class unavailable."
    } elseif ($modelClass) {
        $r['Confidence']='Low'; $r['ValidationStatus']='Suspicious'; $r['ValidationNote']="Model class is $modelClass but the detected serial does not begin with a known OPS prefix. Verify the OPS serial from the sticker."
    } else {
        $r['Confidence']='Low'; $r['ValidationStatus']='Suspicious'; $r['ValidationNote']='Detected serial does not begin with a known OPS prefix. Verify the OPS serial.'
    }
    $r['PossiblyTruncated'] = ($r['Best'].Length -gt 0 -and $r['Best'].Length -lt 8)
    return $r
}

# ================================================================
#  HOSTNAME BUILDER & VALIDATOR
# ================================================================
function Build-Hostname {
    # v5.3 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§8: Room is always the actual room number. Mobile hostnames use MB + last 4 of the
    # panel serial (NOT the room). A temporary "X" suffix is always appended because old AD
    # computer objects may still exist and cannot be removed by technicians.
    param(
        [string]$SchoolCode, [string]$MfrCode, [string]$MountType,
        [string]$Room, [string]$PanelSerial = ''
    )
    if ($MountType -eq 'Mobile') {
        $last4 = if ($PanelSerial.Length -ge 4) { $PanelSerial.Substring($PanelSerial.Length - 4) } else { $PanelSerial }
        $hn = "${SchoolCode}I9${MfrCode}MB${last4}X"
    } else {
        $hn = "${SchoolCode}I9${MfrCode}${Room}X"
    }
    return ($hn.ToUpper() -replace '[^A-Z0-9\-]','')
}
# Best-effort DNS + AD existence check for a hostname (ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§9). Runs from the local staging
# account, so the AD half may not be reachable; it is advisory only. The "X" suffix is the
# primary protection against collisions with old AD objects.
function Test-HostnameAvailability {
    param([string]$Hostname)
    $dnsFound = $false; $adChecked = $false; $adFound = $false
    # Check both the short name and the FQDN (ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§9.2)
    foreach ($n in @($Hostname, "$Hostname.$($script:Config.Domain)")) {
        try { if (Resolve-DnsName -Name $n -ErrorAction Stop 2>$null) { $dnsFound = $true; break } } catch {}
    }
    try {
        $searcher = [ADSISearcher]"(&(objectCategory=computer)(cn=$Hostname))"
        $searcher.SearchScope = 'Subtree'
        $found = $searcher.FindOne()
        $adChecked = $true
        if ($found) { $adFound = $true }
    } catch { $adChecked = $false }

    if ($dnsFound -and $adFound)      { return "Warning: hostname exists in DNS and appears to exist in AD." }
    elseif ($adFound)                 { return "Warning: hostname may already exist in AD." }
    elseif ($dnsFound)                { return "Warning: hostname exists in DNS." }
    elseif ($adChecked)               { return "Hostname appears available (no DNS or AD match)." }
    else                              { return "DNS check completed. AD object check not available from this account." }
}
# v5.3.2 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§4: local domain-membership detection. Win32_ComputerSystem.PartOfDomain is the
# primary signal; the secure-channel test is supplemental (only when joined + online).
function Get-DomainMembership {
    $status = 'Unknown'; $domain = ''
    try {
        $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop
        $domain = "$($cs.Domain)"
        if     ($cs.PartOfDomain -eq $true)  { $status = 'Domain Joined' }
        elseif ($cs.PartOfDomain -eq $false) { $status = 'Not Domain Joined' }
        else                                 { $status = 'Unknown' }
    } catch { $status = 'Unknown' }
    $script:DomainMembershipStatus = $status
    $script:DetectedDomain         = $domain
    $script:DomainCheckAt          = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
    if ($status -eq 'Domain Joined') {
        $script:SecureChannelStatus = 'Not Tested'
        if ($script:IsNetworkAvailable) {
            try { $script:SecureChannelStatus = if (Test-ComputerSecureChannel -ErrorAction Stop) { 'Healthy' } else { 'Failed' } }
            catch { $script:SecureChannelStatus = 'Unknown' }
        }
    } else {
        $script:SecureChannelStatus = 'Not Applicable'
    }
    Write-Log "Domain membership: $status (domain '$domain', secure channel $($script:SecureChannelStatus))."
    return $status
}

# v5.4 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§29: a hostname that belongs to THIS device (or to this same Summer project) is NOT a new
# DNS/AD conflict. Prevents a Phase A retry from forcing the tech to add extra suffix characters.
function Test-HostnameIsSelf {
    param([string]$Hostname)
    if (-not $Hostname) { return $false }
    if ("$Hostname" -ieq "$env:COMPUTERNAME") { return $true }
    # The same project already owns this name (retry after a failed Phase A / handoff resume)
    if ($script:SummerRecord -and "$($script:SummerRecord.Hostname)" -ieq "$Hostname") { return $true }
    if ($script:Hostname -and "$script:Hostname" -ieq "$Hostname" -and $script:RelatedSummerRunId) { return $true }
    # DNS resolves the name to one of THIS device's own addresses
    try {
        $mine = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
                  Where-Object { $_.IPAddress -notlike '169.254.*' -and $_.IPAddress -ne '127.0.0.1' } |
                  Select-Object -ExpandProperty IPAddress)
        if ($mine.Count -gt 0) {
            foreach ($n in @($Hostname, "$Hostname.$($script:Config.Domain)")) {
                $res = Resolve-DnsName -Name $n -Type A -ErrorAction SilentlyContinue 2>$null
                foreach ($rr in @($res)) { if ($rr.IPAddress -and ($mine -contains $rr.IPAddress)) { return $true } }
            }
        }
    } catch {}
    return $false
}
# ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â
#  v5.4 SHARED IMAGE DECISION  (review defect #5/#6)
#  ONE implementation of the image matrix, dot-sourced on the main thread AND injected
#  into every background runspace, so the initial Summer assessment and the final
#  recommendation can never disagree. Pure - no $script: dependencies.
# ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â
$script:ImageDecisionDefs = {
# ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§2.H: rank a Windows feature version so 23H2 < 24H2 < 25H2. Returns -1 if unparseable.
function Get-WindowsFeatureVersionRank {
    param([string]$DisplayVersion)
    if ("$DisplayVersion" -match '^(?<Year>\d{2})H(?<Half>[12])$') {
        return ([int]$Matches.Year * 10) + [int]$Matches.Half
    }
    return -1
}
# ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§2.F: a mandatory update restart is not removed by "pause Windows Update" - a staged update
# still applies on the next reboot, which would fight the Phase A rename.
# v5.4.1 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§1: BLOCKING vs ADVISORY. Only a confirmed reboot-required signal may stop a panel.
# The Sutton false positive came from treating Update-Orchestrator work and pending file renames
# as mandatory - those are set routinely by driver installs, first-boot provisioning, app
# installs and AV activity, and they survive a reboot, so they trapped a healthy 25H2 panel.
# This function only READS the registry - it never deletes or modifies Windows Update keys.
function Test-PendingRestart {
    $blockingReasons = @()
    $advisoryReasons = @()
    # --- Confirmed: Windows itself says a reboot is required ---
    try { if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending') { $blockingReasons += 'Component-Based Servicing reboot pending' } } catch {}
    try { if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') { $blockingReasons += 'Windows Update reboot required' } } catch {}
    # --- Advisory: real signals, but not proof a mandatory restart is outstanding ---
    try { if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootInProgress') { $advisoryReasons += 'Servicing operation in progress' } } catch {}
    try { if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Services\Pending') { $advisoryReasons += 'Update Orchestrator has pending work' } } catch {}
    try {
        $pfro = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name PendingFileRenameOperations -ErrorAction Stop
        if ($pfro.PendingFileRenameOperations) { $advisoryReasons += 'Pending file rename operations' }
    } catch {}
    return @{
        Pending          = ($blockingReasons.Count -gt 0)
        Reasons          = ($blockingReasons -join '; ')
        AdvisoryDetected = ($advisoryReasons.Count -gt 0)
        AdvisoryReasons  = ($advisoryReasons -join '; ')
    }
}
# ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§2.D: which recovery process is valid for this manufacturer. RedoRescue is Boxlight-only.
function Get-RecoveryMethodForManufacturer {
    param([string]$Manufacturer)
    switch ("$Manufacturer") {
        'Boxlight'   { return @{ Method = 'Boxlight RedoRescue Recovery';        RedoRescueAllowed = $true  } }
        'Promethean' { return @{ Method = 'Promethean Standard Windows Recovery'; RedoRescueAllowed = $false } }
        # APS has no approved SMART recovery procedure, so SMART recovery is a human decision.
        # Change this back to a named method only once that procedure is documented.
        'SMART'      { return @{ Method = 'Manual Review';                        RedoRescueAllowed = $false } }
        default      { return @{ Method = 'Manual Review';                        RedoRescueAllowed = $false } }
    }
}
# ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§2.G THE image matrix. Storage profile is decisive ONLY for choosing a Boxlight Windows 10
# RedoRescue image (review defect #4) - it never disqualifies an otherwise healthy Windows 11.
function Get-ImageDecision {
    param(
        [int]$Build, [string]$DisplayVer, [string]$Manufacturer, [string]$OPSClass = '',
        [string]$PartitionStyle, [string]$FirmwareMode, [double]$StorageGB,
        $Profiles, [string]$MinVer = '24H2', [string]$PrefVer = '25H2',
        [bool]$PendingRestart = $false, [string]$PendingReasons = ''
    )
    # Classify by the BUILD boundary first so a Windows 10 box with an unparseable ReleaseId
    # (e.g. "2009") still reaches the Windows 10 branch (review edge case).
    $isWin11 = ($Build -ge 22000)
    $isWin10 = ($Build -gt 0 -and $Build -lt 22000)
    $curRank = Get-WindowsFeatureVersionRank $DisplayVer
    $minRank = Get-WindowsFeatureVersionRank $MinVer
    $osShort = "Windows $(if ($isWin11) { '11' } elseif ($isWin10) { '10' } else { '?' })$(if ($DisplayVer) { " $DisplayVer" })"
    $opsClassNormalized = "$OPSClass".Trim().ToUpperInvariant()

    $prof = $null
    foreach ($p in $Profiles) { if ($StorageGB -ge [int]$p.MinGB -and $StorageGB -le [int]$p.MaxGB) { $prof = $p; break } }
    $isApprovedRedoTarget = ("$Manufacturer" -eq 'Boxlight' -and
                             $opsClassNormalized -in @('MT43','MT63') -and
                             $prof -and [int]$prof.StorageTier -in @(128,256))
    $rec = Get-RecoveryMethodForManufacturer $Manufacturer
    $firmwareReadable = ($FirmwareMode -and $PartitionStyle)
    $firmwareOK = ($FirmwareMode -match 'Uefi' -and $PartitionStyle -eq 'GPT')

    $r = @{
        OK = $false; Reason = ''; Profile = ''; Folder = ''; Tier = 0
        StorageGB = $StorageGB; PartitionStyle = $PartitionStyle; Build = $Build; DisplayVer = $DisplayVer
        OSName = $osShort; FirmwareMode = $FirmwareMode
        WindowsVersionStatus = 'Unable to Determine'
        ImageStatus = 'Manual Review Required'
        ImageDecisionReason = ''
        MinimumAcceptedVersion = $MinVer; PreferredVersion = $PrefVer
        RemediationMethod = 'Manual Review'
        FirmwareConfigurationRequired = $false
        WindowsUpdateRequired = $false
        PendingRestartDetected = [bool]$PendingRestart
        # Carried so a resumed project OVERWRITES the old reasons with a blank value once the
        # restart is done - the backend preserves any field an update omits.
        PendingRestartReasons = "$PendingReasons"
        RecoveryRequired = $false
        RedoRescueAllowed = [bool]$isApprovedRedoTarget
        RedoRescueRequired = $false
        InfrastructureUpdateEligible = $false
        ReimageReason = ''          # stays BLANK unless a real recovery condition exists
    }
    if ($prof) { $r.Profile = "$($prof.ProfileId)"; $r.Folder = "$($prof.ExpectedImageFolder)"; $r.Tier = [int]$prof.StorageTier }

    # --- Windows version status ---
    if ($Build -le 0)                 { $r.WindowsVersionStatus = 'Unable to Determine' }
    elseif ($isWin10)                 { $r.WindowsVersionStatus = 'Upgrade Required' }
    elseif ($curRank -lt 0)           { $r.WindowsVersionStatus = 'Unable to Determine' }
    elseif ($curRank -ge $minRank)    { $r.WindowsVersionStatus = 'Accepted' }
    else                              { $r.WindowsVersionStatus = 'Upgrade Required' }

    # --- Image status ---
    if ($r.WindowsVersionStatus -eq 'Unable to Determine') {
        $r.ImageStatus = 'Manual Review Required'; $r.RemediationMethod = 'Manual Review'
        $r.ImageDecisionReason = 'The Windows version could not be determined on this device.'
    } elseif ($isWin10) {
        # v5.7 project policy: Windows 10 remediation follows the physical OPS hardware class.
        # A panel generation does not determine whether its removable OPS can safely run Windows 11.
        if ("$Manufacturer" -eq 'Boxlight' -and $opsClassNormalized -in @('MT43','MT63')) {
            if ($isApprovedRedoTarget) {
                $r.ImageStatus = 'Recovery Required'
                $r.RemediationMethod = 'Boxlight RedoRescue Recovery'
                $r.RecoveryRequired = $true
                $r.RedoRescueRequired = $true
                $r.ReimageReason = "Windows 10 detected on Boxlight $opsClassNormalized with the approved $([int]$prof.StorageTier)GB profile. The approved path is RedoRescue to the Windows 11 image."
                $r.ImageDecisionReason = "$osShort on Boxlight $opsClassNormalized ($([int]$prof.StorageTier)GB) - restore the approved $([int]$prof.StorageTier)GB Windows 11 image with RedoRescue."
            } else {
                $r.ImageStatus = 'Manual Review Required'
                $r.RemediationMethod = 'Validate Storage / Windows 11 Path'
                $r.RedoRescueAllowed = $false
                $r.RedoRescueRequired = $false
                $r.ImageDecisionReason = "$osShort on Boxlight $opsClassNormalized should move to Windows 11, but the storage profile is not an approved 128GB/256GB RedoRescue target. Do not reimage until the correct upgrade path is validated."
            }
        } elseif ("$Manufacturer" -eq 'Boxlight' -and $opsClassNormalized -eq 'MT21') {
            $r.ImageStatus = 'Manual Review Required'
            $r.RemediationMethod = 'Keep Windows 10 - Replacement Pending'
            $r.RedoRescueAllowed = $false
            $r.RedoRescueRequired = $false
            $r.WindowsUpdateRequired = $false
            $r.InfrastructureUpdateEligible = $false
            $r.ImageDecisionReason = 'MT21 OPS is intentionally remaining on Windows 10 for now. Inventory this device, do not RedoRescue or upgrade it to Windows 11, and keep it in the replacement/hardware-validation population.'
        } elseif ("$Manufacturer" -eq 'Boxlight' -and $opsClassNormalized -eq 'MT11') {
            $r.ImageStatus = 'Manual Review Required'
            $r.RemediationMethod = 'Do Not Upgrade - Replacement Pending'
            $r.RedoRescueAllowed = $false
            $r.RedoRescueRequired = $false
            $r.WindowsUpdateRequired = $false
            $r.InfrastructureUpdateEligible = $false
            $r.ImageDecisionReason = 'MT11 OPS is not approved for Windows 11 remediation. Inventory this device, do not RedoRescue or in-place upgrade it, and retain it for replacement follow-up.'
        } elseif ("$Manufacturer" -eq 'Boxlight' -and $opsClassNormalized -in @('OPS62','OPS72')) {
            $r.ImageStatus = 'Windows Upgrade Required'
            $r.RemediationMethod = 'Windows 11 In-Place Upgrade'
            $r.RedoRescueAllowed = $false
            $r.RedoRescueRequired = $false
            $r.WindowsUpdateRequired = $true
            $r.InfrastructureUpdateEligible = $true
            $r.ImageDecisionReason = "$osShort on Boxlight $opsClassNormalized - use the approved Windows 11 in-place upgrade. Do not RedoRescue."
        } elseif ("$Manufacturer" -eq 'Boxlight') {
            $r.ImageStatus = 'Manual Review Required'
            $r.RemediationMethod = 'Identify OPS Hardware / Validate Windows 11 Path'
            $r.RedoRescueAllowed = $false
            $r.RedoRescueRequired = $false
            $r.WindowsUpdateRequired = $false
            $r.InfrastructureUpdateEligible = $false
            $r.ImageDecisionReason = "$osShort on Boxlight, but OPS hardware class '$opsClassNormalized' is not an approved automatic remediation class. Inventory the device and escalate for hardware/path validation."
        } else {
            $r.ImageStatus = 'Windows Upgrade Required'
            $r.RemediationMethod = 'Windows 11 In-Place Upgrade'
            $r.WindowsUpdateRequired = $true
            $r.InfrastructureUpdateEligible = $true
            $r.ImageDecisionReason = "$osShort on $Manufacturer - route to the approved Windows 11 in-place upgrade. Do not reimage."
        }
    } elseif ($r.WindowsVersionStatus -eq 'Upgrade Required') {
        $r.ImageStatus = 'Windows Upgrade Required'
        $r.RemediationMethod = "In-Place Upgrade to Windows 11 $PrefVer"
        $r.WindowsUpdateRequired = $true
        $r.InfrastructureUpdateEligible = $true
        $r.ImageDecisionReason = "Windows 11 $DisplayVer is older than the minimum accepted version ($MinVer). Upgrade to $PrefVer - do not reimage."
    } elseif ($PendingRestart) {
        $r.ImageStatus = 'Pending Windows Update Restart'
        $r.RemediationMethod = 'Complete Pending Update Restart'
        $r.ImageDecisionReason = "Windows $DisplayVer is accepted, but a mandatory update restart is pending ($PendingReasons)."
    } elseif (-not $firmwareReadable) {
        $r.ImageStatus = 'Manual Review Required'; $r.RemediationMethod = 'Manual Review'
        $r.ImageDecisionReason = 'Firmware mode or partition style could not be read.'
    } elseif (-not $firmwareOK) {
        $r.ImageStatus = 'Firmware Configuration Required'
        $r.RemediationMethod = 'Correct BIOS / UEFI Configuration'
        $r.FirmwareConfigurationRequired = $true
        $r.ImageDecisionReason = "Windows $DisplayVer is accepted, but the OPS is not UEFI-only/GPT (firmware $FirmwareMode, partition $PartitionStyle). Correct BIOS - do not reimage."
    } else {
        # Accepted. NOTE: an unrecognized storage size does NOT block a healthy Windows 11 -
        # the profile only matters for picking a Boxlight RedoRescue image (defect #4).
        $r.ImageStatus = 'Accepted'
        $r.RemediationMethod = 'No Action Required'
        $r.ImageDecisionReason = "Windows 11 $DisplayVer meets the minimum accepted version ($MinVer); firmware is UEFI/GPT." +
            $(if (-not $prof) { " (Storage ${StorageGB}GB is outside the Boxlight 128/256GB profiles - not required for this manufacturer.)" } else { '' })
    }
    $r.OK     = ($r.ImageStatus -eq 'Accepted')
    $r.Reason = $r.ImageDecisionReason
    return $r
}
}
. $script:ImageDecisionDefs   # make the shared matrix available on the main thread
# v5.4: thin wrapper - gathers CURRENT device state and calls the SHARED image matrix
# (Get-ImageDecision). The background Summer assessment calls the same function, so the two
# stages can never disagree (review defect #5).
function Test-ApprovedImage {
    $build = 0; $displayVer = ''
    try {
        $cv = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -ErrorAction Stop
        $build = [int]$cv.CurrentBuild
        $displayVer = if ($cv.DisplayVersion) { $cv.DisplayVersion } else { $cv.ReleaseId }
    } catch {}
    $gb = 0; $partStyle = ''
    try { $sysLetter = $env:SystemDrive.TrimEnd(':'); $osDisk = Get-Partition -DriveLetter $sysLetter -ErrorAction Stop | Get-Disk -ErrorAction Stop }
    catch { $osDisk = Get-Disk -ErrorAction SilentlyContinue | Where-Object { $_.BusType -ne 'USB' } | Sort-Object Size -Descending | Select-Object -First 1 }
    if ($osDisk) { $gb = [math]::Round([double]$osDisk.Size / 1GB, 0); $partStyle = "$($osDisk.PartitionStyle)" }
    $fw = ''; try { $fw = "$((Get-ComputerInfo -Property BiosFirmwareType -ErrorAction Stop).BiosFirmwareType)" } catch {}
    $pending = Test-PendingRestart
    # v5.4.1 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§1.C: advisory-only signals are recorded, never passed in as PendingRestart = TRUE.
    if ($pending.AdvisoryDetected -and -not $pending.Pending) {
        Write-Log "Pending-restart advisory detected but provisioning was not blocked: $($pending.AdvisoryReasons)" 'WARN'
    }
    if ($pending.Pending) { Write-Log "Confirmed pending restart: $($pending.Reasons)" 'WARN' }
    return (Get-ImageDecision -Build $build -DisplayVer $displayVer -Manufacturer $script:Manufacturer -OPSClass (Get-CurrentOPSClass) `
        -PartitionStyle $partStyle -FirmwareMode $fw -StorageGB $gb `
        -Profiles $script:Config.ReimageProfiles `
        -MinVer $(if ($script:Config.MinimumAcceptedOSDisplayVersion) { "$($script:Config.MinimumAcceptedOSDisplayVersion)" } else { '24H2' }) `
        -PrefVer $(if ($script:Config.PreferredOSDisplayVersion) { "$($script:Config.PreferredOSDisplayVersion)" } else { '25H2' }) `
        -PendingRestart ([bool]$pending.Pending) -PendingReasons "$($pending.Reasons)")
}

# v5.3.3 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§1: PURE calculation - determine the provisioning route from device state WITHOUT
# rendering any window. Sets the routing $script vars + returns the resolved action/label so the
# final assessment screen can show ONLY the applicable action button (not a generic "Next").
function Get-ProvisioningRecommendation {
    Get-DomainMembership | Out-Null
    $img = Test-ApprovedImage
    $script:ApprovedImageOK     = $img.OK
    $script:ApprovedImageReason = $img.Reason
    # v5.4 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§2.G: persist the structured decision so every write carries it
    $script:WindowsVersionStatus   = $img.WindowsVersionStatus
    $script:ImageStatus            = $img.ImageStatus
    $script:ImageDecisionReason    = $img.ImageDecisionReason
    $script:RemediationMethod      = $img.RemediationMethod
    $script:ReimageReason          = $img.ReimageReason
    $script:ApprovedImageOSName    = $img.OSName
    $script:ApprovedImageMinimum   = $img.MinimumAcceptedVersion
    $script:ApprovedImagePreferred = $img.PreferredVersion
    $script:FirmwareConfigurationRequired = $img.FirmwareConfigurationRequired
    $script:WindowsUpdateRequired  = $img.WindowsUpdateRequired
    $script:PendingRestartDetected = $img.PendingRestartDetected
    $script:PendingRestartReasons  = "$($img.PendingRestartReasons)"
    $script:RedoRescueAllowed      = $img.RedoRescueAllowed
    $script:RedoRescueRequired     = $img.RedoRescueRequired
    $script:RecoveryRequired       = $img.RecoveryRequired
    $script:InfrastructureUpdateEligible = $img.InfrastructureUpdateEligible
    if ($img.Profile) { $script:SummerImageProfile   = $img.Profile }
    if ($img.Folder)  { $script:SummerExpectedFolder = $img.Folder }
    if ($img.Tier -gt 0) { $script:StorageGB = "$($img.Tier)" }

    # Fix #4: a failed domain read must NOT fall through to the not-joined workflow. Retry once.
    if ($script:DomainMembershipStatus -eq 'Unknown') { Get-DomainMembership | Out-Null }
    $domainJoined  = ($script:DomainMembershipStatus -eq 'Domain Joined')
    $domainUnknown = ($script:DomainMembershipStatus -eq 'Unknown')
    $secureFailed  = ($script:SecureChannelStatus -eq 'Failed')
    $dayOneIssue   = ($script:DayOneStatus -eq 'Issue Reported')
    $script:ProvRecIssueCategory = ''   # set for the domain-state cases so a report is pre-categorised

    # Determine recommended path + the action the primary button will take.
    # v5.4 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§2: Windows remediation (upgrade / pending restart / firmware) is evaluated BEFORE the
    # domain branch and NEVER routes to reimage. A version mismatch is an upgrade, not a wipe.
    $path = ''; $reason = ''; $action = ''
    if ($script:IdentityResolutionRequired) {
        # A missing Boxlight chassis serial is a valid physical observation, but it is not safe to
        # reimage/provision against a made-up identity. The visit is captured and routed to the
        # reconciliation queue until a lead resolves the canonical serial from NDMS/vendor records.
        $path = 'Manual Review Required'; $action = 'manual'
        $script:ProvRecIssueCategory = 'Panel Identity'
        $reason = "Panel serial sticker is missing or unreadable. Observation $($script:PanelObservationId) was captured with the available APS asset / NDMS identifiers. Resolve the canonical panel serial before remediation or provisioning."
    } elseif ($img.ImageStatus -eq 'Recovery Required') {
        # Boxlight on Windows 10 -> approved RedoRescue restore (a real recovery, not a version gap)
        $path = 'RedoRescue Required'; $action = 'redo'
        $reason = "$($img.ImageDecisionReason) Remediation: $($img.RemediationMethod)."
    } elseif ($img.ImageStatus -eq 'Windows Upgrade Required') {
        $path = 'Windows Upgrade Required'; $action = 'winupgrade'
        $reason = "$($img.ImageDecisionReason) Remediation: $($img.RemediationMethod)."
    } elseif ($img.ImageStatus -eq 'Pending Windows Update Restart') {
        $path = 'Pending Windows Update Restart'; $action = 'pendingrestart'
        $reason = $img.ImageDecisionReason
    } elseif ($img.ImageStatus -eq 'Firmware Configuration Required') {
        $path = 'Firmware Configuration Required'; $action = 'firmware'
        $reason = $img.ImageDecisionReason
    } elseif ($img.ImageStatus -eq 'Manual Review Required') {
        $path = 'Manual Review Required'; $action = 'manual'
        $script:ProvRecIssueCategory = 'Provisioning Path Conflict'   # app can't determine a safe path
        $reason = "$($img.ImageDecisionReason) Do not provision without lead review."
    } elseif ($domainUnknown) {
        # Fix #4: could not read domain state - do not classify or provision
        $path = 'Manual Review Required'; $action = 'manual'
        $script:ProvRecIssueCategory = 'Domain State Detection'
        $reason = 'PanelApp could not read the domain membership state for this device. Do not classify it as new or existing. Flag for manual review.'
    } elseif ($domainJoined) {
        if ($secureFailed) {
            # Fix #5: joined but broken trust is not a healthy finish
            $path = 'Manual Review Required'; $action = 'manual'
            $script:ProvRecIssueCategory = 'Domain State Detection'
            $reason = 'Device is domain joined but the secure-channel test FAILED. Do not finish the panel - the domain trust needs repair before it can be considered complete.'
        } else {
            $path = 'No Provisioning Needed'; $action = 'finish'
            $reason = "Device is domain joined and Windows is accepted ($($img.DisplayVer)). No provisioning needed."
        }
    } else {
        # Not domain joined (definitively) and Windows is ACCEPTED (every non-accepted image status
        # was already routed above) - the install type decides (ask if not yet confirmed).
        switch ($script:InstallType) {
            'New Replacement Install' {
                $path = 'Full Provisioning'; $action = 'fullprov'
                $reason = "New replacement panel is not domain joined and Windows $($img.DisplayVer) is accepted."
            }
            'Existing Panel' {
                # v5.4 (review issue #3): no RedoRescue recovery happened here - the image was
                # already accepted. Record it as Existing Panel Provisioning so the audit history
                # does not claim recovery work that never occurred.
                $path = 'Existing Panel Provisioning'; $action = 'existingprov'
                $reason = "Existing panel is not domain joined and Windows $($img.DisplayVer) is accepted - continue provisioning (no RedoRescue recovery required)."
            }
            'Unknown' {
                $path = 'Confirm Install Type'; $action = 'ask'
                $reason = 'PanelApp cannot confirm whether this is a new replacement panel. The device is not domain joined. Confirm the installation type before continuing.'
            }
            default {
                $path = 'Confirm Install Type'; $action = 'ask'
                $reason = 'The device is not domain joined. Confirm whether this is a new replacement panel so PanelApp can route it correctly.'
            }
        }
    }
    if ($dayOneIssue) {
        $readinessDetail = if ($script:ReadinessIssueCategory) { " ($($script:ReadinessIssueCategory))" } else { '' }
        $reason += " Panel Readiness exception$readinessDetail is recorded and remains open for follow-up; it does not block this required inventory/remediation/provisioning path."
    }
    $script:ProvisioningPathRecommended = $path
    $script:ProvisioningRecommendationReason = $reason
    $script:ProvRecAction = $action

    # The specific label shown on the FINAL assessment button + the recommendation button.
    $buttonLabel = switch ($action) {
        'fullprov'       { 'Continue to Full Provisioning' }
        'finish'         { 'Finish This Panel' }
        'redo'           { 'RedoRescue Required' }
        'winupgrade'     { 'Validate / Start Windows 11 Upgrade' }
        'pendingrestart' { 'Complete Pending Update Restart' }
        'firmware'       { 'Firmware Configuration Required' }
        'existingprov'   { 'Continue to Existing Panel Provisioning' }
        'manual'         { 'Manual Review Required' }
        'exception'      { 'Review Exception' }
        'ask'            { 'Next: Confirm Install Type' }
        default          { 'Continue' }
    }
    return @{ Path=$path; Action=$action; Reason=$reason; ButtonLabel=$buttonLabel
              ImageOK=$img.OK; ImageReason=$img.Reason; Image=$img }
}

# v5.3.2 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§13 + v5.3.3 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§1: render the recommendation screen showing ONLY the applicable action.
function Show-ProvRecommendation {
    $rec = Get-ProvisioningRecommendation
    $img = @{ OK = $rec.ImageOK; Reason = $rec.ImageReason }
    $path = $rec.Path; $action = $rec.Action; $reason = $rec.Reason

    # Render
    $script:UI['lblRec_Panel'].Text       = "$($script:SchoolName) - Room $($script:RoomNumber)   |   Panel $(if ($script:PanelSerial) { $script:PanelSerial } else { "SERIAL PENDING [$($script:PanelObservationId)]" })"
    $script:UI['lblRec_InstallType'].Text = if ($script:InstallType) { $script:InstallType } else { 'Not yet confirmed' }
    $script:UI['lblRec_Domain'].Text      = "$($script:DomainMembershipStatus)$(if ($script:DetectedDomain) { "  ($($script:DetectedDomain))" })"
    $script:UI['lblRec_Image'].Text       = "$($rec.Image.OSName) - $($rec.Image.ImageStatus) (min $($rec.Image.MinimumAcceptedVersion), preferred $($rec.Image.PreferredVersion))"
    $script:UI['lblRec_Path'].Text        = $path
    $script:UI['lblRec_Reason'].Text      = $reason

    # Colour the path border by outcome (remediation = amber, not red - it is not a failure)
    $pathBrush = switch ($action) {
        'fullprov' { '#4EC994' } 'finish' { '#4EC994' } 'existingprov' { '#4EC994' }
        'redo'     { '#F0B030' } 'ask'    { '#9FC8E8' }
        'winupgrade' { '#F0B030' } 'pendingrestart' { '#F0B030' } 'firmware' { '#F0B030' }
        default    { '#EF5B5B' }
    }
    $script:UI['lblRec_Path'].Foreground   = New-Brush $pathBrush
    $script:UI['borRec_Path'].BorderBrush  = New-Brush $pathBrush

    # Install-type question is shown only when we still need it
    if ($action -eq 'ask') {
        $script:UI['borInstallQ'].Visibility = 'Visible'
        $script:UI['lblInstallQHint'].Text = if ($script:InstallType -eq 'Unknown') {
            'Install type is still unconfirmed. PanelApp will not assume this is a new panel. Select Yes or No to continue.'
        } else {
            'The device is not domain joined. Confirm the installation type so PanelApp routes it correctly.'
        }
        $script:UI['btnProvRecAction'].Visibility = 'Collapsed'
    } else {
        $script:UI['borInstallQ'].Visibility = 'Collapsed'
        $script:UI['btnProvRecAction'].Visibility = 'Visible'
        $script:UI['btnProvRecAction'].Content = switch ($action) {
            'fullprov'       { 'Continue to Full Provisioning' }
            'finish'         { 'Finish This Panel' }
            'redo'           { 'Finish Assessment and Complete RedoRescue' }
            'winupgrade'     { 'Finish Assessment and Complete Windows Upgrade' }
            'pendingrestart' { 'Finish Assessment and Complete Update Restart' }
            'firmware'       { 'Finish Assessment and Correct BIOS/UEFI' }
            'existingprov'   { 'Continue to Existing Panel Provisioning' }
            'manual'         { 'Save Review Outcome and Close' }
            'exception'      { 'Save Issue Outcome and Close' }
            default          { 'Continue' }
        }
    }
    Show-Screen 'pnlProvRecommend'
}

# r8 finding #4: a state-critical event was PERMANENTLY rejected, so the spreadsheet never
# recorded this path. Stop before any physical work (rename / domain join) and tell the tech
# plainly. A QUEUED event is fine to continue on - later project work stays ordered behind it.
function Stop-OnRejectedProvisioningPath {
    param($Result, [string]$PathLabel)
    $code = if ($Result.Parsed) { "$($Result.Parsed.ErrorCode)" } else { 'REJECTED' }
    $msg  = if ($Result.Parsed) { "$($Result.Parsed.Message)" } else { 'The backend rejected this update.' }
    Write-Log "'$PathLabel' was rejected by the backend ($code) - not starting provisioning." 'ERROR'
    [System.Windows.MessageBox]::Show(
        "The spreadsheet REJECTED this panel's move to '$PathLabel', so the project was not updated.`n`n$code`n$msg`n`n" +
        "Do not rename or domain-join this device. Report this to a lead - the panel has not been changed.",
        'Provisioning Path Not Recorded', 'OK', 'Error') | Out-Null
    Show-Screen 'pnlModeSelect'
    Set-Status "Provisioning stopped - '$PathLabel' was not recorded."
}

# ONE place that stamps the structured v5.4 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§2.G image-decision fields onto an outgoing payload.
# Every route that writes a Summer row calls this, so no path can leave ImageStatus / remediation
# fields blank (review issue #1).
function Add-ImageDecisionFields {
    param([hashtable]$Data)
    $Data['WindowsVersionStatus']          = $script:WindowsVersionStatus
    $Data['ImageStatus']                   = $script:ImageStatus
    $Data['ImageDecisionReason']           = $script:ImageDecisionReason
    $Data['RemediationMethod']             = $script:RemediationMethod
    $Data['MinimumAcceptedVersion']        = $script:ApprovedImageMinimum
    $Data['PreferredVersion']              = $script:ApprovedImagePreferred
    $Data['ReimageReason']                 = $script:ReimageReason
    $Data['FirmwareConfigurationRequired'] = [bool]$script:FirmwareConfigurationRequired
    $Data['WindowsUpdateRequired']         = [bool]$script:WindowsUpdateRequired
    $Data['PendingRestartDetected']        = [bool]$script:PendingRestartDetected
    # Always written (even blank) so a completed restart CLEARS the stale reason text.
    $Data['PendingRestartReasons']         = "$($script:PendingRestartReasons)"
    $Data['RedoRescueAllowed']             = [bool]$script:RedoRescueAllowed
    $Data['RedoRescueRequired']            = [bool]$script:RedoRescueRequired
    $Data['RecoveryRequired']              = [bool]$script:RecoveryRequired
    $Data['InfrastructureUpdateEligible']  = [bool]$script:InfrastructureUpdateEligible
    return $Data
}

# The mirror of Add-ImageDecisionFields: reload the structured decision from a resumed sheet row so
# a resume/retry does not write blanks back over fields the assessment already established.
function Restore-ImageDecisionState {
    param($Rec)
    if ($null -eq $Rec) { return }
    $bool = { param($v) "$v" -match '^(?i)(true|yes|1)$' }
    if ("$($Rec.WindowsVersionStatus)")   { $script:WindowsVersionStatus   = "$($Rec.WindowsVersionStatus)" }
    if ("$($Rec.ImageStatus)")            { $script:ImageStatus            = "$($Rec.ImageStatus)" }
    if ("$($Rec.ImageDecisionReason)")    { $script:ImageDecisionReason    = "$($Rec.ImageDecisionReason)" }
    if ("$($Rec.RemediationMethod)")      { $script:RemediationMethod      = "$($Rec.RemediationMethod)" }
    if ("$($Rec.MinimumAcceptedVersion)") { $script:ApprovedImageMinimum   = "$($Rec.MinimumAcceptedVersion)" }
    if ("$($Rec.PreferredVersion)")       { $script:ApprovedImagePreferred = "$($Rec.PreferredVersion)" }
    $script:ReimageReason                 = "$($Rec.ReimageReason)"
    $script:FirmwareConfigurationRequired = & $bool $Rec.FirmwareConfigurationRequired
    $script:WindowsUpdateRequired         = & $bool $Rec.WindowsUpdateRequired
    $script:PendingRestartDetected        = & $bool $Rec.PendingRestartDetected
    $script:PendingRestartReasons         = "$($Rec.PendingRestartReasons)"
    $script:RedoRescueAllowed             = & $bool $Rec.RedoRescueAllowed
    $script:RedoRescueRequired            = & $bool $Rec.RedoRescueRequired
    $script:RecoveryRequired              = & $bool $Rec.RecoveryRequired
    $script:InfrastructureUpdateEligible  = & $bool $Rec.InfrastructureUpdateEligible
}

# TRUE only when this project genuinely required a Boxlight RedoRescue recovery. Existing panels
# that merely need provisioning/domain repair are NOT recovery work (review issue #2/#3), so they
# must not run the RedoRescue gate or be recorded as Post-RedoRescue.
# v5.4.1 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§2.A: classify a project as genuine recovery work, a legacy misclassification, or
# undecidable. Returns 'Recovery' | 'NotRecovery' | 'Unknown'.
#
# The v5.4 version accepted `ProvisioningPathSelected = Post-RedoRescue Provisioning` as proof.
# That text is NOT reliable: pre-v5.4 builds stamped it on healthy existing panels that only
# needed domain/provisioning repair, and the pre-v5.4 image rule (exact 25H2) marked healthy
# 24H2 panels as RedoRescue Required. Path text, RedoRescue wording in ProjectStatus, and
# ReimageNeeded = Yes are all products of the OLD policy and prove nothing on their own.
function Get-RecoveryProjectClass {
    param($Rec)
    if ($null -eq $Rec) {
        if ([bool]$script:RecoveryRequired -or [bool]$script:RedoRescueRequired -or
            "$($script:ImageStatus)" -eq 'Recovery Required') { return 'Recovery' }
        return 'NotRecovery'
    }
    $isTrue = { param($v) "$v" -match '^(?i)\s*(true|yes|1)\s*$' }

    # --- ORIGINAL device facts from the assessment (the only evidence the old policy could not
    #     fabricate). Everything below is judged against these. ---
    $build   = 0; [void][int]::TryParse("$($Rec.OSBuild)", [ref]$build)
    $osName  = "$($Rec.OSName)"
    $wasWin10 = ($build -gt 0 -and $build -lt 22000) -or
                ($build -le 0 -and $osName -match '(?i)windows\s*10')
    $wasWin11 = ($build -ge 22000) -or ($build -le 0 -and $osName -match '(?i)windows\s*11')
    $isBoxlight = ("$($Rec.Manufacturer)" -eq 'Boxlight')
    $gb = 0.0; [void][double]::TryParse("$($Rec.StorageActualGB)", [ref]$gb)
    $tier = 0; [void][int]::TryParse("$($Rec.StorageTierGB)", [ref]$tier)
    $inProfile = $false
    if ($tier -eq 128 -or $tier -eq 256) { $inProfile = $true }
    elseif ($gb -gt 0) {
        foreach ($p in $script:Config.ReimageProfiles) {
            if ($gb -ge [int]$p.MinGB -and $gb -le [int]$p.MaxGB) { $inProfile = $true; break }
        }
    }
    # The ONLY device shape RedoRescue recovery is valid for. Note the storage profile is
    # required: the approved matrix sends a Boxlight Win10 with unsupported storage to Manual
    # Review, because the correct recovery image cannot be chosen.
    $recoverableDevice = ($isBoxlight -and $wasWin10 -and $inProfile)

    $restoreCompleted = (& $isTrue $Rec.RedoRescueRestoreCompleted)
    $recoveryClaim = $restoreCompleted -or
                     (& $isTrue $Rec.RedoRescueRequired) -or (& $isTrue $Rec.RecoveryRequired) -or
                     "$($Rec.ImageStatus)" -eq 'Recovery Required'

    # 1. A completed restore counts ONLY when the original project could genuinely have needed
    #    one. Start-RedoRescueGate stamps RedoRescueRestoreCompleted='Yes' whenever its checks
    #    pass (OS/version/storage/partition/firmware) - it never proves a restore actually ran.
    #    Under the pre-v5.4.1 routing a healthy Windows 11 panel could be sent to the gate, pass,
    #    and be stamped, so this flag alone is not proof.
    if ($restoreCompleted -and $recoverableDevice) { return 'Recovery' }

    # 2. The ORIGINAL OS was already Windows 11 -> this was never recovery work. This outranks
    #    every structured flag on purpose: a v5.4 development build could have stamped
    #    RecoveryRequired / RedoRescueRequired / ImageStatus='Recovery Required' (and, via the
    #    gate, RedoRescueRestoreCompleted) on a healthy 24H2 panel under the old exact-25H2 rule.
    if ($wasWin11) { return 'NotRecovery' }

    # 3. Any other recovery claim is trusted only on a genuinely recoverable device.
    if ($recoveryClaim) {
        if ($recoverableDevice) { return 'Recovery' }
        # The claim contradicts the device facts (non-Boxlight, not originally Windows 10, or
        # storage outside the approved profiles). A human decides - never assert RedoRescue.
        return 'Unknown'
    }

    # 4. A v5.4+ row that recorded a NON-recovery ImageStatus is trustworthy - believe it.
    if ("$($Rec.ImageStatus)") { return 'NotRecovery' }

    # 5. LEGACY row (no structured fields at all) - decide from the device facts.
    if ($recoverableDevice)              { return 'Recovery' }
    # Windows 10 on a non-Boxlight was always an in-place upgrade, never RedoRescue.
    if ($wasWin10 -and -not $isBoxlight) { return 'NotRecovery' }

    # 6. Not enough information to tell recovery from misclassification.
    return 'Unknown'
}
# Boolean wrapper for the one caller that only needs to LABEL a run (closeout wording), not route
# it. Only a confirmed 'Recovery' counts: calling an unclassifiable project "Post-RedoRescue" in
# the audit record is precisely the inaccuracy this hotfix removes. Every ROUTING decision uses
# Get-RecoveryProjectClass directly so 'Unknown' can go to Manual Review.
function Test-RecoveryProject {
    param($Rec)
    return ((Get-RecoveryProjectClass $Rec) -eq 'Recovery')
}

# Post the recommendation decision (common fields + lifecycle) BEFORE leaving the screen, so the
# Summer row always reflects the recommended path - not the assessment's earlier status (fix #1).
function Post-RecommendationDecision {
    param([string]$ProjectStatus, [string]$PathSelected)
    $now = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
    $script:ProvisioningPathSelected = $PathSelected
    $recRes = Post-MainLog (Add-ImageDecisionFields @{
        LogSheet='Summer2026'; ProjectRunId=$script:ProjectRunId
        ProjectStatus=$ProjectStatus
        InstallType=$script:InstallType
        RoomType=$script:RoomType; OtherRoomType=$script:OtherRoomType
        DomainMembershipStatus=$script:DomainMembershipStatus; DetectedDomain=$script:DetectedDomain
        SecureChannelStatus=$script:SecureChannelStatus; DomainCheckAt=$script:DomainCheckAt
        ProvisioningPathRecommended=$script:ProvisioningPathRecommended
        ProvisioningPathSelected=$PathSelected
        ProvisioningRecommendationReason=$script:ProvisioningRecommendationReason
        ExceptionStatus=$(if ($script:DayOneStatus -eq 'Issue Reported' -or $script:SummerOriginalDayOne -eq 'Issue Reported') { 'Open' } else { '' })
        NewInstallConfirmedBy=$script:NewInstallConfirmedBy; NewInstallConfirmedAt=$script:NewInstallConfirmedAt
        LastUpdatedBy=$script:TechName; LastUpdatedAt=$now
    }) 'RecommendationUpdated'
    Write-Log "Recommendation recorded: $ProjectStatus / $PathSelected"
    return $recRes
}

# Fix #2: an EXISTING panel found on the approved image but not domain joined continues its
# CURRENT project (no new lookup).
function Continue-ToExistingPanelProvisioning {
    # v5.4 (review defect #3): this device ALREADY passed the shared image matrix as Accepted
    # (Windows 11 >= minimum, UEFI/GPT). It only needs provisioning/domain repair, so it must NOT
    # be sent through the strict RedoRescue gate - that gate exists to prove a Boxlight RedoRescue
    # restore happened and would wrongly block a healthy 24H2 panel.
    # v5.4 (review issue #3): and it must NOT be recorded as Post-RedoRescue work either - that
    # label is reserved for projects where RecoveryRequired was actually true.
    $now = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
    $script:InstallType             = 'Existing Panel'
    $script:RelatedSummerRunId      = $script:ProjectRunId
    $script:ProvPath                = 'Standard'
    $script:NewInstallProvisioning  = $false
    $script:RecoveryProvisioning    = $false
    $script:ProvisioningPathSelected = 'Existing Panel Provisioning'
    $script:ProvisioningPathRecommended = 'Existing Panel Provisioning'
    $script:ProvisioningTech        = $script:TechName
    Set-Mode 1 'Existing Panel Provisioning'
    $provRes = Post-MainLog (Add-ImageDecisionFields @{
        LogSheet='Summer2026'; ProjectRunId=$script:ProjectRunId
        ProjectStatus='Provisioning In Progress'
        ProvisioningStatus='Existing Panel - Pending Full Provisioning'
        CurrentStage='Provisioning'; InstallType='Existing Panel'
        RoomType=$script:RoomType; OtherRoomType=$script:OtherRoomType
        DomainMembershipStatus=$script:DomainMembershipStatus; DetectedDomain=$script:DetectedDomain
        SecureChannelStatus=$script:SecureChannelStatus; DomainCheckAt=$script:DomainCheckAt
        ProvisioningPathRecommended='Existing Panel Provisioning'
        ProvisioningPathSelected='Existing Panel Provisioning'
        ProvisioningRecommendationReason=$script:ProvisioningRecommendationReason
        ProvisioningTech=$script:TechName; ExpectedImageFolder=$script:SummerExpectedFolder
        LastUpdatedBy=$script:TechName; LastUpdatedAt=$now
    }) 'ExistingPanelProvisioningSelected'
    Write-Log "Existing panel on an accepted image -> Existing Panel Provisioning on ProjectRunId $($script:ProjectRunId) (no RedoRescue recovery involved)."
    # r8 finding #4: a PERMANENT rejection means the project never entered this path in
    # the spreadsheet - do NOT send the technician on to rename and domain join.
    if ($provRes -and $provRes.Rejected) { Stop-OnRejectedProvisioningPath $provRes 'Existing Panel Provisioning'; return }
    Show-HostnameScreen
}

# Fix #7: clear all device/project-specific state between panels (never the tech name or config).
function Reset-PanelWorkflowState {
    $script:FinishedAssessmentResult = $null; $script:FinishedAssessmentProject = ''
    $script:PanelSerial = ''; $script:OPSSerial = ''; $script:OldOPSSerial = ''
    $script:PanelSerialStickerStatus = ''; $script:PanelSerialSource = ''; $script:PanelSerialVerificationStatus = ''
    $script:PanelObservationId = ''; $script:IdentityResolutionRequired = $false; $script:PanelIdentityResolutionStatus = ''
    $script:IIQAssetTag = ''; $script:NDMSName = ''; $script:NDMSDeviceId = ''; $script:NDMSTags = ''
    $script:Hostname = ''; $script:M3OldOPSDisposition = ''; $script:M5HostnameCorrect = $true
    $script:RMAAction = ''; $script:RMAPreviousPanelSerial = ''; $script:RMAReassignmentConfirmed = $false; $script:RMAInventoryLookup = $null
    $script:InventoryReassignmentConfirmed = $false; $script:InventoryReassignmentType = ''; $script:InventoryReassignmentReason = ''
    $script:InventoryPreviousPanelSerial = ''; $script:TemporaryAssignment = $false; $script:FollowUpRequired = $false
    $script:TestingObservationOnly = $false; $script:InventoryReassignmentLookup = $null
    $script:ProvPath = ''; $script:NetworkType = ''
    $script:ProjectRunId = ''; $script:RelatedSummerRunId = ''
    $script:DayOneStatus = ''; $script:ReadinessIssueCategory = ''; $script:ReadinessIssueNote = ''
    $script:SchoolCode = ''; $script:SchoolName = ''; $script:RoomNumber = ''
    $script:Manufacturer = ''; $script:MfrCode = ''; $script:PanelModel = ''; $script:MountType = ''; $script:StorageGB = ''
    $script:RoomType = ''; $script:OtherRoomType = ''
    $script:InvEditing = $false; $script:InvLookupType = ''; $script:InvLookupValue = ''
    $script:InvLookupResult = $null; $script:InvBeforeSnapshot = $null
    $script:InstallType = ''; $script:DomainMembershipStatus = ''; $script:DetectedDomain = ''
    $script:SecureChannelStatus = ''; $script:DomainCheckAt = ''
    $script:ProvisioningPathRecommended = ''; $script:ProvisioningPathSelected = ''; $script:ProvisioningRecommendationReason = ''
    $script:NewInstallProvisioning = $false; $script:NewInstallConfirmedBy = ''; $script:NewInstallConfirmedAt = ''
    $script:RecoveryProvisioning = $false
    # v5.5 finding #5: the revision belongs to the PREVIOUS panel's project. Carrying it into
    # the next panel produced false STALE_PROJECT_REVISION rejections.
    $script:ProjectStateRevision = ''; $script:ProjectStateRevisionFor = ''
    # ...and the LIVE sync handle must go too. Get-MainSenderContext merges it
    # unconditionally, so a stale handle would re-import the PREVIOUS panel's revision right
    # after this reset - reintroducing the cross-project bug the scoping work removed.
    $script:ActiveSenderSync = $null
    $script:ApprovedImageOK = $false; $script:ApprovedImageReason = ''; $script:ProvRecAction = ''; $script:ProvRecIssueCategory = ''
    # v5.4 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§2.G structured image decision - cleared between panels so nothing carries over
    $script:WindowsVersionStatus = ''; $script:ImageStatus = ''; $script:ImageDecisionReason = ''
    $script:RemediationMethod = ''; $script:ReimageReason = ''; $script:ApprovedImageOSName = ''
    $script:FirmwareConfigurationRequired = $false; $script:WindowsUpdateRequired = $false
    $script:PendingRestartDetected = $false; $script:PendingRestartReasons = ''
    $script:RedoRescueAllowed = $false; $script:RedoRescueRequired = $false
    $script:RecoveryRequired = $false; $script:InfrastructureUpdateEligible = $false
    $script:SummerContinuation = $false; $script:SummerRecord = $null; $script:SummerMatches = @()
    $script:SummerImageProfile = ''; $script:SummerRedoFile = ''; $script:SummerExpectedFolder = ''
    $script:OPSReplacementConfirmed = ''
    $script:PreviousHostname = ''; $script:PreviousHostnameSource = ''
    $script:OldHostnameCheckResult = ''; $script:NewHostnameCheckResult = ''; $script:SelectedHostnameSuffix = ''
    $script:HostnameCheckStatus = 'NotChecked'; $script:PrefilledOldHostname = ''
    # Clear remaining per-panel values so nothing stale follows the next device
    $script:SummerOriginalOPS = ''; $script:SummerOriginalDayOne = ''
    $script:CloseoutIssueReported = $false
    $script:AndroidEthernetExceptionReported = $false; $script:AndroidEthernetExceptionEventId = ''
    $script:EndpointRepairAction = ''; $script:EndpointRepairStage = ''; $script:EndpointRepairOriginalHostname = ''; $script:EndpointRepairExpectedHostname = ''; $script:EndpointRepairDomainState = ''
    $script:ReviewNotes = ''; $script:OPSTruncationNote = ''
    # v5.5.1b ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§1: every field v5.5.1 added is PER PANEL. Leaving them set let the next device
    # inherit the previous one's identity - Start-SummerCapture only fills AssessmentHostname
    # when it is blank, so panel B would have kept panel A's DESKTOP-* name, and the closeout
    # would have reported panel A's join result.
    $script:RawRoomEntry                = ''
    $script:AssessmentHostname          = ''
    $script:DomainJoinTargetDomain      = ''
    $script:DomainJoinCompletedAt       = ''
    $script:PostJoinMembershipStatus    = ''
    $script:PostJoinSecureChannelStatus = ''
    $script:AssessmentType              = 'Initial Assessment'
    $script:ReassessmentReason          = ''
    $script:PreviousProjectRunId        = ''
    Write-Log 'Panel workflow state reset for the next device.'
}
# Fix #1: record the recommended TERMINAL outcome to the Summer row (finish/redo/manual/exception).
# Called by both the main action button and Capture Another, so neither can skip the write-back.
function Save-RecommendationOutcome {
    # r10 finding #1: post FIRST, and show nothing until the result is known. The old order posted
    # the outcome and then immediately displayed the remediation instructions, so a rejected
    # 'RedoRescue Required' still told the technician to restore the device - the exact failure the
    # rejection was meant to prevent - and only afterwards said "not recorded". Every branch now
    # returns the rejection before any MessageBox, exception, or other side effect.
    $outcomeRes = $null
    switch ($script:ProvRecAction) {
        'redo' {
            $outcomeRes = Post-RecommendationDecision 'Pending RedoRescue Restore' 'RedoRescue Required'
            if ($outcomeRes -and $outcomeRes.Rejected) { return $outcomeRes }
            $folder = if ($script:SummerExpectedFolder) { $script:SummerExpectedFolder } else { '(see storage profile)' }
            [System.Windows.MessageBox]::Show(
                "This device needs a RedoRescue restore before provisioning.`n`nExpected image folder:`n$folder`n`nAfter the restore, re-run PanelApp and select Full Provisioning -> Interactive Inventory Project - Post-RedoRescue Provisioning. The same Interactive Inventory project will continue.",
                'RedoRescue Required', 'OK', 'Information') | Out-Null
        }
        'manual' {
            $outcomeRes = Post-RecommendationDecision 'Manual Review Required' 'Manual Review Required'
            # The exception is a SECONDARY write that belongs to an outcome the sheet accepted.
            # Raising it against a rejected recommendation leaves an orphaned exception behind.
            if ($outcomeRes -and $outcomeRes.Rejected) { return $outcomeRes }
            if ($script:ProvRecIssueCategory) {
                # r11: the Manual Review outcome is already recorded - a refused SUPPORTING detail is
                # a warning, never a reason to retry or undo the accepted recommendation.
                $exDetail = Send-ExceptionEvent -Category $script:ProvRecIssueCategory `
                                                -Note $script:ProvisioningRecommendationReason `
                                                -Phase 'Provisioning Recommendation'
                if ($exDetail -and $exDetail.Rejected) {
                    $exWhy = if ($exDetail.Parsed) { "$($exDetail.Parsed.ErrorCode): $($exDetail.Parsed.Message)" } else { 'permanent rejection' }
                    Write-Log "Manual Review recorded, but its supporting exception was rejected ($exWhy)." 'WARN'
                    [System.Windows.MessageBox]::Show(
                        "Manual Review was recorded, but the supporting exception detail was not accepted.`n`n$exWhy`n`n" +
                        "The panel IS marked Manual Review Required. Tell your lead the issue detail is missing so they can add it.",
                        'Manual Review Recorded - Detail Missing', 'OK', 'Warning') | Out-Null
                }
            }
        }
        'finish' {
            if (-not $script:ProjectRunId) { throw 'Cannot finish an assessment without its project ID.' }
            if ($script:FinishedAssessmentResult -and $script:FinishedAssessmentProject -eq $script:ProjectRunId) {
                return $script:FinishedAssessmentResult
            }
            $script:IsNetworkAvailable = Test-Network
            if ($script:IsNetworkAvailable) { Flush-OfflineQueue }
            $outcomeRes = Post-RecommendationDecision 'Assessment Complete - No Reimage Needed' 'No Provisioning Needed'
            if ($outcomeRes -and ($outcomeRes.Delivered -or $outcomeRes.Queued)) {
                $script:FinishedAssessmentProject = $script:ProjectRunId
                $script:FinishedAssessmentResult = $outcomeRes
            }
        }
        'winupgrade' {
            # v5.7: automate the approved in-place path. Compatibility is scanned first; MT21/MT11
            # never reach this action under the OPS-family matrix and the automation re-checks eligibility.
            $outcomeRes = Post-RecommendationDecision 'Windows Upgrade Required' 'Windows 11 In-Place Upgrade'
            if ($outcomeRes -and $outcomeRes.Rejected) { return $outcomeRes }
            Start-Windows11UpgradeCompatibilityScan
        }
        'pendingrestart' {
            $outcomeRes = Post-RecommendationDecision 'Pending Windows Update Restart' 'Complete Pending Update Restart'
            if ($outcomeRes -and $outcomeRes.Rejected) { return $outcomeRes }
            [System.Windows.MessageBox]::Show(
                "PENDING WINDOWS UPDATE RESTART`n`nWindows is accepted, but a mandatory update restart is pending.`n`n1. Complete the required update restart.`n2. Allow Windows to finish servicing.`n3. Relaunch PanelApp.`n4. Resume the same Interactive Inventory project.`n`nDo not start provisioning while an update restart is pending.",
                'Pending Windows Update Restart', 'OK', 'Information') | Out-Null
        }
        'firmware' {
            $outcomeRes = Post-RecommendationDecision 'Firmware Configuration Required' 'Correct BIOS / UEFI Configuration'
            if ($outcomeRes -and $outcomeRes.Rejected) { return $outcomeRes }
            [System.Windows.MessageBox]::Show(
                "FIRMWARE CONFIGURATION REQUIRED`n`nThe Windows installation meets the minimum version requirement, but the OPS is not configured for UEFI-only operation.`n`n1. Enter BIOS.`n2. Disable CSM or Legacy mode.`n3. Set boot mode to UEFI-only.`n4. Save the BIOS configuration.`n5. Reboot the OPS.`n6. Relaunch PanelApp.`n7. Resume the same Interactive Inventory project.`n8. Re-run validation.`n`nDo not create a new ProjectRunId. Do not reimage for a firmware setting.",
                'Firmware Configuration Required', 'OK', 'Information') | Out-Null
        }
        'exception' {
            # Fix #3: keep the lifecycle Exception Open but record the recommendation audit fields
            # (do NOT create another exception - the Day One issue already did).
            $outcomeRes = Post-RecommendationDecision 'Exception Open' 'Exception Open'
        }
        default { }
    }
    return $outcomeRes
}

# r9 finding #3: a remediation instruction the backend REJECTED must not be presented as
# recorded, and the workflow must not reset - the panel still needs handling.
function Stop-OnRejectedOutcome {
    param($Result, [string]$What)
    if (-not $Result -or -not $Result.Rejected) { return $false }
    $code = if ($Result.Parsed) { "$($Result.Parsed.ErrorCode)" } else { 'REJECTED' }
    $msg  = if ($Result.Parsed) { "$($Result.Parsed.Message)" } else { 'The backend rejected this update.' }
    Write-Log "Recommendation outcome '$What' was rejected ($code) - not resetting the workflow." 'ERROR'
    [System.Windows.MessageBox]::Show(
        "The spreadsheet REJECTED this outcome, so '$What' was NOT recorded for this panel.`n`n$code`n$msg`n`n" +
        "Do not act on the instruction yet and do not move to the next panel. Report this to a lead.",
        'Outcome Not Recorded', 'OK', 'Error') | Out-Null
    return $true
}
# v5.3.3 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§1: execute the recommended action. Called by BOTH the final assessment button and the
# recommendation screen button, so the specific action runs directly (no generic "Next").

function Confirm-ProjectSessionExit {
    param([string]$Message, [string]$Title, [bool]$Pending)
    $icon = if ($Pending) { 'Warning' } else { 'Information' }
    [System.Windows.MessageBox]::Show($Message, $Title, 'OK', $icon) | Out-Null
}

function Show-AssessmentCompletion {
    param($Result, [string]$Action = 'finish')
    if (-not $Result -or $Result.Rejected -or (-not $Result.Delivered -and -not $Result.Queued)) {
        throw 'The project outcome was not confirmed or saved. Keep this project open and contact a lead.'
    }
    $summary = switch ($Action) {
        'finish' { 'This panel has completed the Interactive Inventory and Upgrade Project assessment. No provisioning is required.' }
        'redo' { 'RedoRescue is required. Complete the approved restore, then relaunch PanelApp to continue this project.' }
        'pendingrestart' { 'Complete the required Windows Update restart, then relaunch PanelApp to continue this project.' }
        'firmware' { 'Correct the BIOS/UEFI settings, then relaunch PanelApp to continue this project.' }
        'manual' { 'This panel requires lead review. The project remains open for follow-up.' }
        'exception' { 'An issue requires follow-up. The project remains Exception Open.' }
        default { 'The project outcome has been recorded.' }
    }
    if ($script:DayOneStatus -eq 'Issue Reported' -or $script:SummerOriginalDayOne -eq 'Issue Reported') {
        $summary += ' The Panel Readiness exception remains open for follow-up.'
    }
    $title = if ($Result.Queued) { 'Project Outcome Pending Sync' } elseif ($Action -eq 'finish') { 'Panel Assessment Complete' } else { 'Project Follow-up Required' }
    if ($Result.Queued -and $Action -eq 'finish') { $summary = 'Device checks indicate no provisioning is required. Assessment completion is awaiting backend confirmation.' }
    $message = if ($Result.Queued) {
        "The outcome is saved locally; the backend has not confirmed it. Keep the saved queue and reopen PanelApp with the same technician media to synchronize. Do not repeat the assessment or erase unsynchronized local data.`n`nReason: $($Result.Reason)`nSaved at: $($Result.QueuePath)`n`nRequired next step after synchronization:`n$summary"
    } else { $summary }
    $message += "`n`nProject: $($script:ProjectRunId)`nSchool/room: $($script:SchoolCode) $($script:RoomNumber)`nPanel: $($script:PanelSerial)`n`nPress OK to close PanelApp."
    Confirm-ProjectSessionExit -Message $message -Title $title -Pending ([bool]$Result.Queued)
    $script:window.Close()
}

function Invoke-RecommendationAction {
    if ($script:RecommendationActionInProgress) { return }
    $script:RecommendationActionInProgress = $true
    $controls = @{}
    try {
        foreach ($name in @('btnSummerNext','btnProvRecAction','btnProvRecReport','btnSummerReportIssue')) {
            $control = $script:UI[$name]
            if ($control) {
                $controls[$name] = @{Enabled=$control.IsEnabled;Content=$control.Content}
                $control.IsEnabled = $false
                if ($name -in @('btnSummerNext','btnProvRecAction')) { $control.Content = 'Saving - please wait...' }
            }
        }
        Set-Status 'Processing this panel. Please wait...'
        if ($script:window) { $script:window.Dispatcher.Invoke([action]{}, [System.Windows.Threading.DispatcherPriority]::Render) }
        if (-not $script:ProvRecAction) { Get-ProvisioningRecommendation | Out-Null }
        Invoke-RecommendationActionCore
    } finally {
        foreach ($name in $controls.Keys) {
            $script:UI[$name].IsEnabled = $controls[$name].Enabled
            $script:UI[$name].Content = $controls[$name].Content
        }
        $script:RecommendationActionInProgress = $false
    }
}

function Invoke-RecommendationActionCore {
    switch ($script:ProvRecAction) {
        'ask'      { Show-ProvRecommendation }        # not domain joined + unconfirmed -> ask install type
        'fullprov'     { Continue-ToFullProvisioning }
        'existingprov' { Continue-ToExistingPanelProvisioning }
        'finish' {
            $oRes = Save-RecommendationOutcome
            if (Stop-OnRejectedOutcome $oRes 'No Provisioning Needed') { return }
            Show-AssessmentCompletion $oRes
        }
        'winupgrade' {
            # The scan owns the progress screen and next upgrade action; keep it open.
            $oRes = Save-RecommendationOutcome
            if (Stop-OnRejectedOutcome $oRes 'Windows Upgrade Required') { return }
        }
        default {
            $act = $script:ProvRecAction
            $oRes = Save-RecommendationOutcome
            if (Stop-OnRejectedOutcome $oRes $act) { return }
            Show-AssessmentCompletion -Result $oRes -Action $act
        }
    }
}

# v5.3.2 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§7: route a confirmed new replacement panel straight into Full Provisioning, reusing the
# same Summer ProjectRunId and every value already entered - no rescan, no new project.
function Continue-ToFullProvisioning {
    $now = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
    $script:InstallType             = 'New Replacement Install'
    $script:NewInstallConfirmedBy   = $script:TechName
    $script:NewInstallConfirmedAt   = $now
    $script:NewInstallProvisioning  = $true
    $script:RecoveryProvisioning    = $false
    $script:ProvPath                = 'Standard'
    $script:SummerContinuation      = $false           # Interactive Inventory-LINKED, but not a RedoRescue continuation
    $script:RelatedSummerRunId      = $script:ProjectRunId   # keep the SAME project through provisioning
    $script:ProvisioningPathSelected = 'Full Provisioning'
    $script:ProvisioningTech        = $script:TechName
    Set-Mode 1 'Full Provisioning'
    Write-Log "New replacement panel confirmed -> Full Provisioning on ProjectRunId $($script:ProjectRunId)."
    $provRes = Post-MainLog (Add-ImageDecisionFields @{
        LogSheet='Summer2026'; ProjectRunId=$script:ProjectRunId
        ProjectStatus='Provisioning In Progress'; ProvisioningStatus='New Install - Pending Full Provisioning'
        CurrentStage='Provisioning'; InstallType='New Replacement Install'
        RoomType=$script:RoomType; OtherRoomType=$script:OtherRoomType
        DomainMembershipStatus=$script:DomainMembershipStatus; DetectedDomain=$script:DetectedDomain
        SecureChannelStatus=$script:SecureChannelStatus; DomainCheckAt=$script:DomainCheckAt
        ProvisioningPathRecommended='Full Provisioning'; ProvisioningPathSelected='Full Provisioning'
        ProvisioningRecommendationReason=$script:ProvisioningRecommendationReason
        NewInstallConfirmedBy=$script:TechName; NewInstallConfirmedAt=$now
        ProvisioningTech=$script:TechName; ExpectedImageFolder=$script:SummerExpectedFolder
        LastUpdatedBy=$script:TechName; LastUpdatedAt=$now
    }) 'FullProvisioningSelected'
    # r8 finding #4: a PERMANENT rejection means the project never entered this path in
    # the spreadsheet - do NOT send the technician on to rename and domain join.
    if ($provRes -and $provRes.Rejected) { Stop-OnRejectedProvisioningPath $provRes 'Full Provisioning'; return }
    Show-HostnameScreen
}

# ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§3: when the generated hostname conflicts, offer safe alternates instead of stopping the tech.
# Suffix order: X -> Y -> Z, then X2/X3 if the base is short enough. Every candidate is
# NetBIOS-validated, and checked in DNS/AD when the checker works.
function Get-AlternateHostname {
    param([string]$Hostname)
    $base = $Hostname -replace '(X\d?|XX|Y|Z)$',''   # strip an existing temporary suffix
    foreach ($suffix in @('X','Y','Z','X2','X3')) {
        $cand = "$base$suffix"
        $v = Test-Hostname -Hostname $cand
        if (-not $v.Valid) { continue }
        if ($cand -eq $Hostname) { continue }        # skip the one that already conflicted
        $msg = Test-HostnameAvailability -Hostname $cand
        if ($msg -notlike 'Warning*') { return @{ Hostname = $cand; CheckResult = $msg } }
    }
    return $null   # nothing safe available -> escalation is appropriate
}

# Build + populate the hostname screen. Extracted so the v5.3.2 new-install routing can jump
# straight here (reusing the already-entered school/room/mfr) without re-scanning.
function Show-HostnameScreen {
    $hn = Build-Hostname -SchoolCode $script:SchoolCode -MfrCode $script:MfrCode `
                         -MountType $script:MountType -Room $script:RoomNumber `
                         -PanelSerial $script:PanelSerial
    $script:UI['txtHostname'].Text = $hn
    # ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§4: current Windows hostname is reference only (often DESKTOP-xxxx after RedoRescue/new install)
    $script:UI['lblCurrentHostname'].Text = $env:COMPUTERNAME
    $script:UI['borAltHostname'].Visibility = 'Collapsed'
    $script:UI['lblHostnameCheck'].Visibility = 'Collapsed'
    $script:HostnameCheckStatus = 'NotChecked'
    $summerOld = ''
    if ($script:SummerContinuation -and $script:SummerRecord -and $script:SummerRecord.Hostname) {
        $cand = "$($script:SummerRecord.Hostname)".ToUpper()
        if ($cand -and $cand -notlike 'DESKTOP-*') { $summerOld = $cand }   # ignore temp names
    }
    if ($script:InstallType -eq 'New Replacement Install') {
        # v5.3.2 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§10: a brand-new panel has no previous hostname to check
        $script:UI['lblOldHostnameLabel'].Text = 'PREVIOUS / OLD HOSTNAME  (new install - not applicable)'
        $script:UI['txtOldHostname'].Text = ''
        $script:PrefilledOldHostname = ''
        $script:PreviousHostnameSource = 'New Replacement Install - No Previous Hostname'
        $script:UI['lblOldHostnameHint'].Text = 'This is a new replacement panel, so there is no previous hostname to check. Leave this blank.'
    } elseif ($summerOld) {
        $script:UI['lblOldHostnameLabel'].Text = 'PREVIOUS HOSTNAME  (from Interactive Inventory Project record)'
        $script:UI['txtOldHostname'].Text = $summerOld
        $script:PrefilledOldHostname = $summerOld
        $script:PreviousHostnameSource = 'Summer2026 Record'
        $script:UI['lblOldHostnameHint'].Text = 'Captured during the Interactive Inventory assessment. Edit if you know it is different.'
    } elseif ($script:MountType -eq 'Mobile') {
        # ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§7: never assume old mobile names from the new MB+last4 convention
        $script:UI['lblOldHostnameLabel'].Text = 'PREVIOUS / OLD HOSTNAME  (optional)'
        $script:UI['txtOldHostname'].Text = ''
        $script:PrefilledOldHostname = ''
        $script:PreviousHostnameSource = 'Unknown'
        $script:UI['lblOldHostnameHint'].Text = 'Older mobile/cart panels may have been named MOBILE1, MOBILE2, etc. If you know the old hostname, enter it. Otherwise leave it blank. PanelApp generates the new mobile/cart hostname using MB plus the last four characters of the panel serial.'
    } else {
        # ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§8: wall-mounted old names are predictable enough to assume (labeled as assumed)
        $assumed = "$($script:SchoolCode)I9$($script:MfrCode)$($script:RoomNumber)".ToUpper() -replace '[^A-Z0-9\-]',''
        $script:UI['lblOldHostnameLabel'].Text = 'ASSUMED PREVIOUS HOSTNAME  (not guaranteed - edit or clear)'
        $script:UI['txtOldHostname'].Text = $assumed
        $script:PrefilledOldHostname = $assumed
        $script:PreviousHostnameSource = 'Assumed Wall Hostname'
        $script:UI['lblOldHostnameHint'].Text = 'Assumed from school/manufacturer/room using the old wall-mount pattern. Not guaranteed. Old hostname is optional - it is only used to check for stale AD/DNS records.'
    }
    Show-Screen 'pnlHostname'
}
function Test-Hostname {
    param([string]$Hostname)
    $r = @{ Valid = $true; Message = '' }
    if     ($Hostname.Length -eq 0)       { $r.Valid = $false; $r.Message = 'Hostname cannot be empty.' }
    elseif ($Hostname.Length -gt 15)      { $r.Valid = $false; $r.Message = "Exceeds 15-char NetBIOS limit ($($Hostname.Length) chars)." }
    elseif ($Hostname -match '[^A-Z0-9\-]') { $r.Valid = $false; $r.Message = 'Only A-Z, 0-9, hyphens allowed.' }
    elseif ($Hostname -match '^\-|\-$')   { $r.Valid = $false; $r.Message = 'Cannot start or end with a hyphen.' }
    return $r
}

# ================================================================
#  PROVISIONING
# ================================================================
function Set-TimezoneAndNTP {
    Write-Log "Setting timezone: $($script:Config.Timezone)" 'STEP'
    Set-TimeZone -Name $script:Config.Timezone
    $ntp = $script:Config.NTPServer
    Write-Log "NTP: $ntp" 'STEP'
    & w32tm /config /manualpeerlist:$ntp /syncfromflags:manual /reliable:YES /update 2>&1 | Out-Null
    Restart-Service w32tm -Force -ErrorAction SilentlyContinue
    & w32tm /resync /force 2>&1 | Out-Null
}
# NOTE: not currently wired in (Phase A applies power config inline). Kept full-path-safe so it
# cannot inherit a removable-drive working directory if it is ever called.
function Apply-PowerConfig {
    param([string]$Manufacturer)
    $powerCfgExe = Join-Path $env:SystemRoot 'System32\powercfg.exe'
    switch ($Manufacturer) {
        'Boxlight' {
            Write-Log 'Boxlight: power button -> Shutdown, Fast Startup disabled.' 'STEP'
            & $powerCfgExe /setacvalueindex SCHEME_CURRENT SUB_BUTTONS PBUTTONACTION 3 2>&1 | Out-Null
            & $powerCfgExe /setdcvalueindex SCHEME_CURRENT SUB_BUTTONS PBUTTONACTION 3 2>&1 | Out-Null
            & $powerCfgExe /setactive SCHEME_CURRENT 2>&1 | Out-Null
            $hb = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power'
            if (Test-Path $hb) { Set-ItemProperty -Path $hb -Name HiberbootEnabled -Value 0 -Type DWord -ErrorAction SilentlyContinue }
        }
        'SMART' {
            Write-Log 'SMART: power button -> Shutdown.' 'STEP'
            & $powerCfgExe /setacvalueindex SCHEME_CURRENT SUB_BUTTONS PBUTTONACTION 3 2>&1 | Out-Null
            & $powerCfgExe /setdcvalueindex SCHEME_CURRENT SUB_BUTTONS PBUTTONACTION 3 2>&1 | Out-Null
            & $powerCfgExe /setactive SCHEME_CURRENT 2>&1 | Out-Null
        }
        'Promethean' { Write-Log 'Promethean: power config skipped by design.' 'STEP' }
        default      { Write-Log "Unknown manufacturer '$Manufacturer' -- power config skipped." 'WARN' }
    }
}
# v5.5.1 ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§30: the old unbounded Suspend-WindowsUpdate / Resume-WindowsUpdate pair was removed.
# Nothing called them, and leaving an unbounded pause in the file invited a future change to call
# it instead of Invoke-WUPauseWithTimeout (RunnerDefs), which is bounded, verified and audited.
# The RECOVERY path is untouched: Restore-WindowsUpdateNow re-enables Windows Update and removes
# the APSPanelWURecovery task when provisioning is aborted or Phase A fails.
function Join-APSDomain {
    param([string]$DomainUser, [System.Security.SecureString]$SecurePwd)
    Write-Log "Joining $($script:Config.Domain)..." 'STEP'
    $cred = New-Object System.Management.Automation.PSCredential(
                "$($script:Config.Domain)\$DomainUser", $SecurePwd)
    Add-Computer -DomainName $script:Config.Domain -OUPath $script:Config.DomainOU `
                 -Credential $cred -Force -ErrorAction Stop
    Write-Log 'Add-Computer completed.'
}

# ================================================================
#  STATE FILE
# ================================================================
# v5.6.1 field stability: the local `user` account is only a bootstrap/provisioning account.
# Phase A silently makes it safe for the reboot sequence. No technician prompt is shown and the
# password itself is never changed. If the account is expected but cannot be prepared, Phase A
# stops BEFORE state/task/rename/WU changes so the OPS cannot be stranded at sign-in.
function Invoke-ProvisioningAccountPreflight {
    $name = if ($script:ProvisioningAccountName) { "$($script:ProvisioningAccountName)" } else { 'user' }
    $checked = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $script:ProvisioningAccountCheckedAt = $checked
    $script:ProvisioningAccountPreflight = 'Failed'
    $script:ProvisioningAccountEnabled = ''
    $script:ProvisioningAccountPasswordNeverExpires = ''
    try {
        $winlogon = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'
        $defaultUser = ''
        try { $defaultUser = "$((Get-ItemProperty $winlogon -Name DefaultUserName -ErrorAction SilentlyContinue).DefaultUserName)" } catch {}
        $account = Get-LocalUser -Name $name -ErrorAction SilentlyContinue
        $expected = (($env:USERNAME -ieq $name) -or ($defaultUser -ieq $name) -or
                     $script:NewInstallProvisioning -or $script:RecoveryProvisioning)
        if (-not $account) {
            if ($expected) { throw "Local provisioning account '$name' was not found." }
            $script:ProvisioningAccountPreflight = 'Not Applicable - Account Not Present'
            Write-Log "Provisioning-account preflight: $name is not present and is not required for this provisioning path."
            return [pscustomobject]@{ Success=$true; Applicable=$false; Account=$name; Enabled=''; PasswordNeverExpires=''; CheckedAt=$checked }
        }
        if (-not $account.Enabled) {
            Enable-LocalUser -Name $name -ErrorAction Stop
            Write-Log "Provisioning-account preflight: enabled local account '$name'."
        }
        Set-LocalUser -Name $name -PasswordNeverExpires $true -ErrorAction Stop
        # Clear an already-expired/must-change marker without changing the password. This keeps an
        # image that happened to cross the local max-password-age boundary from stopping Phase B.
        try {
            $adsi = [ADSI]("WinNT://{0}/{1},user" -f $env:COMPUTERNAME, $name)
            $adsi.PasswordExpired = 0
            $adsi.SetInfo()
        } catch { Write-Log "Provisioning-account expired-state clear via ADSI was not needed/available: $_" 'WARN' }
        $verify = Get-LocalUser -Name $name -ErrorAction Stop
        $never = ($null -eq $verify.PasswordExpires)
        if (-not $verify.Enabled) { throw "Local provisioning account '$name' is still disabled after repair." }
        if (-not $never) { throw "Local provisioning account '$name' still has a password-expiration date after repair." }
        $script:ProvisioningAccountEnabled = 'TRUE'
        $script:ProvisioningAccountPasswordNeverExpires = 'TRUE'
        $script:ProvisioningAccountPreflight = 'Passed'
        Write-Log "Provisioning-account preflight PASSED for '$name' (enabled, PasswordNeverExpires=True)."
        return [pscustomobject]@{ Success=$true; Applicable=$true; Account=$name; Enabled=$true; PasswordNeverExpires=$true; CheckedAt=$checked }
    } catch {
        $script:ProvisioningAccountPreflight = 'Failed'
        Write-Log "Provisioning-account preflight FAILED for '$name': $_" 'ERROR'
        return [pscustomobject]@{ Success=$false; Applicable=$true; Account=$name; Enabled=$false; PasswordNeverExpires=$false; CheckedAt=$checked; Error="$_" }
    }
}

function Write-StateFile {
    $state = @{
        Hostname=          $script:Hostname
        Domain=            $script:Config.Domain
        DomainOU=          $script:Config.DomainOU
        Mode=              $script:ModeLabel
        TechName=          $script:TechName
        SchoolCode=        $script:SchoolCode
        SchoolName=        $script:SchoolName
        Room=              $script:RoomNumber
        MountType=         $script:MountType
        PanelSerial=       $script:PanelSerial
        OPSSerial=         $script:OPSSerial
        Manufacturer=      $script:Manufacturer
        PanelModel=        $script:PanelModel
        StorageGB=         $script:StorageGB
        OPSTruncationNote= $script:OPSTruncationNote
        ReviewNotes=       $script:ReviewNotes
        OriginalScriptDir= $script:ScriptDir
        UsbRoot=           $script:UsbRoot
        RunId=             $script:RunId
        DeviceKey=         $script:PanelSerial
        PhaseAStatus=      'In Progress'
        PhaseAStartedAt=   (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
        AppScriptUrl=      $script:Config.AppScriptUrl
        # Summer continuation linkage carried across the reboot (v5.2 Phase 3)
        RelatedSummerRunId=      $script:RelatedSummerRunId
        SummerImageProfile=      $script:SummerImageProfile
        SummerRedoFile=          $script:SummerRedoFile
        SummerExpectedFolder=    $script:SummerExpectedFolder
        NewInstallProvisioning=  $script:NewInstallProvisioning
        RecoveryProvisioning=    $script:RecoveryProvisioning
        EndpointRepairAction=           $script:EndpointRepairAction
        EndpointRepairStage=            $script:EndpointRepairStage
        EndpointRepairOriginalHostname= $script:EndpointRepairOriginalHostname
        EndpointRepairExpectedHostname= $script:EndpointRepairExpectedHostname
        EndpointRepairDomainState=      $script:EndpointRepairDomainState
        AndroidEthernetExceptionReported= $script:AndroidEthernetExceptionReported
        AndroidEthernetExceptionEventId=  $script:AndroidEthernetExceptionEventId
        # v5.5 finding #2: Phase B runs after a REBOOT in a new process. Without these it
        # cannot resume the revision the client last received, so its post would carry no
        # expectation and optimistic concurrency would silently switch off.
        ProjectStateRevision=    $script:ProjectStateRevision
        ProjectStateRevisionFor= $script:ProjectStateRevisionFor
        ClientSessionId=         $script:ClientSessionId
        ClientDeviceName=        $script:ClientDeviceName
        EventSequence=           $script:EventSequence
        SenderScriptVersion=     $script:ScriptVersion
        InstallType=             $script:InstallType
        RoomType=                $script:RoomType
        OtherRoomType=           $script:OtherRoomType
        DomainMembershipStatus=  $script:DomainMembershipStatus
        DetectedDomain=          $script:DetectedDomain
        SecureChannelStatus=     $script:SecureChannelStatus
        DomainCheckAt=           $script:DomainCheckAt
        ProvisioningPathRecommended= $script:ProvisioningPathRecommended
        ProvisioningPathSelected=    $script:ProvisioningPathSelected
        ProvisioningRecommendationReason= $script:ProvisioningRecommendationReason
        NewInstallConfirmedBy=   $script:NewInstallConfirmedBy
        NewInstallConfirmedAt=   $script:NewInstallConfirmedAt
        PreviousHostname=        $script:PreviousHostname
        PreviousHostnameSource=  $script:PreviousHostnameSource
        OldHostnameCheckResult=  $script:OldHostnameCheckResult
        NewHostnameCheckResult=  $script:NewHostnameCheckResult
        SelectedHostnameSuffix=  $script:SelectedHostnameSuffix
        SummerOriginalDayOne=    $script:SummerOriginalDayOne
        OPSReplacementConfirmed= $script:OPSReplacementConfirmed
        # v5.6 unified RMA audit/reassignment context survives Phase A -> reboot -> Phase B.
        RMAAction=                 $script:RMAAction
        RMAPreviousPanelSerial=    $script:RMAPreviousPanelSerial
        RMAReassignmentConfirmed=  $script:RMAReassignmentConfirmed
        InventoryReassignmentConfirmed= $script:InventoryReassignmentConfirmed
        InventoryReassignmentType=      $script:InventoryReassignmentType
        InventoryReassignmentReason=    $script:InventoryReassignmentReason
        InventoryPreviousPanelSerial=   $script:InventoryPreviousPanelSerial
        TemporaryAssignment=            $script:TemporaryAssignment
        FollowUpRequired=                $script:FollowUpRequired
        TestingObservationOnly=         $script:TestingObservationOnly
        # ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§1: survives the rename reboot so Phase B can still report what the device was called
        # when we found it, not the name we just gave it.
        AssessmentHostname=      $script:AssessmentHostname
        RawRoom=                 $script:RawRoomEntry
        ProvisioningAccount=                    $script:ProvisioningAccountName
        ProvisioningAccountPreflight=           $script:ProvisioningAccountPreflight
        ProvisioningAccountEnabled=             $script:ProvisioningAccountEnabled
        ProvisioningAccountPasswordNeverExpires=$script:ProvisioningAccountPasswordNeverExpires
        ProvisioningAccountCheckedAt=           $script:ProvisioningAccountCheckedAt
        Timestamp=         (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
    }
    if (-not (Test-Path $script:ProvisioningDir)) { New-Item -ItemType Directory -Path $script:ProvisioningDir -Force | Out-Null }
    $state | ConvertTo-Json | Set-Content -Path "$script:ProvisioningDir\state.json" -Encoding UTF8
    Write-Log "State file written to $script:ProvisioningDir\state.json"
}
function Read-StateFile {
    $p = "$script:ProvisioningDir\state.json"
    if (Test-Path $p) { return (Get-Content $p -Raw | ConvertFrom-Json) }
    return $null
}
function Remove-StateFile {
    $p = "$script:ProvisioningDir\state.json"
    if (Test-Path $p) { Remove-Item $p -Force -ErrorAction SilentlyContinue }
    Write-Log 'State file removed.'
}

# ================================================================
#  WINDOWS 11 IN-PLACE UPGRADE AUTOMATION (v5.7)
# ================================================================
# Uses supported Windows Setup automation. The source must be approved STOCK Windows 11 media;
# do not point this at the customized RedoRescue image. Setup /Auto Upgrade does not support an
# image customized by adding/removing/changing apps, settings, or drivers.
function Get-WindowsUpgradeStatePath { return (Join-Path $script:ProvisioningDir 'windows-upgrade-state.json') }

function Get-WindowsSetupExitHex {
    param([int]$ExitCode)
    $u = [BitConverter]::ToUInt32([BitConverter]::GetBytes([int]$ExitCode), 0)
    return ('0x{0:X8}' -f $u)
}

function Get-WindowsUpgradeCompatMeaning {
    param([string]$HexCode)
    switch ($HexCode.ToUpperInvariant()) {
        '0XC1900210' { return 'Compatible - no blocking concerns found' }
        '0XC1900208' { return 'Blocked by an application or compatibility issue' }
        '0XC1900204' { return 'Selected migration/upgrade choice is not available' }
        '0XC1900200' { return 'Blocked by Windows system requirements' }
        '0XC190020E' { return 'Insufficient free disk space for the upgrade' }
        default      { return 'Windows Setup returned an unexpected compatibility result' }
    }
}

function Resolve-Windows11UpgradeSetup {
    # Explicit config wins. It may point at setup.exe, an extracted/mounted media folder, or an ISO.
    $configured = ''
    try { $configured = "$($script:Config.Windows11UpgradeMediaPath)".Trim() } catch {}
    $candidates = New-Object System.Collections.Generic.List[string]
    if ($configured) {
        if ([IO.Path]::IsPathRooted($configured)) { $candidates.Add($configured) }
        else {
            if ($script:UsbRoot)   { $candidates.Add((Join-Path $script:UsbRoot $configured)) }
            if ($script:ScriptDir) { $candidates.Add((Join-Path $script:ScriptDir $configured)) }
        }
    }
    if ($script:UsbRoot) {
        foreach ($rel in @('Windows11-25H2','Windows11_25H2','Windows11','Win11-25H2')) {
            $candidates.Add((Join-Path $script:UsbRoot $rel))
        }
    }

    foreach ($candidate in @($candidates | Select-Object -Unique)) {
        if (-not $candidate) { continue }
        if (Test-Path $candidate -PathType Leaf) {
            if ([IO.Path]::GetFileName($candidate) -ieq 'setup.exe') {
                return [pscustomobject]@{ SetupPath=$candidate; Source=$candidate; MountedIso='' }
            }
            if ([IO.Path]::GetExtension($candidate) -ieq '.iso') {
                try {
                    $img = Mount-DiskImage -ImagePath $candidate -PassThru -ErrorAction Stop
                    Start-Sleep -Seconds 1
                    $vol = $img | Get-Volume -ErrorAction Stop | Where-Object DriveLetter | Select-Object -First 1
                    if ($vol) {
                        $setup = "$($vol.DriveLetter):\setup.exe"
                        if (Test-Path $setup) {
                            return [pscustomobject]@{ SetupPath=$setup; Source=$candidate; MountedIso=$candidate }
                        }
                    }
                } catch { Write-Log "Could not mount Windows upgrade ISO '$candidate': $_" 'WARN' }
            }
        } elseif (Test-Path $candidate -PathType Container) {
            $setup = Join-Path $candidate 'setup.exe'
            if (Test-Path $setup) {
                return [pscustomobject]@{ SetupPath=$setup; Source=$candidate; MountedIso='' }
            }
        }
    }

    # Last chance: already-mounted optical/ISO media containing Windows Setup.
    try {
        foreach ($v in @(Get-Volume -ErrorAction SilentlyContinue | Where-Object DriveLetter)) {
            $setup = "$($v.DriveLetter):\setup.exe"
            $sources = "$($v.DriveLetter):\sources"
            if ((Test-Path $setup) -and (Test-Path $sources)) {
                return [pscustomobject]@{ SetupPath=$setup; Source="$($v.DriveLetter):\"; MountedIso='' }
            }
        }
    } catch {}
    return $null
}

function Test-WindowsUpgradeAutomationEligibility {
    $img = Test-ApprovedImage
    if ($img.ImageStatus -ne 'Windows Upgrade Required' -or -not [bool]$img.InfrastructureUpdateEligible) {
        return [pscustomobject]@{ Eligible=$false; Reason="Current image decision is '$($img.ImageStatus)' / '$($img.RemediationMethod)'."; Image=$img }
    }
    $opsClass = Get-CurrentOPSClass
    if ("$script:Manufacturer" -eq 'Boxlight' -and "$opsClass" -eq 'MT11') {
        return [pscustomobject]@{ Eligible=$false; Reason='MT11 is not approved for an automated Windows upgrade.'; Image=$img }
    }
    if ("$script:Manufacturer" -eq 'Boxlight' -and "$opsClass" -eq 'MT21' -and [int]$img.Build -lt 22000) {
        return [pscustomobject]@{ Eligible=$false; Reason='MT21 devices that are still on Windows 10 are intentionally being held on Windows 10 for now.'; Image=$img }
    }
    return [pscustomobject]@{ Eligible=$true; Reason=''; Image=$img; OPSClass="$opsClass" }
}

function Save-WindowsUpgradeState {
    param([string]$Stage, [string]$SetupPath, [string]$MediaSource)
    if (-not (Test-Path $script:ProvisioningDir)) {
        New-Item -ItemType Directory -Path $script:ProvisioningDir -Force | Out-Null
    }
    $state = [ordered]@{
        Workflow='Windows11InPlaceUpgrade'; Stage=$Stage; ProjectRunId=$script:ProjectRunId
        RelatedSummerRunId=$script:RelatedSummerRunId; RunId=$script:RunId; TechName=$script:TechName
        PanelSerial=$script:PanelSerial; OPSSerial=$script:OPSSerial; OPSClass=(Get-CurrentOPSClass)
        SchoolCode=$script:SchoolCode; SchoolName=$script:SchoolName; Room=$script:RoomNumber
        RoomType=$script:RoomType; OtherRoomType=$script:OtherRoomType; MountType=$script:MountType
        Manufacturer=$script:Manufacturer; PanelModel=$script:PanelModel; InstallType=$script:InstallType
        UsbRoot=$script:UsbRoot; SetupPath=$SetupPath; MediaSource=$MediaSource
        TargetVersion=$(if ($script:Config.PreferredOSDisplayVersion) { "$($script:Config.PreferredOSDisplayVersion)" } else { '25H2' })
        OriginalOS=$script:ApprovedImageOSName; OriginalHostname=$env:COMPUTERNAME
        ProjectStateRevision=$script:ProjectStateRevision; ProjectStateRevisionFor=$script:ProjectStateRevisionFor
        ClientSessionId=$script:ClientSessionId; ClientDeviceName=$script:ClientDeviceName; EventSequence=$script:EventSequence
        CreatedAt=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
    }
    $state | ConvertTo-Json -Depth 5 | Set-Content -Path (Get-WindowsUpgradeStatePath) -Encoding UTF8
}

function Test-PathUnderProvisioningDirectory {
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path) -or [string]::IsNullOrWhiteSpace($script:ProvisioningDir)) { return $false }
    try {
        $fullPath = [System.IO.Path]::GetFullPath($Path)
        $root = [System.IO.Path]::GetFullPath($script:ProvisioningDir).TrimEnd('\') + '\'
        return $fullPath.StartsWith($root,[System.StringComparison]::OrdinalIgnoreCase)
    } catch { return $false }
}

function Get-PersistentPanelAppScriptPath {
    # v5.7 launcher stages a unique runtime file inside ProvisioningDir. If we are already running
    # from there, that exact file is the safest reboot target; do not copy it over a fixed
    # C:\ProgramData\APS\OPSProvisioning\PanelApp.ps1 path again.
    if (Test-PathUnderProvisioningDirectory -Path $PSCommandPath) {
        Write-Log "Using existing local PanelApp runtime for reboot continuation: $PSCommandPath"
        return $PSCommandPath
    }
    if (-not (Test-Path $script:ProvisioningDir)) {
        New-Item -ItemType Directory -Path $script:ProvisioningDir -Force | Out-Null
    }
    $dest = Join-Path $script:ProvisioningDir ('PanelApp.runtime.{0}.{1}.ps1' -f (Get-Date -Format 'yyyyMMddHHmmss'),([guid]::NewGuid().ToString('N').Substring(0,8)))
    Copy-Item -Path $PSCommandPath -Destination $dest -Force -ErrorAction Stop
    Write-Log "Copied PanelApp to persistent reboot runtime $dest"
    return $dest
}

function Ensure-PersistentPanelAppConfig {
    $cfgSrc = Join-Path $script:ScriptDir 'config.json'
    $cfgDst = Join-Path $script:ProvisioningDir 'config.json'
    if (-not (Test-Path $cfgSrc)) { throw 'config.json is unavailable; cannot prepare reboot continuation.' }
    try {
        if ([System.IO.Path]::GetFullPath($cfgSrc) -ieq [System.IO.Path]::GetFullPath($cfgDst)) {
            Write-Log "config.json is already on the persistent local path."
            return $cfgDst
        }
    } catch {}
    Copy-Item -Path $cfgSrc -Destination $cfgDst -Force -ErrorAction Stop
    Write-Log "config.json copied to $cfgDst"
    return $cfgDst
}

function Register-WindowsUpgradeResumeTask {
    if (-not (Test-Path $script:ProvisioningDir)) {
        New-Item -ItemType Directory -Path $script:ProvisioningDir -Force | Out-Null
    }
    $dest = Get-PersistentPanelAppScriptPath
    [void](Ensure-PersistentPanelAppConfig)
    $arg = "-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File `"$dest`" -UpgradeResume"
    $act = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $arg
    $trig = New-ScheduledTaskTrigger -AtLogOn
    $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Hours 1)
    $currentUser = "$env:USERDOMAIN\$env:USERNAME"
    $prin = New-ScheduledTaskPrincipal -UserId $currentUser -LogonType Interactive -RunLevel Highest
    Register-ScheduledTask -TaskName 'APSPanelWindowsUpgradeResume' -Action $act -Trigger $trig -Settings $settings -Principal $prin -Force -ErrorAction Stop | Out-Null
    Write-Log "Windows upgrade resume task registered for $currentUser."
}

function Remove-WindowsUpgradeResumeTask {
    Unregister-ScheduledTask -TaskName 'APSPanelWindowsUpgradeResume' -Confirm:$false -ErrorAction SilentlyContinue
}

function Copy-WindowsUpgradeLogsToPortableMedia {
    $logRoot = Join-Path $script:ProvisioningDir 'WindowsUpgradeLogs'
    if (-not (Test-Path $logRoot) -or -not $script:UsbRoot -or -not (Test-Path $script:UsbRoot)) { return }
    try {
        $destRoot = Join-Path $script:UsbRoot 'APS\WindowsUpgradeLogs'
        New-Item -ItemType Directory -Path $destRoot -Force | Out-Null
        $name = if ($script:PanelSerial) { $script:PanelSerial } else { $env:COMPUTERNAME }
        $folder = Join-Path $destRoot ("{0}_{1}" -f $name, (Get-Date -Format 'yyyyMMdd_HHmmss'))
        Copy-Item $logRoot $folder -Recurse -Force -ErrorAction Stop
        Write-Log "Windows upgrade logs copied to technician media: $folder"
    } catch { Write-Log "Could not copy Windows upgrade logs to technician media: $_" 'WARN' }
}

function Start-Windows11UpgradeCompatibilityScan {
    $elig = Test-WindowsUpgradeAutomationEligibility
    if (-not $elig.Eligible) {
        [System.Windows.MessageBox]::Show(
            "Automated Windows 11 upgrade is not allowed on this device.`n`n$($elig.Reason)",
            'Windows Upgrade Blocked','OK','Warning') | Out-Null
        return
    }
    $media = Resolve-Windows11UpgradeSetup
    if (-not $media) {
        [System.Windows.MessageBox]::Show(
            "Approved Windows 11 upgrade media was not found.`n`nPut the STOCK Windows 11 25H2 media on the technician drive (recommended folder: Windows11-25H2), mount the ISO, or set Windows11UpgradeMediaPath in config.json.`n`nDo not use the customized RedoRescue image as in-place-upgrade media.",
            'Windows 11 Media Required','OK','Warning') | Out-Null
        return
    }

    $script:WindowsUpgradeSetupPath = "$($media.SetupPath)"
    $script:WindowsUpgradeOPSClass = "$($elig.OPSClass)"
    $script:WindowsUpgradeTarget = if ($script:Config.PreferredOSDisplayVersion) { "$($script:Config.PreferredOSDisplayVersion)" } else { '25H2' }
    Reset-ProgressScreen 'Windows 11 - Compatibility Scan'
    $logDir = Join-Path $script:ProvisioningDir 'WindowsUpgradeLogs'
    New-Item -ItemType Directory -Path $logDir -Force | Out-Null
    $compatLog = Join-Path $logDir ("Compat_{0}.zip" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
    $sync = [hashtable]::Synchronized(@{
        UI=$script:UI; LogFile=$script:LogFile; ErrorLog=$script:ErrorLog; RunFlags=$script:RunFlags
        TechName=$script:TechName; AppScriptUrl=$script:Config.AppScriptUrl; ScriptDir=$script:ScriptDir
        UsbRoot=$script:UsbRoot; RunId=$script:RunId; ProvisioningDir=$script:ProvisioningDir
        ClientSessionId=$script:ClientSessionId; ClientDeviceName=$script:ClientDeviceName; ScriptVersion=$script:ScriptVersion
        EventSequence=$script:EventSequence; ProjectStateRevision=$script:ProjectStateRevision; ProjectStateRevisionFor=$script:ProjectStateRevisionFor
        ProjectRunId=$script:ProjectRunId; PanelSerial=$script:PanelSerial; OPSSerial=$script:OPSSerial
        SchoolCode=$script:SchoolCode; Room=$script:RoomNumber; RoomType=$script:RoomType; OtherRoomType=$script:OtherRoomType
        SetupPath="$($media.SetupPath)"; MediaSource="$($media.Source)"; CompatLog=$compatLog
        OPSClass=$script:WindowsUpgradeOPSClass; TargetVersion=$script:WindowsUpgradeTarget
        OriginalOS=$script:ApprovedImageOSName; ProgressAction=''; CompatPassed=$false; CompatCode=''; CompatResult=''
    })
    $script:WindowsUpgradeRunspaceSync = $sync
    Start-ProvisionJob -Sync $sync -Work {
        try {
            Status 'Running Windows Setup compatibility scan...'
            Log "Setup source: $($s.MediaSource)"
            $args = @('/auto','upgrade','/quiet','/eula','accept','/compat','scanonly','/noreboot','/dynamicupdate','disable','/copylogs',('"' + $s.CompatLog + '"'))
            $proc = Start-Process -FilePath $s.SetupPath -ArgumentList $args -WorkingDirectory (Split-Path $s.SetupPath -Parent) -Wait -PassThru -ErrorAction Stop
            $u = [BitConverter]::ToUInt32([BitConverter]::GetBytes([int]$proc.ExitCode), 0)
            $hex = ('0x{0:X8}' -f $u)
            $meaning = switch ($hex.ToUpperInvariant()) {
                '0XC1900210' { 'Compatible - no blocking concerns found' }
                '0XC1900208' { 'Blocked by an application or compatibility issue' }
                '0XC1900204' { 'Selected migration/upgrade choice is not available' }
                '0XC1900200' { 'Blocked by Windows system requirements' }
                '0XC190020E' { 'Insufficient free disk space for the upgrade' }
                default      { 'Windows Setup returned an unexpected compatibility result' }
            }
            $s.CompatCode=$hex
            $s.CompatResult=$meaning
            $s.CompatPassed=($hex -eq '0xC1900210')
            Post-Log @{ LogSheet='Summer2026'; ProjectRunId=$s.ProjectRunId; ProjectStatus='Windows Upgrade Required'
                WindowsUpgradeStage='Compatibility Scan Complete'; WindowsUpgradeCompatibilityResult=$meaning
                WindowsUpgradeCompatibilityExitCode=$hex; WindowsUpgradeMediaSource=$s.MediaSource
                WindowsUpgradeTargetVersion=$s.TargetVersion; WindowsUpgradeOriginalOS=$s.OriginalOS
                WindowsUpgradeOPSClass=$s.OPSClass; LastUpdatedBy=$s.TechName; LastUpdatedAt=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') } 'WindowsUpgradeCompatibilityChecked' | Out-Null
            if ($s.CompatPassed) {
                Log "Compatibility scan PASSED ($hex)."
                $s.UI['pbarProgress'].Dispatcher.Invoke([action]{
                    $s.UI['pbarProgress'].IsIndeterminate=$false
                    $s.UI['pbarProgress'].Value=100
                    $s.UI['lblProgressStatus'].Text='Compatibility scan passed. Ready to start Windows 11 upgrade.'
                    $s.UI['lblProgressStatus'].Foreground=[System.Windows.Media.SolidColorBrush]([System.Windows.Media.ColorConverter]::ConvertFromString('#4EC994'))
                    $s.UI['btnProgressDone'].Content='Start Windows 11 Upgrade'
                    $s.UI['btnProgressDone'].Visibility=[System.Windows.Visibility]::Visible
                })
                $s.ProgressAction='StartWindowsUpgrade'
            } else {
                Log "Compatibility scan BLOCKED ($hex): $meaning" 'WARN'
                Fail "Windows 11 compatibility scan did not pass ($hex): $meaning. Do not force the upgrade; review the Setup logs and escalate if needed."
            }
        } catch {
            $s.CompatPassed=$false
            $s.CompatResult="$_"
            Log "Windows compatibility scan failed to run: $_" 'ERROR'
            try {
                Post-Log @{ LogSheet='Summer2026'; ProjectRunId=$s.ProjectRunId; ProjectStatus='Windows Upgrade Required'
                    WindowsUpgradeStage='Compatibility Scan Error'; WindowsUpgradeCompatibilityResult="$_"
                    WindowsUpgradeMediaSource=$s.MediaSource; WindowsUpgradeTargetVersion=$s.TargetVersion
                    WindowsUpgradeOPSClass=$s.OPSClass; LastUpdatedBy=$s.TechName; LastUpdatedAt=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') } 'WindowsUpgradeCompatibilityChecked' | Out-Null
            } catch {}
            Fail "Windows Setup compatibility scan could not run: $_"
        }
    }
}

function Start-Windows11UpgradeInstall {
    if ($script:WindowsUpgradeRunspaceSync) {
        try {
            Merge-SyncSenderContext $script:WindowsUpgradeRunspaceSync
            $script:ProgressAction = "$($script:WindowsUpgradeRunspaceSync.ProgressAction)"
            $script:WindowsUpgradeCompatCode = "$($script:WindowsUpgradeRunspaceSync.CompatCode)"
            $script:WindowsUpgradeCompatResult = "$($script:WindowsUpgradeRunspaceSync.CompatResult)"
            if (-not [bool]$script:WindowsUpgradeRunspaceSync.CompatPassed) {
                [System.Windows.MessageBox]::Show(
                    'The compatibility scan has not passed. The Windows upgrade will not start.',
                    'Upgrade Blocked','OK','Warning') | Out-Null
                return
            }
        } catch {
            Write-Log "Could not merge Windows upgrade scan state: $_" 'WARN'
            return
        }
    } else {
        [System.Windows.MessageBox]::Show('No successful compatibility scan is available for this session. Run the scan again.','Upgrade Blocked','OK','Warning') | Out-Null
        return
    }

    $elig = Test-WindowsUpgradeAutomationEligibility
    if (-not $elig.Eligible) {
        [System.Windows.MessageBox]::Show(
            "The device is no longer eligible for this upgrade.`n`n$($elig.Reason)",
            'Upgrade Blocked','OK','Warning') | Out-Null
        return
    }
    if (-not $script:WindowsUpgradeSetupPath -or -not (Test-Path $script:WindowsUpgradeSetupPath)) {
        [System.Windows.MessageBox]::Show(
            'The Windows 11 setup source is no longer available. Reconnect the technician media and run the compatibility scan again.',
            'Upgrade Media Missing','OK','Warning') | Out-Null
        return
    }

    $confirm = [System.Windows.MessageBox]::Show(
        "Compatibility scan PASSED ($($script:WindowsUpgradeCompatCode)).`n`nStart the Windows 11 $($script:WindowsUpgradeTarget) in-place upgrade now?`n`nApps and data are preserved. Windows Setup will reboot the OPS automatically. Leave the Windows installation media connected while Setup stages and begins the reboot. PanelApp will resume after sign-in and verify the result.`n`nDo not remove power during the upgrade.",
        'Start Windows 11 Upgrade','YesNo','Warning')
    if ($confirm -ne 'Yes') {
        Set-Status 'Windows upgrade cancelled after compatibility scan.'
        return
    }

    try {
        Save-WindowsUpgradeState -Stage 'Setup Started' -SetupPath $script:WindowsUpgradeSetupPath -MediaSource $script:WindowsUpgradeSetupPath
        Register-WindowsUpgradeResumeTask
        $startRes = Post-MainLog @{
            LogSheet='Summer2026'; ProjectRunId=$script:ProjectRunId; ProjectStatus='Windows Upgrade Required'
            WindowsUpgradeStage='Setup Started'; WindowsUpgradeCompatibilityResult=$script:WindowsUpgradeCompatResult
            WindowsUpgradeCompatibilityExitCode=$script:WindowsUpgradeCompatCode; WindowsUpgradeMediaSource=$script:WindowsUpgradeSetupPath
            WindowsUpgradeTargetVersion=$script:WindowsUpgradeTarget; WindowsUpgradeStartedBy=$script:TechName
            WindowsUpgradeStartedAt=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'); WindowsUpgradeOPSClass=(Get-CurrentOPSClass)
            LastUpdatedBy=$script:TechName; LastUpdatedAt=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
        } 'WindowsUpgradeStarted'
        if ($startRes -and $startRes.Rejected) {
            Remove-WindowsUpgradeResumeTask
            Remove-Item (Get-WindowsUpgradeStatePath) -Force -ErrorAction SilentlyContinue
            [System.Windows.MessageBox]::Show(
                "The spreadsheet rejected the Windows upgrade start event ($($startRes.Parsed.ErrorCode)). The upgrade was NOT started.",
                'Upgrade Not Started','OK','Error') | Out-Null
            return
        }

        Reset-ProgressScreen 'Windows 11 - Upgrade Starting'
        Update-ProgressStatus 'Starting Windows Setup. The OPS will reboot automatically...'
        Write-Log "Launching Windows 11 in-place upgrade from $($script:WindowsUpgradeSetupPath)."
        $logDir = Join-Path $script:ProvisioningDir 'WindowsUpgradeLogs'
        New-Item -ItemType Directory -Path $logDir -Force | Out-Null
        $copyLog = Join-Path $logDir ("Upgrade_{0}.zip" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
        $args = @('/auto','upgrade','/quiet','/eula','accept','/dynamicupdate','disable','/showoobe','none','/copylogs',('"' + $copyLog + '"'))
        Start-Process -FilePath $script:WindowsUpgradeSetupPath -ArgumentList $args -WorkingDirectory (Split-Path $script:WindowsUpgradeSetupPath -Parent) -ErrorAction Stop | Out-Null
        $script:UI['lblProgressStatus'].Text = 'Windows Setup started. Leave the OPS powered on and the upgrade media connected while Setup stages/reboots.'
        $script:UI['btnProgressDone'].Visibility = 'Collapsed'
    } catch {
        Remove-WindowsUpgradeResumeTask
        try { Remove-Item (Get-WindowsUpgradeStatePath) -Force -ErrorAction SilentlyContinue } catch {}
        Post-MainLog @{
            LogSheet='Summer2026'; ProjectRunId=$script:ProjectRunId; ProjectStatus='Windows Upgrade Required'
            WindowsUpgradeStage='Setup Launch Failed'; WindowsUpgradeResult='Failed to Launch'; WindowsUpgradeLastError="$_"
            WindowsUpgradeTargetVersion=$script:WindowsUpgradeTarget; WindowsUpgradeOPSClass=(Get-CurrentOPSClass)
            LastUpdatedBy=$script:TechName; LastUpdatedAt=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
        } 'WindowsUpgradeFailed' | Out-Null
        [System.Windows.MessageBox]::Show(
            "Windows Setup could not be started.`n`n$_`n`nNo upgrade was launched.",
            'Windows Upgrade Failed','OK','Error') | Out-Null
    }
}

function Invoke-Windows11UpgradeResume {
    $statePath = Get-WindowsUpgradeStatePath
    if (-not (Test-Path $statePath)) {
        Remove-WindowsUpgradeResumeTask
        [System.Windows.MessageBox]::Show(
            'Windows upgrade resume state was not found. Open Interactive Inventory Project and scan this panel to verify its current state.',
            'Upgrade Resume State Missing','OK','Warning') | Out-Null
        Show-Screen 'pnlUserEntry'
        return
    }
    try { $st = Get-Content $statePath -Raw | ConvertFrom-Json }
    catch {
        Remove-WindowsUpgradeResumeTask
        [System.Windows.MessageBox]::Show("Windows upgrade resume state could not be read.`n`n$_",'Upgrade Resume Error','OK','Error') | Out-Null
        Show-Screen 'pnlUserEntry'
        return
    }

    $script:ProjectRunId="$($st.ProjectRunId)"
    $script:RelatedSummerRunId="$($st.ProjectRunId)"
    $script:RunId="$($st.RunId)"
    $script:TechName="$($st.TechName)"
    $script:PanelSerial="$($st.PanelSerial)"
    $script:OPSSerial="$($st.OPSSerial)"
    $script:SchoolCode="$($st.SchoolCode)"
    $script:SchoolName="$($st.SchoolName)"
    $script:RoomNumber="$($st.Room)"
    $script:RoomType="$($st.RoomType)"
    $script:OtherRoomType="$($st.OtherRoomType)"
    $script:MountType="$($st.MountType)"
    $script:Manufacturer="$($st.Manufacturer)"
    $script:PanelModel="$($st.PanelModel)"
    $script:InstallType="$($st.InstallType)"
    if ("$($st.UsbRoot)") { $script:UsbRoot="$($st.UsbRoot)" }
    Restore-ProjectRevision ([pscustomobject]@{
        ProjectRunId="$($st.ProjectStateRevisionFor)"
        ProjectStateRevision="$($st.ProjectStateRevision)"
    })
    if ("$($st.ClientSessionId)") { $script:ClientSessionId="$($st.ClientSessionId)" }
    if ("$($st.ClientDeviceName)") { $script:ClientDeviceName="$($st.ClientDeviceName)" }
    $seq=0
    if ([int]::TryParse("$($st.EventSequence)",[ref]$seq) -and $seq -gt $script:EventSequence) { $script:EventSequence=$seq }
    $target = if ("$($st.TargetVersion)") { "$($st.TargetVersion)" } else { '25H2' }

    $build=0
    $display=''
    $osName=''
    try {
        $cv=Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -ErrorAction Stop
        $build=[int]$cv.CurrentBuild
        $display=if($cv.DisplayVersion){"$($cv.DisplayVersion)"}else{"$($cv.ReleaseId)"}
        $osName="$($cv.ProductName) $display (build $build)"
    } catch {}
    $targetRank=Get-WindowsFeatureVersionRank $target
    $currentRank=Get-WindowsFeatureVersionRank $display
    $success=($build -ge 22000 -and $targetRank -ge 0 -and $currentRank -ge $targetRank)
    Get-DomainMembership | Out-Null
    Update-SystemDriveStorageTelemetry

    if ($success) {
        $res = Post-MainLog (Add-ImageDecisionFields @{
            LogSheet='Summer2026'; ProjectRunId=$script:ProjectRunId
            ProjectStatus='Assessment Complete - Recommendation Pending'; CurrentStage='Assessment'
            WindowsUpgradeStage='Completed - Verified'; WindowsUpgradeResult='Success'; WindowsUpgradeTargetVersion=$target
            WindowsUpgradeOriginalOS="$($st.OriginalOS)"; WindowsUpgradeCompletedOS=$osName; WindowsUpgradeOPSClass="$($st.OPSClass)"
            WindowsUpgradeCompletedBy=$script:TechName; WindowsUpgradeCompletedAt=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
            PanelSerial=$script:PanelSerial; OPSSerial=$script:OPSSerial; CurrentOPSSerial=$script:OPSSerial; OPSClass="$($st.OPSClass)"
            SchoolCode=$script:SchoolCode; SchoolName=$script:SchoolName; Room=$script:RoomNumber; Hostname=$env:COMPUTERNAME
            OSName=$osName; OSBuild=$build; OSDisplayVer=$display
            CurrentOSName=$osName; CurrentOSBuild=$build; CurrentOSDisplayVer=$display
            DomainMembershipStatus=$script:DomainMembershipStatus; DetectedDomain=$script:DetectedDomain
            SecureChannelStatus=$script:SecureChannelStatus
            LastUpdatedBy=$script:TechName; LastUpdatedAt=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
        }) 'WindowsUpgradeCompleted'
        if ($res -and $res.Rejected) {
            [System.Windows.MessageBox]::Show(
                "Windows 11 is installed, but the spreadsheet rejected the completion update ($($res.Parsed.ErrorCode)). The local upgrade state has been retained for reconciliation.",
                'Upgrade Complete - Record Not Accepted','OK','Error') | Out-Null
            return
        }
        Copy-WindowsUpgradeLogsToPortableMedia
        Remove-WindowsUpgradeResumeTask
        Remove-Item $statePath -Force -ErrorAction SilentlyContinue
        [System.Windows.MessageBox]::Show(
            "Windows 11 $display is installed and verified.`n`nPanelApp will now re-evaluate the same project so you can complete any remaining domain/readiness work.",
            'Windows 11 Upgrade Complete','OK','Information') | Out-Null
        Set-Mode 7 'Interactive Inventory Assessment'
        Show-ProvRecommendation
        return
    }

    $err = "Expected Windows 11 $target or newer after upgrade, but detected '$osName'. Windows Setup may have rolled back or not completed."
    Post-MainLog @{
        LogSheet='Summer2026'; ProjectRunId=$script:ProjectRunId; ProjectStatus='Manual Review Required'; CurrentStage='Assessment'
        WindowsUpgradeStage='Failed / Rolled Back'; WindowsUpgradeResult='Failed'; WindowsUpgradeTargetVersion=$target
        WindowsUpgradeOriginalOS="$($st.OriginalOS)"; WindowsUpgradeCompletedOS=$osName; WindowsUpgradeOPSClass="$($st.OPSClass)"
        WindowsUpgradeLastError=$err; LastUpdatedBy=$script:TechName; LastUpdatedAt=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
    } 'WindowsUpgradeFailed' | Out-Null
    Copy-WindowsUpgradeLogsToPortableMedia
    Remove-WindowsUpgradeResumeTask
    Remove-Item $statePath -Force -ErrorAction SilentlyContinue
    $script:UI['lblGateTitle'].Text='Windows Upgrade Needs Review'
    $script:UI['lblGateMsg'].Text="$err`n`nDo not repeatedly force Setup. Review the copied Windows Setup logs and escalate this OPS."
    $script:UI['lblGateState'].Text="ProjectRunId: $($script:ProjectRunId)`nPanel: $($script:PanelSerial)`nOPS: $($script:OPSSerial) / $($st.OPSClass)"
    Show-Screen 'pnlRedoGateBlock'
}

# ================================================================
#  SCHEDULED TASK
# ================================================================
function Register-PhaseBTask {
    if (-not (Test-Path $script:ProvisioningDir)) {
        New-Item -ItemType Directory -Path $script:ProvisioningDir -Force | Out-Null
    }
    $dest = Get-PersistentPanelAppScriptPath
    [void](Ensure-PersistentPanelAppConfig)
    $arg  = "-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File `"$dest`" -PhaseB"
    $act  = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $arg
    $trig = New-ScheduledTaskTrigger -AtLogOn
    $cfg  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Hours 1)
    # Use the current logged-in user rather than a group - group+Interactive is unreliable
    $currentUser = "$env:USERDOMAIN\$env:USERNAME"
    $prin = New-ScheduledTaskPrincipal -UserId $currentUser -LogonType Interactive -RunLevel Highest
    Register-ScheduledTask -TaskName 'APSPanelPhaseB' -Action $act -Trigger $trig `
                           -Settings $cfg -Principal $prin -Force -ErrorAction Stop | Out-Null
    Write-Log "Phase B scheduled task registered for $currentUser"
}
function Remove-PhaseBTask {
    Unregister-ScheduledTask -TaskName 'APSPanelPhaseB' -Confirm:$false -ErrorAction SilentlyContinue
    Write-Log 'Phase B scheduled task removed.'
}

# Fail-safe (ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§18.4): if Phase B never completes (tech stops, task fails, no creds, join never
# happens), this one-time task re-enables Windows Update ~8h later, then removes itself. Phase B
# success removes it. A visible "Restore Windows Update Settings" button does the same on demand.
function Register-WURecoveryTask {
    try {
        $cmd = "Set-Service wuauserv -StartupType Automatic -ErrorAction SilentlyContinue; " +
               "Start-Service wuauserv -ErrorAction SilentlyContinue; " +
               "`$p='HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU'; " +
               "if (Test-Path `$p) { Remove-ItemProperty `$p -Name NoAutoUpdate -ErrorAction SilentlyContinue }; " +
               "Unregister-ScheduledTask -TaskName 'APSPanelWURecovery' -Confirm:`$false -ErrorAction SilentlyContinue"
        $arg  = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command `"$cmd`""
        $act  = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $arg
        $trig = New-ScheduledTaskTrigger -Once -At (Get-Date).AddHours(8)
        $set  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable
        $prin = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
        Register-ScheduledTask -TaskName 'APSPanelWURecovery' -Action $act -Trigger $trig `
                               -Settings $set -Principal $prin -Force -ErrorAction Stop | Out-Null
        Write-Log 'Windows Update recovery task registered (8h fail-safe).'
    } catch {
        # Rethrow so Execute-PhaseA's setup guard actually sees the failure and stops (review fix #1)
        Write-Log "WU recovery task registration failed: $_" 'ERROR'
        throw
    }
}
function Remove-WURecoveryTask {
    Unregister-ScheduledTask -TaskName 'APSPanelWURecovery' -Confirm:$false -ErrorAction SilentlyContinue
    Write-Log 'Windows Update recovery task removed.'
}
function Restore-WindowsUpdateNow {
    try {
        Set-Service  wuauserv -StartupType Automatic -ErrorAction SilentlyContinue
        Start-Service wuauserv -ErrorAction SilentlyContinue
        $p = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU'
        if (Test-Path $p) { Remove-ItemProperty $p -Name NoAutoUpdate -ErrorAction SilentlyContinue }
        Remove-WURecoveryTask
        Write-Log 'Windows Update settings restored on demand.'
        return $true
    } catch { Write-Log "Restore Windows Update failed: $_" 'WARN'; return $false }
}

# Modal confirm for the abort action. Cancel is the default-focused choice. Returns $true to abort.
function Show-AbortConfirm {
    [xml]$x = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Abort Provisioning Attempt?" Width="560" SizeToContent="Height"
        WindowStartupLocation="CenterOwner" ResizeMode="NoResize" Background="#1C1C1C">
  <StackPanel Margin="26">
    <TextBlock Text="Abort Provisioning Attempt?" FontFamily="Segoe UI" FontSize="18"
               FontWeight="Bold" Foreground="#FFFFFF" Margin="0,0,0,14"/>
    <TextBlock TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="13" Foreground="#CCCCCC" Margin="0,0,0,20"
      Text="This stops the pending Phase B/domain-join continuation.&#x0a;&#x0a;PanelApp will:&#x0a;   - remove the scheduled Phase B task&#x0a;   - restore Windows Update&#x0a;   - remove the Windows Update recovery task&#x0a;   - preserve the current provisioning state as an aborted record&#x0a;&#x0a;This will not reverse changes already completed during Phase A, including a computer rename.&#x0a;&#x0a;Select Cancel to continue provisioning, or Abort Provisioning to stop this attempt."/>
    <StackPanel Orientation="Horizontal" HorizontalAlignment="Right">
      <Button x:Name="btnDlgCancel" Content="Cancel" MinWidth="120" Padding="16,8" Margin="0,0,10,0"
              IsDefault="True" IsCancel="True"/>
      <Button x:Name="btnDlgAbort" Content="Abort Provisioning" MinWidth="170" Padding="16,8"
              Background="#C8102E" Foreground="#FFFFFF" BorderThickness="0"/>
    </StackPanel>
  </StackPanel>
</Window>
'@
    try {
        $dlg = [System.Windows.Markup.XamlReader]::Load([System.Xml.XmlNodeReader]::new($x))
        $dlg.Owner = $script:window
        $dlg.FindName('btnDlgCancel').Add_Click({ $dlg.DialogResult = $false })
        $dlg.FindName('btnDlgAbort').Add_Click({  $dlg.DialogResult = $true  })
        $dlg.FindName('btnDlgCancel').Focus() | Out-Null
        return ([bool]$dlg.ShowDialog())
    } catch { Write-Log "Abort confirm dialog failed: $_" 'WARN'; return $false }
}

# Real abort: cancel the pending domain-join continuation and restore update state, but leave any
# Phase A rename in place (we never reverse completed changes).
function Abort-Provisioning {
    Write-Log 'ABORT: technician aborted the provisioning attempt.' 'WARN'
    $now = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    try { Remove-PhaseBTask } catch { Write-Log "Abort: remove Phase B task failed: $_" 'WARN' }
    $wuOk = Restore-WindowsUpdateNow   # restores WU + removes APSPanelWURecovery
    # Archive the pending state file as aborted (do not silently delete), marking PhaseAStatus
    $stateAction = 'Missing'
    try {
        $sf = "$script:ProvisioningDir\state.json"
        if (Test-Path $sf) {
            try {
                $st = Get-Content $sf -Raw | ConvertFrom-Json
                $st | Add-Member -NotePropertyName PhaseAStatus -NotePropertyValue 'Aborted' -Force
                $st | ConvertTo-Json | Set-Content -Path $sf -Encoding UTF8
            } catch {}
            $dest = "$script:ProvisioningDir\state.aborted_$(Get-Date -Format 'yyyyMMdd_HHmmss').json"
            Move-Item -Path $sf -Destination $dest -Force
            $stateAction = 'Archived'
            Write-Log "Abort: pending state archived to $dest"
        }
    } catch { $stateAction = 'Failed'; Write-Log "Abort: state archive failed: $_" 'WARN' }
    # ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§39.4: backend logging - the workflow needs review before another attempt
    # r11 finding #2: the abort is a PHYSICAL event that already happened (tasks removed, Windows
    # Update restored, state archived, any rename still in place). A backend rejection cannot undo
    # any of it, so the abort never fails locally - but the caller must be able to say what the
    # spreadsheet actually accepted instead of a flat "Provisioning aborted".
    $projectResult = $null
    $exceptionResult = $null
    if ($script:RelatedSummerRunId) {
        # Verify the recovery task is actually gone before claiming it (review smaller fix #2)
        $wuTaskGone = -not (Get-ScheduledTask -TaskName 'APSPanelWURecovery' -ErrorAction SilentlyContinue)
        $projectResult = Send-Event -Payload @{
            LogSheet='Summer2026'; ProjectRunId=$script:RelatedSummerRunId
            ProjectStatus='Manual Review Required'; PhaseAStatus='Aborted'
            AbortReason='Technician aborted after Phase A checkpoint'; AbortedBy=$script:TechName; AbortedAt=$now
            WURecoveryTaskStatus=$(if ($wuTaskGone) {'Removed'} else {'Failed to Remove'})
            WindowsUpdateRestored=$(if ($wuOk) {'TRUE'} else {'FALSE'})
            StateFileFinalAction=$stateAction
            LastUpdatedBy=$script:TechName; LastUpdatedAt=$now
        } -EventType 'ReviewerStateCorrection'
    }
    # Record the aborted-provisioning event (links to the Summer record if this was a continuation).
    # Sent even when the project mutation was rejected: unlike the Manual Review recommendation, the
    # abort is an observation of something that physically happened, and it stays worth recording.
    $exceptionResult = Send-ExceptionEvent -Category 'Provisioning Aborted' `
        -Note 'Technician aborted the provisioning attempt after Phase A. Device may already be renamed; review device state before re-provisioning.' `
        -Phase 'Phase A Abort'
    return [pscustomobject]@{
        ProjectResult         = $projectResult
        ExceptionResult       = $exceptionResult
        StateAction           = $stateAction
        WindowsUpdateRestored = $wuOk
        Rejected              = [bool](($projectResult -and $projectResult.Rejected) -or
                                       ($exceptionResult -and $exceptionResult.Rejected))
        Queued                = [bool](($projectResult -and $projectResult.Queued) -or
                                       ($exceptionResult -and $exceptionResult.Queued))
    }
}

# ================================================================
#  BACKEND HEALTH / RESPONSIVE HTTP  (v5.6.1)
# ================================================================
# WPF must keep processing messages while an HTTPS request is outstanding. WebClient's Task APIs
# let the network operation run asynchronously while this loop pumps Windows messages. This avoids
# the grey/Not Responding window without changing the established visual design or sender semantics.
function Invoke-ResponsiveWebJson {
    param(
        [Parameter(Mandatory)][string]$Uri,
        [ValidateSet('GET','POST')][string]$Method = 'GET',
        [string]$Body = '',
        [int]$TimeoutSeconds = 8
    )
    if ($TimeoutSeconds -le 0) { $TimeoutSeconds = 8 }
    $wc = New-Object System.Net.WebClient
    $wc.Encoding = [System.Text.Encoding]::UTF8
    $wc.Headers['Accept'] = 'application/json'
    if ($Method -eq 'POST') { $wc.Headers['Content-Type'] = 'application/json' }
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    try {
        if ($Method -eq 'POST') { $task = $wc.UploadStringTaskAsync([uri]$Uri, 'POST', $Body) }
        else                    { $task = $wc.DownloadStringTaskAsync([uri]$Uri) }
        while (-not $task.IsCompleted) {
            try { [System.Windows.Forms.Application]::DoEvents() } catch {}
            Start-Sleep -Milliseconds 50
            if ($sw.Elapsed.TotalSeconds -ge $TimeoutSeconds) {
                try { $wc.CancelAsync() } catch {}
                throw "PanelApp backend request timed out after $TimeoutSeconds seconds."
            }
        }
        try { $text = [string]$task.Result }
        catch {
            $msg = if ($_.Exception.InnerException) { $_.Exception.InnerException.Message } else { $_.Exception.Message }
            throw $msg
        }
        if ([string]::IsNullOrWhiteSpace($text)) { return $null }
        try { return ($text | ConvertFrom-Json) } catch { return $text }
    } finally {
        $sw.Stop()
        try { $wc.Dispose() } catch {}
    }
}

function Get-BackendHealth {
    param([switch]$Force)
    if (-not $Force -and $script:BackendStatus -ne 'Unknown' -and $script:BackendLastCheckedAt) {
        return [pscustomobject]@{
            Status=$script:BackendStatus; Detail=$script:BackendStatusDetail
            MinimumVersion=$script:BackendMinimumVersion; BackendBuildId=$script:BackendBuildId
            CheckedAt=$script:BackendLastCheckedAt
        }
    }
    $url = "$($script:Config.AppScriptUrl)"
    $checked = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $status='Unconfigured'; $detail='Apps Script URL is not configured.'; $min=''; $buildId=''
    if (-not [string]::IsNullOrWhiteSpace($url) -and $url -notlike '*YOUR_DEPLOYMENT*' -and $url -notlike '*PASTE_TEST*') {
        try {
            $sep = if ($url -match '\?') { '&' } else { '?' }
            $probe = Invoke-ResponsiveWebJson -Uri "$url${sep}action=version" -Method GET -TimeoutSeconds 6
            if ($probe -and $probe.PSObject.Properties['minimumVersion']) {
                $min="$($probe.minimumVersion)"
                if ($probe.PSObject.Properties['backendBuildId']) { $buildId="$($probe.backendBuildId)" }
                if ($buildId -eq $script:RequiredBackendBuildId) {
                    $status='Available'
                    $detail='PanelApp backend responded with the required field build.'
                } else {
                    $status='BackendUpdateRequired'
                    $reported = if ($buildId) { $buildId } else { '(no backend build ID)' }
                    $detail="Configured endpoint reported $reported; deploy required build $($script:RequiredBackendBuildId) before project work."
                }
            } elseif ($probe -is [string] -and ($probe -match 'Sign in - Google Accounts|AccountChooser|accounts\.google\.com')) {
                $status='AuthenticationRequired'; $detail='The Apps Script deployment requires an interactive Google sign-in.'
            } else {
                $status='InvalidResponse'; $detail='The endpoint responded, but not with the PanelApp version payload.'
            }
        } catch {
            $status='Unavailable'; $detail="$_"
        }
    }
    $script:BackendStatus=$status; $script:BackendStatusDetail=$detail
    $script:BackendMinimumVersion=$min; $script:BackendBuildId=$buildId
    $script:BackendLastCheckedAt=$checked
    $healthMsg = "Backend health: $status"
    if ($min)     { $healthMsg += " (minimum version $min)" }
    if ($buildId) { $healthMsg += " (build $buildId)" }
    if ($detail)  { $healthMsg += " - $detail" }
    Write-Log $healthMsg $(if ($status -eq 'Available') { 'INFO' } else { 'WARN' })
    return [pscustomobject]@{
        Status=$status; Detail=$detail; MinimumVersion=$min
        BackendBuildId=$buildId; CheckedAt=$checked
    }
}

# Compatibility wrapper: existing workflow code uses IsNetworkAvailable. In v5.6.1 that means
# "the PanelApp backend can accept an unauthenticated request", not just generic internet access.
function Test-Network {
    $h = Get-BackendHealth -Force
    return ($h.Status -eq 'Available')
}

function Get-MinimumVersion {
    $h = Get-BackendHealth
    if ($h.Status -eq 'Available' -and $h.MinimumVersion) { return [string]$h.MinimumVersion }
    return $null
}

function Get-PanelAppComparableVersion {
    param([string]$Text)
    if ($Text.Trim() -notmatch '^(\d+\.\d+(?:\.\d+){0,2})(?:[-+][0-9A-Za-z.-]+)?$') { throw "Invalid PanelApp version: $Text" }
    return [version]$Matches[1]
}

# v5.7: workflows that must read or mutate authoritative inventory are blocked when
# PanelApp sync is unavailable. Physical observation/capture modes remain offline-capable.
function Require-AuthoritativeBackend {
    param([string]$ActionName)
    $action = if ($ActionName) { $ActionName } else { 'This action' }
    try {
        $h = Get-BackendHealth -Force
        $script:IsNetworkAvailable = ($h.Status -eq 'Available')
    } catch { $script:IsNetworkAvailable = $false }
    if ($script:IsNetworkAvailable) { return $true }

    Write-Log "$action blocked because authoritative PanelApp sync is unavailable." 'WARN'
    [System.Windows.MessageBox]::Show(
        "$action requires a live connection to the PanelApp spreadsheet/backend because it must read or change the current authoritative inventory record.`n`nNo inventory change was made.`n`nYou can still use Interactive Inventory Project or General Inventory Capture to record a physical observation offline; that observation will queue and synchronize later.",
        'PanelApp Sync Required', 'OK', 'Warning') | Out-Null
    Set-Status "$action blocked - PanelApp sync unavailable."
    return $false
}

# Capture the Windows/system volume once per PanelApp process. Failure is non-blocking.
function Update-SystemDriveStorageTelemetry {
    if ($script:StorageTelemetryCaptured) { return }
    $script:StorageTelemetryCaptured = $true
    try {
        $deviceId = "$($env:SystemDrive)".TrimEnd([char]92)
        $logical = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$deviceId'" -ErrorAction Stop | Select-Object -First 1
        if ($logical -and [double]$logical.Size -gt 0) {
            $total = [double]$logical.Size
            $free  = if ($null -ne $logical.FreeSpace) { [double]$logical.FreeSpace } else { 0 }
            $used  = [math]::Max([double]0, $total - $free)
            $script:StorageTotalGB = [math]::Round($total / 1GB, 1)
            $script:StorageUsedGB  = [math]::Round($used  / 1GB, 1)
            $script:StorageFreeGB  = [math]::Round($free  / 1GB, 1)
            Write-Log "System-drive storage: total=$($script:StorageTotalGB)GB used=$($script:StorageUsedGB)GB free=$($script:StorageFreeGB)GB"
        }
    } catch { Write-Log "System-drive storage telemetry unavailable: $_" 'WARN' }
}

function Get-SummerProjectStateRemote {
    param([string]$ProjectRunId)
    if (-not $ProjectRunId -or -not $script:IsNetworkAvailable) { return $null }
    try {
        $url = "$($script:Config.AppScriptUrl)"; $sep = if ($url -match '\?') { '&' } else { '?' }
        $enc = [uri]::EscapeDataString($ProjectRunId)
        return (Invoke-ResponsiveWebJson -Uri "$url${sep}action=summerProjectState&projectRunId=$enc" -Method GET -TimeoutSeconds 8)
    } catch { Write-Log "Interactive Inventory project-state lookup failed: $_" 'WARN'; return $null }
}

# ================================================================
#  RUN IDS + SUMMER CONTINUATION LOOKUP (v5.2 Phase 3)
# ================================================================
function New-RunId {
    $g = [guid]::NewGuid().ToString('N').Substring(0,8).ToUpper()
    return "PA-$(Get-Date -Format 'yyyyMMdd')-$(Get-Date -Format 'HHmmss')-$g"
}
function Find-SummerContinuation {
    param([string]$PanelSerial)
    $url = $script:Config.AppScriptUrl
    if ([string]::IsNullOrWhiteSpace($url) -or $url -like '*YOUR_DEPLOYMENT*' -or
        -not $script:IsNetworkAvailable -or [string]::IsNullOrWhiteSpace($PanelSerial)) { return @() }
    try {
        $sep = if ($url -like '*`?*') { '&' } else { '?' }
        $enc = [System.Uri]::EscapeDataString($PanelSerial)
        $r = Invoke-ResponsiveWebJson -Uri "$url${sep}action=summerLookup&panelSerial=$enc" -Method GET -TimeoutSeconds 8
        if ($r -and $r.records) { return @($r.records) }
        return @()
    } catch { Write-Log "Interactive Inventory lookup failed: $_" 'WARN'; return @() }
}

# ================================================================
#  OFFLINE QUEUE + EVENT SENDING (v5.2 Phase 4)
# ================================================================
# Where to WRITE a queued event: prefer the USB only when it is actually writable. A removable
# drive can be present but carry an NTFS ACL from another OPS/account, which previously caused an
# Access-to-the-path-is-denied class of field failure. Fall back to local ProgramData rather than
# letting a queue-path permission problem abort the workflow.
function Test-PanelAppWritableDirectory {
    param([Parameter(Mandatory=$true)][string]$Path)
    try {
        if (-not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Path $Path -Force -ErrorAction Stop | Out-Null }
        $probe = Join-Path $Path ('.panelapp_write_probe_{0}_{1}.tmp' -f $PID,([guid]::NewGuid().ToString('N').Substring(0,8)))
        [System.IO.File]::WriteAllText($probe,'PanelApp write probe',[System.Text.Encoding]::UTF8)
        Remove-Item -LiteralPath $probe -Force -ErrorAction Stop
        return $true
    } catch {
        Write-Log "Directory is not writable: $Path - $($_.Exception.Message)" 'WARN'
        return $false
    }
}
function Get-QueueDir {
    if ($script:UsbRoot -and (Test-Path -LiteralPath $script:UsbRoot)) {
        $portable = Join-Path $script:UsbRoot 'APS\OfflineQueue'
        if (Test-PanelAppWritableDirectory $portable) { return $portable }
        Write-Log "Portable offline queue is unavailable at $portable; using local fallback. Do not reimage while unsynced work remains local." 'WARN'
    }
    $local = Join-Path $script:ProvisioningDir 'OfflineQueue'
    if (-not (Test-PanelAppWritableDirectory $local)) {
        throw "PanelApp cannot write its offline queue to either the portable drive or local working directory. Local path: $local"
    }
    return $local
}
# All queue locations to READ/flush (USB if present + local fallback).
function Get-QueueDirs {
    $dirs = @()
    if ($script:UsbRoot -and (Test-Path $script:UsbRoot)) { $dirs += (Join-Path $script:UsbRoot 'APS\OfflineQueue') }
    if ($script:ProvisioningDir) { $dirs += (Join-Path $script:ProvisioningDir 'OfflineQueue') }
    return $dirs
}
# A successful Apps Script write returns HTTP 200 with { success: true }. A 200 with
# success=false (or no success field) is a REJECTION and must not be treated as delivered.
function Test-SheetResponse {
    param($Response)
    return ($Response -and ($Response.success -eq $true))
}

# ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â
# v5.5 CLIENT CORE ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â ONE sender, shared by the main thread and every background
# runspace. Dot-sourced here and AddScript-injected in Start-ProvisionJob, exactly
# like $script:ImageDecisionDefs.
#
# Review finding #1: the runspace used to carry its own Queue-Event/Post-Log with a
# private Invoke-RestMethod, so Summer assessments, the RedoRescue gate, Phase A and
# the inventory modes all bypassed the reliability layer entirely. Everything now goes
# through Send-PanelAppEvent, and the ONLY two POST sites in the app are that function
# and the offline replay in Flush-OfflineQueue.
#
# All state is passed in an explicit $Ctx hashtable, because the main thread keeps its
# state in $script: and a runspace keeps it in the $s sync hashtable.
# ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â
$script:SenderDefs = {

# ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§12.2 scanner noise out, case-folded. Hyphens and leading zeroes are MEANINGFUL in
# OPS/panel serials and are preserved. Mirrors canonSerial() in the Apps Script; the
# backend normalizes again because the client is never the trust boundary (ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§12.4).
function Get-CanonicalSerial {
    param([string]$Value)
    if ($null -eq $Value) { return '' }
    $s = [string]$Value
    $s = $s -replace '[\x00-\x1F\x7F]', ''            # CR/LF/TAB + scanner control prefixes
    $s = $s -replace '[\u200B-\u200D\uFEFF]', ''      # zero-width + BOM
    $s = $s -replace '\s', ''                          # stray spaces mid-read
    return $s.ToUpperInvariant()
}
# ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§12.3 short-name identity; the FQDN stays in the Raw value.
function Get-CanonicalHostname {
    param([string]$Value)
    if ($null -eq $Value) { return '' }
    $s = ([string]$Value) -replace '[\x00-\x1F\x7F]', ''
    $s = $s -replace '[\u200B-\u200D\uFEFF]', ''      # same zero-width cleanup as serials
    $s = $s.Trim() -replace '\.+$', ''
    if ($s.IndexOf('.') -gt 0) { $s = $s.Split('.')[0] }
    return $s.ToUpperInvariant()
}

function New-PanelAppEventId {
    "EVT-{0}-{1}" -f (Get-Date -Format 'yyyyMMdd-HHmmss'),
                     ([guid]::NewGuid().ToString('N').Substring(0,8).ToUpperInvariant())
}

# ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§3 stamp the envelope onto a payload. Called once, when the event is CREATED - a retry
# reuses the same EventId so the backend can recognize it (ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§4.3).
# r14 (field data): "b 129" / "b129" / "B 129" / "rm 134" split one physical room into several
# identities. Uppercase, strip ALL whitespace + control characters. HYPHENS ARE KEPT - "B-126"
# vs "B126" stays a flagged possible-duplicate until APS agrees on a room convention.
function Get-CanonicalRoom {
    param([string]$Value)
    if ($null -eq $Value) { return '' }
    $s = [string]$Value
    $s = $s -replace '[\x00-\x1F\x7F]', ''
    $s = $s -replace '[\u200B-\u200D\uFEFF]', ''
    $s = $s -replace '\s', ''
    return $s.ToUpperInvariant()
}
# Free-text identity-ish fields (OtherRoomType): uppercase, single internal spaces survive.
function Get-CanonicalFreeText {
    param([string]$Value)
    if ($null -eq $Value) { return '' }
    $s = [string]$Value
    $s = $s -replace '[\x00-\x1F\x7F]', ''
    $s = $s -replace '[\u200B-\u200D\uFEFF]', ''
    $s = ($s -replace '\s+', ' ').Trim()
    return $s.ToUpperInvariant()
}
function Add-EventEnvelope {
    param([hashtable]$Payload, [string]$EventType, [hashtable]$Ctx)
    if (-not $Payload.ContainsKey('EventId'))        { $Payload['EventId'] = New-PanelAppEventId }
    if (-not $Payload.ContainsKey('EventCreatedAt')) { $Payload['EventCreatedAt'] = (Get-Date).ToString('o') }
    if ($EventType -and -not $Payload.ContainsKey('EventType')) { $Payload['EventType'] = $EventType }
    if (-not $Payload.ContainsKey('EventSequence')) {
        $Ctx['Sequence'] = [int]$Ctx['Sequence'] + 1
        $Payload['EventSequence'] = $Ctx['Sequence']
    }
    $Payload['ClientDeviceName'] = $Ctx['DeviceName']
    $Payload['ClientSessionId']  = $Ctx['SessionId']
    if (-not $Payload.ContainsKey('IsOfflineReplay')) { $Payload['IsOfflineReplay'] = $false }
    if (-not $Payload.ContainsKey('AppVersion'))      { $Payload['AppVersion'] = $Ctx['ScriptVersion'] }
    # v5.7: central injection means every mode/event carries the same storage observation.
    foreach ($storageField in @('StorageTotalGB','StorageUsedGB','StorageFreeGB')) {
        if (-not $Payload.ContainsKey($storageField) -and $Ctx.ContainsKey($storageField) -and "$($Ctx[$storageField])" -ne '') {
            $Payload[$storageField] = $Ctx[$storageField]
        }
    }
    # ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§5 / review finding #5: the revision is only meaningful for the project it came from.
    # Applying a global revision to a DIFFERENT panel produced false STALE_PROJECT_REVISION.
    $payloadRun = "$($Payload['ProjectRunId'])"
    if (-not $payloadRun) { $payloadRun = "$($Payload['RelatedSummerProjectRunId'])" }
    if ($payloadRun -and "$($Ctx['Revision'])" -ne '' -and "$($Ctx['RevisionFor'])" -eq $payloadRun) {
        if (-not $Payload.ContainsKey('BaseProjectStateRevision'))     { $Payload['BaseProjectStateRevision']     = $Ctx['Revision'] }
        if (-not $Payload.ContainsKey('ExpectedProjectStateRevision')) { $Payload['ExpectedProjectStateRevision'] = $Ctx['Revision'] }
    }
    # ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§12 canonical identity travels with every event.
    if ($Payload.ContainsKey('PanelSerial') -and "$($Payload['PanelSerial'])") {
        if (-not $Payload.ContainsKey('RawPanelSerial'))       { $Payload['RawPanelSerial'] = "$($Payload['PanelSerial'])" }
        $Payload['CanonicalPanelSerial'] = Get-CanonicalSerial "$($Payload['PanelSerial'])"
    }
    $opsSrc = if ($Payload.ContainsKey('CurrentOPSSerial') -and "$($Payload['CurrentOPSSerial'])") { "$($Payload['CurrentOPSSerial'])" }
              elseif ($Payload.ContainsKey('OPSSerial')) { "$($Payload['OPSSerial'])" } else { '' }
    if ($opsSrc) {
        if (-not $Payload.ContainsKey('RawOPSSerial')) { $Payload['RawOPSSerial'] = $opsSrc }
        $Payload['CanonicalOPSSerial'] = Get-CanonicalSerial $opsSrc
    }
    if ($Payload.ContainsKey('Hostname') -and "$($Payload['Hostname'])") {
        if (-not $Payload.ContainsKey('RawHostname')) { $Payload['RawHostname'] = "$($Payload['Hostname'])" }
        $Payload['CanonicalHostname'] = Get-CanonicalHostname "$($Payload['Hostname'])"
    }
    # r14: room identity travels with every event, exactly like the serials. Room itself is
    # rewritten to the normalized display value; RawRoom preserves what was typed.
    if ($Payload.ContainsKey('Room') -and "$($Payload['Room'])") {
        # ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§21: only synthesize RawRoom when the caller did not supply the technician's own text.
        if (-not $Payload.ContainsKey('RawRoom') -or -not "$($Payload['RawRoom'])") {
            $Payload['RawRoom'] = "$($Payload['Room'])"
        }
        $canonR = Get-CanonicalRoom "$($Payload['Room'])"
        $Payload['CanonicalRoom'] = $canonR
        $Payload['Room'] = $canonR
    }
    if ($Payload.ContainsKey('OtherRoomType') -and "$($Payload['OtherRoomType'])") {
        $Payload['OtherRoomType'] = Get-CanonicalFreeText "$($Payload['OtherRoomType'])"
    }
    return $Payload
}

# ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§8 interpret a v5.5 structured response. Falls back safely for a v5.4.1-era backend
# that only returns { success: true } during the pilot (ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§2.4).
function Read-SheetResponse {
    param($Response)
    $out = @{
        Success   = ($Response -and $Response.success -eq $true)
        Applied   = $false; Duplicate = $false; Retryable = $true
        ErrorCode = ''; Message = ''; Revision = ''; Status = ''
        InventoryReviewRequired = $false; WarningCode = ''; WarningMessage = ''
    }
    if (-not $Response) { return $out }
    foreach ($p in @('applied','duplicate','retryable','errorCode','message','projectStateRevision','projectStatus')) {
        if (-not $Response.PSObject.Properties[$p]) { continue }
        switch ($p) {
            'applied'   { $out.Applied   = ($Response.applied   -eq $true) }
            'duplicate' { $out.Duplicate = ($Response.duplicate -eq $true) }
            'retryable' { $out.Retryable = ($Response.retryable -eq $true) }
            'errorCode' { $out.ErrorCode = "$($Response.errorCode)" }
            'message'   { $out.Message   = "$($Response.message)" }
            'projectStateRevision' { $out.Revision = "$($Response.projectStateRevision)" }
            'projectStatus'        { $out.Status   = "$($Response.projectStatus)" }
        }
    }
    # A backend with no structured contract: success means applied, failure is retryable.
    if (-not $Response.PSObject.Properties['retryable']) { $out.Retryable = -not $out.Success }
    # r7 ruling: the event APPLIED but the current-inventory layer needs review. Never queued,
    # never retried - surfaced so a lead can reconcile the current records.
    if ($Response.PSObject.Properties['detail'] -and $Response.detail -and
        "$($Response.detail.postCommitSyncStatus)" -eq 'Failed') {
        $out.InventoryReviewRequired = $true
        $out.WarningCode    = "$($Response.detail.warningCode)"
        $out.WarningMessage = "$($Response.detail.warningMessage)"
    }
    if ($out.Success -and -not $Response.PSObject.Properties['applied']) { $out.Applied = $true }
    return $out
}
# Permanent business-rule rejections (ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§8.3) - retrying can never make these succeed.
function Get-PermanentErrorCodes {
    return @('ACTIVE_PROJECT_CONFLICT','STALE_PROJECT_REVISION','INVALID_STATE_TRANSITION',
             'DUPLICATE_PROJECT_RUN_ID','DUPLICATE_PANEL_IDENTITY','DUPLICATE_OPS_IDENTITY',
             'INVALID_PAYLOAD','VALIDATION_FAILURE','UNSUPPORTED_CLEAR_FIELD','MANUAL_REVIEW_REQUIRED')
}
function Test-PermanentRejection {
    param($Parsed)
    if (-not $Parsed) { return $false }
    if ($Parsed.ErrorCode -and (Get-PermanentErrorCodes) -contains $Parsed.ErrorCode) { return $true }
    return ((-not $Parsed.Success) -and (-not $Parsed.Retryable))
}

# ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§7.1 the queued file stores the ENVELOPED payload, so replay resends the same EventId,
# EventSequence and EventCreatedAt the backend already knows about.
function Write-QueuedEvent {
    param([hashtable]$Payload, [string]$EventType, [hashtable]$Ctx)
    # The USB can disappear after the initial write probe. Retry the same event locally.
    foreach ($dir in @(@($Ctx['QueueDir'], $Ctx['FallbackQueueDir']) | Where-Object { $_ } | Select-Object -Unique)) {
        $localCtx = $Ctx.Clone()
        $localCtx['QueueDir'] = $dir
        $saved = Write-QueuedEventToDirectory -Payload $Payload -EventType $EventType -Ctx $localCtx
        if ($saved) { return $saved }
    }
    return $null
}
function Write-QueuedEventToDirectory {
    param([hashtable]$Payload, [string]$EventType, [hashtable]$Ctx)
    try {
        $dir = $Ctx['QueueDir']
        if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        if (-not $Payload.ContainsKey('OriginalQueueCreatedAt')) { $Payload['OriginalQueueCreatedAt'] = (Get-Date).ToString('o') }
        $Payload['IsOfflineReplay'] = $true
        $evt = @{
            EventId   = "$($Payload['EventId'])"; RunId = $Ctx['RunId']
            EventType = $EventType; Payload = $Payload
            # v5.5 finding #3: a linked PanelLog (closeout, Phase B) carries only
            # RelatedSummerProjectRunId. Recording just ProjectRunId made those events look
            # unprojected, so they lost per-project ordering and revision chaining on replay.
            ProjectRunId  = $(if ("$($Payload['ProjectRunId'])") { "$($Payload['ProjectRunId'])" } else { "$($Payload['RelatedSummerProjectRunId'])" })
            EventSequence = $Payload['EventSequence']
            EventCreatedAt = "$($Payload['EventCreatedAt'])"
            OriginalQueueCreatedAt = "$($Payload['OriginalQueueCreatedAt'])"
            BaseProjectStateRevision = "$($Payload['BaseProjectStateRevision'])"
            CreatedAt = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
            RetryCount = 0; SyncStatus = 'Pending'; LastSyncAttempt = ''
        }
        # The EventId is "EVT-<date>-<random>", so the FIRST 8 characters are identical for
        # every event. Using them meant two events queued in the same second with the same
        # sequence produced the same filename and one silently overwrote the other. Use the
        # RANDOM tail, and never overwrite an existing file.
        $clean = "$($Payload['EventId'])" -replace '[^A-Za-z0-9]',''
        $stem  = if ($clean.Length -ge 8) { $clean.Substring($clean.Length - 8) } else { $clean.PadLeft(8,'0') }
        $base  = "{0:D6}_{1}_{2}" -f [int]$Payload['EventSequence'], (Get-Date -Format 'yyyyMMdd_HHmmss'), $stem
        $fp = Join-Path $dir "$base.json"
        $n = 1
        while (Test-Path $fp) { $fp = Join-Path $dir ("{0}_{1}.json" -f $base, $n); $n++ }
        # Publish only complete JSON. A failed/partial write must never look replayable.
        $tempPath = $fp + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
        try {
            $bytes = [System.Text.Encoding]::UTF8.GetBytes(($evt | ConvertTo-Json -Depth 12))
            $stream = [System.IO.File]::Open($tempPath,[System.IO.FileMode]::CreateNew,[System.IO.FileAccess]::Write,[System.IO.FileShare]::None)
            try { $stream.Write($bytes,0,$bytes.Length); $stream.Flush($true) } finally { $stream.Dispose() }
            [System.IO.File]::Move($tempPath,$fp)
        } finally {
            if (Test-Path -LiteralPath $tempPath) { Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue }
        }
        return $fp
    } catch { return $null }
}
# r12 finding #2: ONE queue scanner, injected into every runspace with the rest of the sender.
# The main thread had this logic and the runspaces did not, so a background event could post live
# and overtake work the queue was still holding for the same project.
function Test-QueuedWorkInDirs {
    param([string[]]$Dirs, [string]$ProjectRunId)
    if (-not $ProjectRunId) { return $false }
    foreach ($d in @($Dirs | Where-Object { $_ } | Select-Object -Unique)) {
        if (-not (Test-Path $d)) { continue }
        foreach ($f in @(Get-ChildItem -Path $d -Filter '*.json' -ErrorAction SilentlyContinue)) {
            if ($f.Name -like '*.reason.json') { continue }
            $e = $null
            try { $e = Get-Content $f.FullName -Raw | ConvertFrom-Json } catch { continue }
            if (-not $e) { continue }
            $r = "$($e.ProjectRunId)"
            if (-not $r -and $e.Payload) {
                if ($e.Payload.PSObject.Properties['ProjectRunId'])                          { $r = "$($e.Payload.ProjectRunId)" }
                if (-not $r -and $e.Payload.PSObject.Properties['RelatedSummerProjectRunId']) { $r = "$($e.Payload.RelatedSummerProjectRunId)" }
            }
            if ($r -eq $ProjectRunId) { return $true }
        }
    }
    return $false
}
# ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§9 a permanent rejection is preserved for review - never deleted, never forced through.
function Write-RejectedEvent {
    param([hashtable]$Payload, [string]$EventType, $Parsed, [hashtable]$Ctx)
    try {
        $dir = Join-Path $Ctx['QueueDir'] 'Rejected'
        if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        $clean = "$($Payload['EventId'])" -replace '[^A-Za-z0-9]',''
        $stem  = if ($clean.Length -ge 8) { $clean.Substring($clean.Length - 8) } else { $clean.PadLeft(8,'0') }
        $base  = "{0}_{1}" -f (Get-Date -Format 'yyyyMMdd_HHmmss'), $stem
        $fp = Join-Path $dir "$base.json"
        $n = 1
        while (Test-Path $fp) { $fp = Join-Path $dir ("{0}_{1}.json" -f $base, $n); $n++ }
        @{ EventId="$($Payload['EventId'])"; EventType=$EventType; Payload=$Payload
           ProjectRunId="$($Payload['ProjectRunId'])" } | ConvertTo-Json -Depth 12 | Set-Content -Path $fp -Encoding UTF8
        @{ ErrorCode=$Parsed.ErrorCode; ErrorMessage=$Parsed.Message; RejectedAt=(Get-Date).ToString('o')
           CurrentProjectStatus=$Parsed.Status; CurrentProjectStateRevision=$Parsed.Revision
        } | ConvertTo-Json -Depth 6 | Set-Content -Path ($fp + '.reason.json') -Encoding UTF8
        return $fp
    } catch { return $null }
}

# Main-thread sends use WebClient async tasks plus DoEvents so WPF remains responsive; provisioning
# runspaces keep Invoke-RestMethod because they already run off the UI thread.
function Invoke-PanelAppSenderPost {
    param([string]$Uri, [string]$Json, [hashtable]$Ctx)
    $timeout = 25
    if ($Ctx.ContainsKey('RequestTimeoutSeconds')) { try { $timeout=[math]::Min(60,[math]::Max(25,[int]$Ctx['RequestTimeoutSeconds'])) } catch {} }
    if (-not ($Ctx.ContainsKey('Responsive') -and $Ctx['Responsive'])) {
        return (Invoke-RestMethod -Uri $Uri -Method POST -Body $Json -ContentType 'application/json' -TimeoutSec $timeout)
    }
    $wc = New-Object System.Net.WebClient
    $wc.Encoding = [System.Text.Encoding]::UTF8
    $wc.Headers['Accept'] = 'application/json'
    $wc.Headers['Content-Type'] = 'application/json'
    $sw=[System.Diagnostics.Stopwatch]::StartNew()
    try {
        $task=$wc.UploadStringTaskAsync([uri]$Uri,'POST',$Json)
        while (-not $task.IsCompleted) {
            try { [System.Windows.Forms.Application]::DoEvents() } catch {}
            Start-Sleep -Milliseconds 50
            if ($sw.Elapsed.TotalSeconds -ge $timeout) { try { $wc.CancelAsync() } catch {}; throw "PanelApp backend POST timed out after $timeout seconds." }
        }
        try { $txt=[string]$task.Result } catch { $msg=if ($_.Exception.InnerException) {$_.Exception.InnerException.Message}else{$_.Exception.Message}; throw $msg }
        try { return ($txt | ConvertFrom-Json) } catch { return $txt }
    } finally { $sw.Stop(); try { $wc.Dispose() } catch {} }
}

# Shared by UI and background senders: no dependency on main-thread script variables.
function Get-PanelAppEventStatusRemote {
    param([string]$EventId, [hashtable]$Ctx)
    if (-not $EventId -or -not $Ctx.Url) { return $null }
    $url = [string]$Ctx.Url
    $sep = if ($url.Contains('?')) { '&' } else { '?' }
    $uri = $url + $sep + 'action=eventStatus&eventId=' + [uri]::EscapeDataString($EventId)
    try {
        if (-not $Ctx.Responsive) {
            return (Invoke-RestMethod -Uri $uri -Method GET -TimeoutSec 8)
        }
        $wc = New-Object System.Net.WebClient
        $wc.Encoding = [System.Text.Encoding]::UTF8
        $sw = [System.Diagnostics.Stopwatch]::StartNew()
        try {
            $task = $wc.DownloadStringTaskAsync([uri]$uri)
            while (-not $task.IsCompleted) {
                try { [System.Windows.Forms.Application]::DoEvents() } catch {}
                Start-Sleep -Milliseconds 50
                if ($sw.Elapsed.TotalSeconds -ge 8) { $wc.CancelAsync(); return $null }
            }
            return ([string]$task.Result | ConvertFrom-Json)
        } finally { $sw.Stop(); $wc.Dispose() }
    } catch { return $null } # An unavailable receipt must still reach durable queue storage.
}

# THE online sender. Returns a result hashtable; the caller logs in its own idiom.
function Send-PanelAppEvent {
    param([hashtable]$Payload, [string]$EventType, [hashtable]$Ctx)
    Add-EventEnvelope -Payload $Payload -EventType $EventType -Ctx $Ctx | Out-Null
    $url = $Ctx['Url']
    $parsed = $null
    $deliveryError = $false
    $reason = if ($Ctx['QueueHoldReason']) { "$($Ctx['QueueHoldReason'])" }
              elseif ([string]::IsNullOrWhiteSpace($url) -or $url -like '*YOUR_DEPLOYMENT*') { 'PanelApp backend URL is not configured.' }
              elseif ($Ctx['BackendStatus']) { "PanelApp sync check: $($Ctx['BackendStatus']). $($Ctx['BackendStatusDetail'])" }
              else { 'PanelApp sync has not been confirmed available; internet access may still be working.' }
    $online = -not ([string]::IsNullOrWhiteSpace($url) -or $url -like '*YOUR_DEPLOYMENT*' -or ($Ctx.ContainsKey('Online') -and -not $Ctx['Online']))
    if ($online) {
      try {
        $jsonBody = ($Payload | ConvertTo-Json -Compress -Depth 12)
        $r = Invoke-PanelAppSenderPost -Uri $url -Json $jsonBody -Ctx $Ctx
        $parsed = Read-SheetResponse $r
        # ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§5 remember the revision AND which project it belongs to (review finding #5).
        if ($parsed.Revision -ne '') {
            $run = "$($Payload['ProjectRunId'])"; if (-not $run) { $run = "$($Payload['RelatedSummerProjectRunId'])" }
            if ($run) { $Ctx['Revision'] = $parsed.Revision; $Ctx['RevisionFor'] = $run }
        }
        $reason = if ($parsed.ErrorCode) { "$($parsed.ErrorCode): $($parsed.Message)" } else { 'The backend response did not confirm that the event was accepted.' }
      } catch {
        $reason = "$_"
        $deliveryError = $true
      }
    }
    # A response can be lost at the client boundary after Apps Script has already committed
    # the event. Confirm the immutable EventId before telling a technician that work is pending.
    if ($deliveryError -and "$($Payload['EventId'])") {
        $eventState = $null
        try { $eventState = Get-PanelAppEventStatusRemote -EventId "$($Payload['EventId'])" -Ctx $Ctx } catch {}
        $project = "$($Payload['ProjectRunId'])"
        if (-not $project) { $project = "$($Payload['RelatedSummerProjectRunId'])" }
        # Never accept a malformed response or another project's receipt.
        if ($eventState -and $eventState.found -eq $true -and
            "$($eventState.eventId)" -ceq "$($Payload['EventId'])" -and
            "$($eventState.projectRunId)" -ceq $project) {
            $applyStatus = "$($eventState.applyStatus)"
            $wasApplied = ($applyStatus -eq 'Applied')
            $wasDuplicate = ($applyStatus -eq 'Duplicate - Previously Applied')
            # Historical validation failures could mean transient errors. Preserve the backend's
            # existing legacy rule rather than converting them to permanent rejections.
            $wasRejected = ($applyStatus -like 'Rejected -*' -and
                "$($eventState.errorCode)" -ne 'VALIDATION_FAILURE' -and
                (Get-PermanentErrorCodes) -contains "$($eventState.errorCode)")
            if ($wasApplied -or $wasDuplicate -or $wasRejected) {
                $parsed = Read-SheetResponse ([pscustomobject]@{
                    success = ($wasApplied -or $wasDuplicate); applied = $wasApplied
                    duplicate = $wasDuplicate; retryable = (-not $wasRejected)
                    errorCode = $(if ($wasRejected) { "$($eventState.errorCode)" } else { '' })
                    message = "$($eventState.errorMessage)"
                    projectStateRevision = "$($eventState.appliedProjectStateRevision)"
                    projectStatus = "$($eventState.resultingProjectStatus)"
                })
                if ($project -and $parsed.Revision -match '^\d+$' -and
                    ($Ctx.RevisionFor -ne $project -or [int]$parsed.Revision -ge [int]$Ctx.Revision)) {
                    $Ctx['Revision'] = $parsed.Revision; $Ctx['RevisionFor'] = $project
                }
                $reason = if ($wasRejected) { "$($parsed.ErrorCode): $($parsed.Message)" } else { '' }
            }
        }
    }
    if ($parsed -and $parsed.Success) { return @{ Sent=$true; Queued=$false; Rejected=$false; Parsed=$parsed; Reason='' } }
    if ($parsed -and (Test-PermanentRejection $parsed)) {
        Write-RejectedEvent -Payload $Payload -EventType $EventType -Parsed $parsed -Ctx $Ctx | Out-Null
        return @{ Sent=$false; Queued=$false; Rejected=$true; Parsed=$parsed; Reason=$parsed.ErrorCode }
    }
    $saved = Write-QueuedEvent -Payload $Payload -EventType $EventType -Ctx $Ctx
    if (-not $saved) {
        $failure = New-Object System.IO.IOException("PanelApp could not confirm delivery or save event $($Payload['EventId']) to either the portable or local queue. Stop this workflow and contact a lead. Keep this window open; do not repeat the submission or reimage this device.")
        $failure.Data['PanelAppPersistenceFailure'] = $true
        throw $failure
    }
    return @{ Sent=$false; Queued=$true; Rejected=$false; Parsed=$parsed; Reason=$reason; QueuePath=$saved }
}
}
. $script:SenderDefs   # main thread

$script:ClientSessionId  = [guid]::NewGuid().ToString('N').Substring(0,12).ToUpperInvariant()
$script:ClientDeviceName = $env:COMPUTERNAME
$script:EventSequence    = 0
# Latest server revision this client knows, and the project it belongs to (ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§5).
$script:ProjectStateRevision = ''

# Build the sender context from main-thread state. Sequence/Revision are written back
# so the shared functions can advance them.
# v5.5 finding #5: adopt the revision a resumed Summer row already carries, so optimistic
# concurrency stays ACTIVE across a continuation instead of silently switching off.
# r5 finding #2: NEVER move a project revision backward. $Rec is a snapshot read BEFORE any
# work happened, so restoring it after a state-changing event (e.g. LegacyRecoveryCleared, which
# advances 4 -> 5) would re-assert the pre-event value and the next post is rejected as stale.
# That is precisely the Windows 11 24H2 rehabilitation path, so this must stay one-directional.
function Restore-ProjectRevision {
    param($Rec)
    if (-not $Rec) { return }
    $rev = "$($Rec.ProjectStateRevision)"
    $run = "$($Rec.ProjectRunId)"
    if (-not ($rev -and $run)) {
        # Pre-v5.5 row with no revision: only clear when we do not already know something newer
        # for this same project.
        if ($script:ProjectStateRevisionFor -ne $run) {
            $script:ProjectStateRevision = ''; $script:ProjectStateRevisionFor = ''
        }
        return
    }
    $rowRev = 0; [void][int]::TryParse($rev, [ref]$rowRev)
    $curRev = 0; [void][int]::TryParse("$($script:ProjectStateRevision)", [ref]$curRev)
    if ($script:ProjectStateRevisionFor -eq $run -and $curRev -ge $rowRev) {
        Write-Log "Keeping in-session revision $curRev for $run (row snapshot was $rowRev)."
        return
    }
    $script:ProjectStateRevision    = "$rowRev"
    $script:ProjectStateRevisionFor = $run
    Write-Log "Adopted project revision $rowRev for $run."
}
# v5.5 review finding #2: EVERY runspace needs the sender context, not a hand-copied subset.
# Where it was missing the runspace posted with a blank AppVersion, so the backend treated it
# as a pre-v5.5 client and the strict envelope guard silently did not apply - which is exactly
# how a bypass hides. Start-ProvisionJob calls this for every sync hashtable.
function Add-SenderContextToSync {
    param([hashtable]$Sync)
    Update-SystemDriveStorageTelemetry
    $Sync['StorageTotalGB']          = $script:StorageTotalGB
    $Sync['StorageUsedGB']           = $script:StorageUsedGB
    $Sync['StorageFreeGB']           = $script:StorageFreeGB
    $Sync['ClientSessionId']         = $script:ClientSessionId
    $Sync['ClientDeviceName']        = $script:ClientDeviceName
    $Sync['ScriptVersion']           = $script:ScriptVersion
    $Sync['EventSequence']           = $script:EventSequence
    $Sync['ProjectStateRevision']    = $script:ProjectStateRevision
    $Sync['ProjectStateRevisionFor'] = $script:ProjectStateRevisionFor
    if (-not $Sync.ContainsKey('AppScriptUrl'))    { $Sync['AppScriptUrl']    = $script:Config.AppScriptUrl }
    if (-not $Sync.ContainsKey('ProvisioningDir')) { $Sync['ProvisioningDir'] = $script:ProvisioningDir }
    if (-not $Sync.ContainsKey('UsbRoot'))         { $Sync['UsbRoot']         = $script:UsbRoot }
    if (-not $Sync.ContainsKey('QueueDir'))        { $Sync['QueueDir']        = Get-QueueDir }
    if (-not $Sync.ContainsKey('ScriptDir'))       { $Sync['ScriptDir']       = $script:ScriptDir }
    if (-not $Sync.ContainsKey('RunId'))           { $Sync['RunId']           = $script:RunId }
    # r12 finding #2: import a hold that already exists for this sync's project, so the FIRST
    # event the runspace sends cannot overtake main-thread work still sitting in the queue.
    $syncRun = "$($Sync['ProjectRunId'])"
    if (-not $syncRun) { $syncRun = "$($Sync['RelatedSummerRunId'])" }
    if (-not $syncRun) { $syncRun = "$($Sync['RelatedSummerProjectRunId'])" }
    if ($syncRun -and (Test-ProjectHasQueuedWork $syncRun)) {
        $Sync['PendingQueuedProjectRunId'] = $syncRun
        Write-Log "Project $syncRun has queued work - the background job will queue behind it." 'WARN'
    }
    return $Sync
}
# Pull the sequence/revision a finished runspace advanced back into main-thread state.
# MONOTONIC (r5 finding #1): the sync is a snapshot from whenever the runspace last posted.
# Adopting it unconditionally walked the revision BACKWARD when a main-thread event had since
# advanced it - e.g. runspace at 5, main thread reaches 6, next merge drops back to 5 and the
# following post is rejected as stale. Only ever move forward, and only within one project.
function Merge-SyncSenderContext {
    param([hashtable]$Sync)
    if (-not $Sync) { return }
    if ($Sync.ContainsKey('EventSequence')) {
        $n = 0; [void][int]::TryParse("$($Sync['EventSequence'])", [ref]$n)
        if ($n -gt $script:EventSequence) { $script:EventSequence = $n }
    }
    # r6 finding #2: a runspace that had to queue an event marks the project here; the main
    # thread must adopt that hold so a later LIVE event cannot overtake the queued one.
    $pendingRun = "$($Sync['PendingQueuedProjectRunId'])"
    if ($pendingRun) { $script:PendingQueuedProjects[$pendingRun] = $true }
    # v5.5.1 ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§12: Phase B runs in a runspace; the closeout payload is built on the MAIN thread,
    # so the join result has to come back or closeout would resend the pre-provisioning state.
    foreach ($k in @('DomainJoinTargetDomain','DomainJoinCompletedAt',
                     'PostJoinMembershipStatus','PostJoinSecureChannelStatus','AssessmentHostname')) {
        if ($Sync.ContainsKey($k) -and "$($Sync[$k])") { Set-Variable -Name $k -Scope Script -Value "$($Sync[$k])" }
    }
    if ($Sync.ContainsKey('Hostname') -and "$($Sync['Hostname'])") { $script:Hostname = "$($Sync['Hostname'])" }
    $incomingRun = "$($Sync['ProjectStateRevisionFor'])"
    if (-not $incomingRun) { return }
    $incomingRev = 0; [void][int]::TryParse("$($Sync['ProjectStateRevision'])", [ref]$incomingRev)
    $currentRev  = 0; [void][int]::TryParse("$($script:ProjectStateRevision)", [ref]$currentRev)
    # Adopt when we know nothing, when the project changed, or when the runspace is genuinely ahead.
    if ((-not $script:ProjectStateRevisionFor) -or
        ($script:ProjectStateRevisionFor -ne $incomingRun) -or
        ($incomingRev -gt $currentRev)) {
        $script:ProjectStateRevision    = "$incomingRev"
        $script:ProjectStateRevisionFor = $incomingRun
    }
}
# r6 finding #2: the in-memory map only knows about events THIS process queued. The queue
# directory is the real source of truth - it also covers a runspace queue we have not merged
# yet, and work left behind by a previous launch. Checked before every live post.
function Test-ProjectHasQueuedWork {
    param([string]$ProjectRunId)
    if (-not $ProjectRunId) { return $false }
    if ($script:PendingQueuedProjects.ContainsKey($ProjectRunId)) { return $true }
    if (Test-QueuedWorkInDirs -Dirs (Get-QueueDirs) -ProjectRunId $ProjectRunId) {
        $script:PendingQueuedProjects[$ProjectRunId] = $true
        return $true
    }
    return $false
}
function Get-MainSenderContext {
    # Adopt whatever a background runspace advanced since the last main-thread send.
    if ($script:ActiveSenderSync) { Merge-SyncSenderContext $script:ActiveSenderSync }
    Update-SystemDriveStorageTelemetry
    return @{
        Url = $script:Config.AppScriptUrl; QueueDir = (Get-QueueDir)
        FallbackQueueDir = (Join-Path $script:ProvisioningDir 'OfflineQueue')
        StorageTotalGB = $script:StorageTotalGB; StorageUsedGB = $script:StorageUsedGB; StorageFreeGB = $script:StorageFreeGB
        SessionId = $script:ClientSessionId; DeviceName = $script:ClientDeviceName
        ScriptVersion = $script:ScriptVersion; RunId = $script:RunId
        Sequence = $script:EventSequence
        Revision = $script:ProjectStateRevision; RevisionFor = $script:ProjectStateRevisionFor
        Online = [bool]$script:IsNetworkAvailable
        BackendStatus = $script:BackendStatus; BackendStatusDetail = $script:BackendStatusDetail
        Responsive = $true
        RequestTimeoutSeconds = $(if ($script:Config.BackendRequestTimeoutSeconds) { [math]::Min(60, [math]::Max(25, [int]$script:Config.BackendRequestTimeoutSeconds)) } else { 25 })
    }
}
function Sync-MainSenderContext {
    param([hashtable]$Ctx)
    $script:EventSequence            = [int]$Ctx['Sequence']
    $script:ProjectStateRevision     = "$($Ctx['Revision'])"
    $script:ProjectStateRevisionFor  = "$($Ctx['RevisionFor'])"
    # r5 finding #1: push the newer values back into the LIVE runspace sync so the next merge
    # cannot re-import a stale snapshot. Together with the monotonic merge this makes the
    # revision strictly non-decreasing regardless of which thread advanced it last.
    if ($script:ActiveSenderSync) {
        $script:ActiveSenderSync['EventSequence'] = $script:EventSequence
        if ("$($Ctx['RevisionFor'])") {
            $script:ActiveSenderSync['ProjectStateRevision']    = "$($Ctx['Revision'])"
            $script:ActiveSenderSync['ProjectStateRevisionFor'] = "$($Ctx['RevisionFor'])"
        }
    }
}
# Thin main-thread wrappers over the ONE shared sender in $script:SenderDefs.
function Save-OfflineEvent {
    param([hashtable]$Payload, [string]$EventType = 'Event')
    $ctx = Get-MainSenderContext
    $fp = Write-QueuedEvent -Payload $Payload -EventType $EventType -Ctx $ctx
    Sync-MainSenderContext $ctx
    if ($fp) { Write-Log "Event queued offline (seq $($Payload['EventSequence']), $($Payload['EventId'])): $fp" 'WARN'; return $true }
    Write-Log 'Could not queue offline event.' 'ERROR'; return $false
}
function Save-RejectedEvent {
    param([hashtable]$Payload, [string]$EventType, $Parsed)
    $ctx = Get-MainSenderContext
    return (Write-RejectedEvent -Payload $Payload -EventType $EventType -Parsed $Parsed -Ctx $ctx)
}
# ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§9.1 a permanently rejected QUEUE FILE is preserved for review, never deleted or forced.
function Move-ToRejectedQueue {
    param([string]$FilePath, $Parsed)
    try {
        $rejDir = Join-Path (Split-Path $FilePath -Parent) 'Rejected'
        if (-not (Test-Path $rejDir)) { New-Item -ItemType Directory -Path $rejDir -Force | Out-Null }
        $name = Split-Path $FilePath -Leaf
        $dest = Join-Path $rejDir $name
        Move-Item -Path $FilePath -Destination $dest -Force -ErrorAction Stop
        @{
            ErrorCode = $Parsed.ErrorCode; ErrorMessage = $Parsed.Message
            RejectedAt = (Get-Date).ToString('o')
            CurrentProjectStatus = $Parsed.Status
            CurrentProjectStateRevision = $Parsed.Revision
        } | ConvertTo-Json -Depth 6 | Set-Content -Path ($dest + '.reason.json') -Encoding UTF8
        Write-Log "Queued event permanently rejected ($($Parsed.ErrorCode)) - moved to Rejected: $name" 'ERROR'
        return $dest
    } catch { Write-Log "Could not move rejected event: $_" 'ERROR'; return $null }
}
# MAIN-THREAD equivalent of the runspace-only Post-Log (which lives in $script:RunnerDefs).
# Main-runspace callers (recommendation / provisioning routing) must use THIS, not Post-Log.
# $EventType is the exact v5.5 lifecycle name and is mandatory - a generic default is what let
# lifecycle meaning get lost (review finding #3).
function Post-MainLog {
    param([hashtable]$Data, [Parameter(Mandatory)][string]$EventType)
    if (-not $Data.ContainsKey('Timestamp')) { $Data['Timestamp'] = Get-Date -Format 'yyyy-MM-dd HH:mm:ss' }
    if (-not $Data.ContainsKey('TechName'))  { $Data['TechName']  = $script:TechName }
    if ($script:RunId -and -not $Data.ContainsKey('RunId')) { $Data['RunId'] = $script:RunId }
    # r8 finding #4: RETURN the result. State-critical callers must be able to stop when the
    # backend permanently rejects - otherwise a tech physically provisions a panel whose
    # project never entered that path in the spreadsheet.
    return Send-Event -Payload $Data -EventType $EventType
}
# Main-thread entry point. Delegates to Send-PanelAppEvent so there is exactly ONE
# online POST implementation shared with every background runspace.
# r5 finding #3: returns a STATUS, not a bare Boolean. Callers that gate irreversible actions
# (Phase B closeout, final closeout + reboot + state archival) must be able to tell
# Applied / Duplicate / Queued / Rejected apart. `if (Send-Event ...)` still behaves sanely
# because only Applied/Duplicate are truthy via .Delivered.
function Send-Event {
    param([hashtable]$Payload, [string]$EventType = 'Event')
    if ($script:RunId -and -not $Payload.ContainsKey('RunId')) { $Payload['RunId'] = $script:RunId }
    $ctx = Get-MainSenderContext
    # r5 finding #3 (ordering): if this project already has queued work, send this event to the
    # queue too. Otherwise a live closeout can reach the backend BEFORE a queued PhaseBCompleted
    # that the network dropped, and the lifecycle applies out of order.
    $thisRun = "$($Payload['ProjectRunId'])"; if (-not $thisRun) { $thisRun = "$($Payload['RelatedSummerProjectRunId'])" }
    if ($thisRun -and (Test-ProjectHasQueuedWork $thisRun)) {
        Write-Log "Project $thisRun has queued work - queueing $EventType behind it to preserve order." 'WARN'
        $ctx['Online'] = $false
        $ctx['QueueHoldReason'] = 'Waiting for earlier saved events in this project to synchronize in order.'
    }
    $res = Send-PanelAppEvent -Payload $Payload -EventType $EventType -Ctx $ctx
    Sync-MainSenderContext $ctx
    $status = 'Queued'
    if ($res.Sent)          { $status = if ($res.Parsed -and $res.Parsed.Duplicate) { 'Duplicate' } else { 'Applied' } }
    elseif ($res.Rejected)  { $status = 'Rejected' }
    if ($status -eq 'Duplicate') { Write-Log "Event $($Payload['EventId']) was already applied - backend treated it as a duplicate." }
    # r7 ruling: applied, but the current-inventory layer could not be synchronized.
    if ($res.Parsed -and $res.Parsed.InventoryReviewRequired) {
        $status = 'Applied - Inventory Review Required'
        Write-Log ("Event applied, but current inventory needs review ($($res.Parsed.WarningCode)): " +
                   "$($res.Parsed.WarningMessage)") 'WARN'
    }
    if ($status -eq 'Rejected') {
        Write-Log "Apps Script PERMANENTLY rejected ($EventType / $($res.Parsed.ErrorCode)): $($res.Parsed.Message)" 'ERROR'
        $script:LastRejection = $res.Parsed
    }
    if ($status -eq 'Queued') {
        Write-Log "Event not delivered ($EventType): $($res.Reason) -- saved for synchronization." 'WARN'
        # r5 finding #3: once a project has queued work, later LIVE events must not leapfrog it.
        $run = "$($Payload['ProjectRunId'])"; if (-not $run) { $run = "$($Payload['RelatedSummerProjectRunId'])" }
        if ($run) { $script:PendingQueuedProjects[$run] = $true }
    }
    return [pscustomobject]@{
        Status    = $status
        Delivered = ($status -like 'Applied*' -or $status -eq 'Duplicate')
        Queued    = ($status -eq 'Queued')
        Rejected  = ($status -eq 'Rejected')
        Parsed    = $res.Parsed
        EventId   = "$($Payload['EventId'])"
        Reason    = "$($res.Reason)"
        QueuePath = "$($res.QueuePath)"
    }
}
# ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§7.2 replay is ORDERED and SEQUENTIAL, grouped per project. Sending a project's queued
# lifecycle events concurrently (or out of order) is what lets an old event land on top of
# newer work, so each project's chain is walked one event at a time and stops on the first
# permanent rejection (ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§7.3).
function Flush-OfflineQueue {
    $url = $script:Config.AppScriptUrl
    if ([string]::IsNullOrWhiteSpace($url) -or $url -like '*YOUR_DEPLOYMENT*' -or -not $script:IsNetworkAvailable) { return }
    $items = @()
    foreach ($d in (Get-QueueDirs)) {
        if (-not (Test-Path $d)) { continue }
        foreach ($f in @(Get-ChildItem -Path $d -Filter '*.json' -ErrorAction SilentlyContinue)) {
            if ($f.Name -like '*.reason.json') { continue }
            $evt = $null
            try { $evt = Get-Content $f.FullName -Raw | ConvertFrom-Json } catch { continue }
            if (-not $evt) { continue }
            $seq = 0; if ($evt.PSObject.Properties['EventSequence']) { [void][int]::TryParse("$($evt.EventSequence)", [ref]$seq) }
            $created = $f.CreationTimeUtc
            if ($evt.PSObject.Properties['EventCreatedAt'] -and "$($evt.EventCreatedAt)") {
                try { $created = [datetime]::Parse("$($evt.EventCreatedAt)") } catch {}
            }
            # v5.5 finding #3: same fallback as Add-EventEnvelope / Write-QueuedEvent, so a
            # linked PanelLog groups under its Summer project instead of looking unprojected.
            $proj = ''
            if ($evt.PSObject.Properties['ProjectRunId']) { $proj = "$($evt.ProjectRunId)" }
            if (-not $proj -and $evt.Payload) {
                if ($evt.Payload.PSObject.Properties['ProjectRunId'])              { $proj = "$($evt.Payload.ProjectRunId)" }
                if (-not $proj -and $evt.Payload.PSObject.Properties['RelatedSummerProjectRunId']) { $proj = "$($evt.Payload.RelatedSummerProjectRunId)" }
            }
            # v5.5 review finding #6: events with NO project are independent of one another.
            # Grouping them all under "" meant a temporary failure on one unlinked exception
            # could reject unrelated unlinked inventory events. Give each its own chain.
            $groupKey = if ($proj) { "P:$proj" } else { "E:$($evt.EventId)" }
            $items += [pscustomobject]@{ File=$f; Evt=$evt; Seq=$seq; Created=$created; Project=$proj; GroupKey=$groupKey }
        }
    }
    if ($items.Count -eq 0) { return }
    Write-Log "Flushing $($items.Count) queued offline event(s) in project order..."
    $syncedProjects = @{}
    # r7 finding #3: track EVERY project we touched, not just the ones that synced. A chain that
    # was permanently rejected leaves no queue files but would otherwise keep its in-memory hold
    # forever, forcing all later work for that project into the queue.
    $processedProjects = @{}

    foreach ($group in ($items | Group-Object GroupKey)) {
        # 'Rejected' = a PERMANENT failure; dependent events are pulled out of the queue.
        # 'Deferred' = a temporary failure; this chain simply stops for THIS flush and every
        # remaining event stays queued untouched (review finding #6).
        $chainRejected = $false
        $chainDeferred = $false
        $stopReason    = ''
        $chainRevision = ''
        foreach ($item in ($group.Group | Sort-Object Seq, Created)) {
            $f = $item.File; $evt = $item.Evt
            if ($item.Project) { $processedProjects[$item.Project] = $true }
            if ($chainDeferred) { continue }   # retained in place, retried on the next flush
            if ($chainRejected) {
                # ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§7.3 the earlier event was permanently rejected, so later events in the chain
                # can never apply either - preserve them for review rather than sending them.
                $blocked = @{
                    ErrorCode = 'CHAIN_STOPPED'
                    Message = "An earlier event in this project's offline chain was permanently rejected ($stopReason). This dependent event was not sent."
                    Status = ''; Revision = ''
                }
                $blockedType = "$($evt.EventType)"; if (-not $blockedType) { $blockedType = "$($evt.Payload.EventType)" }
                $blockedId = "$($evt.EventId)"; if (-not $blockedId) { $blockedId = "$($evt.Payload.EventId)" }
                Update-StateAfterReplayRejection -ProjectRunId $item.Project -EventType $blockedType -EventId $blockedId -Parsed $blocked
                Move-ToRejectedQueue -FilePath $f.FullName -Parsed $blocked | Out-Null
                continue
            }
            $payload = @{}
            foreach ($p in $evt.Payload.PSObject.Properties) { $payload[$p.Name] = $p.Value }
            $payload['IsOfflineReplay'] = $true
            # r7 finding #2: keep the main sequence ahead of everything replayed, or a NEW
            # event after the flush can reuse a number the queued chain already used.
            if ($item.Seq -gt $script:EventSequence) { $script:EventSequence = $item.Seq }
            # ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§7.2.5 chain the revision forward from the previous successful apply, but only
            # when it belongs to THIS project (finding #5).
            # Keep the FIRST event's original expectation. Only a successful predecessor in
            # THIS replay chain can advance it; a live/global revision must not force stale work through.
            if ("$chainRevision" -ne '' -and $item.Project) {
                $payload['ExpectedProjectStateRevision'] = $chainRevision
            }
            $parsed = $null
            try {
                $r = Invoke-ResponsiveWebJson -Uri $url -Method POST -Body ($payload | ConvertTo-Json -Compress -Depth 12) -TimeoutSeconds 25
                $parsed = Read-SheetResponse $r
            } catch {
                Write-Log "Queued event still failing (network), retaining: $($f.Name)" 'WARN'
                Update-QueueRetryMetadata -File $f -Evt $evt
                $chainDeferred = $true; $stopReason = 'network unavailable'
                continue
            }
            if ($parsed.Success) {
                if ($parsed.Revision -ne '' -and $item.Project) {
                    $chainRevision = $parsed.Revision
                    $script:ProjectStateRevision    = $parsed.Revision
                    $script:ProjectStateRevisionFor = $item.Project
                }
                $archive = Join-Path $f.DirectoryName 'sent'
                if (-not (Test-Path $archive)) { New-Item -ItemType Directory -Path $archive -Force | Out-Null }
                Move-Item -Path $f.FullName -Destination (Join-Path $archive $f.Name) -Force -ErrorAction SilentlyContinue
                Write-Log "Synced queued event: $($f.Name)$(if ($parsed.Duplicate) { ' (already applied)' })"
                $syncedProjects[$item.Project] = $true
                # r8 finding #2: persist the applied revision/sequence BEFORE the closeout check,
                # so a launch that ends without closeout still resumes from the right revision.
                $replayType = "$($evt.EventType)"; if (-not $replayType) { $replayType = "$($payload['EventType'])" }
                Update-StateSenderAfterReplay -ProjectRunId $item.Project -EventType $replayType `
                    -Parsed $parsed -EventSequence ([int]$item.Seq)
                # r7 finding #1: the queued FINAL CLOSEOUT just landed - retire the local pending
                # state so the next launch does not reopen closeout for a completed project.
                Complete-QueuedCloseoutIfMatched -Evt $evt -Payload $payload -Project $item.Project
                Complete-QueuedExceptionIfMatched -Evt $evt -Payload $payload -Project $item.Project
                continue
            }
            if (Test-PermanentRejection $parsed) {
                # r9 finding #1: reconcile the LOCAL state before archiving, so a rejected queued
                # Phase B / closeout cannot leave state.json claiming Queued/Pending.
                $rejType = "$($evt.EventType)"; if (-not $rejType) { $rejType = "$($payload['EventType'])" }
                $rejId   = "$($payload['EventId'])"; if (-not $rejId) { $rejId = "$($evt.EventId)" }
                Update-StateAfterReplayRejection -ProjectRunId $item.Project -EventType $rejType `
                    -EventId $rejId -Parsed $parsed
                # ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§7.3 do NOT rewrite the expected revision and force it through.
                Move-ToRejectedQueue -FilePath $f.FullName -Parsed $parsed | Out-Null
                $chainRejected = $true; $stopReason = $parsed.ErrorCode
                $script:LastRejection = $parsed
                if ($parsed.ErrorCode -eq 'STALE_PROJECT_REVISION') {
                    Write-Log ("Queued work for project $($item.Project) is OLDER than the spreadsheet " +
                               "(sheet is at revision $($parsed.Revision) / '$($parsed.Status)'). " +
                               "Remaining queued events for this project were not applied.") 'ERROR'
                }
                continue
            }
            # Retryable (LOCK_TIMEOUT / rate limit / temporary backend): keep it AND everything
            # after it. Nothing is rejected and nothing is lost.
            Write-Log "Queued event deferred ($($parsed.ErrorCode)) - retained for the next flush: $($f.Name)" 'WARN'
            Update-QueueRetryMetadata -File $f -Evt $evt
            $chainDeferred = $true; $stopReason = "$($parsed.ErrorCode)"
        }
    }
    # r5 finding #3: a project is only released from the pending-queue hold once NOTHING of its
    # work is still queued - otherwise a live event could still overtake a leftover file.
    foreach ($proj in @($processedProjects.Keys)) {
        if (-not $proj) { continue }
        $stillQueued = $false
        foreach ($d in (Get-QueueDirs)) {
            if (-not (Test-Path $d)) { continue }
            foreach ($qf2 in @(Get-ChildItem -Path $d -Filter '*.json' -ErrorAction SilentlyContinue)) {
                if ($qf2.Name -like '*.reason.json') { continue }
                $e2 = $null
                try { $e2 = Get-Content $qf2.FullName -Raw | ConvertFrom-Json } catch { continue }
                if (-not $e2) { continue }
                $p2 = "$($e2.ProjectRunId)"
                if (-not $p2 -and $e2.Payload) {
                    if ($e2.Payload.PSObject.Properties['ProjectRunId']) { $p2 = "$($e2.Payload.ProjectRunId)" }
                    if (-not $p2 -and $e2.Payload.PSObject.Properties['RelatedSummerProjectRunId']) { $p2 = "$($e2.Payload.RelatedSummerProjectRunId)" }
                }
                if ($p2 -eq $proj) { $stillQueued = $true; break }
            }
            if ($stillQueued) { break }
        }
        if (-not $stillQueued -and $script:PendingQueuedProjects.ContainsKey($proj)) {
            $script:PendingQueuedProjects.Remove($proj) | Out-Null
            if ($script:ActiveSenderSync -and "$($script:ActiveSenderSync['PendingQueuedProjectRunId'])" -eq $proj) {
                $script:ActiveSenderSync['PendingQueuedProjectRunId'] = ''
            }
            Write-Log "Project $proj queue fully drained - live sending resumed."
        }
    }
    if ($script:LastRejection) { Show-QueueRejectionNotice }
}
# r8 finding #2: a replayed PhaseBCompleted advances the revision IN MEMORY, but if the tech
# closes PanelApp before finishing closeout the next launch reads the stale state file and the
# closeout is rejected as stale. Persist the applied revision/sequence after every replay.
function Update-StateSenderAfterReplay {
    param([string]$ProjectRunId, [string]$EventType, $Parsed, [int]$EventSequence)
    if (-not $ProjectRunId) { return }
    $statePath = Join-Path $script:ProvisioningDir 'state.json'
    if (-not (Test-Path $statePath)) { return }
    try {
        $state = Get-Content $statePath -Raw | ConvertFrom-Json
        if ("$($state.RelatedSummerRunId)" -ne $ProjectRunId) { return }
        if ("$($Parsed.Revision)") {
            $state | Add-Member -NotePropertyName ProjectStateRevision    -NotePropertyValue "$($Parsed.Revision)" -Force
            $state | Add-Member -NotePropertyName ProjectStateRevisionFor -NotePropertyValue $ProjectRunId         -Force
        }
        $storedSeq = 0; [void][int]::TryParse("$($state.EventSequence)", [ref]$storedSeq)
        if ($EventSequence -gt $storedSeq) { $state | Add-Member -NotePropertyName EventSequence -NotePropertyValue $EventSequence -Force }
        if ($EventType -eq 'PhaseBCompleted') {
            $state | Add-Member -NotePropertyName PhaseBBackendStatus -NotePropertyValue 'Applied' -Force
            $state | Add-Member -NotePropertyName FinalCloseoutStatus -NotePropertyValue 'Pending' -Force
        }
        $state | ConvertTo-Json -Depth 12 | Set-Content -Path $statePath -Encoding UTF8
    } catch { Write-Log "Could not update state after replay: $_" 'WARN' }
}
# r9 finding #1: a queued lifecycle event that is PERMANENTLY rejected during replay must
# reconcile the local state too. Otherwise state.json still says Queued/Pending and the next
# launch happily opens closeout for a phase the spreadsheet never accepted.
function Update-StateAfterReplayRejection {
    param([string]$ProjectRunId, [string]$EventType, [string]$EventId, $Parsed)
    if (-not $ProjectRunId) { return }
    $statePath = Join-Path $script:ProvisioningDir 'state.json'
    if (-not (Test-Path $statePath)) { return }
    try {
        $state = Get-Content $statePath -Raw | ConvertFrom-Json
        if ("$($state.RelatedSummerRunId)" -ne $ProjectRunId) { return }
        if ($EventType -eq 'PhaseBCompleted') {
            $state | Add-Member -NotePropertyName PhaseBBackendStatus       -NotePropertyValue 'Rejected' -Force
            $state | Add-Member -NotePropertyName FinalCloseoutStatus       -NotePropertyValue 'Blocked'  -Force
            $state | Add-Member -NotePropertyName PhaseBBackendErrorCode    -NotePropertyValue "$($Parsed.ErrorCode)" -Force
            $state | Add-Member -NotePropertyName PhaseBBackendErrorMessage -NotePropertyValue "$($Parsed.Message)"   -Force
        }
        if ($EventType -eq 'FinalCloseoutCompleted') {
            $state | Add-Member -NotePropertyName CloseoutBackendStatus       -NotePropertyValue 'Rejected' -Force
            $state | Add-Member -NotePropertyName FinalCloseoutStatus         -NotePropertyValue 'Blocked'  -Force
            $state | Add-Member -NotePropertyName CloseoutBackendErrorCode    -NotePropertyValue "$($Parsed.ErrorCode)" -Force
            $state | Add-Member -NotePropertyName CloseoutBackendErrorMessage -NotePropertyValue "$($Parsed.Message)"   -Force
            $state | Add-Member -NotePropertyName RejectedCloseoutEventId     -NotePropertyValue $EventId -Force
            # The pending pin must go, or the closeout button keeps claiming "still pending".
            $state | Add-Member -NotePropertyName PendingCloseoutEventId      -NotePropertyValue '' -Force
        }
        if ($EventType -eq 'Exception' -and $EventId -and "$($state.PendingExceptionEventId)" -eq $EventId) {
            # r10 finding #2: the tech was told this panel is Exception Open. It never was, so the
            # closeout must be re-opened rather than left "reported" against nothing.
            $state | Add-Member -NotePropertyName CloseoutExceptionStatus       -NotePropertyValue 'Rejected' -Force
            $state | Add-Member -NotePropertyName FinalCloseoutStatus           -NotePropertyValue 'Blocked'  -Force
            $state | Add-Member -NotePropertyName CloseoutExceptionErrorCode    -NotePropertyValue "$($Parsed.ErrorCode)" -Force
            $state | Add-Member -NotePropertyName CloseoutExceptionErrorMessage -NotePropertyValue "$($Parsed.Message)"   -Force
            $state | Add-Member -NotePropertyName PendingExceptionEventId       -NotePropertyValue '' -Force
        }
        $state | ConvertTo-Json -Depth 12 | Set-Content -Path $statePath -Encoding UTF8
        Write-Log "Rejected queued $EventType reconciled with state.json ($($Parsed.ErrorCode))." 'WARN'
    } catch { Write-Log "Could not reconcile rejected queued event with state.json: $_" 'WARN' }
}
# r7 finding #1: archive the local pending state once the queued final closeout actually
# applies. Matches on the EXACT EventId recorded when the closeout was queued, falling back to
# event type + project for a state file written before that field existed.
function Complete-QueuedCloseoutIfMatched {
    param($Evt, [hashtable]$Payload, [string]$Project)
    $type = "$($Evt.EventType)"; if (-not $type) { $type = "$($Payload['EventType'])" }
    if ($type -ne 'FinalCloseoutCompleted') { return }
    try {
        $sf = Join-Path $script:ProvisioningDir 'state.json'
        if (-not (Test-Path $sf)) { return }
        $st = Get-Content $sf -Raw | ConvertFrom-Json
        $eid = "$($Payload['EventId'])"; if (-not $eid) { $eid = "$($Evt.EventId)" }
        $pinned  = "$($st.PendingCloseoutEventId)"
        $stProj  = "$($st.RelatedSummerRunId)"
        $matched = ($Project -and $stProj -eq $Project -and $eid -and ((-not $pinned) -or $pinned -eq $eid))
        if (-not $matched) { return }
        # Persist acceptance before archiving. A file-move failure must not turn an accepted
        # closeout back into a pending submission or cause a second event on retry.
        $st | Add-Member -NotePropertyName CloseoutBackendStatus -NotePropertyValue 'Applied' -Force
        $st | Add-Member -NotePropertyName FinalCloseoutStatus -NotePropertyValue 'Complete' -Force
        $st | Add-Member -NotePropertyName CompletedCloseoutEventId -NotePropertyValue $eid -Force
        $st | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $sf -Encoding UTF8 -ErrorAction Stop
        $script:LastSyncedCloseout = [pscustomobject]@{
            ProjectRunId = $stProj; EventId = $eid; Hostname = "$($st.Hostname)"; PanelSerial = "$($st.PanelSerial)"
        }
        $dest = Join-Path $script:ProvisioningDir "state.closeout_synced_$(Get-Date -Format 'yyyyMMdd_HHmmss').json"
        Move-Item -Path $sf -Destination $dest -Force -ErrorAction Stop
        $script:ResumeCloseoutPending = $false
        Write-Log "Queued final closeout ($eid) synced - local pending state archived; closeout will not reopen."
    } catch { Write-Log "Queued closeout synced, but local state cleanup failed: $_" 'WARN' }
}
# r12 finding #1: the closeout counterpart for a QUEUED EXCEPTION. When that exact event applies
# (or the backend reports it already applied), the project genuinely is Exception Open and the
# retained state can be archived. Until then the state file stays put so a permanent rejection
# can still be reconciled locally.
function Complete-QueuedExceptionIfMatched {
    param($Evt, [hashtable]$Payload, [string]$Project)
    $type = "$($Evt.EventType)"; if (-not $type) { $type = "$($Payload['EventType'])" }
    if ($type -ne 'Exception') { return }
    try {
        $sf = Join-Path $script:ProvisioningDir 'state.json'
        if (-not (Test-Path $sf)) { return }
        $st = Get-Content $sf -Raw | ConvertFrom-Json
        $pinned = "$($st.PendingExceptionEventId)"
        if (-not $pinned) { return }
        $eid = "$($Payload['EventId'])"; if (-not $eid) { $eid = "$($Evt.EventId)" }
        if ($pinned -ne $eid) { return }
        $stProj = "$($st.PendingExceptionProject)"
        if (-not $stProj) { $stProj = "$($st.RelatedSummerRunId)" }
        if ($Project -and $stProj -and $stProj -ne $Project) { return }
        $dest = Join-Path $script:ProvisioningDir "state.exception_synced_$(Get-Date -Format 'yyyyMMdd_HHmmss').json"
        Move-Item -Path $sf -Destination $dest -Force -ErrorAction Stop
        $script:ResumeCloseoutPending = $false
        Write-Log "Queued closeout exception ($eid) synced - the project is Exception Open; local state archived."
    } catch { Write-Log "Queued exception synced, but local state cleanup failed: $_" 'WARN' }
}
function Update-QueueRetryMetadata {
    param($File, $Evt)
    try {
        $rc = 0; if ($Evt.PSObject.Properties['RetryCount']) { $rc = [int]$Evt.RetryCount }
        $Evt | Add-Member -NotePropertyName RetryCount -NotePropertyValue ($rc + 1) -Force
        $Evt | Add-Member -NotePropertyName LastSyncAttempt -NotePropertyValue (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') -Force
        $Evt | ConvertTo-Json -Depth 12 | Set-Content -Path $File.FullName -Encoding UTF8
    } catch {}
}
# ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§7.3 the technician must be told plainly that the sheet is ahead of their queued work.
function Show-QueueRejectionNotice {
    $r = $script:LastRejection
    $script:LastRejection = $null
    if (-not $r) { return }
    $msg = if ($r.ErrorCode -eq 'STALE_PROJECT_REVISION') {
        "Some work saved on this flash drive could not be applied.`n`nThe project in the spreadsheet is NEWER than the queued work" +
        $(if ($r.Status) { " (it is now '$($r.Status)')" }) + ".`n`nThe queued events were preserved in the Rejected folder for review. " +
        "Nothing in the spreadsheet was overwritten."
    } else {
        "Some work saved on this flash drive could not be applied.`n`nReason: $($r.ErrorCode)`n$($r.Message)`n`n" +
        "The events were preserved in the Rejected folder for review."
    }
    try { [System.Windows.MessageBox]::Show($msg, 'Queued Work Not Applied', 'OK', 'Warning') | Out-Null } catch { Write-Log $msg 'WARN' }
}

# ================================================================
#  SUMMER CONTINUATION + ISSUE-REPORT SCREEN HELPERS (v5.2 Phase 3/4)
# ================================================================
# Populate the continuation confirm screen (does NOT show it). The RedoRescue gate
# reveals it on pass; a direct show is done via Show-SummerContinuation below.
function Prepare-SummerContinuation {
    param($Rec)
    $script:SummerRecord = $Rec
    $origOPS = if ($Rec.OriginalOPSSerial) { "$($Rec.OriginalOPSSerial)" }
               elseif ($Rec.OPSSerial)     { "$($Rec.OPSSerial)" } else { '' }
    # v5.3.3 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§3: restore the saved Room Type so it carries through provisioning without re-entry
    $script:RoomType      = "$($Rec.RoomType)"
    $script:OtherRoomType = "$($Rec.OtherRoomType)"
    $rtDisp = if ($script:RoomType -eq 'Other' -and $script:OtherRoomType) { "Other - $($script:OtherRoomType)" } else { "$($script:RoomType)" }
    $script:UI['lblCont_School'].Text  = "$($Rec.SchoolName) ($($Rec.SchoolCode))"
    $script:UI['lblCont_Room'].Text    = if ($rtDisp) { "$rtDisp / $($Rec.Room)" } else { "$($Rec.Room)" }
    $script:UI['lblCont_Panel'].Text   = "$($Rec.PanelSerial)"
    $script:UI['lblCont_OrigOPS'].Text = $origOPS
    $script:UI['lblCont_CurOPS'].Text  = $script:OPSSerial
    $script:UI['lblCont_Profile'].Text = "$($Rec.ImageProfile)"
    # ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§36: technician-facing screens reference the approved image FOLDER, not the .redo filename
    $folder = "$($Rec.ExpectedImageFolder)"
    if (-not $folder -and $Rec.ImageProfile) {
        $p = $script:Config.ReimageProfiles | Where-Object { $_.ProfileId -eq "$($Rec.ImageProfile)" } | Select-Object -First 1
        if ($p -and $p.ExpectedImageFolder) { $folder = "$($p.ExpectedImageFolder)" }
    }
    $script:SummerExpectedFolder = $folder
    $script:UI['lblCont_Redo'].Text    = if ($folder) { $folder } else { '(not recorded - verify with lead)' }
    $script:UI['lblCont_Status'].Text  = "$($Rec.ProjectStatus)"
    $script:UI['lblCont_RunId'].Text   = "$($Rec.ProjectRunId)"
    # ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§37: team handoff - show who assessed it, not just the last update
    $assessedBy = "$($Rec.AssessmentTechnician)"
    $script:UI['lblCont_LastBy'].Text  = if ($assessedBy) { "$($Rec.LastUpdatedBy) (assessed by $assessedBy)" } else { "$($Rec.LastUpdatedBy)" }
    $script:UI['lblCont_LastAt'].Text  = "$($Rec.LastUpdatedAt)"
    $script:UI['chkImageConfirm'].IsChecked = $false
    $script:UI['lblContError'].Visibility = 'Collapsed'
    if ($origOPS -and $script:OPSSerial -and ($origOPS -ne $script:OPSSerial)) {
        $script:UI['borOPSMismatch'].Visibility = 'Visible'
        $script:UI['rdoOPSNo'].IsChecked  = $false
        $script:UI['rdoOPSYes'].IsChecked = $false
    } else {
        $script:UI['borOPSMismatch'].Visibility = 'Collapsed'
    }
}
function Show-SummerContinuation { param($Rec); Prepare-SummerContinuation $Rec; Show-Screen 'pnlSummerContinuation' }

# Block screen when Post-RedoRescue Provisioning is attempted for a panel with no active Summer record.
function Show-NoSummerRecordBlock {
    $script:UI['lblGateTitle'].Text = 'No Active Interactive Inventory Project Record'
    $script:UI['lblGateMsg'].Text = "No active Interactive Inventory Project record was found for this panel serial.`n`nPost-RedoRescue Provisioning is only for devices flagged for reimage during the Interactive Inventory Project Assessment. Run the Interactive Inventory Assessment first, or use Standard / Full Provisioning."
    $script:UI['lblGateState'].Text = "Panel serial: $($script:PanelSerial)`nOPS serial: $($script:OPSSerial)"
    Show-Screen 'pnlRedoGateBlock'
}

# RedoRescue gate (ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§3): verify the current device state looks like the restored Win11 image
# BEFORE allowing Post-RedoRescue Provisioning. Pre-populates the continuation screen so a
# pass can reveal it directly from the background dispatcher.
function Start-RedoRescueGate {
    param($Rec)
    # Weekend field hardening: continuation rows are existing v5.5+ projects, so every
    # state-changing gate/provisioning post must carry the revision the backend last issued.
    # Restore it at the gate boundary so every caller receives the same concurrency protection.
    Restore-ProjectRevision $Rec
    Prepare-SummerContinuation $Rec
    $expectedTier = 0; if ($Rec.StorageTierGB) { try { $expectedTier = [int]$Rec.StorageTierGB } catch {} }
    # Unknown expected tier: derive it from the record's ImageProfile before giving up
    if ($expectedTier -le 0 -and $Rec.ImageProfile) {
        $p = $script:Config.ReimageProfiles | Where-Object { $_.ProfileId -eq "$($Rec.ImageProfile)" } | Select-Object -First 1
        if ($p) { $expectedTier = [int]$p.StorageTier }
    }
    Reset-ProgressScreen 'Verifying Restored Image'
    $sync = [hashtable]::Synchronized(@{
        UI = $script:UI; LogFile = $script:LogFile; ErrorLog = $script:ErrorLog; RunFlags = $script:RunFlags
        TechName = $script:TechName; AppScriptUrl = $script:Config.AppScriptUrl; ScriptDir = $script:ScriptDir
        UsbRoot = $script:UsbRoot; RunId = $script:RunId; ProvisioningDir = $script:ProvisioningDir
        ExpectedTier = $expectedTier
        GatePassedProjectStatus = $(if ("$($Rec.ProjectStatus)" -in @('Pending RedoRescue Restore','Blocked - RedoRescue Not Completed','Reimage Pending','RedoRescue Restored - Pending Provisioning')) { 'RedoRescue Restored - Pending Provisioning' } else { "$($Rec.ProjectStatus)" })
        ClientSessionId = $script:ClientSessionId; ClientDeviceName = $script:ClientDeviceName
        ScriptVersion = $script:ScriptVersion; EventSequence = $script:EventSequence
        ProjectStateRevision = $script:ProjectStateRevision; ProjectStateRevisionFor = $script:ProjectStateRevisionFor
        MinAcceptedVer   = $script:Config.MinimumAcceptedOSDisplayVersion
        ReimageProfiles = $script:Config.ReimageProfiles
        ProjectRunId = "$($Rec.ProjectRunId)"; PanelSerial = $script:PanelSerial; OPSSerial = $script:OPSSerial
    })
    Start-ProvisionJob -Sync $sync -Work {
        try {
            Status 'Reading current OS and disk state...'
            $build = 0; $displayVer = ''; $edition = ''
            try {
                $cv = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -ErrorAction Stop
                $build = [int]$cv.CurrentBuild
                $displayVer = if ($cv.DisplayVersion) { $cv.DisplayVersion } else { $cv.ReleaseId }
                $edition = "$($cv.EditionID)"
            } catch {}
            # OS label uses the real Win10/11 boundary (22000). The gate itself checks Windows 11
            # plus the MINIMUM accepted feature-version rank below - there is no 26200 build floor.
            $isWin11OS  = ($build -ge 22000)
            $osShort = "Windows $(if ($isWin11OS) { '11' } else { '10' }) ($displayVer)"

            $gb = 0; $partStyle = ''
            try { $sysLetter = $env:SystemDrive.TrimEnd(':'); $osDisk = Get-Partition -DriveLetter $sysLetter -ErrorAction Stop | Get-Disk -ErrorAction Stop }
            catch { $osDisk = Get-Disk -ErrorAction SilentlyContinue | Where-Object { $_.BusType -ne 'USB' } | Sort-Object Size -Descending | Select-Object -First 1 }
            if ($osDisk) { $gb = [math]::Round([double]$osDisk.Size / 1GB, 0); $partStyle = "$($osDisk.PartitionStyle)" }
            $tierNum = 0; foreach ($p in $s.ReimageProfiles) { if ($gb -ge [int]$p.MinGB -and $gb -le [int]$p.MaxGB) { $tierNum = [int]$p.StorageTier; break } }
            $firmwareMode = ''; try { $firmwareMode = "$((Get-ComputerInfo -Property BiosFirmwareType -ErrorAction Stop).BiosFirmwareType)" } catch {}

            # HARD gate: for a restored-image proof, UNKNOWN fails - it never passes (ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§2 review fix).
            $blockers = @()
            if ($build -le 0)                    { $blockers += "OS build could not be read" }
            # v5.4: the restore must land on Windows 11 at/above the MINIMUM accepted feature
            # version - not the preferred build - so a valid 24H2 restore is not falsely blocked.
            elseif ($build -lt 22000)            { $blockers += "OS build $build is not Windows 11 - the RedoRescue restore does not appear to have completed" }
            # v5.4 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§2: accept the minimum feature version or newer (rank-based), not an exact match.
            $rankOf = { param($v); if ("$v" -match '^(?<Year>\d{2})H(?<Half>[12])$') { return ([int]$Matches.Year * 10) + [int]$Matches.Half }; return -1 }
            $minAccept = if ($s.MinAcceptedVer) { "$($s.MinAcceptedVer)" } else { '24H2' }
            if (-not $displayVer)                { $blockers += "OS display version could not be read" }
            elseif ((& $rankOf $displayVer) -lt (& $rankOf $minAccept)) { $blockers += "OS version $displayVer is older than the minimum accepted version ($minAccept)" }
            if ($tierNum -le 0)                  { $blockers += "storage tier could not be classified (${gb} GB detected)" }
            elseif ($s.ExpectedTier -le 0)       { $blockers += "expected storage tier could not be determined from the Interactive Inventory record" }
            elseif ($tierNum -ne $s.ExpectedTier){ $blockers += "storage tier ${tierNum}GB does not match expected $($s.ExpectedTier)GB" }
            if (-not $partStyle)                 { $blockers += "partition style could not be read" }
            elseif ($partStyle -ne 'GPT')        { $blockers += "partition is $partStyle (GPT required)" }
            if (-not $firmwareMode)              { $blockers += "firmware mode could not be read" }
            elseif ($firmwareMode -notmatch 'Uefi') { $blockers += "firmware is $firmwareMode (UEFI required)" }
            $stateStr = "OS: $osShort  (build $build)`nStorage: ${gb} GB (tier ${tierNum}GB)`nPartition: $partStyle`nFirmware: $firmwareMode"
            $now = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'

            if ($blockers.Count -gt 0) {
                Log "RedoRescue gate FAILED: $($blockers -join '; ')." 'WARN'
                Post-Log @{
                    LogSheet = 'Summer2026'; ProjectRunId = $s.ProjectRunId
                    PanelSerial = $s.PanelSerial; OPSSerial = $s.OPSSerial
                    ProjectStatus = 'Blocked - RedoRescue Not Completed'; RedoRescueGateStatus = 'Failed'
                    RedoRescueGateReason = ($blockers -join '; ')
                    BlockedReason = ($blockers -join '; ')
                    BlockedAt = $now; BlockedBy = $s.TechName
                    CurrentOSName = $osShort; CurrentOSBuild = $build; CurrentOSDisplayVer = $displayVer
                    CurrentPartitionStyle = $partStyle; CurrentFirmwareMode = $firmwareMode
                    LastUpdatedBy = $s.TechName; LastUpdatedAt = $now
                } 'RedoRescueGateFailed'
                try { $s.UI['pbarProgress'].Dispatcher.Invoke([action]{
                    $s.UI['lblGateTitle'].Text = 'RedoRescue Restore Not Completed'
                    $s.UI['lblGateMsg'].Text = "RedoRescue restore does not appear to match the expected UEFI/GPT Windows 11 image state.`n`nCheck BIOS boot mode, boot order, and CSM/Legacy settings. Restore again using UEFI boot if needed.`n`nIf the restore has not been performed yet, complete the RedoRescue restore first, then boot Windows and reopen PanelApp."
                    $s.UI['lblGateState'].Text = $stateStr
                    $s.UI['pnlProgress'].Visibility = [System.Windows.Visibility]::Collapsed
                    $s.UI['pnlRedoGateBlock'].Visibility = [System.Windows.Visibility]::Visible
                }) } catch {}
                return
            }
            # PASS (all hard checks satisfied)
            Log "RedoRescue gate PASSED: $osShort build $build."
            $gateRes = Post-Log @{
                LogSheet = 'Summer2026'; ProjectRunId = $s.ProjectRunId
                PanelSerial = $s.PanelSerial; OPSSerial = $s.OPSSerial
                ProjectStatus = $s.GatePassedProjectStatus
                RedoRescueGateStatus = 'Passed'; RedoRescueRestoreCompleted = 'Yes'
                RedoRescueRestoreValidatedBy = $s.TechName; RedoRescueRestoreValidatedAt = $now
                RedoRescueGateReason = 'Passed all checks (OS/version/storage/partition/firmware)'
                CurrentOSName = $osShort; CurrentOSBuild = $build; CurrentOSDisplayVer = $displayVer
                CurrentPartitionStyle = $partStyle; CurrentFirmwareMode = $firmwareMode
                LastUpdatedBy = $s.TechName; LastUpdatedAt = $now
            } 'PostRedoRescueProvisioningSelected'
            # r9 finding #2: the gate PASSED locally, but if the spreadsheet rejected the result
            # the project was never advanced - do not offer the continuation screen.
            if ($gateRes -and $gateRes.Rejected) {
                $why = if ($gateRes.Parsed) { "$($gateRes.Parsed.ErrorCode): $($gateRes.Parsed.Message)" } else { 'permanent rejection' }
                Log "RedoRescue gate passed locally but the spreadsheet REJECTED the result ($why)." 'ERROR'
                try { $s.UI['pbarProgress'].Dispatcher.Invoke([action]{
                    $s.UI['pnlProgress'].Visibility = [System.Windows.Visibility]::Collapsed
                    $s.UI['lblGateTitle'].Text = 'Restore Result Not Recorded'
                    $s.UI['lblGateMsg'].Text =
                        "The restore checks passed on this device, but the spreadsheet REJECTED the result, so the project was not advanced.`n`n$why`n`nDo not continue provisioning. Report this to a lead."
                    $s.UI['lblGateState'].Text = "ProjectRunId: $($s.ProjectRunId)"
                    $s.UI['pnlRedoGateBlock'].Visibility = [System.Windows.Visibility]::Visible
                }) } catch {}
                return
            }
            try { $s.UI['pbarProgress'].Dispatcher.Invoke([action]{
                $s.UI['pnlProgress'].Visibility = [System.Windows.Visibility]::Collapsed
                $s.UI['pnlSummerContinuation'].Visibility = [System.Windows.Visibility]::Visible
            }) } catch {}
        } catch { Log "RedoRescue gate error: $_" 'ERROR'; Fail "$_" }
    }
}
# UNUSED since review fix #5: multiple active projects for one panel is a data-integrity
# situation, so Show-MultiActiveBlock is called instead - a technician must never choose which
# record wins. Kept (with pnlSummerSelect) only for a possible lead-supervised selection flow.
function Show-SummerSelect {
    param($Matches)
    $script:UI['cboSummerMatch'].Items.Clear()
    foreach ($m in $Matches) {
        $it = [System.Windows.Controls.ComboBoxItem]::new()
        $it.Content = "$($m.ProjectRunId)  |  $($m.SchoolCode) $($m.Room)  |  $($m.ProjectStatus)"
        $it.Tag = "$($m.ProjectRunId)"
        $script:UI['cboSummerMatch'].Items.Add($it) | Out-Null
    }
    Show-Screen 'pnlSummerSelect'
}
# Hardening #3: a short context summary at the top of the closeout screen so the tech can
# confirm they are closing the correct panel before checking the boxes.
function Set-CloseoutContext {
    $sch = if ($script:SchoolName) { "$($script:SchoolCode) - $($script:SchoolName)" } else { "$($script:SchoolCode)" }
    $rt  = if ($script:RoomType -eq 'Other' -and $script:OtherRoomType) { "Other - $($script:OtherRoomType)" } else { "$($script:RoomType)" }
    $script:UI['lblCloseoutContext'].Text =
        "School: $sch    Room Type: $rt    Room: $($script:RoomNumber)`n" +
        "Panel serial: $($script:PanelSerial)    Hostname: $($script:Hostname)`n" +
        "ProjectRunId: $($script:RelatedSummerRunId)"
    # ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§9: dynamic closeout title (new install vs RedoRescue recovery vs existing panel)
    $script:UI['lblCloseoutTitle'].Text = Get-CloseoutPhaseLabel
    # r13 finding #1: this is the one entry point every closeout path goes through, so the
    # submission guard and the button are reset here. Without it a panel that ended in a terminal
    # state ("Closeout Not Recorded") would leave the button dead for the NEXT panel.
    $script:CloseoutSubmissionInProgress = $false
    $script:CloseoutCommitted            = $false
    $script:CloseoutTerminalState        = $false
    try {
        $script:UI['btnCloseoutReboot'].IsEnabled = $true
        $script:UI['btnCloseoutReboot'].Content   = 'Finish and Reboot'
        $script:UI['lblCloseoutBusy'].Visibility  = 'Collapsed'
        $script:UI['lblCloseoutError'].Visibility = 'Collapsed'
    } catch {}
}
# v5.4 (review issue #3): "Post-RedoRescue" is reserved for projects that actually performed a
# RedoRescue recovery. An existing panel that only needed provisioning gets its own label.
function Get-CloseoutPhaseLabel {
    if ($script:NewInstallProvisioning) { return 'New Install Provisioning Closeout' }
    if ($script:RecoveryProvisioning)   { return 'Post-RedoRescue Closeout' }
    if ($script:RelatedSummerRunId)     { return 'Existing Panel Provisioning Closeout' }
    return 'Provisioning Closeout'
}
# Review fix #5: multiple active projects for one panel is a data-integrity situation -
# normal field selection is NOT allowed. Report the linking issue instead.
function Show-MultiActiveBlock {
    param($Matches)
    $ids = ($Matches | ForEach-Object { "$($_.ProjectRunId)  ($($_.ProjectStatus))" }) -join "`n"
    $script:UI['lblGateTitle'].Text = 'Multiple Active Interactive Inventory Projects'
    $script:UI['lblGateMsg'].Text = "Multiple active projects found for this panel.`n`nDo not choose one during normal field work.`n`nThe affected records have been flagged, or queued for flagging when the connection returns, for Manual Review. Use Report a Problem to add details."
    $script:UI['lblGateState'].Text = "Panel serial: $($script:PanelSerial)`n`nActive records:`n$ids"
    # Review fix #4: flag every affected project + create one linked exception on the backend
    # so the spreadsheet matches what the tech sees. Offline-safe via the normal queue.
    Send-Event -Payload @{
        Action        = 'flagMultipleActiveProjects'
        PanelSerial   = $script:PanelSerial
        OPSSerial     = $script:OPSSerial
        ProjectRunIds = (($Matches | ForEach-Object { "$($_.ProjectRunId)" }) -join '|')
        Technician    = $script:TechName
        RunId         = $script:RunId
        ScriptVersion = $script:ScriptVersion
        Timestamp     = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
    } -EventType 'FlagMultiActive' | Out-Null
    Show-Screen 'pnlRedoGateBlock'
}
# Review fix #3: route an active Summer record by its lifecycle stage - do not funnel every
# status back into the RedoRescue gate / Phase A.
# v5.4 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§2: a project parked for Windows upgrade / firmware correction / pending restart resumes by
# restoring its context and RE-EVALUATING the device (the tech has since done the remediation).
# v5.4.1 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§2.C: an old row reclassified as NON-recovery carries stale gate/blocked/recovery fields
# written under the pre-v5.4 policy. Clear them on the SAME ProjectRunId before re-evaluating, so
# the row does not keep asserting a RedoRescue that was never actually required.
# Blank strings clear the cell - Send-Event transmits them and the backend writes them through.
# Identity fields (ProjectRunId / PanelSerial / OPSSerial / AssessmentTechnician / AssessmentCompletedAt)
# are deliberately NOT touched, and no new Summer row is created.
function Clear-LegacyRecoveryState {
    param($Rec)
    $now = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
    $script:RecoveryRequired = $false; $script:RedoRescueRequired = $false
    $script:ReimageReason = ''
    # v5.5 review finding #4: 'Blocked - RedoRescue Not Completed' outranks
    # 'Assessment Complete - Recommendation Pending', so this IS a backward move and the
    # backend will reject it unless it arrives as a controlled override event carrying an
    # audit reason. Without this the v5.4.1 24H2 rehabilitation silently stops working.
    $overrideReason = "Legacy recovery state cleared: the row carried '$($Rec.ProjectStatus)' but shows no genuine RedoRescue recovery evidence under the v5.4.1 classifier."
    $clearRes = Post-MainLog @{
        LogSheet='Summer2026'; ProjectRunId="$($Rec.ProjectRunId)"
        ProjectStatus='Assessment Complete - Recommendation Pending'
        RecoveryRequired=$false; RedoRescueRequired=$false
        ReimageReason=''
        RedoRescueGateStatus=''; RedoRescueGateReason=''
        BlockedReason=''; BlockedAt=''; BlockedBy=''
        BypassReason=''; BypassAt=''; BypassBy=''
        # ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§14 blanks no longer erase implicitly - name the fields explicitly.
        ClearFields=@('ReimageReason','RedoRescueGateStatus','RedoRescueGateReason',
                      'BlockedReason','BlockedAt','BlockedBy','BypassReason','BypassAt','BypassBy')
        StateOverrideReason=$overrideReason; StateOverrideBy=$script:TechName; StateOverrideAt=$now
        LegacyRecoveryClearedBy=$script:TechName; LegacyRecoveryClearedAt=$now
        LegacyRecoveryClearedFrom="$($Rec.ProjectStatus)"
        LastUpdatedBy=$script:TechName; LastUpdatedAt=$now
    } 'LegacyRecoveryCleared'
    if ($clearRes -and $clearRes.Rejected) {
        Write-Log "LegacyRecoveryCleared was REJECTED - the legacy state was NOT cleared." 'ERROR'
        return $false
    }
    Write-Log "Legacy recovery state cleared on $($Rec.ProjectRunId) (was '$($Rec.ProjectStatus)') - re-evaluating under the v5.4 image matrix."
    return $true
}
# v5.4.1 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§2.B: recovery-looking statuses no longer go STRAIGHT to the gate. Decide first whether
# the project is genuine recovery work; a pre-v5.4 misclassification is re-evaluated instead of
# being trapped, and an undecidable row goes to Manual Review rather than asserting RedoRescue.
function Route-RecoveryContinuation {
    param($Rec)
    switch (Get-RecoveryProjectClass $Rec) {
        'Recovery' {
            Write-Log "Genuine RedoRescue project $($Rec.ProjectRunId) - running the restore gate."
            Start-RedoRescueGate $Rec
        }
        'NotRecovery' {
            Write-Log "Project $($Rec.ProjectRunId) carries status '$($Rec.ProjectStatus)' but shows no genuine recovery evidence - clearing legacy state."
            if (-not (Clear-LegacyRecoveryState $Rec)) {
                [System.Windows.MessageBox]::Show(
                    "The spreadsheet rejected the legacy-recovery correction, so this project still shows its old blocked status.

Do not reimage this panel. Report it to a lead.",
                    'Legacy Correction Not Recorded', 'OK', 'Error') | Out-Null
                Show-Screen 'pnlModeSelect'; return
            }
            Resume-RecommendationForProject $Rec
        }
        default { Show-UnclassifiedRecoveryReview $Rec }
    }
}
# v5.4.1: a record we cannot classify goes to Manual Review - NEVER to the gate. Running the gate
# is not a neutral safety check: it writes 'Blocked - RedoRescue Not Completed', a specific and
# possibly false assertion that a RedoRescue restore was required.
function Show-UnclassifiedRecoveryReview {
    param($Rec, [string]$Context = 'continuation')
    $now = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
    Post-MainLog @{
        LogSheet='Summer2026'; ProjectRunId="$($Rec.ProjectRunId)"
        ProjectStatus='Manual Review Required'
        ManualReviewReason="Legacy record ($Context): the row does not contain enough evidence to tell a genuine RedoRescue recovery from a pre-v5.4 image-policy misclassification (status '$($Rec.ProjectStatus)', OS '$($Rec.OSName)', manufacturer '$($Rec.Manufacturer)', storage '$($Rec.StorageActualGB)')."
        LastUpdatedBy=$script:TechName; LastUpdatedAt=$now
    } 'ReviewerStateCorrection'
    $script:UI['lblGateTitle'].Text = 'Manual Review Required'
    $script:UI['lblGateMsg'].Text = "This project was recorded under the older image policy and does not contain enough information to tell whether a RedoRescue restore was genuinely required.`n`nDo not reimage this panel. A lead needs to review the record before provisioning continues."
    $script:UI['lblGateState'].Text = "ProjectRunId: $($Rec.ProjectRunId)`nStatus: $($Rec.ProjectStatus)`nRecorded OS: $($Rec.OSName)`nManufacturer: $($Rec.Manufacturer)`nStorage: $($Rec.StorageActualGB) GB"
    Write-Log "Project $($Rec.ProjectRunId) could not be classified as recovery or misclassification ($Context) - routed to Manual Review." 'WARN'
    Show-Screen 'pnlRedoGateBlock'
}
function Resume-RecommendationForProject {
    param($Rec)
    $script:ProjectRunId = "$($Rec.ProjectRunId)"
    # v5.4.1 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§2.D: keep the project's identity on the SAME row - never mint a new ProjectRunId.
    $script:RelatedSummerRunId = "$($Rec.ProjectRunId)"
    Restore-ProjectRevision $Rec
    if (-not $script:PanelSerial -and "$($Rec.PanelSerial)") { $script:PanelSerial = "$($Rec.PanelSerial)" }
    $script:SchoolCode   = "$($Rec.SchoolCode)"; $script:SchoolName = "$($Rec.SchoolName)"
    $script:RoomNumber   = "$($Rec.Room)";       $script:MountType  = "$($Rec.MountType)"
    $script:RoomType     = "$($Rec.RoomType)";   $script:OtherRoomType = "$($Rec.OtherRoomType)"
    $script:Manufacturer = "$($Rec.Manufacturer)"; $script:MfrCode  = "$($Rec.MfrCode)"
    $script:PanelModel   = "$($Rec.PanelModel)";  $script:StorageGB = "$($Rec.StorageActualGB)"
    if ("$($Rec.CurrentOPSSerial)") { $script:OPSSerial = "$($Rec.CurrentOPSSerial)" } elseif ("$($Rec.OPSSerial)") { $script:OPSSerial = "$($Rec.OPSSerial)" }
    $script:InstallType  = "$($Rec.InstallType)"
    $script:DayOneStatus = "$($Rec.DayOneStatus)"
    Set-Mode 7 'Interactive Inventory Assessment'
    Write-Log "Resuming project $($Rec.ProjectRunId) after remediation ($($Rec.ProjectStatus)) - re-evaluating device."
    Show-ProvRecommendation
}
# Restore a new-install project's context and resume Full Provisioning (rename-skip -> power ->
# Phase B). Used by both the pre-Phase-A handoff branch and a new-install "Failed - Phase A" retry.
function Resume-NewInstallFullProvisioning {
    param($Rec)
    $script:SummerContinuation      = $false
    $script:ProjectRunId            = "$($Rec.ProjectRunId)"
    $script:RelatedSummerRunId      = "$($Rec.ProjectRunId)"
    # Honor the record's actual install type - this resume path serves both a new replacement
    # install and an accepted existing panel that never required a RedoRescue restore.
    $script:InstallType             = if ("$($Rec.InstallType)") { "$($Rec.InstallType)" } else { 'New Replacement Install' }
    $script:NewInstallProvisioning  = ($script:InstallType -eq 'New Replacement Install')
    $script:RecoveryProvisioning    = $false   # this resume path is never recovery work (issue #2/#3)
    $script:ProvPath                = 'Standard'
    Restore-ImageDecisionState $Rec
    $script:ProvisioningPathSelected = if ("$($Rec.ProvisioningPathSelected)" -and "$($Rec.ProvisioningPathSelected)" -ne 'Post-RedoRescue Provisioning') {
        "$($Rec.ProvisioningPathSelected)"
    } elseif ($script:NewInstallProvisioning) { 'Full Provisioning' } else { 'Existing Panel Provisioning' }
    $script:SchoolCode   = "$($Rec.SchoolCode)"; $script:SchoolName = "$($Rec.SchoolName)"
    $script:RoomNumber   = "$($Rec.Room)";       $script:MountType  = "$($Rec.MountType)"
    $script:Manufacturer = "$($Rec.Manufacturer)"; $script:MfrCode  = "$($Rec.MfrCode)"
    $script:PanelModel   = "$($Rec.PanelModel)";  $script:StorageGB = "$($Rec.StorageActualGB)"
    $script:RoomType     = "$($Rec.RoomType)";    $script:OtherRoomType = "$($Rec.OtherRoomType)"
    $script:SummerImageProfile   = "$($Rec.ImageProfile)"
    $script:SummerExpectedFolder = "$($Rec.ExpectedImageFolder)"
    if ("$($Rec.CurrentOPSSerial)") { $script:OPSSerial = "$($Rec.CurrentOPSSerial)" } elseif ("$($Rec.OPSSerial)") { $script:OPSSerial = "$($Rec.OPSSerial)" }
    $script:DomainMembershipStatus      = "$($Rec.DomainMembershipStatus)"
    $script:DetectedDomain              = "$($Rec.DetectedDomain)"
    $script:SecureChannelStatus         = "$($Rec.SecureChannelStatus)"
    $script:DomainCheckAt               = "$($Rec.DomainCheckAt)"
    $script:ProvisioningPathRecommended = if ("$($Rec.ProvisioningPathRecommended)" -and "$($Rec.ProvisioningPathRecommended)" -ne 'Post-RedoRescue Provisioning') {
        "$($Rec.ProvisioningPathRecommended)"
    } else { $script:ProvisioningPathSelected }
    $script:ProvisioningRecommendationReason = "$($Rec.ProvisioningRecommendationReason)"
    $script:NewInstallConfirmedBy       = "$($Rec.NewInstallConfirmedBy)"
    $script:NewInstallConfirmedAt       = "$($Rec.NewInstallConfirmedAt)"
    $script:ProvisioningTech = $script:TechName
    Set-Mode 1 $script:ProvisioningPathSelected
    $provRes = Post-MainLog (Add-ImageDecisionFields @{ LogSheet='Summer2026'; ProjectRunId=$script:ProjectRunId
        ProvisioningPathRecommended=$script:ProvisioningPathRecommended
        ProvisioningPathSelected=$script:ProvisioningPathSelected
        ProvisioningTech=$script:TechName; LastUpdatedBy=$script:TechName
        LastUpdatedAt=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') }) 'FullProvisioningSelected'
    Write-Log "Resuming $($script:ProvisioningPathSelected) for $($Rec.ProjectRunId)."
    # r8 finding #4: a PERMANENT rejection means the project never entered this path in
    # the spreadsheet - do NOT send the technician on to rename and domain join.
    if ($provRes -and $provRes.Rejected) { Stop-OnRejectedProvisioningPath $provRes $script:ProvisioningPathSelected; return }
    Show-HostnameScreen
}
function Route-SummerContinuation {
    param($Rec)
    $st = "$($Rec.ProjectStatus)"
    switch -Wildcard ($st) {
        # v5.4.1 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§2.B: verify the project is REAL recovery work before running the gate.
        'Pending RedoRescue Restore'            { Route-RecoveryContinuation $Rec; return }
        'Reimage Pending'                       { Route-RecoveryContinuation $Rec; return }   # legacy value
        'Blocked - RedoRescue Not Completed'    { Route-RecoveryContinuation $Rec; return }
        'RedoRescue Restored - Pending Provisioning' { Route-RecoveryContinuation $Rec; return }
        'Windows Upgrade Required'          { Resume-RecommendationForProject $Rec; return }
        'Firmware Configuration Required'   { Resume-RecommendationForProject $Rec; return }
        'Pending Windows Update Restart'    { Resume-RecommendationForProject $Rec; return }
        'Assessment Complete - Recommendation Pending' {
            # Review #6: the panel was assessed (approved image) but the tech never picked the
            # final action. Restore the assessment context and re-show the recommendation.
            $script:ProjectRunId = "$($Rec.ProjectRunId)"
            $script:SchoolCode   = "$($Rec.SchoolCode)"; $script:SchoolName = "$($Rec.SchoolName)"
            $script:RoomNumber   = "$($Rec.Room)";       $script:MountType  = "$($Rec.MountType)"
            $script:RoomType     = "$($Rec.RoomType)";   $script:OtherRoomType = "$($Rec.OtherRoomType)"
            $script:Manufacturer = "$($Rec.Manufacturer)"; $script:MfrCode  = "$($Rec.MfrCode)"
            $script:PanelModel   = "$($Rec.PanelModel)";  $script:StorageGB = "$($Rec.StorageActualGB)"
            if ("$($Rec.CurrentOPSSerial)") { $script:OPSSerial = "$($Rec.CurrentOPSSerial)" } elseif ("$($Rec.OPSSerial)") { $script:OPSSerial = "$($Rec.OPSSerial)" }
            $script:InstallType  = "$($Rec.InstallType)"
            $script:DayOneStatus = "$($Rec.DayOneStatus)"
            Set-Mode 7 'Interactive Inventory Assessment'
            Write-Log "Resuming recommendation for $($Rec.ProjectRunId)."
            Show-ProvRecommendation
            return
        }
        'Provisioning In Progress' {
            if ("$($Rec.PhaseBStatus)" -eq 'Complete' -or "$($Rec.ProvisioningStatus)" -like '*Awaiting Closeout*') {
                # Phase B done, closeout never finished -> resume closeout, same ProjectRunId.
                # Review fix #4: this path runs after the local state.json was archived, so restore
                # the full device/location context from the Summer record (blank fields otherwise).
                $script:SummerContinuation   = $true
                $script:RelatedSummerRunId   = "$($Rec.ProjectRunId)"
                $script:SummerImageProfile   = "$($Rec.ImageProfile)"
                $script:SummerRedoFile       = "$($Rec.RedoImageFile)"
                $script:SummerExpectedFolder = "$($Rec.ExpectedImageFolder)"
                $script:SchoolCode   = "$($Rec.SchoolCode)"
                $script:SchoolName   = "$($Rec.SchoolName)"
                $script:RoomNumber   = "$($Rec.Room)"
                $script:MountType    = "$($Rec.MountType)"
                $script:Manufacturer = "$($Rec.Manufacturer)"
                $script:PanelModel   = "$($Rec.PanelModel)"
                $script:StorageGB    = "$($Rec.StorageActualGB)"
                $script:OPSReplacementConfirmed = "$($Rec.OPSReplacementConfirmed)"
                $script:InstallType  = "$($Rec.InstallType)"
                $script:RoomType     = "$($Rec.RoomType)"; $script:OtherRoomType = "$($Rec.OtherRoomType)"
                $script:NewInstallProvisioning = ("$($Rec.InstallType)" -eq 'New Replacement Install' -or "$($Rec.ProvisioningStatus)" -like 'New Install*')
                $script:RecoveryProvisioning   = Test-RecoveryProject $Rec
                Restore-ImageDecisionState $Rec
                # Fix #2: restore routing evidence too, so the closeout PanelLog does not write
                # blanks back over the Summer routing fields when local state.json is gone.
                $script:DomainMembershipStatus      = "$($Rec.DomainMembershipStatus)"
                $script:DetectedDomain              = "$($Rec.DetectedDomain)"
                $script:SecureChannelStatus         = "$($Rec.SecureChannelStatus)"
                $script:DomainCheckAt               = "$($Rec.DomainCheckAt)"
                $script:ProvisioningPathRecommended = "$($Rec.ProvisioningPathRecommended)"
                $script:ProvisioningPathSelected    = "$($Rec.ProvisioningPathSelected)"
                $script:ProvisioningRecommendationReason = "$($Rec.ProvisioningRecommendationReason)"
                $script:NewInstallConfirmedBy       = "$($Rec.NewInstallConfirmedBy)"
                $script:NewInstallConfirmedAt       = "$($Rec.NewInstallConfirmedAt)"
                if ("$($Rec.CurrentOPSSerial)") { $script:OPSSerial = "$($Rec.CurrentOPSSerial)" } elseif ("$($Rec.OPSSerial)") { $script:OPSSerial = "$($Rec.OPSSerial)" }
                # Use the CURRENT (domain-joined) computer name, not the pre-RedoRescue assessment name
                $script:Hostname = $env:COMPUTERNAME
                $script:CloseoutIssueReported = $false
                foreach ($c in @('chkCoImage','chkCoTouch','chkCoSound','chkCoNetwork','chkCoNDMS','chkCoAndroidEthernet')) { $script:UI[$c].IsChecked = $false }
                Set-CloseoutContext
                Write-Log "Resuming $(Get-CloseoutPhaseLabel) for $($Rec.ProjectRunId)."
                Show-Screen 'pnlReimageCloseout'
            } elseif (("$($Rec.ProvisioningStatus)" -like 'New Install - Pending Full Provisioning*' -or
                       "$($Rec.ProvisioningStatus)" -like 'Existing Panel - Pending Full Provisioning*') -and
                      [string]::IsNullOrWhiteSpace("$($Rec.PhaseAStatus)")) {
                # Fix #3: provisioning confirmed but Phase A not yet started -> a DIFFERENT tech can
                # resume (rename-skip handles an already-renamed device). Works for new installs and
                # for accepted existing panels that never needed a RedoRescue restore.
                Resume-NewInstallFullProvisioning $Rec
            } else {
                [System.Windows.MessageBox]::Show(
                    "This project shows provisioning in progress (Phase B not complete).`n`nIf Phase A already ran on this device, reboot it and let the Phase B continuation open automatically. If provisioning was interrupted before Phase A, contact a lead before re-running it.",
                    'Provisioning In Progress', 'OK', 'Warning') | Out-Null
                Show-Screen 'pnlModeSelect'
            }
            return
        }
        'Failed - Phase A' {
            # v5.4 (review issue #2): the retry route depends on whether this project ACTUALLY
            # required a RedoRescue recovery - not on whether it is an existing panel. A healthy
            # existing panel on an accepted image never went through the gate, so re-running the
            # gate on retry would wrongly block it (e.g. storage outside the 128/256GB profiles).
            # v5.4.1: use the TRI-STATE class. An undecidable row must not be sent to the gate -
            # that would write a false 'Blocked - RedoRescue Not Completed'.
            $class = Get-RecoveryProjectClass $Rec
            if ($class -eq 'Unknown') { Show-UnclassifiedRecoveryReview $Rec 'Phase A retry'; return }
            $prompt = if ($class -eq 'Recovery') {
                "This project previously failed during Phase A.`n`nOK = retry provisioning (the RedoRescue gate will run again first).`nCancel = go back and use Report an Issue."
            } else {
                "This project previously failed during Phase A.`n`nOK = retry provisioning (an already-renamed device is handled automatically).`nCancel = go back and use Report an Issue."
            }
            $r = [System.Windows.MessageBox]::Show($prompt, 'Previous Phase A Failure', 'OKCancel', 'Warning')
            if ($r -ne 'OK') { Show-Screen 'pnlModeSelect'; return }
            if ($class -eq 'Recovery') { Start-RedoRescueGate $Rec } else { Resume-NewInstallFullProvisioning $Rec }
            return
        }
        'Failed - Phase B'      { }
        'Failed - Domain Join'  { }
        'Exception Open' {
            [System.Windows.MessageBox]::Show(
                "This project has an open exception ($($Rec.ReadinessIssueCategory)).`n`nResolve or review the exception before continuing provisioning. Use Report an Issue if the situation has changed.",
                'Exception Open', 'OK', 'Warning') | Out-Null
            Show-Screen 'pnlModeSelect'; return
        }
        'Manual Review Required' {
            $script:UI['lblGateTitle'].Text = 'Manual Review Required'
            $script:UI['lblGateMsg'].Text = "This project is marked Manual Review Required.`n`nDo not continue provisioning from this screen until the record has been reviewed."
            $script:UI['lblGateState'].Text = "ProjectRunId: $($Rec.ProjectRunId)`nStatus: $st"
            Show-Screen 'pnlRedoGateBlock'; return
        }
        default { Route-RecoveryContinuation $Rec; return }
    }
    # Failed - Phase B / Domain Join: device is renamed + Phase A done; resume Phase B troubleshooting
    [System.Windows.MessageBox]::Show(
        "This project previously failed during Phase B / domain join.`n`nReboot the device to reopen the Phase B continuation (if its local state is intact), verify network/DNS and use the correct domain-join account. If Phase B no longer opens after reboot, report an issue.",
        'Previous Phase B Failure', 'OK', 'Warning') | Out-Null
    Show-Screen 'pnlModeSelect'
}
function Show-IssueReport {
    param([string]$Phase, [string]$ReturnScreen)
    $script:IssueContextPhase = $Phase
    $script:IssueReturnScreen = $ReturnScreen
    $script:UI['cboExCategory'].SelectedIndex = -1
    $script:UI['txtExNote'].Text = ''
    $script:UI['lblExError'].Visibility = 'Collapsed'
    $displayPhase = $Phase -replace '\bSummer\b', 'Interactive Inventory Project'
    $ctx = "Mode: $($script:ModeLabel)   Phase: $displayPhase"
    if ($script:PanelSerial) { $ctx += "   Panel: $($script:PanelSerial)" }
    $script:UI['lblExContext'].Text = $ctx
    Show-Screen 'pnlIssueReport'
    # ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§7: put the tech straight on the category picker so the fields are obviously usable.
    try { $script:UI['cboExCategory'].Focus() | Out-Null } catch {}
}
# Resolve the project linkage for an issue:
#  - Summer continuation (reimage)  -> RelatedSummerRunId
#  - Original Summer assessment     -> ProjectRunId
#  - Normal non-Summer work         -> blank
function Resolve-IssueProjectId {
    if ($script:RelatedSummerRunId) { return $script:RelatedSummerRunId }
    if ($script:ProjectRunId)       { return $script:ProjectRunId }
    return ''
}
function Send-ExceptionEvent {
    param([string]$Category, [string]$Note, [string]$Phase)
    $linkId = Resolve-IssueProjectId
    $origin = if ($linkId) { 'Summer2026' } else { '' }
    $payload = @{
        LogSheet         = 'PanelAppExceptions'
        RunId            = $script:RunId
        ProjectRunId     = $linkId
        ProjectOrigin    = $origin
        Technician       = $script:TechName
        Mode             = $script:ModeLabel
        Phase            = $Phase
        SchoolCode       = $script:SchoolCode
        Room             = $script:RoomNumber
        RoomType         = $script:RoomType
        OtherRoomType    = $script:OtherRoomType
        PanelSerial      = $script:PanelSerial
        OPSSerial        = $script:OPSSerial
        Hostname         = $script:Hostname
        IssueCategory    = $Category
        IssueDescription = $Note
        Severity         = 'Reported'
        ImageProfile     = $script:SummerImageProfile
        RedoImageFile    = $script:SummerRedoFile
        ScriptVersion    = $script:ScriptVersion
        SyncStatus       = 'Submitted'
        Timestamp        = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
    }
    # r10 finding #2: return the COMPLETE result. Collapsing it to .Delivered made a permanent
    # rejection indistinguishable from an offline queue, and the caller then told the technician
    # the panel was marked Exception Open when the spreadsheet had recorded nothing at all.
    $exRes = Send-Event -Payload $payload -EventType 'Exception'
    $what = if ($exRes.Rejected) { "REJECTED by the spreadsheet ($($exRes.Parsed.ErrorCode): $($exRes.Parsed.Message))" }
            elseif ($exRes.Delivered) { 'submitted' }
            else { 'queued offline' }
    Write-Log "Issue reported ($Category, link=$linkId) - $what." $(if ($exRes.Rejected) { 'ERROR' } else { 'INFO' })
    return $exRes
}
function Submit-IssueReport {
    # Returns $null when the form is incomplete (nothing was sent), otherwise the delivery result.
    $sel = $script:UI['cboExCategory'].SelectedItem
    if (-not $sel) {
        $script:UI['lblExError'].Text = 'Select an issue category.'
        $script:UI['lblExError'].Visibility = 'Visible'
        return $null
    }
    return Send-ExceptionEvent -Category "$($sel.Content)" `
                               -Note ($script:UI['txtExNote'].Text.Trim()) `
                               -Phase $script:IssueContextPhase
}

# ================================================================
#  STORAGE SIZE
# ================================================================
function Get-StorageSize {
    # The OPS storage is the INTERNAL disk Windows is installed on. Target it
    # directly so a plugged-in USB/external drive can never be mistaken for the
    # OPS storage (previously this picked the largest disk, which grabbed a
    # connected external HDD).
    try {
        $sysLetter = $env:SystemDrive.TrimEnd(':')
        $osDisk = Get-Partition -DriveLetter $sysLetter -ErrorAction Stop | Get-Disk -ErrorAction Stop
        if ($osDisk -and $osDisk.Size -gt 0) {
            return ("{0}GB" -f [math]::Round($osDisk.Size / 1GB, 0))
        }
    } catch {}

    # Fallback 1: largest non-removable disk (exclude USB-bus external drives).
    # Internal OPS storage is NVMe / SATA / eMMC - never USB.
    try {
        $fixed = @(Get-Disk -ErrorAction Stop |
                   Where-Object { $_.BusType -ne 'USB' } |
                   Sort-Object Size -Descending)
        if ($fixed.Count -gt 0 -and $fixed[0].Size -gt 0) {
            return ("{0}GB" -f [math]::Round($fixed[0].Size / 1GB, 0))
        }
    } catch {}

    # Fallback 2 (oldest systems): WMI, fixed media only.
    try {
        $drives = @(Get-WmiObject Win32_DiskDrive -ErrorAction Stop |
                    Where-Object { $_.MediaType -eq 'Fixed hard disk media' } |
                    Sort-Object Size -Descending)
        if ($drives.Count -gt 0 -and $drives[0].Size -gt 0) {
            return ("{0}GB" -f [math]::Round($drives[0].Size / 1GB, 0))
        }
    } catch {}

    return 'Unknown'
}

Write-Log '==== APS Panel App starting ===='
Write-Log "Script path : $PSCommandPath"
Write-Log "Phase B mode: $($PhaseB.IsPresent)"

# ================================================================
#  WPF XAML
# ================================================================
try {
[xml]$script:xamlDoc = @'
<Window
    xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
    xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
    Title="APS Interactive Panel Management"
    MinWidth="800" MinHeight="560" Width="920" Height="700"
    WindowStartupLocation="CenterScreen"
    Background="#1C1C1C">
  <Window.Resources>

    <!-- Primary (APS Red) button -->
    <Style x:Key="PrimaryBtn" TargetType="Button">
      <Setter Property="Background" Value="#C8102E"/>
      <Setter Property="Foreground" Value="White"/>
      <Setter Property="FontFamily" Value="Segoe UI"/>
      <Setter Property="FontSize" Value="13"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="Padding" Value="24,9"/>
      <Setter Property="BorderThickness" Value="0"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="MinHeight" Value="36"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border x:Name="bd" Background="{TemplateBinding Background}" CornerRadius="4" Padding="{TemplateBinding Padding}">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True">  <Setter TargetName="bd" Property="Background" Value="#D91E3A"/> </Trigger>
              <Trigger Property="IsPressed"   Value="True">  <Setter TargetName="bd" Property="Background" Value="#A00C24"/> </Trigger>
              <Trigger Property="IsEnabled"   Value="False">
                <Setter TargetName="bd" Property="Background" Value="#2E2E2E"/>
                <Setter Property="Foreground" Value="#555555"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <!-- Ghost / secondary button -->
    <Style x:Key="GhostBtn" TargetType="Button">
      <Setter Property="Background" Value="#2A2A2A"/>
      <Setter Property="Foreground" Value="#CCCCCC"/>
      <Setter Property="FontFamily" Value="Segoe UI"/>
      <Setter Property="FontSize" Value="13"/>
      <Setter Property="Padding" Value="20,9"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="BorderBrush" Value="#3A3A3A"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="MinHeight" Value="36"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border x:Name="bd" Background="{TemplateBinding Background}"
                    BorderBrush="{TemplateBinding BorderBrush}"
                    BorderThickness="{TemplateBinding BorderThickness}"
                    CornerRadius="4" Padding="{TemplateBinding Padding}">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True">
                <Setter TargetName="bd" Property="Background" Value="#333333"/>
                <Setter TargetName="bd" Property="BorderBrush" Value="#C8102E"/>
              </Trigger>
              <Trigger Property="IsPressed" Value="True"> <Setter TargetName="bd" Property="Background" Value="#1A1A1A"/> </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <!-- Green / execute button -->
    <Style x:Key="GreenBtn" TargetType="Button">
      <Setter Property="Background" Value="#1E7E34"/>
      <Setter Property="Foreground" Value="White"/>
      <Setter Property="FontFamily" Value="Segoe UI"/>
      <Setter Property="FontSize" Value="13"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="Padding" Value="24,9"/>
      <Setter Property="BorderThickness" Value="0"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="MinHeight" Value="36"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border x:Name="bd" Background="{TemplateBinding Background}" CornerRadius="4" Padding="{TemplateBinding Padding}">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True">  <Setter TargetName="bd" Property="Background" Value="#28A745"/> </Trigger>
              <Trigger Property="IsPressed"   Value="True">  <Setter TargetName="bd" Property="Background" Value="#186429"/> </Trigger>
              <Trigger Property="IsEnabled"   Value="False">
                <Setter TargetName="bd" Property="Background" Value="#2E2E2E"/>
                <Setter Property="Foreground" Value="#555555"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <!-- Mode selection button -->
    <Style x:Key="ModeBtn" TargetType="Button">
      <Setter Property="Background" Value="#222222"/>
      <Setter Property="Foreground" Value="#FFFFFF"/>
      <Setter Property="FontFamily" Value="Segoe UI"/>
      <Setter Property="Padding" Value="18,14"/>
      <Setter Property="Margin" Value="0,0,0,8"/>
      <Setter Property="BorderBrush" Value="#3A3A3A"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="HorizontalAlignment" Value="Stretch"/>
      <Setter Property="HorizontalContentAlignment" Value="Left"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border x:Name="bd" Background="{TemplateBinding Background}"
                    BorderBrush="{TemplateBinding BorderBrush}"
                    BorderThickness="{TemplateBinding BorderThickness}"
                    CornerRadius="6" Padding="{TemplateBinding Padding}">
              <ContentPresenter HorizontalAlignment="Left" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True">
                <Setter TargetName="bd" Property="Background" Value="#2E2E2E"/>
                <Setter TargetName="bd" Property="BorderBrush" Value="#C8102E"/>
              </Trigger>
              <Trigger Property="IsPressed" Value="True"> <Setter TargetName="bd" Property="Background" Value="#1A1A1A"/> </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <!-- Dark TextBox -->
    <Style x:Key="DarkInput" TargetType="TextBox">
      <Setter Property="Background" Value="#141414"/>
      <Setter Property="Foreground" Value="#FFFFFF"/>
      <Setter Property="BorderBrush" Value="#3A3A3A"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="FontFamily" Value="Segoe UI"/>
      <Setter Property="FontSize" Value="14"/>
      <Setter Property="Padding" Value="10,8"/>
      <Setter Property="CaretBrush" Value="#C8102E"/>
    </Style>

    <!-- Monospace log TextBox -->
    <Style x:Key="DarkMono" TargetType="TextBox">
      <Setter Property="Background" Value="#0A0A0A"/>
      <Setter Property="Foreground" Value="#AAAAAA"/>
      <Setter Property="BorderBrush" Value="#1A1A1A"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="FontFamily" Value="Consolas"/>
      <Setter Property="FontSize" Value="11"/>
      <Setter Property="Padding" Value="10,8"/>
      <Setter Property="IsReadOnly" Value="True"/>
    </Style>

    <!-- PasswordBox -->
    <Style x:Key="DarkPassBox" TargetType="PasswordBox">
      <Setter Property="Background" Value="#141414"/>
      <Setter Property="Foreground" Value="#FFFFFF"/>
      <Setter Property="BorderBrush" Value="#3A3A3A"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="FontFamily" Value="Segoe UI"/>
      <Setter Property="FontSize" Value="14"/>
      <Setter Property="Padding" Value="10,8"/>
    </Style>

    <!-- Dark ComboBox with dark dropdown -->
    <Style x:Key="DarkCombo" TargetType="ComboBox">
      <Setter Property="Background" Value="#141414"/>
      <Setter Property="Foreground" Value="#FFFFFF"/>
      <Setter Property="BorderBrush" Value="#3A3A3A"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="FontFamily" Value="Segoe UI"/>
      <Setter Property="FontSize" Value="13"/>
      <Setter Property="MinHeight" Value="36"/>
      <Setter Property="Padding" Value="6,0,4,0"/>
      <Setter Property="ItemContainerStyle">
        <Setter.Value>
          <Style TargetType="ComboBoxItem">
            <Setter Property="Background" Value="#1C1C1C"/>
            <Setter Property="Foreground" Value="#FFFFFF"/>
            <Setter Property="Padding" Value="10,7"/>
            <Setter Property="FontFamily" Value="Segoe UI"/>
            <Setter Property="FontSize" Value="13"/>
            <Style.Triggers>
              <Trigger Property="IsMouseOver" Value="True">
                <Setter Property="Background" Value="#C8102E"/>
                <Setter Property="Foreground" Value="#FFFFFF"/>
              </Trigger>
              <Trigger Property="IsSelected" Value="True">
                <Setter Property="Background" Value="#A00C24"/>
                <Setter Property="Foreground" Value="#FFFFFF"/>
              </Trigger>
            </Style.Triggers>
          </Style>
        </Setter.Value>
      </Setter>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="ComboBox">
            <Grid x:Name="templateRoot">
              <Border x:Name="MainBorder"
                      Background="{TemplateBinding Background}"
                      BorderBrush="{TemplateBinding BorderBrush}"
                      BorderThickness="{TemplateBinding BorderThickness}"
                      CornerRadius="3">
                <Grid Margin="6,0,0,0">
                  <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="22"/>
                  </Grid.ColumnDefinitions>
                  <ContentPresenter x:Name="ContentSite"
                    Content="{TemplateBinding SelectionBoxItem}"
                    ContentTemplate="{TemplateBinding SelectionBoxItemTemplate}"
                    IsHitTestVisible="False"
                    VerticalAlignment="Center"/>
                  <ToggleButton Grid.ColumnSpan="2"
                    Background="Transparent" BorderThickness="0"
                    IsChecked="{Binding IsDropDownOpen, Mode=TwoWay, RelativeSource={RelativeSource TemplatedParent}}"
                    Focusable="False"/>
                  <TextBlock Grid.Column="1" Text="&#x25BC;" FontSize="8"
                             Foreground="#888888" HorizontalAlignment="Center"
                             VerticalAlignment="Center" IsHitTestVisible="False"/>
                </Grid>
              </Border>
              <Popup x:Name="PART_Popup"
                     Placement="Bottom"
                     IsOpen="{TemplateBinding IsDropDownOpen}"
                     AllowsTransparency="True"
                     Focusable="False">
                <Border Background="#1C1C1C"
                        BorderBrush="#3A3A3A"
                        BorderThickness="1"
                        MinWidth="{Binding ActualWidth, ElementName=templateRoot}">
                  <ScrollViewer MaxHeight="280" VerticalScrollBarVisibility="Auto">
                    <ItemsPresenter/>
                  </ScrollViewer>
                </Border>
              </Popup>
            </Grid>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver"    Value="True"> <Setter TargetName="MainBorder" Property="BorderBrush" Value="#C8102E"/> </Trigger>
              <Trigger Property="IsDropDownOpen" Value="True"> <Setter TargetName="MainBorder" Property="BorderBrush" Value="#C8102E"/> </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <!-- Radio button -->
    <Style x:Key="DarkRadio" TargetType="RadioButton">
      <Setter Property="Foreground" Value="#FFFFFF"/>
      <Setter Property="FontFamily" Value="Segoe UI"/>
      <Setter Property="FontSize" Value="13"/>
      <Setter Property="Margin" Value="0,6,24,6"/>
      <Setter Property="Cursor" Value="Hand"/>
    </Style>

  </Window.Resources>

  <Grid>
    <Grid.RowDefinitions>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="*"/>
      <RowDefinition Height="Auto"/>
    </Grid.RowDefinitions>

    <!-- Header -->
    <Border Grid.Row="0" Background="#111111" Padding="24,14">
      <Grid>
        <StackPanel HorizontalAlignment="Left">
          <TextBlock Text="APS Interactive Panel Management"
                     FontFamily="Segoe UI" FontSize="18" FontWeight="Bold" Foreground="#C8102E"/>
          <TextBlock Text="Atlanta Public Schools - Information Technology Division"
                     FontFamily="Segoe UI" FontSize="11" Foreground="#555555"/>
        </StackPanel>
        <StackPanel HorizontalAlignment="Right" VerticalAlignment="Center">
          <TextBlock x:Name="lblTechDisplay" Text="" FontFamily="Segoe UI" FontSize="12"
                     Foreground="#CCCCCC" HorizontalAlignment="Right"/>
          <TextBlock x:Name="lblModeDisplay" Text="" FontFamily="Segoe UI" FontSize="11"
                     Foreground="#888888" HorizontalAlignment="Right"/>
        </StackPanel>
      </Grid>
    </Border>

    <!-- Screens (all stacked; one visible at a time) -->
    <Grid Grid.Row="1" Background="#1C1C1C">

      <!-- SCREEN 1: Username entry -->
      <Grid x:Name="pnlUserEntry" Visibility="Visible">
        <Grid.RowDefinitions>
          <RowDefinition Height="*"/>
          <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>
        <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto">
          <StackPanel MaxWidth="480" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="40,50,40,20">
            <TextBlock Text="Welcome" FontFamily="Segoe UI" FontSize="26" FontWeight="Bold"
                       Foreground="#FFFFFF" Margin="0,0,0,4"/>
            <TextBlock Text="Interactive Panel Provisioning and Documentation"
                       FontFamily="Segoe UI" FontSize="13" Foreground="#888888" Margin="0,0,0,28"/>
            <Border Background="#262626" CornerRadius="6" Padding="14,10" Margin="0,0,0,28">
              <StackPanel Orientation="Horizontal">
                <Ellipse x:Name="ellNetStatus" Width="10" Height="10" Fill="#888888"
                         Margin="0,0,10,0" VerticalAlignment="Center"/>
                <TextBlock x:Name="lblNetStatus" Text="Checking network..."
                           FontFamily="Segoe UI" FontSize="12" Foreground="#AAAAAA" VerticalAlignment="Center"/>
              </StackPanel>
            </Border>
            <TextBlock Text="YOUR APS USERNAME" FontFamily="Segoe UI" FontSize="10"
                       FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <TextBox x:Name="txtTechName" Style="{StaticResource DarkInput}"
                     FontSize="15" Padding="12,10" MaxLength="60"/>
            <TextBlock Text="Use your regular APS username - not your _fieldtech, shared, or admin account."
                       FontFamily="Segoe UI" FontSize="11" Foreground="#AAAAAA" Margin="0,6,0,0" TextWrapping="Wrap"/>
            <TextBlock Text="Enter the username only, such as charjohnson. Do not enter an email address or DOMAIN\username."
                       FontFamily="Segoe UI" FontSize="11" Foreground="#666666" Margin="0,3,0,0" TextWrapping="Wrap"/>
            <TextBlock x:Name="lblTechNameError" Text="" Foreground="#EF5B5B"
                       FontFamily="Segoe UI" FontSize="11" Margin="0,6,0,0" Visibility="Collapsed"/>
          </StackPanel>
        </ScrollViewer>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Button x:Name="btnContinueUsername" Style="{StaticResource PrimaryBtn}"
                  Content="Continue" HorizontalAlignment="Right" MinWidth="150"/>
        </Border>
      </Grid>

      <!-- SCREEN 2: Mode selection -->
      <Grid x:Name="pnlModeSelect" Visibility="Collapsed">
        <Grid.RowDefinitions>
          <RowDefinition Height="*"/>
          <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>
        <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto">
          <StackPanel Margin="40,28,40,10">
            <TextBlock Text="Select Mode" FontFamily="Segoe UI" FontSize="22"
                       FontWeight="Bold" Foreground="#FFFFFF" Margin="0,0,0,4"/>
            <TextBlock Text="Choose the type of work being performed on this device"
                       FontFamily="Segoe UI" FontSize="13" Foreground="#888888" Margin="0,0,0,22"/>

            <Button x:Name="btnSummer2026" Style="{StaticResource ModeBtn}"
                    BorderBrush="#1FB89A" BorderThickness="2" Background="#10302B" Margin="0,0,0,18">
              <StackPanel Orientation="Horizontal">
                <Border Background="#0E7C66" CornerRadius="4" Width="40" Height="40" Margin="0,0,14,0">
                  <TextBlock Text="&#x2605;" FontSize="20" FontWeight="Bold" Foreground="White"
                             HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </Border>
                <StackPanel VerticalAlignment="Center">
                  <TextBlock Text="Interactive Inventory Project 2026" FontFamily="Segoe UI" FontSize="15" FontWeight="Bold" Foreground="#FFFFFF"/>
                  <TextBlock Text="Interactive inventory + Panel Readiness + Windows remediation/provisioning workflow"
                             FontFamily="Segoe UI" FontSize="12" Foreground="#9FE8D8" Margin="0,3,0,0"/>
                </StackPanel>
              </StackPanel>
            </Button>

            <Button x:Name="btnMode1" Style="{StaticResource ModeBtn}" Visibility="Collapsed">
              <StackPanel Orientation="Horizontal">
                <Border Background="#C8102E" CornerRadius="4" Width="40" Height="40" Margin="0,0,14,0">
                  <TextBlock Text="1" FontSize="20" FontWeight="Bold" Foreground="White"
                             HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </Border>
                <StackPanel VerticalAlignment="Center">
                  <TextBlock Text="Full Provisioning" FontFamily="Segoe UI" FontSize="15" FontWeight="Bold" Foreground="#FFFFFF"/>
                  <TextBlock Text="Standard provisioning, or Post-RedoRescue provisioning for an Interactive Inventory Project device"
                             FontFamily="Segoe UI" FontSize="12" Foreground="#888888" Margin="0,3,0,0"/>
                </StackPanel>
              </StackPanel>
            </Button>

            <Button x:Name="btnMode2" Style="{StaticResource ModeBtn}" Visibility="Collapsed">
              <StackPanel Orientation="Horizontal">
                <Border Background="#8B0000" CornerRadius="4" Width="40" Height="40" Margin="0,0,14,0">
                  <TextBlock Text="2" FontSize="20" FontWeight="Bold" Foreground="White"
                             HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </Border>
                <StackPanel VerticalAlignment="Center">
                  <TextBlock Text="RMA / Warranty Replacement" FontFamily="Segoe UI" FontSize="15" FontWeight="Bold" Foreground="#FFFFFF"/>
                  <TextBlock Text="One RMA workflow - PanelApp decides inventory-only, rename-only, or full provisioning"
                             FontFamily="Segoe UI" FontSize="12" Foreground="#888888" Margin="0,3,0,0"/>
                </StackPanel>
              </StackPanel>
            </Button>

            <Button x:Name="btnMode3" Style="{StaticResource ModeBtn}" Visibility="Collapsed">
              <StackPanel Orientation="Horizontal">
                <Border Background="#7B5E38" CornerRadius="4" Width="40" Height="40" Margin="0,0,14,0">
                  <TextBlock Text="3" FontSize="20" FontWeight="Bold" Foreground="White"
                             HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </Border>
                <StackPanel VerticalAlignment="Center">
                  <TextBlock Text="OPS Module Move" FontFamily="Segoe UI" FontSize="15" FontWeight="Bold" Foreground="#FFFFFF"/>
                  <TextBlock Text="Moving an OPS/PC module to a different panel chassis - rename and log"
                             FontFamily="Segoe UI" FontSize="12" Foreground="#888888" Margin="0,3,0,0"/>
                </StackPanel>
              </StackPanel>
            </Button>

            <Button x:Name="btnMode4" Style="{StaticResource ModeBtn}" Visibility="Collapsed">
              <StackPanel Orientation="Horizontal">
                <Border Background="#6B3E7B" CornerRadius="4" Width="40" Height="40" Margin="0,0,14,0">
                  <TextBlock Text="4" FontSize="20" FontWeight="Bold" Foreground="White"
                             HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </Border>
                <StackPanel VerticalAlignment="Center">
                  <TextBlock Text="Panel Relocation" FontFamily="Segoe UI" FontSize="15" FontWeight="Bold" Foreground="#FFFFFF"/>
                  <TextBlock Text="Panel physically moved to a new location - update records and rename"
                             FontFamily="Segoe UI" FontSize="12" Foreground="#888888" Margin="0,3,0,0"/>
                </StackPanel>
              </StackPanel>
            </Button>

            <Button x:Name="btnMode5" Style="{StaticResource ModeBtn}" Visibility="Collapsed">
              <StackPanel Orientation="Horizontal">
                <Border Background="#1E5F8B" CornerRadius="4" Width="40" Height="40" Margin="0,0,14,0">
                  <TextBlock Text="5" FontSize="20" FontWeight="Bold" Foreground="White"
                             HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </Border>
                <StackPanel VerticalAlignment="Center">
                  <TextBlock Text="Warranty Replacement - Same Model, Same OPS" FontFamily="Segoe UI" FontSize="15" FontWeight="Bold" Foreground="#FFFFFF"/>
                  <TextBlock Text="Chassis replaced under warranty - verify hostname, log entry"
                             FontFamily="Segoe UI" FontSize="12" Foreground="#888888" Margin="0,3,0,0"/>
                </StackPanel>
              </StackPanel>
            </Button>

            <Button x:Name="btnMode6" Style="{StaticResource ModeBtn}" Visibility="Collapsed">
              <StackPanel Orientation="Horizontal">
                <Border Background="#2D7A3A" CornerRadius="4" Width="40" Height="40" Margin="0,0,14,0">
                  <TextBlock Text="6" FontSize="20" FontWeight="Bold" Foreground="White"
                             HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </Border>
                <StackPanel VerticalAlignment="Center">
                  <TextBlock Text="General Inventory Capture" FontFamily="Segoe UI" FontSize="15" FontWeight="Bold" Foreground="#FFFFFF"/>
                  <TextBlock Text="Document panel details for inventory - serial, model, location, storage"
                             FontFamily="Segoe UI" FontSize="12" Foreground="#888888" Margin="0,3,0,0"/>
                  <TextBlock Text="Do not use this mode for the Interactive Inventory Project 2026."
                             FontFamily="Segoe UI" FontSize="11" FontWeight="SemiBold" Foreground="#F0B030" Margin="0,3,0,0"/>
                </StackPanel>
              </StackPanel>
            </Button>

            <Button x:Name="btnModeEndpointRepair" Style="{StaticResource ModeBtn}" Visibility="Collapsed">
              <StackPanel Orientation="Horizontal">
                <Border Background="#7B5DA7" CornerRadius="4" Width="40" Height="40" Margin="0,0,14,0">
                  <TextBlock Text="E" FontSize="20" FontWeight="Bold" Foreground="White"
                             HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </Border>
                <StackPanel VerticalAlignment="Center">
                  <TextBlock Text="Endpoint Repair" FontFamily="Segoe UI" FontSize="15" FontWeight="Bold" Foreground="#FFFFFF"/>
                  <TextBlock Text="Repair Windows identity only: rename the device, repair/join the APS domain, or do both."
                             TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="12" Foreground="#888888" Margin="0,3,0,0"/>
                </StackPanel>
              </StackPanel>
            </Button>
            <Button x:Name="btnModeOPSRequest" Style="{StaticResource ModeBtn}" Visibility="Collapsed">
              <StackPanel Orientation="Horizontal">
                <Border Background="#3B6E8F" CornerRadius="4" Width="40" Height="40" Margin="0,0,14,0">
                  <TextBlock Text="R" FontSize="20" FontWeight="Bold" Foreground="White"
                             HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </Border>
                <StackPanel VerticalAlignment="Center">
                  <TextBlock Text="Request an OPS" FontFamily="Segoe UI" FontSize="15" FontWeight="Bold" Foreground="#FFFFFF"/>
                  <TextBlock Text="Submit an OPS need for a panel. The request is logged for lead / PAIR follow-up."
                             TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="12" Foreground="#888888" Margin="0,3,0,0"/>
                </StackPanel>
              </StackPanel>
            </Button>
            <!-- v5.4 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§4: Correct / Update Inventory Record -->
            <Button x:Name="btnModeInventory" Style="{StaticResource ModeBtn}">
              <StackPanel Orientation="Horizontal">
                <Border Background="#1A73E8" CornerRadius="4" Width="40" Height="40" Margin="0,0,14,0">
                  <TextBlock Text="&#x270E;" FontSize="20" FontWeight="Bold" Foreground="White"
                             HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </Border>
                <StackPanel VerticalAlignment="Center">
                  <TextBlock Text="Correct Inventory Record" FontFamily="Segoe UI" FontSize="15" FontWeight="Bold" Foreground="#FFFFFF"/>
                  <TextBlock Text="Look up an existing panel or OPS record, correct inventory information, fill missing fields, or report conflicting records."
                             TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="12" Foreground="#888888" Margin="0,3,0,0"/>
                  <TextBlock Text="Inventory corrections only. This mode does not rename the device, join the domain, provision Windows, or reimage the OPS. For Windows identity repairs, use Endpoint Repair under Other." TextWrapping="Wrap"
                             FontFamily="Segoe UI" FontSize="11" FontWeight="SemiBold" Foreground="#9FC8E8" Margin="0,3,0,0"/>
                </StackPanel>
              </StackPanel>
            </Button>

            <Button x:Name="btnOtherModes" Style="{StaticResource ModeBtn}" BorderBrush="#555555" BorderThickness="1">
              <StackPanel Orientation="Horizontal">
                <Border Background="#444444" CornerRadius="4" Width="40" Height="40" Margin="0,0,14,0">
                  <TextBlock Text="..." FontSize="18" FontWeight="Bold" Foreground="White"
                             HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </Border>
                <StackPanel VerticalAlignment="Center">
                  <TextBlock Text="Other" FontFamily="Segoe UI" FontSize="15" FontWeight="Bold" Foreground="#FFFFFF"/>
                  <TextBlock Text="RMA, OPS move, panel relocation, OPS requests, general provisioning, and other operational workflows"
                             TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="12" Foreground="#888888" Margin="0,3,0,0"/>
                </StackPanel>
              </StackPanel>
            </Button>
          </StackPanel>
        </ScrollViewer>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Button x:Name="btnModeBack" Style="{StaticResource GhostBtn}"
                  Content="&lt; Change User" HorizontalAlignment="Left" MinWidth="140"/>
        </Border>
      </Grid>


      <!-- SCREEN 2q: v5.7 Endpoint Repair -->
      <Grid x:Name="pnlEndpointRepair" Visibility="Collapsed">
        <Grid.RowDefinitions><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
        <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto">
          <StackPanel MaxWidth="640" HorizontalAlignment="Center" Margin="40,28,40,18">
            <TextBlock Text="Endpoint Repair" FontFamily="Segoe UI" FontSize="22" FontWeight="Bold" Foreground="#FFFFFF" Margin="0,0,0,4"/>
            <TextBlock Text="Use this only when the panel/OPS is staying in place and Windows identity or domain membership needs correction. Endpoint Repair does not reimage, upgrade Windows, install software, or perform an inventory reassignment."
                       TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="13" Foreground="#888888" Margin="0,0,0,20"/>
            <TextBlock Text="WHAT NEEDS TO BE CORRECTED?" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,8"/>
            <Button x:Name="btnEndpointRenameOnly" Style="{StaticResource ModeBtn}" Margin="0,0,0,10">
              <StackPanel><TextBlock Text="Rename Device Only" FontFamily="Segoe UI" FontSize="15" FontWeight="Bold" Foreground="#FFFFFF"/>
                <TextBlock Text="Use when Windows is otherwise healthy but the hostname is wrong." TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="12" Foreground="#888888" Margin="0,3,0,0"/></StackPanel>
            </Button>
            <Button x:Name="btnEndpointDomainOnly" Style="{StaticResource ModeBtn}" Margin="0,0,0,10">
              <StackPanel><TextBlock Text="Join Domain Only" FontFamily="Segoe UI" FontSize="15" FontWeight="Bold" Foreground="#FFFFFF"/>
                <TextBlock Text="Use when the hostname is already correct but the OPS is not on the APS domain, or its secure channel needs repair." TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="12" Foreground="#888888" Margin="0,3,0,0"/></StackPanel>
            </Button>
            <Button x:Name="btnEndpointRenameJoin" Style="{StaticResource ModeBtn}">
              <StackPanel><TextBlock Text="Rename + Join Domain" FontFamily="Segoe UI" FontSize="15" FontWeight="Bold" Foreground="#FFFFFF"/>
                <TextBlock Text="Use when both the Windows hostname and APS domain membership need correction." TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="12" Foreground="#888888" Margin="0,3,0,0"/></StackPanel>
            </Button>
            <Border Background="#1B1621" BorderBrush="#7B5DA7" BorderThickness="1" CornerRadius="6" Padding="14" Margin="0,18,0,0">
              <TextBlock Text="Safety boundary: Correct Inventory Record changes inventory data only. Endpoint Repair changes Windows identity only. Neither mode performs RedoRescue or a Windows feature upgrade." TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="12" Foreground="#CDBBE3"/>
            </Border>
          </StackPanel>
        </ScrollViewer>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Button x:Name="btnEndpointBack" Style="{StaticResource GhostBtn}" Content="&lt; Back" HorizontalAlignment="Left" MinWidth="140"/>
        </Border>
      </Grid>
      <!-- SCREEN 2r: OPS request -->
      <Grid x:Name="pnlOPSRequest" Visibility="Collapsed">
        <Grid.RowDefinitions>
          <RowDefinition Height="*"/>
          <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>
        <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto">
          <StackPanel Margin="40,28,40,18">
            <TextBlock Text="Request an OPS" FontFamily="Segoe UI" FontSize="22"
                       FontWeight="Bold" Foreground="#FFFFFF" Margin="0,0,0,4"/>
            <TextBlock Text="Use this when a panel needs an OPS/PC module. This does not move, rename, domain join, or provision a device."
                       TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="13"
                       Foreground="#888888" Margin="0,0,0,20"/>

            <TextBlock Text="SCHOOL" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <ComboBox x:Name="cboOPSReqSchool" Style="{StaticResource DarkCombo}" Margin="0,0,0,14"/>
            <TextBlock x:Name="lblOPSReqSchoolError" Text="" Foreground="#EF5B5B" FontFamily="Segoe UI" FontSize="11"
                       Margin="0,-8,0,10" Visibility="Collapsed"/>

            <TextBlock Text="ROOM" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <TextBox x:Name="txtOPSReqRoom" Style="{StaticResource DarkInput}" MaxLength="24" Margin="0,0,0,14"/>

            <TextBlock Text="PANEL SERIAL" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <TextBox x:Name="txtOPSReqPanelSerial" Style="{StaticResource DarkInput}" MaxLength="80" Margin="0,0,0,14"/>

            <TextBlock Text="CURRENT OPS SERIAL (OPTIONAL)" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <TextBox x:Name="txtOPSReqCurrentOPS" Style="{StaticResource DarkInput}" MaxLength="80" Margin="0,0,0,4"/>
            <TextBlock Text="PanelApp will prefill this when it can detect the installed OPS. Leave blank if no OPS is present."
                       TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="11" Foreground="#666666" Margin="0,0,0,14"/>

            <TextBlock Text="WHY IS AN OPS NEEDED?" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <ComboBox x:Name="cboOPSReqReason" Style="{StaticResource DarkCombo}" Margin="0,0,0,14">
              <ComboBoxItem Content="No OPS installed"/>
              <ComboBoxItem Content="Current OPS failed"/>
              <ComboBoxItem Content="Temporary replacement needed"/>
              <ComboBoxItem Content="Planned replacement / project need"/>
              <ComboBoxItem Content="Other"/>
            </ComboBox>

            <TextBlock Text="IMPACT / URGENCY" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <ComboBox x:Name="cboOPSReqUrgency" Style="{StaticResource DarkCombo}" Margin="0,0,0,14">
              <ComboBoxItem Content="Classroom down - no usable OPS"/>
              <ComboBoxItem Content="Classroom degraded - temporary workaround exists"/>
              <ComboBoxItem Content="Planned / non-urgent"/>
            </ComboBox>

            <TextBlock Text="NOTES" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <TextBox x:Name="txtOPSReqNotes" Style="{StaticResource DarkInput}" Height="76"
                     AcceptsReturn="True" TextWrapping="Wrap" VerticalScrollBarVisibility="Auto" MaxLength="1000"/>

            <TextBlock x:Name="lblOPSReqError" Text="" Foreground="#EF5B5B" FontFamily="Segoe UI" FontSize="11"
                       Margin="0,10,0,0" Visibility="Collapsed"/>
          </StackPanel>
        </ScrollViewer>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Grid>
            <Button x:Name="btnOPSReqBack" Style="{StaticResource GhostBtn}" Content="&lt; Back"
                    HorizontalAlignment="Left" MinWidth="120"/>
            <Button x:Name="btnOPSReqSubmit" Style="{StaticResource PrimaryBtn}" Content="Submit OPS Request"
                    HorizontalAlignment="Right" MinWidth="180"/>
          </Grid>
        </Border>
      </Grid>

      <!-- SCREEN 2a: Full Provisioning type (Standard vs Post-RedoRescue) -->
      <Grid x:Name="pnlFullProvType" Visibility="Collapsed">
        <Grid.RowDefinitions>
          <RowDefinition Height="*"/>
          <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>
        <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto">
          <StackPanel Margin="40,28,40,10">
            <TextBlock Text="Select Provisioning Type" FontFamily="Segoe UI" FontSize="22"
                       FontWeight="Bold" Foreground="#FFFFFF" Margin="0,0,0,4"/>
            <TextBlock Text="RedoRescue performs the image restore. PanelApp does not image the drive. Use Post-RedoRescue Provisioning only after RedoRescue restore has already completed and Windows has booted into the restored image."
                       TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="13"
                       Foreground="#888888" Margin="0,0,0,22"/>

            <Button x:Name="btnProvStandard" Style="{StaticResource ModeBtn}">
              <StackPanel Orientation="Horizontal">
                <Border Background="#C8102E" CornerRadius="4" Width="40" Height="40" Margin="0,0,14,0">
                  <TextBlock Text="S" FontSize="20" FontWeight="Bold" Foreground="White"
                             HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </Border>
                <StackPanel VerticalAlignment="Center">
                  <TextBlock Text="Standard / Full Provisioning" FontFamily="Segoe UI" FontSize="15" FontWeight="Bold" Foreground="#FFFFFF"/>
                  <TextBlock Text="New install or a reimaged device not tracked by the Interactive Inventory Project"
                             FontFamily="Segoe UI" FontSize="12" Foreground="#888888" Margin="0,3,0,0"/>
                </StackPanel>
              </StackPanel>
            </Button>

            <Button x:Name="btnProvPostRedo" Style="{StaticResource ModeBtn}"
                    BorderBrush="#1FB89A" BorderThickness="2" Background="#10302B">
              <StackPanel Orientation="Horizontal">
                <Border Background="#0E7C66" CornerRadius="4" Width="40" Height="40" Margin="0,0,14,0">
                  <TextBlock Text="&#x2605;" FontSize="20" FontWeight="Bold" Foreground="White"
                             HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </Border>
                <StackPanel VerticalAlignment="Center">
                  <TextBlock Text="Interactive Inventory Project - Post-RedoRescue Provisioning" TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="15" FontWeight="Bold" Foreground="#FFFFFF"/>
                  <TextBlock Text="Continue an Interactive Inventory Project device AFTER its RedoRescue restore has completed and Windows booted"
                             FontFamily="Segoe UI" FontSize="12" Foreground="#9FE8D8" Margin="0,3,0,0"/>
                </StackPanel>
              </StackPanel>
            </Button>
          </StackPanel>
        </ScrollViewer>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Button x:Name="btnFullProvBack" Style="{StaticResource GhostBtn}"
                  Content="&lt; Back" HorizontalAlignment="Left" MinWidth="140"/>
        </Border>
      </Grid>

      <!-- SCREEN 2b: Install type sub-selection (Standard / Full Provisioning) -->
      <Grid x:Name="pnlInstallType" Visibility="Collapsed">
        <Grid.RowDefinitions>
          <RowDefinition Height="*"/>
          <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>
        <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto">
          <StackPanel Margin="40,28,40,10">
            <TextBlock Text="New Install or Reimage?" FontFamily="Segoe UI" FontSize="22"
                       FontWeight="Bold" Foreground="#FFFFFF" Margin="0,0,0,4"/>
            <TextBlock Text="Select whether this is a brand-new installation or a device already restored outside the Interactive Inventory Project."
                       TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="13"
                       Foreground="#888888" Margin="0,0,0,22"/>

            <Button x:Name="btnNewInstall" Style="{StaticResource ModeBtn}">
              <StackPanel Orientation="Horizontal">
                <Border Background="#C8102E" CornerRadius="4" Width="40" Height="40" Margin="0,0,14,0">
                  <TextBlock Text="N" FontSize="20" FontWeight="Bold" Foreground="White"
                             HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </Border>
                <StackPanel VerticalAlignment="Center">
                  <TextBlock Text="New Install" FontFamily="Segoe UI" FontSize="15" FontWeight="Bold" Foreground="#FFFFFF"/>
                  <TextBlock Text="First-time provisioning of a new device"
                             FontFamily="Segoe UI" FontSize="12" Foreground="#888888" Margin="0,3,0,0"/>
                </StackPanel>
              </StackPanel>
            </Button>

            <Button x:Name="btnReimage" Style="{StaticResource ModeBtn}">
              <StackPanel Orientation="Horizontal">
                <Border Background="#8B0000" CornerRadius="4" Width="40" Height="40" Margin="0,0,14,0">
                  <TextBlock Text="R" FontSize="20" FontWeight="Bold" Foreground="White"
                             HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </Border>
                <StackPanel VerticalAlignment="Center">
                  <TextBlock Text="Reimage (non-Interactive Inventory)" FontFamily="Segoe UI" FontSize="15" FontWeight="Bold" Foreground="#FFFFFF"/>
                  <TextBlock Text="Use only after RedoRescue has already restored the image (device not in the Interactive Inventory Project)"
                             FontFamily="Segoe UI" FontSize="12" Foreground="#888888" Margin="0,3,0,0"/>
                </StackPanel>
              </StackPanel>
            </Button>
          </StackPanel>
        </ScrollViewer>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Button x:Name="btnInstallTypeBack" Style="{StaticResource GhostBtn}"
                  Content="&lt; Back" HorizontalAlignment="Left" MinWidth="140"/>
        </Border>
      </Grid>

      <!-- SCREEN 3: OPS Serial Pull -->
      <Grid x:Name="pnlOPSSerial" Visibility="Collapsed">
        <Grid.RowDefinitions>
          <RowDefinition Height="*"/>
          <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>
        <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto">
          <StackPanel Margin="40,28,40,10">
            <TextBlock Text="OPS / PC Module Serial Number" FontFamily="Segoe UI" FontSize="22"
                       FontWeight="Bold" Foreground="#FFFFFF" Margin="0,0,0,4"/>
            <TextBlock Text="Serial numbers retrieved from this device. Review and confirm the best candidate."
                       TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="13" Foreground="#888888" Margin="0,0,0,22"/>
            <Border Background="#262626" CornerRadius="8" Padding="20,16" Margin="0,0,0,14">
              <StackPanel>
                <TextBlock Text="WMI QUERY RESULTS" FontFamily="Segoe UI" FontSize="10"
                           FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,12"/>
                <Grid Margin="0,0,0,8">
                  <Grid.ColumnDefinitions><ColumnDefinition Width="190"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
                  <TextBlock Text="Win32_BIOS" FontFamily="Segoe UI" FontSize="12" Foreground="#777777"/>
                  <TextBlock x:Name="lblOPS_BIOS" Grid.Column="1" FontFamily="Consolas" FontSize="13" Foreground="#FFFFFF" Text="--"/>
                </Grid>
                <Grid Margin="0,0,0,8">
                  <Grid.ColumnDefinitions><ColumnDefinition Width="190"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
                  <TextBlock Text="Win32_CSProduct" FontFamily="Segoe UI" FontSize="12" Foreground="#777777"/>
                  <TextBlock x:Name="lblOPS_Product" Grid.Column="1" FontFamily="Consolas" FontSize="13" Foreground="#FFFFFF" Text="--"/>
                </Grid>
                <Grid Margin="0,0,0,8">
                  <Grid.ColumnDefinitions><ColumnDefinition Width="190"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
                  <TextBlock Text="Win32_BaseBoard" FontFamily="Segoe UI" FontSize="12" Foreground="#777777"/>
                  <TextBlock x:Name="lblOPS_Board" Grid.Column="1" FontFamily="Consolas" FontSize="13" Foreground="#FFFFFF" Text="--"/>
                </Grid>
                <Grid>
                  <Grid.ColumnDefinitions><ColumnDefinition Width="190"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
                  <TextBlock Text="Registry (BIOS)" FontFamily="Segoe UI" FontSize="12" Foreground="#777777"/>
                  <TextBlock x:Name="lblOPS_Reg" Grid.Column="1" FontFamily="Consolas" FontSize="13" Foreground="#FFFFFF" Text="--"/>
                </Grid>
              </StackPanel>
            </Border>
            <Border Background="#0F1E10" CornerRadius="8" BorderBrush="#2D6A4F" BorderThickness="1"
                    Padding="20,14" Margin="0,0,0,12">
              <StackPanel>
                <TextBlock Text="DETECTED OPS SERIAL  (highest-confidence match)"
                           FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold"
                           Foreground="#4EC994" Margin="0,0,0,8"/>
                <TextBlock x:Name="lblOPS_BestValue" FontFamily="Consolas" FontSize="18"
                           FontWeight="Bold" Foreground="#4EC994" Text="--"/>
                <TextBlock x:Name="lblOPS_BestSource" FontFamily="Segoe UI" FontSize="11"
                           Foreground="#2D5A40" Text="" Margin="0,4,0,0"/>
                <TextBlock x:Name="lblOPS_Confidence" FontFamily="Segoe UI" FontSize="11"
                           Foreground="#4EC994" Text="" Margin="0,2,0,0"/>
              </StackPanel>
            </Border>
            <Border x:Name="borOPSSuspicious" Background="#1E1200" CornerRadius="6" BorderBrush="#8B6914"
                    BorderThickness="1" Padding="16,10" Margin="0,0,0,10" Visibility="Collapsed">
              <TextBlock x:Name="lblOPSSuspicious" TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="12" Foreground="#F0B030"
                Text="The detected OPS serial does not match the expected OPS model prefix. Verify the OPS serial before continuing."/>
            </Border>
            <TextBlock Text="OPS SERIAL TO USE  (edit if the detected value is wrong)"
                       FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,4,0,6"/>
            <TextBox x:Name="txtOPSOverride" Style="{StaticResource DarkInput}" FontFamily="Consolas"
                     FontSize="15" Padding="10,8" Margin="0,0,0,8"/>
            <TextBlock Text="HOW WAS THIS SERIAL VERIFIED?  (if you edited it)"
                       FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <ComboBox x:Name="cboOPSOverrideReason" Style="{StaticResource DarkCombo}" IsEditable="False" Margin="0,0,0,12"/>
            <Border x:Name="borOPSTrunc" Background="#1E1200" CornerRadius="6" BorderBrush="#8B6914"
                    BorderThickness="1" Padding="16,10" Margin="0,0,0,10" Visibility="Collapsed">
              <TextBlock TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="12" Foreground="#F0B030"
                Text="Warning: Serial appears short (under 8 chars) and may be incomplete. It will be flagged in the log entry."/>
            </Border>
            <Border x:Name="borOPSNone" Background="#200808" CornerRadius="6" BorderBrush="#7A1515"
                    BorderThickness="1" Padding="16,10" Visibility="Collapsed">
              <TextBlock TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="12" Foreground="#EF5B5B"
                Text="No serial number found. OPS serial will be logged as UNKNOWN. Verify the module is seated correctly."/>
            </Border>
          </StackPanel>
        </ScrollViewer>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Grid>
            <Button x:Name="btnOPSBack" Style="{StaticResource GhostBtn}" Content="&lt; Back" HorizontalAlignment="Left" MinWidth="120"/>
            <Button x:Name="btnOPSConfirm" Style="{StaticResource PrimaryBtn}" Content="Confirm Serial" HorizontalAlignment="Right" MinWidth="160"/>
          </Grid>
        </Border>
      </Grid>

      <!-- SCREEN 4: Barcode scan -->
      <Grid x:Name="pnlScanBarcode" Visibility="Collapsed">
        <Grid.RowDefinitions>
          <RowDefinition Height="*"/>
          <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>
        <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto">
          <StackPanel MaxWidth="560" HorizontalAlignment="Center" Margin="40,28,40,10">
            <TextBlock x:Name="lblScanHeader" Text="Scan Panel Barcode" FontFamily="Segoe UI"
                       FontSize="22" FontWeight="Bold" Foreground="#FFFFFF" Margin="0,0,0,4"/>
            <TextBlock x:Name="lblScanInstruction"
                       Text="Point the barcode scanner at the label on the panel chassis and scan."
                       TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="13"
                       Foreground="#888888" Margin="0,0,0,24"/>
            <TextBlock Text="BARCODE / SERIAL NUMBER" FontFamily="Segoe UI" FontSize="10"
                       FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <Grid>
              <Grid.ColumnDefinitions>
                <ColumnDefinition Width="*"/>
                <ColumnDefinition Width="Auto"/>
              </Grid.ColumnDefinitions>
              <TextBox x:Name="txtBarcodeInput" Style="{StaticResource DarkInput}"
                       FontFamily="Consolas" FontSize="15" VerticalContentAlignment="Center"/>
              <Border Grid.Column="1" x:Name="borScanIndicator" Background="#262626"
                      CornerRadius="4" Margin="8,0,0,0" Padding="12,0" MinWidth="90">
                <TextBlock x:Name="lblScanStatus" Text="Ready"
                           FontFamily="Segoe UI" FontSize="11" Foreground="#888888"
                           VerticalAlignment="Center" HorizontalAlignment="Center"/>
              </Border>
            </Grid>
            <Border x:Name="borScannedResult" Background="#0F1E10" CornerRadius="6"
                    Padding="14,10" Margin="0,14,0,0" Visibility="Collapsed">
              <StackPanel Orientation="Horizontal">
                <TextBlock Text="Captured: " FontFamily="Segoe UI" FontSize="12"
                           Foreground="#888888" VerticalAlignment="Center"/>
                <TextBlock x:Name="lblScannedSerial" FontFamily="Consolas" FontSize="14"
                           FontWeight="Bold" Foreground="#4EC994"/>
              </StackPanel>
            </Border>
            <Border x:Name="borMobileHint" Background="#1E1E28" CornerRadius="6"
                    BorderBrush="#383838" BorderThickness="1"
                    Padding="14,10" Margin="0,14,0,0" Visibility="Collapsed">
              <TextBlock TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="12" Foreground="#8899BB"
                         Text="Mobile unit: the last 4 digits of this serial will be pre-filled as the mobile suffix on the next screen."/>
            </Border>
            <Button x:Name="btnPanelSerialMissing" Style="{StaticResource GhostBtn}"
                    Content="Panel serial sticker missing or unreadable" HorizontalAlignment="Left"
                    Margin="0,18,0,0" MinWidth="280" Visibility="Collapsed"/>
            <TextBlock x:Name="lblPanelSerialMissingHint" Visibility="Collapsed"
                       Text="Use this only when the physical panel serial sticker cannot be read. Do not enter UNKNOWN, an OPS serial, or an asset tag as the panel serial."
                       TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="11" Foreground="#F0B030" Margin="0,8,0,0"/>
          </StackPanel>
        </ScrollViewer>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Grid>
            <Button x:Name="btnScanBack" Style="{StaticResource GhostBtn}" Content="&lt; Back" HorizontalAlignment="Left" MinWidth="120"/>
            <Button x:Name="btnScanContinue" Style="{StaticResource PrimaryBtn}"
                    Content="Continue" HorizontalAlignment="Right" MinWidth="150" IsEnabled="False"/>
          </Grid>
        </Border>
      </Grid>

      <!-- SCREEN 4b: Missing / unreadable panel serial -->
      <Grid x:Name="pnlMissingPanelSerial" Visibility="Collapsed">
        <Grid.RowDefinitions><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
        <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto">
          <StackPanel MaxWidth="620" HorizontalAlignment="Center" Margin="40,28,40,12">
            <TextBlock Text="Panel Serial Sticker Missing or Unreadable" FontFamily="Segoe UI" FontSize="22"
                       FontWeight="Bold" Foreground="#FFFFFF" Margin="0,0,0,4"/>
            <TextBlock Text="Do not guess a serial number. Select the panel manufacturer and capture the supported identity evidence below."
                       TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="13" Foreground="#888888" Margin="0,0,0,20"/>

            <TextBlock Text="MANUFACTURER" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <ComboBox x:Name="cboMissingPanelManufacturer" Style="{StaticResource DarkCombo}" IsEditable="False" Margin="0,0,0,4"/>
            <TextBlock x:Name="lblMissingPanelManufacturerError" Text="" Foreground="#EF5B5B" FontFamily="Segoe UI" FontSize="11"
                       Margin="0,2,0,14" Visibility="Collapsed"/>

            <Border x:Name="pnlMissingPromethean" Background="#12261F" BorderBrush="#2D6A4F" BorderThickness="1"
                    CornerRadius="6" Padding="14" Visibility="Collapsed">
              <StackPanel>
                <TextBlock Text="PROMETHEAN" FontFamily="Segoe UI" FontSize="12" FontWeight="Bold" Foreground="#4EC994"/>
                <TextBlock Text="Open the panel Android settings and locate the actual Promethean panel serial number. Enter that real serial below; PanelApp will use it as the panel serial for the normal inventory workflow."
                           TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="12" Foreground="#CCCCCC" Margin="0,6,0,12"/>
                <TextBlock Text="PANEL SERIAL FROM ANDROID SETTINGS" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
                <TextBox x:Name="txtMissingPrometheanSerial" Style="{StaticResource DarkInput}" FontFamily="Consolas" FontSize="14" MaxLength="80"/>
              </StackPanel>
            </Border>

            <Border x:Name="pnlMissingBoxlight" Background="#1E1E28" BorderBrush="#3D4F6A" BorderThickness="1"
                    CornerRadius="6" Padding="14" Visibility="Collapsed">
              <StackPanel>
                <TextBlock Text="BOXLIGHT" FontFamily="Segoe UI" FontSize="12" FontWeight="Bold" Foreground="#9FC8E8"/>
                <TextBlock Text="Do not open a service/debug menu as part of the normal inventory visit. Capture the identifiers you can see. On the NDMS enrollment screen, Device ID and Tags are acceptable; if the NDMS name is available, enter it too. The lead will reconcile the real panel serial through NDMS/vendor records."
                           TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="12" Foreground="#CCCCCC" Margin="0,6,0,14"/>
                <TextBlock Text="APS ASSET TAG (IF PRESENT)" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
                <TextBox x:Name="txtMissingAssetTag" Style="{StaticResource DarkInput}" FontFamily="Consolas" FontSize="14" MaxLength="80" Margin="0,0,0,12"/>
                <TextBlock Text="NDMS NAME (IF AVAILABLE)" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
                <TextBox x:Name="txtMissingNDMSName" Style="{StaticResource DarkInput}" FontFamily="Consolas" FontSize="14" MaxLength="120" Margin="0,0,0,12"/>
                <TextBlock Text="NDMS DEVICE ID" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
                <TextBox x:Name="txtMissingNDMSDeviceId" Style="{StaticResource DarkInput}" FontFamily="Consolas" FontSize="14" MaxLength="120" Margin="0,0,0,12"/>
                <TextBlock Text="NDMS TAGS" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
                <TextBox x:Name="txtMissingNDMSTags" Style="{StaticResource DarkInput}" FontSize="14" MaxLength="240"/>
                <TextBlock Text="Enter every visible NDMS tag, separated by commas if there is more than one. At least one Boxlight reconciliation field (asset tag, NDMS name, Device ID, or tags) is required."
                           TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="11" Foreground="#8899BB" Margin="0,8,0,0"/>
              </StackPanel>
            </Border>
            <TextBlock x:Name="lblMissingPanelSerialError" Text="" TextWrapping="Wrap" Foreground="#EF5B5B"
                       FontFamily="Segoe UI" FontSize="11" Margin="0,10,0,0" Visibility="Collapsed"/>
          </StackPanel>
        </ScrollViewer>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Grid>
            <Button x:Name="btnMissingPanelSerialBack" Style="{StaticResource GhostBtn}" Content="&lt; Back" HorizontalAlignment="Left" MinWidth="120"/>
            <Button x:Name="btnMissingPanelSerialContinue" Style="{StaticResource PrimaryBtn}" Content="Continue" HorizontalAlignment="Right" MinWidth="150"/>
          </Grid>
        </Border>
      </Grid>

      <!-- SCREEN 5: Location (school / manufacturer / mount / room) -->
      <Grid x:Name="pnlLocation" Visibility="Collapsed">
        <Grid.RowDefinitions>
          <RowDefinition Height="*"/>
          <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>
        <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto">
          <StackPanel Margin="40,28,40,10">
            <TextBlock Text="Location and Device Details" FontFamily="Segoe UI" FontSize="22"
                       FontWeight="Bold" Foreground="#FFFFFF" Margin="0,0,0,4"/>
            <TextBlock Text="Select the school, manufacturer, and mounting type, then enter the room."
                       TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="13"
                       Foreground="#888888" Margin="0,0,0,24"/>
            <TextBlock Text="SCHOOL" FontFamily="Segoe UI" FontSize="10"
                       FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <ComboBox x:Name="cboSchool" Style="{StaticResource DarkCombo}" IsEditable="False" Margin="0,0,0,4"/>
            <TextBlock x:Name="lblSchoolError" Text="" Foreground="#EF5B5B"
                       FontFamily="Segoe UI" FontSize="11" Margin="0,2,0,16" Visibility="Collapsed"/>
            <TextBlock x:Name="lblMfrLabel" Text="MANUFACTURER" FontFamily="Segoe UI"
                       FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <ComboBox x:Name="cboManufacturer" Style="{StaticResource DarkCombo}" IsEditable="False" Margin="0,0,0,4"/>
            <TextBlock x:Name="lblMfrError" Text="" Foreground="#EF5B5B"
                       FontFamily="Segoe UI" FontSize="11" Margin="0,2,0,16" Visibility="Collapsed"/>
            <TextBlock x:Name="lblModelLabel" Text="PANEL MODEL" FontFamily="Segoe UI"
                       FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <ComboBox x:Name="cboPanelModel" Style="{StaticResource DarkCombo}" IsEditable="False" Margin="0,0,0,4"/>
            <TextBlock x:Name="lblPanelModelError" Text="" Foreground="#EF5B5B"
                       FontFamily="Segoe UI" FontSize="11" Margin="0,2,0,16" Visibility="Collapsed"/>
            <TextBlock Text="ROOM TYPE" FontFamily="Segoe UI" FontSize="10"
                       FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <ComboBox x:Name="cboRoomType" Style="{StaticResource DarkCombo}" IsEditable="False" Margin="0,0,0,4"/>
            <TextBlock x:Name="lblRoomTypeError" Text="" Foreground="#EF5B5B"
                       FontFamily="Segoe UI" FontSize="11" Margin="0,2,0,10" Visibility="Collapsed"/>
            <TextBlock x:Name="lblOtherRoomTypeLabel" Text="DESCRIBE ROOM TYPE (OTHER)" FontFamily="Segoe UI" FontSize="10"
                       FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6" Visibility="Collapsed"/>
            <TextBox x:Name="txtOtherRoomType" Style="{StaticResource DarkInput}"
                     FontSize="14" Padding="12,9" MaxLength="40" Margin="0,0,0,16" Visibility="Collapsed"/>
            <TextBlock Text="MOUNT TYPE" FontFamily="Segoe UI" FontSize="10"
                       FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,8"/>
            <StackPanel Orientation="Horizontal" Margin="0,0,0,20">
              <RadioButton x:Name="rdoWallMounted" Style="{StaticResource DarkRadio}"
                           Content="Wall Mounted" IsChecked="True"/>
              <RadioButton x:Name="rdoMobile" Style="{StaticResource DarkRadio}" Content="Mobile / Cart"/>
            </StackPanel>
            <TextBlock x:Name="lblRoomLabel" Text="ROOM NUMBER"
                       FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold"
                       Foreground="#888888" Margin="0,0,0,6"/>
            <TextBox x:Name="txtRoomNumber" Style="{StaticResource DarkInput}"
                     FontSize="15" Padding="12,10" MaxLength="20" Margin="0,0,0,4"/>
            <TextBlock x:Name="lblRoomHint"
                       Text="Wall: room number (e.g. 214, GYM). Mobile: auto-filled with last 4 of serial - edit freely."
                       FontFamily="Segoe UI" FontSize="11" Foreground="#555555" Margin="0,0,0,2"/>
            <TextBlock x:Name="lblRoomError" Text="" Foreground="#EF5B5B"
                       FontFamily="Segoe UI" FontSize="11" Margin="0,2,0,0" Visibility="Collapsed"/>
          </StackPanel>
        </ScrollViewer>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Grid>
            <Button x:Name="btnLocationBack" Style="{StaticResource GhostBtn}" Content="&lt; Back" HorizontalAlignment="Left" MinWidth="120"/>
            <Button x:Name="btnLocationContinue" Style="{StaticResource PrimaryBtn}"
                    Content="Build Hostname" HorizontalAlignment="Right" MinWidth="170"/>
          </Grid>
        </Border>
      </Grid>

      <!-- SCREEN 6: Hostname builder / confirm -->
      <Grid x:Name="pnlHostname" Visibility="Collapsed">
        <Grid.RowDefinitions>
          <RowDefinition Height="*"/>
          <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>
        <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto">
          <StackPanel MaxWidth="560" HorizontalAlignment="Center" Margin="40,28,40,10">
            <TextBlock Text="Confirm Hostname" FontFamily="Segoe UI" FontSize="22"
                       FontWeight="Bold" Foreground="#FFFFFF" Margin="0,0,0,4"/>
            <TextBlock Text="The hostname below was built from your selections. Edit if needed, then confirm."
                       TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="13"
                       Foreground="#888888" Margin="0,0,0,24"/>
            <TextBlock Text="COMPUTER HOSTNAME  (NetBIOS - max 15 characters)"
                       FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold"
                       Foreground="#888888" Margin="0,0,0,6"/>
            <TextBox x:Name="txtHostname" Style="{StaticResource DarkInput}"
                     FontFamily="Consolas" FontSize="22" FontWeight="Bold"
                     Padding="12,10" MaxLength="15" CharacterCasing="Upper"/>
            <Grid Margin="0,6,0,0">
              <TextBlock x:Name="lblHostnameValidation" Text="" Foreground="#EF5B5B"
                         FontFamily="Segoe UI" FontSize="12" HorizontalAlignment="Left"/>
              <TextBlock x:Name="lblHostnameLength" Text="0 / 15" Foreground="#888888"
                         FontFamily="Segoe UI Mono" FontSize="11" HorizontalAlignment="Right"/>
            </Grid>
            <Border Background="#1E1E1E" CornerRadius="6" Padding="14,10" Margin="0,20,0,0">
              <TextBlock TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="12" Foreground="#666666"
                Text="Wall:   [School]I9[Mfr][Room]X       e.g. MJI9BL279X&#x0a;Mobile: [School]I9[Mfr]MB[Last4]X  e.g. MJI9BLMB0279X"/>
            </Border>
            <Border Background="#12261F" CornerRadius="6" BorderBrush="#2D6A4F" BorderThickness="1" Padding="14,10" Margin="0,10,0,0">
              <TextBlock TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="12" Foreground="#9FE8D8"
                Text="The app adds the temporary X suffix because old AD computer objects may still exist. You do not need to add it yourself."/>
            </Border>
            <Border Background="#1E1E1E" CornerRadius="6" Padding="14,10" Margin="0,10,0,0">
              <StackPanel>
                <TextBlock Text="CURRENT WINDOWS HOSTNAME  (reference only)" FontFamily="Segoe UI" FontSize="10"
                           FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,4"/>
                <TextBlock x:Name="lblCurrentHostname" FontFamily="Consolas" FontSize="13" Foreground="#AAAAAA" Text="--"/>
                <TextBlock Text="This may be the temporary hostname created after RedoRescue restore. It is shown for reference only."
                           TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="11" Foreground="#555555" Margin="0,4,0,0"/>
              </StackPanel>
            </Border>
            <TextBlock x:Name="lblOldHostnameLabel" Text="PREVIOUS / OLD HOSTNAME  (optional)" FontFamily="Segoe UI" FontSize="10"
                       FontWeight="SemiBold" Foreground="#888888" Margin="0,14,0,6"/>
            <TextBox x:Name="txtOldHostname" Style="{StaticResource DarkInput}" FontFamily="Consolas"
                     FontSize="14" Padding="10,8" MaxLength="15" CharacterCasing="Upper"/>
            <TextBlock x:Name="lblOldHostnameHint" TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="11"
                       Foreground="#555555" Margin="0,4,0,0"
                       Text="If you know the old hostname, enter it so PanelApp can check for old AD/DNS records. If you do not know it, leave this blank."/>
            <Button x:Name="btnCheckHostname" Style="{StaticResource GhostBtn}" Content="Check Hostname in AD/DNS"
                    HorizontalAlignment="Left" Margin="0,12,0,0"/>
            <TextBlock x:Name="lblHostnameCheck" Text="" TextWrapping="Wrap" FontFamily="Segoe UI"
                       FontSize="12" Foreground="#F0B030" Margin="0,8,0,0" Visibility="Collapsed"/>
            <Border x:Name="borAltHostname" Background="#12261F" CornerRadius="6" BorderBrush="#2D6A4F"
                    BorderThickness="1" Padding="14,10" Margin="0,10,0,0" Visibility="Collapsed">
              <StackPanel>
                <TextBlock Text="AVAILABLE ALTERNATE HOSTNAME" FontFamily="Segoe UI" FontSize="10"
                           FontWeight="SemiBold" Foreground="#4EC994" Margin="0,0,0,4"/>
                <TextBlock x:Name="lblAltHostname" FontFamily="Consolas" FontSize="16" FontWeight="Bold" Foreground="#4EC994" Text="--"/>
                <Button x:Name="btnUseAlternate" Style="{StaticResource GhostBtn}" Content="Use This Alternate Hostname"
                        HorizontalAlignment="Left" Margin="0,8,0,0"/>
              </StackPanel>
            </Border>
          </StackPanel>
        </ScrollViewer>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Grid>
            <Button x:Name="btnHostnameBack" Style="{StaticResource GhostBtn}" Content="&lt; Back" HorizontalAlignment="Left" MinWidth="120"/>
            <Button x:Name="btnHostnameConfirm" Style="{StaticResource PrimaryBtn}" Content="Confirm" HorizontalAlignment="Right" MinWidth="150"/>
          </Grid>
        </Border>
      </Grid>

      <!-- SCREEN 7: Mode 3 - OPS disposition -->
      <Grid x:Name="pnlM3Disposition" Visibility="Collapsed">
        <Grid.RowDefinitions>
          <RowDefinition Height="*"/>
          <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>
        <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto">
          <StackPanel Margin="40,28,40,10" MaxWidth="560" HorizontalAlignment="Center">
            <TextBlock Text="Removed OPS - What Happens Next?" FontFamily="Segoe UI" FontSize="22"
                       FontWeight="Bold" Foreground="#FFFFFF" Margin="0,0,0,4"/>
            <TextBlock Text="The OPS module being replaced needs to be accounted for."
                       FontFamily="Segoe UI" FontSize="13" Foreground="#888888" Margin="0,0,0,24"/>
            <RadioButton x:Name="rdoM3SetAside" Style="{StaticResource DarkRadio}"
                         Content="Setting it aside (not going into another panel right now)"
                         GroupName="M3Disp" IsChecked="True" Margin="0,0,0,12"/>
            <RadioButton x:Name="rdoM3AnotherPanel" Style="{StaticResource DarkRadio}"
                         Content="Going directly into another panel - will be captured when that panel is processed"
                         GroupName="M3Disp" Margin="0,0,0,22"/>
            <Border x:Name="borM3MoveReason" Background="#262626" CornerRadius="8" Padding="20,16" Margin="0,0,0,18">
              <StackPanel>
                <TextBlock Text="WHY IS THIS OPS IN THIS PANEL?" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
                <TextBlock x:Name="lblM3ReassignmentContext" Text="Choose the reason for this OPS move." FontFamily="Segoe UI" FontSize="12" Foreground="#CCCCCC" TextWrapping="Wrap" Margin="0,0,0,14"/>
                <RadioButton x:Name="rdoM3Permanent" Style="{StaticResource DarkRadio}" Content="Permanent OPS move / swap" GroupName="M3MoveType" Margin="0,0,0,10"/>
                <RadioButton x:Name="rdoM3Temporary" Style="{StaticResource DarkRadio}" Content="Temporary classroom coverage - this OPS will need follow-up" GroupName="M3MoveType" Margin="0,0,0,10"/>
                <RadioButton x:Name="rdoM3Testing" Style="{StaticResource DarkRadio}" Content="Testing / troubleshooting only - do NOT change current inventory pairing" GroupName="M3MoveType" Margin="0,0,0,6"/>
                <TextBlock x:Name="lblM3MoveReasonError" Text="Select why the OPS is being moved." FontFamily="Segoe UI" FontSize="11" Foreground="#FF6B6B" Visibility="Collapsed" TextWrapping="Wrap" Margin="0,8,0,0"/>
              </StackPanel>
            </Border>
            <Border x:Name="pnlM3OldOPS" Background="#262626" CornerRadius="8" Padding="20,16" Visibility="Visible">
              <StackPanel>
                <TextBlock Text="SCAN BARCODE OF THE REMOVED OPS MODULE"
                           FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold"
                           Foreground="#888888" Margin="0,0,0,8"/>
                <Grid>
                  <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="Auto"/>
                  </Grid.ColumnDefinitions>
                  <TextBox x:Name="txtOldOPSBarcode" Style="{StaticResource DarkInput}"
                           FontFamily="Consolas" FontSize="14" VerticalContentAlignment="Center"/>
                  <Border Grid.Column="1" Background="#2A2A2A" CornerRadius="4"
                          Margin="8,0,0,0" Padding="10,0" MinWidth="80">
                    <TextBlock x:Name="lblOldOPSScanStatus" Text="Ready"
                               FontFamily="Segoe UI" FontSize="11" Foreground="#888888"
                               VerticalAlignment="Center" HorizontalAlignment="Center"/>
                  </Border>
                </Grid>
              </StackPanel>
            </Border>
          </StackPanel>
        </ScrollViewer>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Grid>
            <Button x:Name="btnM3Back" Style="{StaticResource GhostBtn}" Content="&lt; Back" HorizontalAlignment="Left" MinWidth="120"/>
            <Button x:Name="btnM3Continue" Style="{StaticResource PrimaryBtn}" Content="Continue" HorizontalAlignment="Right" MinWidth="150"/>
          </Grid>
        </Border>
      </Grid>

      <!-- SCREEN 8: Mode 5 - hostname verification -->
      <Grid x:Name="pnlM5HostnameCheck" Visibility="Collapsed">
        <Grid.RowDefinitions>
          <RowDefinition Height="*"/>
          <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>
        <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto">
          <StackPanel Margin="40,28,40,10" MaxWidth="560" HorizontalAlignment="Center">
            <TextBlock Text="Verify Current Hostname" FontFamily="Segoe UI" FontSize="22"
                       FontWeight="Bold" Foreground="#FFFFFF" Margin="0,0,0,4"/>
            <TextBlock Text="Confirm whether the existing hostname is correct for this panel's location."
                       TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="13"
                       Foreground="#888888" Margin="0,0,0,22"/>
            <Border Background="#262626" CornerRadius="8" Padding="20,14" Margin="0,0,0,20">
              <StackPanel>
                <TextBlock Text="CURRENT HOSTNAME" FontFamily="Segoe UI" FontSize="10"
                           FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
                <TextBlock x:Name="lblM5CurrentHostname" FontFamily="Consolas"
                           FontSize="22" FontWeight="Bold" Foreground="#C8102E"/>
              </StackPanel>
            </Border>
            <TextBlock Text="Is this hostname correct for the panel's current location?"
                       FontFamily="Segoe UI" FontSize="14" Foreground="#FFFFFF" Margin="0,0,0,12"/>
            <StackPanel Orientation="Horizontal">
              <RadioButton x:Name="rdoM5Yes" Style="{StaticResource DarkRadio}"
                           Content="Yes - hostname is correct" GroupName="M5HN" IsChecked="True"/>
              <RadioButton x:Name="rdoM5No"  Style="{StaticResource DarkRadio}"
                           Content="No - rebuild hostname"    GroupName="M5HN"/>
            </StackPanel>
            <Border x:Name="borM5RebuildNote" Background="#1E1200" CornerRadius="6"
                    BorderBrush="#8B6914" BorderThickness="1"
                    Padding="14,10" Margin="0,16,0,0" Visibility="Collapsed">
              <TextBlock TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="12" Foreground="#F0B030"
                         Text="Clicking Continue will take you to the Location screen to build the correct hostname. The device WILL be renamed."/>
            </Border>
          </StackPanel>
        </ScrollViewer>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Grid>
            <Button x:Name="btnM5Back" Style="{StaticResource GhostBtn}" Content="&lt; Back" HorizontalAlignment="Left" MinWidth="120"/>
            <Button x:Name="btnM5Continue" Style="{StaticResource PrimaryBtn}" Content="Continue" HorizontalAlignment="Right" MinWidth="150"/>
          </Grid>
        </Border>
      </Grid>

      <!-- SCREEN 9: Review / Confirm -->
      <Grid x:Name="pnlReview" Visibility="Collapsed">
        <Grid.RowDefinitions>
          <RowDefinition Height="*"/>
          <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>
        <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto">
          <StackPanel Margin="40,28,40,10">
            <TextBlock x:Name="lblReviewTitle" Text="Review and Confirm" FontFamily="Segoe UI"
                       FontSize="22" FontWeight="Bold" Foreground="#FFFFFF" Margin="0,0,0,4"/>
            <TextBlock Text="Verify all captured information before any changes are made to this device."
                       TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="13"
                       Foreground="#888888" Margin="0,0,0,22"/>
            <Border Background="#262626" CornerRadius="8" Padding="20,16" Margin="0,0,0,14">
              <StackPanel x:Name="spReviewItems"/>
            </Border>
            <Border x:Name="borReviewWarning" Background="#1E1200" CornerRadius="6"
                    BorderBrush="#8B6914" BorderThickness="1" Padding="16,12" Visibility="Collapsed">
              <TextBlock x:Name="lblReviewWarning" TextWrapping="Wrap"
                         FontFamily="Segoe UI" FontSize="12" Foreground="#F0B030"/>
            </Border>
          </StackPanel>
        </ScrollViewer>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Grid>
            <Button x:Name="btnReviewBack"    Style="{StaticResource GhostBtn}" Content="&lt; Back" HorizontalAlignment="Left" MinWidth="120"/>
            <Button x:Name="btnReviewExecute" Style="{StaticResource GreenBtn}"  Content="Confirm and Execute" HorizontalAlignment="Right" MinWidth="200"/>
          </Grid>
        </Border>
      </Grid>

      <!-- SCREEN 10: Progress / execution log -->
      <Grid x:Name="pnlProgress" Visibility="Collapsed">
        <Grid.RowDefinitions>
          <RowDefinition Height="*"/>
          <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>
        <StackPanel Grid.Row="0" Margin="40,28,40,10">
          <TextBlock x:Name="lblProgressHeader" Text="Executing..."
                     FontFamily="Segoe UI" FontSize="22" FontWeight="Bold"
                     Foreground="#FFFFFF" Margin="0,0,0,4"/>
          <TextBlock x:Name="lblProgressStatus" Text="Starting..."
                     FontFamily="Segoe UI" FontSize="13" Foreground="#C8102E" Margin="0,0,0,12"/>
          <ProgressBar x:Name="pbarProgress" Height="4" IsIndeterminate="True"
                       Foreground="#C8102E" Background="#262626"
                       BorderThickness="0" Margin="0,0,0,14"/>
          <TextBox x:Name="txtProgressLog" Style="{StaticResource DarkMono}"
                   Height="260" VerticalScrollBarVisibility="Auto"
                   HorizontalScrollBarVisibility="Auto"
                   TextWrapping="NoWrap" AcceptsReturn="True"/>
        </StackPanel>
        <Border x:Name="borPhaseAFailure" Background="#200808" CornerRadius="6" BorderBrush="#7A1515"
                BorderThickness="1" Padding="14,10" Margin="0,10,0,0" Visibility="Collapsed">
          <StackPanel>
            <TextBlock Text="PHASE A FAILURE - CLEANUP STATUS" FontFamily="Segoe UI" FontSize="10"
                       FontWeight="SemiBold" Foreground="#EF5B5B" Margin="0,0,0,6"/>
            <TextBlock x:Name="lblPhaseAFailureState" TextWrapping="Wrap" FontFamily="Consolas"
                       FontSize="12" Foreground="#F0B0B0" Text="--"/>
          </StackPanel>
        </Border>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Grid>
            <Button x:Name="btnAbortProvision" Style="{StaticResource GhostBtn}"
                    Content="Abort Provisioning Attempt..." HorizontalAlignment="Left" MinWidth="200" Visibility="Collapsed"/>
            <StackPanel Orientation="Horizontal" HorizontalAlignment="Right">
              <Button x:Name="btnProgressReportIssue" Style="{StaticResource GhostBtn}"
                      Content="Report an Issue" MinWidth="150" Margin="0,0,10,0" Visibility="Collapsed"/>
              <Button x:Name="btnProgressRetry" Style="{StaticResource GhostBtn}"
                      Content="Retry Phase A" MinWidth="150" Margin="0,0,10,0" Visibility="Collapsed"/>
              <Button x:Name="btnProgressDone" Style="{StaticResource GhostBtn}"
                      Content="Close" MinWidth="120" Margin="0,0,10,0" Visibility="Collapsed"/>
              <Button x:Name="btnProgressReboot" Style="{StaticResource GreenBtn}"
                      Content="Reboot Now" MinWidth="150" Visibility="Collapsed"/>
            </StackPanel>
          </Grid>
        </Border>
      </Grid>

      <!-- SCREEN 11: Phase B - domain join -->
      <Grid x:Name="pnlPhaseB" Visibility="Collapsed">
        <Grid.RowDefinitions>
          <RowDefinition Height="*"/>
          <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>
        <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto">
          <StackPanel Margin="40,28,40,10" MaxWidth="540" HorizontalAlignment="Center">
            <TextBlock Text="Phase B - Domain Join" FontFamily="Segoe UI" FontSize="22"
                       FontWeight="Bold" Foreground="#FFFFFF" Margin="0,0,0,4"/>
            <TextBlock Text="Phase A completed. Enter domain credentials to join apsk12.org."
                       TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="13"
                       Foreground="#888888" Margin="0,0,0,22"/>
            <Border Background="#262626" CornerRadius="8" Padding="16,12" Margin="0,0,0,20">
              <TextBlock x:Name="txtPhaseBInfo" TextWrapping="Wrap"
                         FontFamily="Consolas" FontSize="12" Foreground="#AAAAAA"/>
            </Border>
            <TextBlock Text="DOMAIN USERNAME  (apsk12.org)" FontFamily="Segoe UI" FontSize="10"
                       FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <TextBox x:Name="txtDomainUser" Style="{StaticResource DarkInput}"
                     FontSize="14" Padding="10,8" Margin="0,0,0,4" MaxLength="60"/>
            <TextBlock Text="Use your APS domain admin or field tech domain-join account. Do not use your standard APS user account."
                       TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="11" Foreground="#F0B030" Margin="0,0,0,16"/>
            <TextBlock Text="DOMAIN PASSWORD" FontFamily="Segoe UI" FontSize="10"
                       FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <PasswordBox x:Name="pwbDomainPass" Style="{StaticResource DarkPassBox}"
                         FontSize="14" Padding="10,8" Margin="0,0,0,6"/>
            <TextBox x:Name="txtDomainPassVisible" Style="{StaticResource DarkInput}"
                     FontSize="14" Padding="10,8" Margin="0,0,0,6" Visibility="Collapsed"/>
            <CheckBox x:Name="chkShowPass" Content="Show password" Foreground="#CCCCCC"
                      FontFamily="Segoe UI" FontSize="12" Margin="0,0,0,6"/>
            <TextBlock Text="Credentials are used only for this domain join and are not stored."
                       FontFamily="Segoe UI" FontSize="11" Foreground="#555555" Margin="0,0,0,20"/>
            <ProgressBar x:Name="pbarPhaseB" Height="4" IsIndeterminate="False"
                         Value="0" Foreground="#C8102E" Background="#262626"
                         BorderThickness="0" Margin="0,0,0,10"/>
            <TextBox x:Name="txtPhaseBLog" Style="{StaticResource DarkMono}"
                     Height="150" VerticalScrollBarVisibility="Auto"
                     TextWrapping="NoWrap" AcceptsReturn="True"/>
            <TextBlock x:Name="lblPhaseBStatus" Text="" FontFamily="Segoe UI"
                       FontSize="12" Foreground="#4EC994" Margin="0,8,0,0"/>
          </StackPanel>
        </ScrollViewer>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Grid>
            <Button x:Name="btnJoinDomain" Style="{StaticResource GreenBtn}"
                    Content="Join Domain" HorizontalAlignment="Left" MinWidth="160"/>
            <Button x:Name="btnPhaseBReportIssue" Style="{StaticResource GhostBtn}"
                    Content="Report an Issue" HorizontalAlignment="Center" MinWidth="150" Visibility="Collapsed"/>
            <Button x:Name="btnPhaseBReboot" Style="{StaticResource PrimaryBtn}"
                    Content="Reboot to Complete" HorizontalAlignment="Right"
                    MinWidth="200" Visibility="Collapsed"/>
          </Grid>
        </Border>
      </Grid>

      <!-- SCREEN 12: Complete -->
      <Grid x:Name="pnlComplete" Visibility="Collapsed">
        <StackPanel VerticalAlignment="Center" HorizontalAlignment="Center" MaxWidth="480">
          <TextBlock x:Name="lblCompleteIcon" Text="&#x2714;" FontSize="64"
                     HorizontalAlignment="Center" Foreground="#4EC994" Margin="0,0,0,16"/>
          <TextBlock x:Name="lblCompleteTitle" Text="Complete" FontFamily="Segoe UI"
                     FontSize="28" FontWeight="Bold" Foreground="#FFFFFF"
                     HorizontalAlignment="Center" Margin="0,0,0,10"/>
          <TextBlock x:Name="lblCompleteMessage" TextWrapping="Wrap" FontFamily="Segoe UI"
                     FontSize="14" Foreground="#AAAAAA" TextAlignment="Center" Margin="0,0,0,30"/>
          <Button x:Name="btnCloseApp" Style="{StaticResource PrimaryBtn}"
                  Content="Close Application" HorizontalAlignment="Center" MinWidth="200"/>
        </StackPanel>
      </Grid>

      <!-- SCREEN 12a: Interactive Inventory Project Day One Readiness -->
      <Grid x:Name="pnlDayOneCheck" Visibility="Collapsed">
        <Grid.RowDefinitions>
          <RowDefinition Height="*"/>
          <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>
        <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto">
          <StackPanel MaxWidth="620" HorizontalAlignment="Center" Margin="40,28,40,10">
            <TextBlock Text="Interactive Inventory Project 2026 - Panel Readiness" FontFamily="Segoe UI" FontSize="22"
                       FontWeight="Bold" Foreground="#FFFFFF" Margin="0,0,0,4"/>
            <TextBlock Text="By selecting Continue, you are confirming this panel is ready for classroom use. If any required item is not ready, select Report an Issue instead."
                       TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="13" Foreground="#888888" Margin="0,0,0,20"/>

            <Border Background="#262626" CornerRadius="8" Padding="20,16" Margin="0,0,0,16">
              <StackPanel>
                <TextBlock Text="READINESS CHECKS" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,12"/>
                <CheckBox x:Name="chkDisplay" Content="Panel powers on and the OPS displays correctly" Foreground="#FFFFFF" FontFamily="Segoe UI" FontSize="13" Margin="0,0,0,10"/>
                <CheckBox x:Name="chkTouch"   Content="Touch is working" Foreground="#FFFFFF" FontFamily="Segoe UI" FontSize="13" Margin="0,0,0,10"/>
                <CheckBox x:Name="chkSound"   Content="Sound is working" Foreground="#FFFFFF" FontFamily="Segoe UI" FontSize="13" Margin="0,0,0,10"/>
                <CheckBox x:Name="chkCables"  Content="Cables are managed and secured" Foreground="#FFFFFF" FontFamily="Segoe UI" FontSize="13" Margin="0,0,0,10"/>
                <CheckBox x:Name="chkNetwork" Content="Network connection is working" Foreground="#FFFFFF" FontFamily="Segoe UI" FontSize="13" Margin="0,0,0,10"/>
                <CheckBox x:Name="chkNDMS"    Content="NDMS is enrolled and online on the Android side" Foreground="#FFFFFF" FontFamily="Segoe UI" FontSize="13" Margin="0,0,0,2"/>
              </StackPanel>
            </Border>

            <TextBlock Text="NETWORK CONNECTION TYPE" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,8"/>
            <StackPanel Orientation="Horizontal" Margin="0,0,0,6">
              <RadioButton x:Name="rdoNetEthernet" Style="{StaticResource DarkRadio}" Content="Ethernet" GroupName="DayOneNet"/>
              <RadioButton x:Name="rdoNetWifi"     Style="{StaticResource DarkRadio}" Content="Wi-Fi" GroupName="DayOneNet"/>
            </StackPanel>

            <TextBlock x:Name="lblDayOneError" Text="" Foreground="#EF5B5B" FontFamily="Segoe UI"
                       FontSize="12" TextWrapping="Wrap" Margin="0,4,0,0" Visibility="Collapsed"/>

            <Button x:Name="btnReportIssue" Style="{StaticResource GhostBtn}"
                    Content="Report an Issue / Not Panel Ready" HorizontalAlignment="Left" Margin="0,14,0,0"/>

            <Border x:Name="borIssueForm" Background="#200808" CornerRadius="8" BorderBrush="#7A1515"
                    BorderThickness="1" Padding="20,16" Margin="0,14,0,0" Visibility="Collapsed">
              <StackPanel>
                <TextBlock Text="REPORT AN ISSUE" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#EF5B5B" Margin="0,0,0,10"/>
                <TextBlock Text="ISSUE CATEGORY" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
                <ComboBox x:Name="cboIssueCategory" Style="{StaticResource DarkCombo}" IsEditable="False" Margin="0,0,0,12"/>
                <TextBlock Text="NOTE (OPTIONAL)" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
                <TextBox x:Name="txtIssueNote" Style="{StaticResource DarkInput}" FontSize="13" Height="64"
                         TextWrapping="Wrap" AcceptsReturn="True" VerticalScrollBarVisibility="Auto" Margin="0,0,0,12"/>
                <Button x:Name="btnIssueSubmit" Style="{StaticResource PrimaryBtn}" Content="Submit and Continue Inventory" HorizontalAlignment="Left"/>
              </StackPanel>
            </Border>
          </StackPanel>
        </ScrollViewer>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Grid>
            <Button x:Name="btnDayOneBack" Style="{StaticResource GhostBtn}" Content="&lt; Back" HorizontalAlignment="Left" MinWidth="120"/>
            <Button x:Name="btnDayOneContinue" Style="{StaticResource PrimaryBtn}" Content="Continue" HorizontalAlignment="Right" MinWidth="170"/>
          </Grid>
        </Border>
      </Grid>

      <!-- SCREEN 12b: Interactive Inventory Project Inventory - capture summary -->
      <Grid x:Name="pnlSummerSummary" Visibility="Collapsed">
        <Grid.RowDefinitions>
          <RowDefinition Height="*"/>
          <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>
        <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto">
          <StackPanel MaxWidth="600" HorizontalAlignment="Center" Margin="40,28,40,10">
            <StackPanel Orientation="Horizontal" Margin="0,0,0,4">
              <TextBlock Text="&#x2714;" FontSize="22" Foreground="#4EC994" VerticalAlignment="Center" Margin="0,0,10,0"/>
              <TextBlock Text="Interactive Inventory Project - Captured" FontFamily="Segoe UI" FontSize="22"
                         FontWeight="Bold" Foreground="#FFFFFF" VerticalAlignment="Center"/>
            </StackPanel>
            <TextBlock Text="This device has been recorded. Follow the action below."
                       FontFamily="Segoe UI" FontSize="13" Foreground="#888888" Margin="0,0,0,20"/>

            <Border Background="#262626" CornerRadius="8" Padding="20,16" Margin="0,0,0,16">
              <StackPanel>
                <Grid Margin="0,0,0,10">
                  <Grid.ColumnDefinitions><ColumnDefinition Width="150"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
                  <TextBlock Text="Location" FontFamily="Segoe UI" FontSize="13" Foreground="#888888"/>
                  <TextBlock x:Name="lblSum_Device" Grid.Column="1" FontFamily="Consolas" FontSize="14" FontWeight="Bold" Foreground="#FFFFFF" Text="--"/>
                </Grid>
                <Grid Margin="0,0,0,10">
                  <Grid.ColumnDefinitions><ColumnDefinition Width="150"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
                  <TextBlock Text="OPS Serial" FontFamily="Segoe UI" FontSize="13" Foreground="#888888"/>
                  <TextBlock x:Name="lblSum_OPS" Grid.Column="1" FontFamily="Consolas" FontSize="14" FontWeight="Bold" Foreground="#FFFFFF" Text="--"/>
                </Grid>
                <Grid Margin="0,0,0,10">
                  <Grid.ColumnDefinitions><ColumnDefinition Width="150"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
                  <TextBlock Text="Panel Serial" FontFamily="Segoe UI" FontSize="13" Foreground="#888888"/>
                  <TextBlock x:Name="lblSum_Panel" Grid.Column="1" FontFamily="Consolas" FontSize="14" FontWeight="Bold" Foreground="#4EC994" Text="--"/>
                </Grid>
                <Grid Margin="0,0,0,10">
                  <Grid.ColumnDefinitions><ColumnDefinition Width="150"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
                  <TextBlock Text="Storage" FontFamily="Segoe UI" FontSize="13" Foreground="#888888"/>
                  <TextBlock x:Name="lblSum_Storage" Grid.Column="1" FontFamily="Consolas" FontSize="14" FontWeight="Bold" Foreground="#FFFFFF" Text="--"/>
                </Grid>
                <Grid>
                  <Grid.ColumnDefinitions><ColumnDefinition Width="150"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
                  <TextBlock Text="OS" FontFamily="Segoe UI" FontSize="13" Foreground="#888888"/>
                  <TextBlock x:Name="lblSum_OS" Grid.Column="1" FontFamily="Consolas" FontSize="14" FontWeight="Bold" Foreground="#FFFFFF" Text="--"/>
                </Grid>
              </StackPanel>
            </Border>

            <Border x:Name="borSum_Action" Background="#1E1200" CornerRadius="8" BorderBrush="#8B6914"
                    BorderThickness="2" Padding="20,16" Margin="0,0,0,16">
              <StackPanel>
                <TextBlock Text="ACTION" FontFamily="Segoe UI" FontSize="11" FontWeight="SemiBold"
                           Foreground="#888888" Margin="0,0,0,6"/>
                <TextBlock x:Name="lblSum_Action" FontFamily="Segoe UI" FontSize="20" FontWeight="Bold"
                           Foreground="#F0B030" TextWrapping="Wrap" Text="--"/>
              </StackPanel>
            </Border>

            <Border Background="#1E1E1E" CornerRadius="6" Padding="14,10">
              <TextBlock x:Name="lblSum_Next" TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="13"
                         Foreground="#AAAAAA"
                         Text="Next: proceed with the reimage if instructed, then move on to the next panel."/>
            </Border>
          </StackPanel>
        </ScrollViewer>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Grid>
            <!-- ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§8: Close + Capture Another are moved to the recommendation screen so the tech
                 cannot leave a new panel appearing complete without recording the final path. -->
            <Button x:Name="btnSummerClose" Style="{StaticResource GhostBtn}" Content="Close" HorizontalAlignment="Left" MinWidth="110" Visibility="Collapsed"/>
            <StackPanel Orientation="Horizontal" HorizontalAlignment="Right">
              <Button x:Name="btnSummerReportIssue" Style="{StaticResource GhostBtn}" Content="Report an Issue" MinWidth="140" Margin="0,0,10,0"/>
              <Button x:Name="btnSummerNext" Style="{StaticResource PrimaryBtn}" Content="Next: Provisioning Options" HorizontalAlignment="Right" MinWidth="210"/>
            </StackPanel>
          </Grid>
        </Border>
      </Grid>

      <!-- SCREEN 12b2: v5.3.2 provisioning recommendation (routes new panels into Full Provisioning) -->
      <Grid x:Name="pnlProvRecommend" Visibility="Collapsed">
        <Grid.RowDefinitions><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
        <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto">
          <StackPanel MaxWidth="620" HorizontalAlignment="Center" Margin="40,24,40,10">
            <TextBlock Text="Device Provisioning Recommendation" FontFamily="Segoe UI" FontSize="22"
                       FontWeight="Bold" Foreground="#FFFFFF" Margin="0,0,0,14"/>
            <Border Background="#262626" CornerRadius="8" Padding="20,16" Margin="0,0,0,14">
              <StackPanel>
                <Grid Margin="0,0,0,8"><Grid.ColumnDefinitions><ColumnDefinition Width="150"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><TextBlock Text="Panel" Foreground="#888888" FontFamily="Segoe UI" FontSize="13"/><TextBlock x:Name="lblRec_Panel" Grid.Column="1" Foreground="#FFFFFF" FontFamily="Consolas" FontSize="13" Text="--"/></Grid>
                <Grid Margin="0,0,0,8"><Grid.ColumnDefinitions><ColumnDefinition Width="150"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><TextBlock Text="Install type" Foreground="#888888" FontFamily="Segoe UI" FontSize="13"/><TextBlock x:Name="lblRec_InstallType" Grid.Column="1" Foreground="#FFFFFF" FontFamily="Consolas" FontSize="13" Text="--"/></Grid>
                <Grid Margin="0,0,0,8"><Grid.ColumnDefinitions><ColumnDefinition Width="150"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><TextBlock Text="Domain status" Foreground="#888888" FontFamily="Segoe UI" FontSize="13"/><TextBlock x:Name="lblRec_Domain" Grid.Column="1" Foreground="#FFFFFF" FontFamily="Consolas" FontSize="13" Text="--"/></Grid>
                <Grid><Grid.ColumnDefinitions><ColumnDefinition Width="150"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><TextBlock Text="Image status" Foreground="#888888" FontFamily="Segoe UI" FontSize="13"/><TextBlock x:Name="lblRec_Image" Grid.Column="1" Foreground="#FFFFFF" FontFamily="Consolas" FontSize="13" TextWrapping="Wrap" Text="--"/></Grid>
              </StackPanel>
            </Border>
            <Border x:Name="borInstallQ" Background="#1E2A38" CornerRadius="8" BorderBrush="#2D4A6A" BorderThickness="1" Padding="20,16" Margin="0,0,0,14" Visibility="Collapsed">
              <StackPanel>
                <TextBlock Text="Is this a newly installed replacement panel?" FontFamily="Segoe UI" FontSize="15" FontWeight="SemiBold" Foreground="#FFFFFF" Margin="0,0,0,4"/>
                <TextBlock x:Name="lblInstallQHint" TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="12" Foreground="#9FC8E8" Margin="0,0,0,12" Text="The device is not domain joined. Confirm the installation type so PanelApp routes it correctly."/>
                <StackPanel Orientation="Horizontal">
                  <Button x:Name="btnInstallNew" Style="{StaticResource GreenBtn}" Content="Yes - New Replacement Panel" MinWidth="220" Margin="0,0,10,0"/>
                  <Button x:Name="btnInstallExisting" Style="{StaticResource GhostBtn}" Content="No - Existing Panel" MinWidth="160" Margin="0,0,10,0"/>
                  <Button x:Name="btnInstallUnsure" Style="{StaticResource GhostBtn}" Content="Not Sure" MinWidth="110"/>
                </StackPanel>
              </StackPanel>
            </Border>
            <Border x:Name="borRec_Path" Background="#0F1E10" CornerRadius="8" BorderBrush="#2D6A4F" BorderThickness="2" Padding="20,16" Margin="0,0,0,14">
              <StackPanel>
                <TextBlock Text="RECOMMENDED PATH" FontFamily="Segoe UI" FontSize="11" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
                <TextBlock x:Name="lblRec_Path" FontFamily="Segoe UI" FontSize="20" FontWeight="Bold" Foreground="#4EC994" TextWrapping="Wrap" Text="--"/>
                <TextBlock x:Name="lblRec_Reason" FontFamily="Segoe UI" FontSize="12" Foreground="#AAAAAA" TextWrapping="Wrap" Margin="0,8,0,0" Text=""/>
              </StackPanel>
            </Border>
          </StackPanel>
        </ScrollViewer>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Grid>
            <Button x:Name="btnProvRecReport" Style="{StaticResource GhostBtn}" Content="Report a Problem" HorizontalAlignment="Left" MinWidth="150"/>
            <StackPanel Orientation="Horizontal" HorizontalAlignment="Right">
              <Button x:Name="btnProvRecAction" Style="{StaticResource PrimaryBtn}" Content="Continue" MinWidth="230"/>
            </StackPanel>
          </Grid>
        </Border>
      </Grid>

      <!-- SCREEN 13a: v5.4 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§5 Inventory Record Lookup -->
      <Grid x:Name="pnlInvLookup" Visibility="Collapsed">
        <Grid.RowDefinitions><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
        <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto">
          <StackPanel MaxWidth="600" HorizontalAlignment="Center" Margin="40,28,40,10">
            <TextBlock Text="Inventory Record Lookup" FontFamily="Segoe UI" FontSize="22" FontWeight="Bold" Foreground="#FFFFFF" Margin="0,0,0,4"/>
            <TextBlock Text="Find an existing panel or OPS record to correct information, fill missing fields, or report a conflict. Panel serial is the preferred key - the OPS, hostname and room can all change."
                       TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="13" Foreground="#888888" Margin="0,0,0,20"/>
            <TextBlock Text="LOOKUP TYPE" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <ComboBox x:Name="cboInvLookupType" Style="{StaticResource DarkCombo}" IsEditable="False" Margin="0,0,0,14"/>
            <TextBlock x:Name="lblInvLookupValuePrompt" Text="SCAN OR ENTER PANEL SERIAL" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <TextBox x:Name="txtInvLookupValue" Style="{StaticResource DarkInput}" FontFamily="Consolas" FontSize="15" Padding="12,10" MaxLength="64"/>
            <StackPanel x:Name="pnlInvSchoolRoom" Visibility="Collapsed" Margin="0,0,0,2">
              <TextBlock Text="SCHOOL" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
              <ComboBox x:Name="cboInvLookupSchool" Style="{StaticResource DarkCombo}" IsEditable="False" Margin="0,0,0,14"/>
              <TextBlock Text="ROOM NUMBER" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
              <TextBox x:Name="txtInvLookupRoom" Style="{StaticResource DarkInput}" FontFamily="Consolas" FontSize="15" Padding="12,10" MaxLength="32"/>
            </StackPanel>
            <TextBlock x:Name="lblInvLookupError" Text="" Foreground="#EF5B5B" FontFamily="Segoe UI" FontSize="12" Margin="0,8,0,0" Visibility="Collapsed"/>
            <Button x:Name="btnInvFind" Style="{StaticResource PrimaryBtn}" Content="Find Record" HorizontalAlignment="Left" MinWidth="160" Margin="0,16,0,0"/>
            <Border x:Name="borInvResult" Background="#1E1E1E" CornerRadius="6" Padding="16,12" Margin="0,18,0,0" Visibility="Collapsed">
              <StackPanel>
                <TextBlock x:Name="lblInvResultTitle" Text="" FontFamily="Segoe UI" FontSize="14" FontWeight="Bold" Foreground="#FFFFFF" Margin="0,0,0,8"/>
                <TextBlock x:Name="lblInvResultBody" Text="" TextWrapping="Wrap" FontFamily="Consolas" FontSize="12" Foreground="#CCCCCC"/>
                <TextBlock x:Name="lblInvCrossCheck" Text="" TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="12" Foreground="#F0B030" Margin="0,10,0,0" Visibility="Collapsed"/>
                <StackPanel Orientation="Horizontal" Margin="0,14,0,0">
                  <Button x:Name="btnInvUpdate"  Style="{StaticResource GreenBtn}" Content="Update This Record" MinWidth="170" Margin="0,0,10,0" Visibility="Collapsed"/>
                  <Button x:Name="btnInvHistory" Style="{StaticResource GhostBtn}" Content="View History" MinWidth="130" Margin="0,0,10,0" Visibility="Collapsed"/>
                  <Button x:Name="btnInvConflict" Style="{StaticResource GhostBtn}" Content="Report a Conflict" MinWidth="150"/>
                </StackPanel>
              </StackPanel>
            </Border>
          </StackPanel>
        </ScrollViewer>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Grid><Button x:Name="btnInvLookupBack" Style="{StaticResource GhostBtn}" Content="&lt; Return to Main Menu" HorizontalAlignment="Left" MinWidth="190"/></Grid>
        </Border>
      </Grid>

      <!-- SCREEN 13b: v5.4 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§13 Before-and-after review -->
      <Grid x:Name="pnlInvReview" Visibility="Collapsed">
        <Grid.RowDefinitions><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
        <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto">
          <StackPanel MaxWidth="640" HorizontalAlignment="Center" Margin="40,24,40,10">
            <TextBlock Text="Confirm Inventory Update" FontFamily="Segoe UI" FontSize="22" FontWeight="Bold" Foreground="#FFFFFF" Margin="0,0,0,4"/>
            <TextBlock Text="Nothing is written until you submit. The original source rows are never changed - this records a correction and updates the current inventory."
                       TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="13" Foreground="#888888" Margin="0,0,0,16"/>
            <Border Background="#1E1E1E" CornerRadius="6" Padding="16,12" Margin="0,0,0,14">
              <TextBlock x:Name="lblInvDiff" Text="--" TextWrapping="NoWrap" FontFamily="Consolas" FontSize="12" Foreground="#CCCCCC"/>
            </Border>
            <TextBlock Text="CORRECTION TYPE" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <ComboBox x:Name="cboInvCorrType" Style="{StaticResource DarkCombo}" IsEditable="False" Margin="0,0,0,12"/>
            <TextBlock Text="CORRECTION REASON" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <ComboBox x:Name="cboInvCorrReason" Style="{StaticResource DarkCombo}" IsEditable="False" Margin="0,0,0,12"/>
            <TextBlock Text="NOTES" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <TextBox x:Name="txtInvNotes" Style="{StaticResource DarkInput}" FontSize="13" Height="70" TextWrapping="Wrap" AcceptsReturn="True" VerticalScrollBarVisibility="Auto"/>
            <TextBlock x:Name="lblInvReviewError" Text="" Foreground="#EF5B5B" FontFamily="Segoe UI" FontSize="12" Margin="0,8,0,0" Visibility="Collapsed"/>
          </StackPanel>
        </ScrollViewer>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Grid>
            <Button x:Name="btnInvReviewBack" Style="{StaticResource GhostBtn}" Content="&lt; Go Back" HorizontalAlignment="Left" MinWidth="130"/>
            <StackPanel Orientation="Horizontal" HorizontalAlignment="Right">
              <Button x:Name="btnInvReviewConflict" Style="{StaticResource GhostBtn}" Content="Report a Conflict" MinWidth="150" Margin="0,0,10,0"/>
              <Button x:Name="btnInvSubmit" Style="{StaticResource PrimaryBtn}" Content="Submit Correction" MinWidth="170"/>
            </StackPanel>
          </Grid>
        </Border>
      </Grid>

      <!-- SCREEN 13c: v5.4 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§15 Report a Conflict -->
      <Grid x:Name="pnlInvConflict" Visibility="Collapsed">
        <Grid.RowDefinitions><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
        <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto">
          <StackPanel MaxWidth="620" HorizontalAlignment="Center" Margin="40,24,40,10">
            <TextBlock Text="Report an Inventory Conflict" FontFamily="Segoe UI" FontSize="22" FontWeight="Bold" Foreground="#FFFFFF" Margin="0,0,0,4"/>
            <TextBlock Text="The existing records will NOT be changed. A lead or inventory reviewer verifies and resolves the conflict from the spreadsheet."
                       TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="13" Foreground="#888888" Margin="0,0,0,16"/>
            <Border Background="#1E1E1E" CornerRadius="6" Padding="16,12" Margin="0,0,0,14">
              <TextBlock x:Name="lblInvConflictContext" Text="--" TextWrapping="Wrap" FontFamily="Consolas" FontSize="12" Foreground="#CCCCCC"/>
            </Border>
            <TextBlock Text="CONFLICT TYPE" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <ComboBox x:Name="cboInvConflictType" Style="{StaticResource DarkCombo}" IsEditable="False" Margin="0,0,0,12"/>
            <TextBlock Text="WHAT DID YOU OBSERVE?" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <TextBox x:Name="txtInvConflictNotes" Style="{StaticResource DarkInput}" FontSize="13" Height="90" TextWrapping="Wrap" AcceptsReturn="True" VerticalScrollBarVisibility="Auto"/>
            <TextBlock x:Name="lblInvConflictError" Text="" Foreground="#EF5B5B" FontFamily="Segoe UI" FontSize="12" Margin="0,8,0,0" Visibility="Collapsed"/>
          </StackPanel>
        </ScrollViewer>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Grid>
            <Button x:Name="btnInvConflictBack" Style="{StaticResource GhostBtn}" Content="&lt; Go Back" HorizontalAlignment="Left" MinWidth="130"/>
            <Button x:Name="btnInvConflictSubmit" Style="{StaticResource PrimaryBtn}" Content="Submit Conflict Report" HorizontalAlignment="Right" MinWidth="190"/>
          </Grid>
        </Border>
      </Grid>

      <!-- SCREEN 12c2: RedoRescue gate block (state still looks pre-RedoRescue) -->
      <Grid x:Name="pnlRedoGateBlock" Visibility="Collapsed">
        <Grid.RowDefinitions><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
        <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto">
          <StackPanel MaxWidth="600" HorizontalAlignment="Center" Margin="40,28,40,10">
            <TextBlock Text="&#x26D4;" FontSize="52" HorizontalAlignment="Center" Foreground="#EF5B5B" Margin="0,0,0,10"/>
            <TextBlock x:Name="lblGateTitle" Text="RedoRescue Restore Not Completed" FontFamily="Segoe UI"
                       FontSize="22" FontWeight="Bold" Foreground="#FFFFFF" HorizontalAlignment="Center" Margin="0,0,0,12"/>
            <Border Background="#200808" CornerRadius="8" BorderBrush="#7A1515" BorderThickness="1" Padding="20,16" Margin="0,0,0,14">
              <TextBlock x:Name="lblGateMsg" TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="14"
                         Foreground="#F0B0B0" TextAlignment="Center"/>
            </Border>
            <Border Background="#262626" CornerRadius="8" Padding="20,14">
              <StackPanel>
                <TextBlock Text="CURRENT DEVICE STATE" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,8"/>
                <TextBlock x:Name="lblGateState" FontFamily="Consolas" FontSize="12" Foreground="#CCCCCC" TextWrapping="Wrap" Text="--"/>
              </StackPanel>
            </Border>
          </StackPanel>
        </ScrollViewer>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Grid>
            <Button x:Name="btnGateBack" Style="{StaticResource GhostBtn}" Content="&lt; Back to Menu" HorizontalAlignment="Left" MinWidth="150"/>
            <Button x:Name="btnGateReportIssue" Style="{StaticResource GhostBtn}" Content="Report a Problem" HorizontalAlignment="Right" MinWidth="160"/>
          </Grid>
        </Border>
      </Grid>

      <!-- SCREEN 12d: Interactive Inventory continuation confirmation (Post-RedoRescue Provisioning) -->
      <Grid x:Name="pnlSummerContinuation" Visibility="Collapsed">
        <Grid.RowDefinitions><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
        <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto">
          <StackPanel MaxWidth="620" HorizontalAlignment="Center" Margin="40,28,40,10">
            <TextBlock Text="Interactive Inventory Project Continuation Found" TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="22"
                       FontWeight="Bold" Foreground="#1FB89A" Margin="0,0,0,4"/>
            <TextBlock Text="An active Interactive Inventory Project record matches this panel serial. Confirm to continue and close out that project record after provisioning."
                       TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="13" Foreground="#888888" Margin="0,0,0,18"/>
            <Border Background="#262626" CornerRadius="8" Padding="20,16" Margin="0,0,0,14">
              <StackPanel>
                <Grid Margin="0,0,0,8"><Grid.ColumnDefinitions><ColumnDefinition Width="170"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><TextBlock Text="School" Foreground="#888888" FontFamily="Segoe UI" FontSize="12"/><TextBlock x:Name="lblCont_School" Grid.Column="1" Foreground="#FFFFFF" FontFamily="Segoe UI" FontSize="13" Text="--"/></Grid>
                <Grid Margin="0,0,0,8"><Grid.ColumnDefinitions><ColumnDefinition Width="170"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><TextBlock Text="Room" Foreground="#888888" FontFamily="Segoe UI" FontSize="12"/><TextBlock x:Name="lblCont_Room" Grid.Column="1" Foreground="#FFFFFF" FontFamily="Segoe UI" FontSize="13" Text="--"/></Grid>
                <Grid Margin="0,0,0,8"><Grid.ColumnDefinitions><ColumnDefinition Width="170"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><TextBlock Text="Panel serial" Foreground="#888888" FontFamily="Segoe UI" FontSize="12"/><TextBlock x:Name="lblCont_Panel" Grid.Column="1" Foreground="#FFFFFF" FontFamily="Consolas" FontSize="13" Text="--"/></Grid>
                <Grid Margin="0,0,0,8"><Grid.ColumnDefinitions><ColumnDefinition Width="170"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><TextBlock Text="Original OPS serial" Foreground="#888888" FontFamily="Segoe UI" FontSize="12"/><TextBlock x:Name="lblCont_OrigOPS" Grid.Column="1" Foreground="#FFFFFF" FontFamily="Consolas" FontSize="13" Text="--"/></Grid>
                <Grid Margin="0,0,0,8"><Grid.ColumnDefinitions><ColumnDefinition Width="170"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><TextBlock Text="Current OPS serial" Foreground="#888888" FontFamily="Segoe UI" FontSize="12"/><TextBlock x:Name="lblCont_CurOPS" Grid.Column="1" Foreground="#FFFFFF" FontFamily="Consolas" FontSize="13" Text="--"/></Grid>
                <Grid Margin="0,0,0,8"><Grid.ColumnDefinitions><ColumnDefinition Width="170"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><TextBlock Text="Required image" Foreground="#888888" FontFamily="Segoe UI" FontSize="12"/><TextBlock x:Name="lblCont_Profile" Grid.Column="1" Foreground="#FFFFFF" FontFamily="Segoe UI" FontSize="13" Text="--"/></Grid>
                <Grid Margin="0,0,0,8"><Grid.ColumnDefinitions><ColumnDefinition Width="170"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><TextBlock Text="Expected image folder" Foreground="#888888" FontFamily="Segoe UI" FontSize="12"/><TextBlock x:Name="lblCont_Redo" Grid.Column="1" Foreground="#9FE8D8" FontFamily="Consolas" FontSize="12" TextWrapping="Wrap" Text="--"/></Grid>
                <Grid Margin="0,0,0,8"><Grid.ColumnDefinitions><ColumnDefinition Width="170"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><TextBlock Text="Project status" Foreground="#888888" FontFamily="Segoe UI" FontSize="12"/><TextBlock x:Name="lblCont_Status" Grid.Column="1" Foreground="#F0B030" FontFamily="Segoe UI" FontSize="13" FontWeight="SemiBold" Text="--"/></Grid>
                <Grid Margin="0,0,0,8"><Grid.ColumnDefinitions><ColumnDefinition Width="170"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><TextBlock Text="Project Run ID" Foreground="#888888" FontFamily="Segoe UI" FontSize="12"/><TextBlock x:Name="lblCont_RunId" Grid.Column="1" Foreground="#CCCCCC" FontFamily="Consolas" FontSize="12" Text="--"/></Grid>
                <Grid Margin="0,0,0,8"><Grid.ColumnDefinitions><ColumnDefinition Width="170"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><TextBlock Text="Last technician" Foreground="#888888" FontFamily="Segoe UI" FontSize="12"/><TextBlock x:Name="lblCont_LastBy" Grid.Column="1" Foreground="#FFFFFF" FontFamily="Segoe UI" FontSize="13" Text="--"/></Grid>
                <Grid><Grid.ColumnDefinitions><ColumnDefinition Width="170"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><TextBlock Text="Last update" Foreground="#888888" FontFamily="Segoe UI" FontSize="12"/><TextBlock x:Name="lblCont_LastAt" Grid.Column="1" Foreground="#CCCCCC" FontFamily="Segoe UI" FontSize="12" Text="--"/></Grid>
              </StackPanel>
            </Border>
            <Border x:Name="borOPSMismatch" Background="#1E1200" CornerRadius="6" BorderBrush="#8B6914"
                    BorderThickness="1" Padding="16,12" Visibility="Collapsed">
              <StackPanel>
                <TextBlock Text="OPS serial differs from the original Interactive Inventory assessment. Was the OPS replaced?"
                           TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="13" Foreground="#F0B030" Margin="0,0,0,8"/>
                <StackPanel Orientation="Horizontal">
                  <RadioButton x:Name="rdoOPSNo"  Style="{StaticResource DarkRadio}" Content="No - investigate before continuing" GroupName="OPSMismatch"/>
                  <RadioButton x:Name="rdoOPSYes" Style="{StaticResource DarkRadio}" Content="Yes - continue and record replacement" GroupName="OPSMismatch"/>
                </StackPanel>
              </StackPanel>
            </Border>
            <CheckBox x:Name="chkImageConfirm" Foreground="#FFFFFF" FontFamily="Segoe UI" FontSize="13" Margin="0,12,0,0"
                      Content="I confirm the approved RedoRescue image folder above was used."/>
            <TextBlock x:Name="lblContError" Text="" Foreground="#EF5B5B" FontFamily="Segoe UI" FontSize="12" Margin="0,8,0,0" Visibility="Collapsed"/>
          </StackPanel>
        </ScrollViewer>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Grid>
            <Button x:Name="btnContReportIssue" Style="{StaticResource GhostBtn}" Content="Report a Problem" HorizontalAlignment="Left" MinWidth="150"/>
            <Button x:Name="btnContinueSummer" Style="{StaticResource GreenBtn}" Content="Continue Interactive Inventory Project" HorizontalAlignment="Right" MinWidth="230"/>
          </Grid>
        </Border>
      </Grid>

      <!-- SCREEN 12e: Interactive Inventory continuation - multiple matches -->
      <Grid x:Name="pnlSummerSelect" Visibility="Collapsed">
        <Grid.RowDefinitions><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
        <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto">
          <StackPanel MaxWidth="620" HorizontalAlignment="Center" Margin="40,28,40,10">
            <TextBlock Text="Multiple Interactive Inventory Records" FontFamily="Segoe UI" FontSize="22" FontWeight="Bold" Foreground="#FFFFFF" Margin="0,0,0,4"/>
            <TextBlock Text="More than one active Interactive Inventory Project record matches this panel serial. Select the correct Project Run ID, or check with your lead."
                       TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="13" Foreground="#888888" Margin="0,0,0,18"/>
            <TextBlock Text="PROJECT RUN ID" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <ComboBox x:Name="cboSummerMatch" Style="{StaticResource DarkCombo}" IsEditable="False"/>
          </StackPanel>
        </ScrollViewer>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Grid>
            <Button x:Name="btnSelectReportIssue" Style="{StaticResource GhostBtn}" Content="Report a Problem" HorizontalAlignment="Left" MinWidth="150"/>
            <Button x:Name="btnSelectContinue" Style="{StaticResource PrimaryBtn}" Content="Continue" HorizontalAlignment="Right" MinWidth="150"/>
          </Grid>
        </Border>
      </Grid>

      <!-- SCREEN 12f: Reimage closeout (after Interactive Inventory-linked provisioning) -->
      <Grid x:Name="pnlReimageCloseout" Visibility="Collapsed">
        <Grid.RowDefinitions><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
        <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto">
          <StackPanel MaxWidth="600" HorizontalAlignment="Center" Margin="40,28,40,10">
            <TextBlock x:Name="lblCloseoutTitle" Text="Post-RedoRescue Closeout" FontFamily="Segoe UI" FontSize="22" FontWeight="Bold" Foreground="#FFFFFF" Margin="0,0,0,4"/>
            <TextBlock Text="Short panel readiness confirmation - not a full QA checklist. If any check fails, use Report an Issue instead of closing the project."
                       TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="13" Foreground="#888888" Margin="0,0,0,10"/>
            <Border Background="#1E2A38" CornerRadius="6" BorderBrush="#2D4A6A" BorderThickness="1" Padding="14,10" Margin="0,0,0,16">
              <TextBlock x:Name="lblCloseoutContext" TextWrapping="Wrap" FontFamily="Consolas" FontSize="12" Foreground="#9FC8E8" Text="--"/>
            </Border>
            <Border Background="#262626" CornerRadius="8" Padding="20,16" Margin="0,0,0,14">
              <StackPanel>
                <CheckBox x:Name="chkCoImage"   Content="OPS boots into Windows successfully" Foreground="#FFFFFF" FontFamily="Segoe UI" FontSize="13" Margin="0,0,0,10"/>
                <CheckBox x:Name="chkCoTouch"   Content="Touch works on the panel" Foreground="#FFFFFF" FontFamily="Segoe UI" FontSize="13" Margin="0,0,0,10"/>
                <CheckBox x:Name="chkCoSound"   Content="Sound works from the panel" Foreground="#FFFFFF" FontFamily="Segoe UI" FontSize="13" Margin="0,0,0,10"/>
                <CheckBox x:Name="chkCoNetwork" Content="Network works in Windows" Foreground="#FFFFFF" FontFamily="Segoe UI" FontSize="13" Margin="0,0,0,10"/>
                <CheckBox x:Name="chkCoNDMS"    Content="Android side is online in NDMS/Radix" Foreground="#FFFFFF" FontFamily="Segoe UI" FontSize="13" Margin="0,0,0,10"/>
                <CheckBox x:Name="chkCoAndroidEthernet" Content="Android side is connected by Ethernet" Foreground="#FFFFFF" FontFamily="Segoe UI" FontSize="13" Margin="0,0,0,8"/>
                <TextBlock Text="If Android is not on Ethernet, connect it before closeout. NDMS/Radix online status and Android Ethernet are separate checks." TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="11" Foreground="#888888" Margin="24,0,0,8"/>
                <Button x:Name="btnCoEthernetException" Style="{StaticResource GhostBtn}" Content="Android Ethernet Not Working - Record Low Exception" HorizontalAlignment="Left" Margin="24,0,0,6"/>
                <TextBlock x:Name="lblCoEthernetException" Text="" TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="11" Foreground="#F0B030" Margin="24,0,0,2" Visibility="Collapsed"/>
              </StackPanel>
            </Border>
            <Button x:Name="btnCloseoutIssue" Style="{StaticResource GhostBtn}" Content="Report an Issue" HorizontalAlignment="Left"/>
            <TextBlock x:Name="lblCloseoutBusy" Text="" Foreground="#F0B030" FontFamily="Segoe UI" FontSize="13" FontWeight="SemiBold" TextWrapping="Wrap" Margin="0,10,0,0" Visibility="Collapsed"/>
            <TextBlock x:Name="lblCloseoutError" Text="" Foreground="#EF5B5B" FontFamily="Segoe UI" FontSize="12" Margin="0,10,0,0" Visibility="Collapsed"/>
          </StackPanel>
        </ScrollViewer>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Button x:Name="btnCloseoutReboot" Style="{StaticResource GreenBtn}" Content="Finish and Reboot" HorizontalAlignment="Right" MinWidth="180"/>
        </Border>
      </Grid>

      <!-- SCREEN 12g: Report an Issue (reusable -> PanelAppExceptions) -->
      <Grid x:Name="pnlIssueReport" Visibility="Collapsed">
        <Grid.RowDefinitions><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
        <ScrollViewer Grid.Row="0" VerticalScrollBarVisibility="Auto">
          <StackPanel MaxWidth="560" HorizontalAlignment="Center" Margin="40,16,40,10">
            <TextBlock Text="Report an Issue" FontFamily="Segoe UI" FontSize="20" FontWeight="Bold" Foreground="#FFFFFF" Margin="0,0,0,4"/>
            <TextBlock x:Name="lblExContext" Text="" FontFamily="Consolas" FontSize="11" Foreground="#666666" Margin="0,0,0,12"/>
            <TextBlock Text="ISSUE CATEGORY" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <ComboBox x:Name="cboExCategory" Style="{StaticResource DarkCombo}" IsEditable="False" Margin="0,0,0,14"/>
            <TextBlock Text="DESCRIPTION" FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold" Foreground="#888888" Margin="0,0,0,6"/>
            <TextBox x:Name="txtExNote" Style="{StaticResource DarkInput}" FontSize="13" Height="90" TextWrapping="Wrap" AcceptsReturn="True" VerticalScrollBarVisibility="Auto"/>
            <TextBlock Text="Sent to the Interactive Technology team. You do not need spreadsheet access."
                       TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="11" Foreground="#666666" Margin="0,10,0,0"/>
            <TextBlock x:Name="lblExError" Text="" Foreground="#EF5B5B" FontFamily="Segoe UI" FontSize="12" Margin="0,8,0,0" Visibility="Collapsed"/>
          </StackPanel>
        </ScrollViewer>
        <Border Grid.Row="1" Background="#111111" Padding="30,10">
          <Grid>
            <Button x:Name="btnExCancel" Style="{StaticResource GhostBtn}" Content="Cancel" HorizontalAlignment="Left" MinWidth="120"/>
            <Button x:Name="btnExSubmit" Style="{StaticResource PrimaryBtn}" Content="Submit Issue" HorizontalAlignment="Right" MinWidth="160"/>
          </Grid>
        </Border>
      </Grid>

      <!-- SCREEN 13: Version block (hard stop, no bypass) -->
      <Grid x:Name="pnlVersionBlock" Visibility="Collapsed">
        <StackPanel VerticalAlignment="Center" HorizontalAlignment="Center" MaxWidth="540">
          <TextBlock Text="&#x26D4;" FontSize="64" HorizontalAlignment="Center"
                     Foreground="#EF5B5B" Margin="0,0,0,16"/>
          <TextBlock Text="Out-of-Date Version" FontFamily="Segoe UI" FontSize="28"
                     FontWeight="Bold" Foreground="#FFFFFF" HorizontalAlignment="Center" Margin="0,0,0,12"/>
          <Border Background="#200808" CornerRadius="8" BorderBrush="#7A1515"
                  BorderThickness="1" Padding="20,16" Margin="0,0,0,20">
            <TextBlock x:Name="lblVersionBlockMsg" TextWrapping="Wrap" FontFamily="Segoe UI"
                       FontSize="14" Foreground="#F0B0B0" TextAlignment="Center"/>
          </Border>
          <TextBlock Text="Download the latest version from Google Drive, copy it to your flash drive, and run it again."
                     TextWrapping="Wrap" FontFamily="Segoe UI" FontSize="13" Foreground="#AAAAAA"
                     TextAlignment="Center" Margin="0,0,0,28"/>
          <Button x:Name="btnVersionBlockClose" Style="{StaticResource PrimaryBtn}"
                  Content="Close" HorizontalAlignment="Center" MinWidth="200"/>
        </StackPanel>
      </Grid>

    </Grid><!-- end screens -->

    <!-- Status bar -->
    <Border Grid.Row="2" Background="#0A0A0A" Padding="20,6">
      <Grid>
        <TextBlock x:Name="lblStatus" Text="Initializing..."
                   FontFamily="Consolas" FontSize="11" Foreground="#3A3A3A"/>
        <TextBlock x:Name="lblVersionFooter" Text="APS Panel App" HorizontalAlignment="Right"
                   FontFamily="Segoe UI" FontSize="10" Foreground="#333333"/>
      </Grid>
    </Border>

  </Grid>
</Window>
'@
} catch {
    $script:xamlParseErr = "XAML failed to parse: $_"
    try { Add-Content -Path $script:ErrorLog -Value $script:xamlParseErr -Encoding UTF8 } catch {}
    [System.Windows.MessageBox]::Show($script:xamlParseErr, 'APS Panel App - Fatal Error', 'OK', 'Error') | Out-Null
    exit 1
}


# ================================================================
#  LOAD XAML + BIND CONTROLS
# ================================================================
$script:reader = [System.Xml.XmlNodeReader]::new($script:xamlDoc)
try {
    $script:window = [System.Windows.Markup.XamlReader]::Load($script:reader)
} catch {
    [System.Windows.MessageBox]::Show("XAML load failed: $_", 'Fatal Error', 'OK', 'Error') | Out-Null
    exit 1
}

$script:UI = @{}
$script:window.Dispatcher.Add_UnhandledException({
    param($sender,$eventArgs)
    $failure = $eventArgs.Exception
    while ($failure -and -not $failure.Data['PanelAppPersistenceFailure']) { $failure = $failure.InnerException }
    if ($failure) {
        # Only handle the known persistence failure. Let unrelated programming errors remain visible.
        $eventArgs.Handled = $true
        Write-Log $failure.Message 'ERROR'
        Set-Status 'Record not saved - keep this window open and contact a lead.'
        $script:window.Content.IsEnabled = $false
        [System.Windows.MessageBox]::Show($failure.Message,'Record Not Saved','OK','Error') | Out-Null
    }
})
$controlNames = @(
    'lblTechDisplay','lblModeDisplay','lblStatus',
    'pnlUserEntry','txtTechName','lblTechNameError','btnContinueUsername',
    'pnlModeSelect','btnModeBack','btnSummer2026','btnOtherModes','btnMode1','btnMode2','btnMode3','btnMode4','btnMode5','btnMode6','btnModeEndpointRepair','btnModeOPSRequest','btnModeInventory',
    'pnlEndpointRepair','btnEndpointRenameOnly','btnEndpointDomainOnly','btnEndpointRenameJoin','btnEndpointBack',
    'pnlOPSRequest','cboOPSReqSchool','lblOPSReqSchoolError','txtOPSReqRoom','txtOPSReqPanelSerial','txtOPSReqCurrentOPS','cboOPSReqReason','cboOPSReqUrgency','txtOPSReqNotes','lblOPSReqError','btnOPSReqBack','btnOPSReqSubmit',
    'pnlInvLookup','cboInvLookupType','lblInvLookupValuePrompt','txtInvLookupValue','pnlInvSchoolRoom','cboInvLookupSchool','txtInvLookupRoom','lblInvLookupError','btnInvFind','borInvResult',
    'lblInvResultTitle','lblInvResultBody','lblInvCrossCheck','btnInvUpdate','btnInvHistory','btnInvConflict','btnInvLookupBack',
    'pnlInvReview','lblInvDiff','cboInvCorrType','cboInvCorrReason','txtInvNotes','lblInvReviewError',
    'btnInvReviewBack','btnInvReviewConflict','btnInvSubmit',
    'pnlInvConflict','lblInvConflictContext','cboInvConflictType','txtInvConflictNotes','lblInvConflictError',
    'btnInvConflictBack','btnInvConflictSubmit',
    'pnlFullProvType','btnProvStandard','btnProvPostRedo','btnFullProvBack',
    'pnlInstallType','btnInstallTypeBack','btnNewInstall','btnReimage',
    'pnlOPSSerial','lblOPS_BIOS','lblOPS_Product','lblOPS_Board','lblOPS_Reg',
    'lblOPS_BestValue','lblOPS_BestSource','lblOPS_Confidence','borOPSSuspicious','lblOPSSuspicious',
    'txtOPSOverride','cboOPSOverrideReason','borOPSTrunc','borOPSNone','btnOPSBack','btnOPSConfirm',
    'pnlScanBarcode','lblScanHeader','lblScanInstruction','txtBarcodeInput',
    'borScanIndicator','lblScanStatus','borScannedResult','lblScannedSerial',
    'borMobileHint','btnPanelSerialMissing','lblPanelSerialMissingHint','btnScanBack','btnScanContinue',
    'pnlMissingPanelSerial','cboMissingPanelManufacturer','lblMissingPanelManufacturerError',
    'pnlMissingPromethean','txtMissingPrometheanSerial','pnlMissingBoxlight','txtMissingAssetTag','txtMissingNDMSName','txtMissingNDMSDeviceId','txtMissingNDMSTags',
    'lblMissingPanelSerialError','btnMissingPanelSerialBack','btnMissingPanelSerialContinue',
    'pnlLocation','cboSchool','lblSchoolError','cboManufacturer','lblMfrError',
    'cboPanelModel','lblPanelModelError','lblModelLabel',
    'rdoWallMounted','rdoMobile','lblRoomLabel','txtRoomNumber','lblRoomHint','lblRoomError',
    'cboRoomType','lblRoomTypeError','lblOtherRoomTypeLabel','txtOtherRoomType',
    'btnLocationBack','btnLocationContinue',
    'pnlHostname','txtHostname','lblHostnameValidation','lblHostnameLength',
    'btnHostnameBack','btnHostnameConfirm','btnCheckHostname','lblHostnameCheck',
    'lblCurrentHostname','lblOldHostnameLabel','txtOldHostname','lblOldHostnameHint',
    'borAltHostname','lblAltHostname','btnUseAlternate',
    'pnlM3Disposition','rdoM3SetAside','rdoM3AnotherPanel','borM3MoveReason','lblM3ReassignmentContext',
    'rdoM3Permanent','rdoM3Temporary','rdoM3Testing','lblM3MoveReasonError','pnlM3OldOPS',
    'txtOldOPSBarcode','lblOldOPSScanStatus','btnM3Back','btnM3Continue',
    'pnlM5HostnameCheck','lblM5CurrentHostname','rdoM5Yes','rdoM5No',
    'borM5RebuildNote','btnM5Back','btnM5Continue',
    'pnlReview','lblReviewTitle','spReviewItems','borReviewWarning','lblReviewWarning',
    'btnReviewBack','btnReviewExecute',
    'pnlProgress','lblProgressHeader','lblProgressStatus','pbarProgress','txtProgressLog',
    'btnProgressDone','btnProgressReboot','btnProgressReportIssue','btnAbortProvision',
    'btnProgressRetry','borPhaseAFailure','lblPhaseAFailureState',
    'pnlPhaseB','txtPhaseBInfo','txtDomainUser','pwbDomainPass','txtDomainPassVisible','chkShowPass','pbarPhaseB',
    'txtPhaseBLog','lblPhaseBStatus','btnJoinDomain','btnPhaseBReboot','btnPhaseBReportIssue',
    'pnlComplete','lblCompleteIcon','lblCompleteTitle','lblCompleteMessage','btnCloseApp',
    'pnlDayOneCheck','chkDisplay','chkTouch','chkSound','chkCables','chkNetwork','chkNDMS',
    'rdoNetEthernet','rdoNetWifi','lblDayOneError','btnReportIssue','borIssueForm',
    'cboIssueCategory','txtIssueNote','btnIssueSubmit','btnDayOneBack','btnDayOneContinue',
    'pnlSummerSummary','lblSum_Device','lblSum_OPS','lblSum_Panel','lblSum_Storage','lblSum_OS',
    'borSum_Action','lblSum_Action','lblSum_Next','btnSummerClose','btnSummerNext','btnSummerReportIssue',
    'pnlProvRecommend','lblRec_Panel','lblRec_InstallType','lblRec_Domain','lblRec_Image',
    'borInstallQ','lblInstallQHint','btnInstallNew','btnInstallExisting','btnInstallUnsure',
    'borRec_Path','lblRec_Path','lblRec_Reason','btnProvRecReport','btnProvRecAction',
    'pnlRedoGateBlock','lblGateTitle','lblGateMsg','lblGateState','btnGateBack','btnGateReportIssue',
    'pnlSummerContinuation','lblCont_School','lblCont_Room','lblCont_Panel','lblCont_OrigOPS','lblCont_CurOPS',
    'lblCont_Profile','lblCont_Redo','lblCont_Status','lblCont_RunId','lblCont_LastBy','lblCont_LastAt',
    'borOPSMismatch','rdoOPSNo','rdoOPSYes','lblContError','chkImageConfirm','btnContReportIssue','btnContinueSummer',
    'pnlSummerSelect','cboSummerMatch','btnSelectReportIssue','btnSelectContinue',
    'pnlReimageCloseout','chkCoImage','chkCoTouch','chkCoSound','chkCoNetwork','chkCoNDMS','chkCoAndroidEthernet','btnCoEthernetException','lblCoEthernetException',
    'btnCloseoutIssue','btnCloseoutReboot','lblCloseoutError','lblCloseoutContext','lblCloseoutTitle',
    'pnlIssueReport','lblExContext','cboExCategory','txtExNote','lblExError','btnExCancel','btnExSubmit',
    'pnlVersionBlock','lblVersionBlockMsg','btnVersionBlockClose','lblVersionFooter',
    'ellNetStatus','lblNetStatus'
)
foreach ($n in $controlNames) {
    $c = $script:window.FindName($n)
    if ($c) { $script:UI[$n] = $c }
    else { Write-Log "Control not found: $n" 'WARN' }
}

# ================================================================
#  UI HELPERS
# ================================================================
$script:AllScreens = @('pnlUserEntry','pnlModeSelect','pnlFullProvType','pnlInstallType','pnlOPSSerial','pnlScanBarcode','pnlMissingPanelSerial',
    'pnlLocation','pnlHostname','pnlM3Disposition','pnlM5HostnameCheck',
    'pnlReview','pnlProgress','pnlPhaseB','pnlComplete','pnlDayOneCheck','pnlSummerSummary','pnlProvRecommend',
    'pnlInvLookup','pnlInvReview','pnlInvConflict','pnlEndpointRepair','pnlOPSRequest',
    'pnlRedoGateBlock','pnlSummerContinuation','pnlSummerSelect','pnlReimageCloseout','pnlIssueReport','pnlVersionBlock')

function Show-Screen {
    param([string]$Name)
    $script:CurrentScreenName = $Name
    foreach ($s in $script:AllScreens) {
        $ctrl = $script:UI[$s]
        if ($ctrl) { $ctrl.Visibility = if ($s -eq $Name) { 'Visible' } else { 'Collapsed' } }
    }
    if ($Name -eq 'pnlModeSelect') {
        foreach ($b in @('btnMode1','btnMode2','btnMode3','btnMode4','btnMode5','btnMode6','btnModeEndpointRepair','btnModeOPSRequest')) {
            if ($script:UI[$b]) { $script:UI[$b].Visibility = 'Collapsed' }
        }
        $script:OtherModesExpanded = $false
    }
    if ($Name -eq 'pnlComplete' -and $script:UI['lblCompleteIcon']) {
        $script:UI['lblCompleteIcon'].Text = [char]0x2714
        $script:UI['lblCompleteIcon'].Foreground = New-Brush '#4EC994'
    }
    Write-Log "Screen: $Name"
}

function New-Brush {
    param([string]$Hex)
    return [System.Windows.Media.SolidColorBrush][System.Windows.Media.ColorConverter]::ConvertFromString($Hex)
}

function Populate-Dropdowns {
    $script:UI['cboSchool'].Items.Clear()
    foreach ($s in $script:Config.Schools) {
        $item = [System.Windows.Controls.ComboBoxItem]::new()
        $item.Content = "$($s.Code) - $($s.Name)"
        $item.Tag     = $s.Code
        $script:UI['cboSchool'].Items.Add($item) | Out-Null
    }
    $script:UI['cboOPSReqSchool'].Items.Clear()
    foreach ($s in $script:Config.Schools) {
        $item = [System.Windows.Controls.ComboBoxItem]::new()
        $item.Content = "$($s.Code) - $($s.Name)"
        $item.Tag     = $s.Code
        $script:UI['cboOPSReqSchool'].Items.Add($item) | Out-Null
    }
    $script:UI['cboManufacturer'].Items.Clear()
    foreach ($m in $script:Config.Manufacturers) {
        $item = [System.Windows.Controls.ComboBoxItem]::new()
        $item.Content = $m.Name
        $item.Tag     = $m.Code
        $script:UI['cboManufacturer'].Items.Add($item) | Out-Null
    }
    $script:UI['cboPanelModel'].Items.Clear()
    $script:UI['cboMissingPanelManufacturer'].Items.Clear()
    foreach ($name in @('Boxlight','Promethean')) {
        $m = $script:Config.Manufacturers | Where-Object { $_.Name -eq $name } | Select-Object -First 1
        if ($m) {
            $item = [System.Windows.Controls.ComboBoxItem]::new()
            $item.Content = $m.Name; $item.Tag = $m.Code
            $script:UI['cboMissingPanelManufacturer'].Items.Add($item) | Out-Null
        }
    }

    # Day One / exception issue categories (Summer 2026) - shared by both forms
    $cats = @('Touch','Audio','Network','NDMS / Android enrollment',
              'Mount or physical condition','Cable management','OPS / Windows',
              'Panel will not power on','Panel Identity',
              'Installation Type Conflict','Domain State Detection','Provisioning Path Conflict','New Replacement Panel Issue',
              'Other')
    foreach ($combo in @('cboIssueCategory','cboExCategory')) {
        $script:UI[$combo].Items.Clear()
        foreach ($cat in $cats) {
            $ci = [System.Windows.Controls.ComboBoxItem]::new()
            $ci.Content = $cat
            $script:UI[$combo].Items.Add($ci) | Out-Null
        }
    }
    # ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§17.3: how the tech verified an OPS serial override
    $script:UI['cboOPSOverrideReason'].Items.Clear()
    foreach ($r in @('Sticker verified','WMI value confirmed','Lead instructed','Unable to verify')) {
        $ci = [System.Windows.Controls.ComboBoxItem]::new()
        $ci.Content = $r
        $script:UI['cboOPSOverrideReason'].Items.Add($ci) | Out-Null
    }
}

function Update-ModelDropdown {
    param([string]$ManufacturerName)
    $script:UI['cboPanelModel'].Items.Clear()
    $mfr = $script:Config.Manufacturers | Where-Object { $_.Name -eq $ManufacturerName } | Select-Object -First 1
    if ($mfr -and $mfr.Models -and $mfr.Models.Count -gt 0) {
        foreach ($mdl in $mfr.Models) {
            $item = [System.Windows.Controls.ComboBoxItem]::new()
            $item.Content = $mdl
            $script:UI['cboPanelModel'].Items.Add($item) | Out-Null
        }
        $script:UI['lblModelLabel'].Visibility    = 'Visible'
        $script:UI['cboPanelModel'].Visibility    = 'Visible'
        $script:UI['lblPanelModelError'].Visibility = 'Collapsed'
    } else {
        # No models defined for this manufacturer (e.g. SMART) - hide dropdown
        $script:UI['lblModelLabel'].Visibility  = 'Collapsed'
        $script:UI['cboPanelModel'].Visibility  = 'Collapsed'
        $script:PanelModel = ''
    }
}

function Add-ReviewRow {
    param([string]$Label, [string]$Value, [string]$ValueColor = '#FFFFFF')
    $g    = [System.Windows.Controls.Grid]::new()
    $col1 = [System.Windows.Controls.ColumnDefinition]::new()
    $col1.Width = [System.Windows.GridLength]::new(180)
    $col2 = [System.Windows.Controls.ColumnDefinition]::new()
    $col2.Width = [System.Windows.GridLength]::new(1, [System.Windows.GridUnitType]::Star)
    $g.ColumnDefinitions.Add($col1)
    $g.ColumnDefinitions.Add($col2)
    $g.Margin = [System.Windows.Thickness]::new(0,0,0,10)
    $lbl = [System.Windows.Controls.TextBlock]::new()
    $lbl.Text       = $Label
    $lbl.FontFamily = [System.Windows.Media.FontFamily]::new('Segoe UI')
    $lbl.FontSize   = 12
    $lbl.Foreground = New-Brush '#888888'
    $lbl.VerticalAlignment = 'Center'
    [System.Windows.Controls.Grid]::SetColumn($lbl, 0)
    $val = [System.Windows.Controls.TextBlock]::new()
    $val.Text        = $Value
    $val.FontFamily  = [System.Windows.Media.FontFamily]::new('Segoe UI')
    $val.FontSize    = 13
    $val.FontWeight  = 'SemiBold'
    $val.Foreground  = New-Brush $ValueColor
    $val.TextWrapping = 'Wrap'
    [System.Windows.Controls.Grid]::SetColumn($val, 1)
    $g.Children.Add($lbl) | Out-Null
    $g.Children.Add($val) | Out-Null
    $script:UI['spReviewItems'].Children.Add($g) | Out-Null
}

function Show-ReviewScreen {
    $script:UI['spReviewItems'].Children.Clear()
    $script:UI['borReviewWarning'].Visibility = 'Collapsed'
    # v5.3.3 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§3: Room Type display value for the confirmation screen (paired with Room Number)
    $rtReview = if ($script:RoomType -eq 'Other' -and $script:OtherRoomType) { "Other - $($script:OtherRoomType)" }
                elseif ($script:RoomType) { $script:RoomType } else { 'Unknown' }
    switch ($script:CurrentMode) {
        1 {
            $modeStr = $script:ModeLabel
            $script:UI['lblReviewTitle'].Text = $modeStr
            Add-ReviewRow 'Mode'         $modeStr
            Add-ReviewRow 'Technician'   $script:TechName
            Add-ReviewRow 'School'       "$($script:SchoolCode) - $($script:SchoolName)"
            Add-ReviewRow 'Manufacturer' $script:Manufacturer
            if ($script:PanelModel) { Add-ReviewRow 'Panel Model' $script:PanelModel }
            Add-ReviewRow 'Mount Type'   $script:MountType
            Add-ReviewRow 'Room Type'    $rtReview
            Add-ReviewRow 'Room'         $script:RoomNumber
            Add-ReviewRow 'New Hostname' $script:Hostname '#C8102E'
            Add-ReviewRow 'Panel Serial' $script:PanelSerial
            Add-ReviewRow 'OPS Serial'   $script:OPSSerial
            Add-ReviewRow 'Storage'      $script:StorageGB
            Add-ReviewRow 'Action'       'Rename, KMS activate, timezone, power config, schedule domain join'
            if ($script:OPSTruncationNote) {
                $script:UI['borReviewWarning'].Visibility  = 'Visible'
                $script:UI['lblReviewWarning'].Text = "OPS serial may be incomplete: $script:OPSTruncationNote"
            }
        }
        2 {
            $script:UI['lblReviewTitle'].Text = 'RMA / Warranty Replacement'
            Add-ReviewRow 'Mode'         'RMA / Warranty Replacement'
            Add-ReviewRow 'Technician'   $script:TechName
            Add-ReviewRow 'School'       "$($script:SchoolCode) - $($script:SchoolName)"
            Add-ReviewRow 'Manufacturer' $script:Manufacturer
            if ($script:PanelModel) { Add-ReviewRow 'Panel Model' $script:PanelModel }
            Add-ReviewRow 'Mount Type'   $script:MountType
            Add-ReviewRow 'Room Type'    $rtReview
            Add-ReviewRow 'Room'         $script:RoomNumber
            Add-ReviewRow 'Panel Serial' $script:PanelSerial
            Add-ReviewRow 'OPS Serial'   $script:OPSSerial
            if ($script:RMAPreviousPanelSerial) { Add-ReviewRow 'Replaces Panel' $script:RMAPreviousPanelSerial '#F0B030' }
            switch ($script:RMAAction) {
                'InventoryOnly' {
                    Add-ReviewRow 'Hostname' $env:COMPUTERNAME '#4EC994'
                    Add-ReviewRow 'Action' 'Same configured OPS: update current inventory/pairing only - no provisioning'
                }
                'RenameOnly' {
                    Add-ReviewRow 'Current Hostname' $env:COMPUTERNAME '#888888'
                    Add-ReviewRow 'New Hostname' $script:Hostname '#C8102E'
                    Add-ReviewRow 'Action' 'Reuse configured OPS: rename for the replacement panel/location, then update inventory'
                }
                default {
                    Add-ReviewRow 'New Hostname' $script:Hostname '#C8102E'
                    Add-ReviewRow 'Action' 'OPS is not domain joined: run full provisioning, then update inventory'
                }
            }
        }
        3 {
            $script:UI['lblReviewTitle'].Text = 'OPS Module Move'
            Add-ReviewRow 'Mode'              'OPS Module Move'
            Add-ReviewRow 'Technician'        $script:TechName
            Add-ReviewRow 'School'            "$($script:SchoolCode) - $($script:SchoolName)"
            Add-ReviewRow 'Manufacturer'      $script:Manufacturer
            if ($script:PanelModel) { Add-ReviewRow 'Panel Model' $script:PanelModel }
            Add-ReviewRow 'Mount Type'        $script:MountType
            Add-ReviewRow 'Room Type'         $rtReview
            Add-ReviewRow 'Room'              $script:RoomNumber
            Add-ReviewRow 'New Hostname'      $script:Hostname '#C8102E'
            Add-ReviewRow 'New Panel Serial'  $script:PanelSerial
            Add-ReviewRow 'OPS Serial'        $script:OPSSerial
            Add-ReviewRow 'Storage'           $script:StorageGB
            if ($script:OldOPSSerial) { Add-ReviewRow 'Removed OPS Serial' $script:OldOPSSerial }
            Add-ReviewRow 'OPS Disposition'   $script:M3OldOPSDisposition
            Add-ReviewRow 'Move Type'         $script:InventoryReassignmentType '#F0B030'
            if ($script:InventoryPreviousPanelSerial) { Add-ReviewRow 'Previously Recorded Panel' $script:InventoryPreviousPanelSerial '#F0B030' }
            if ($script:TemporaryAssignment) { Add-ReviewRow 'Follow-up' 'REQUIRED - temporary OPS assignment' '#F0B030' }
            if ($script:TestingObservationOnly) {
                Add-ReviewRow 'Action' 'Testing observation only - no rename and no authoritative pairing change' '#4EC994'
            } else {
                Add-ReviewRow 'Action' 'Rename device, record the OPS move, and reconcile current pairing'
            }
        }
        4 {
            $script:UI['lblReviewTitle'].Text = 'Panel Relocation'
            Add-ReviewRow 'Mode'         'Panel Relocation'
            Add-ReviewRow 'Technician'   $script:TechName
            Add-ReviewRow 'School'       "$($script:SchoolCode) - $($script:SchoolName)"
            Add-ReviewRow 'Manufacturer' $script:Manufacturer
            if ($script:PanelModel) { Add-ReviewRow 'Panel Model' $script:PanelModel }
            Add-ReviewRow 'Mount Type'   $script:MountType
            Add-ReviewRow 'Room Type'    $rtReview
            Add-ReviewRow 'Room'         $script:RoomNumber
            Add-ReviewRow 'New Hostname' $script:Hostname '#C8102E'
            Add-ReviewRow 'Panel Serial' $script:PanelSerial
            Add-ReviewRow 'OPS Serial'   $script:OPSSerial
            Add-ReviewRow 'Storage'      $script:StorageGB
            Add-ReviewRow 'Action'       'Rename device, log entry'
        }
        5 {
            $script:UI['lblReviewTitle'].Text = 'Warranty Replacement (Same Model)'
            Add-ReviewRow 'Mode'         'Warranty Replacement (Same Model)'
            Add-ReviewRow 'Technician'   $script:TechName
            Add-ReviewRow 'Panel Serial' $script:PanelSerial
            Add-ReviewRow 'OPS Serial'   $script:OPSSerial
            Add-ReviewRow 'Storage'      $script:StorageGB
            if ($script:M5HostnameCorrect) {
                Add-ReviewRow 'Hostname' $script:Hostname '#4EC994'
                Add-ReviewRow 'Action'  'Log entry only - hostname verified correct'
            } else {
                Add-ReviewRow 'Old Hostname' $env:COMPUTERNAME '#888888'
                Add-ReviewRow 'New Hostname' $script:Hostname  '#C8102E'
                Add-ReviewRow 'School'       "$($script:SchoolCode) - $($script:SchoolName)"
                Add-ReviewRow 'Manufacturer' $script:Manufacturer
                if ($script:PanelModel) { Add-ReviewRow 'Panel Model' $script:PanelModel }
                Add-ReviewRow 'Mount Type'   $script:MountType
                Add-ReviewRow 'Room Type'    $rtReview
                Add-ReviewRow 'Room'         $script:RoomNumber
                Add-ReviewRow 'Action'       'Rename device, log entry'
            }
        }
        6 {
            $script:UI['lblReviewTitle'].Text = 'General Inventory Capture'
            Add-ReviewRow 'Mode'         'General Inventory Capture'
            Add-ReviewRow 'Technician'   $script:TechName
            Add-ReviewRow 'Hostname'     $script:Hostname '#4EC994'
            Add-ReviewRow 'School'       "$($script:SchoolCode) - $($script:SchoolName)"
            Add-ReviewRow 'Manufacturer' $script:Manufacturer
            if ($script:PanelModel) { Add-ReviewRow 'Panel Model' $script:PanelModel '#CCCCCC' }
            Add-ReviewRow 'Mount Type'   $script:MountType
            Add-ReviewRow 'Room Type'    $rtReview
            Add-ReviewRow 'Room'         $script:RoomNumber
            Add-ReviewRow 'Panel Serial' $script:PanelSerial
            Add-ReviewRow 'OPS Serial'   $script:OPSSerial
            Add-ReviewRow 'Storage'      $script:StorageGB
            Add-ReviewRow 'Action'       'Log to Inventory sheet'
        }
    }
    Show-Screen 'pnlReview'
}

function Show-OPSScreen {
    $script:StorageGB = Get-StorageSize
    Write-Log "Storage detected: $script:StorageGB"
    $data = Get-OPSSerialData
    $script:UI['lblOPS_BIOS'].Text    = if ($data.BIOS)     { $data.BIOS     } else { '(not found)' }
    $script:UI['lblOPS_Product'].Text = if ($data.Product)  { $data.Product  } else { '(not found)' }
    $script:UI['lblOPS_Board'].Text   = if ($data.Board)    { $data.Board    } else { '(not found)' }
    $script:UI['lblOPS_Reg'].Text     = if ($data.Registry) { $data.Registry } else { '(not found)' }
    # Persist all four sources + validation for backend debug (ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§6.5)
    $script:OPSSerial_BIOS       = "$($data.BIOS)"
    $script:OPSSerial_Product    = "$($data.Product)"
    $script:OPSSerial_BaseBoard  = "$($data.Board)"
    $script:OPSSerial_Registry   = "$($data.Registry)"
    $script:SelectedOPSSerialSource     = "$($data.BestSource)"
    $script:SelectedOPSSerialConfidence = "$($data.Confidence)"
    $script:OPSSerialValidationStatus   = "$($data.ValidationStatus)"
    $script:OPSSerialValidationNote     = "$($data.ValidationNote)"

    if ($data.Best) {
        $script:OPSSerial = $data.Best
        $script:UI['lblOPS_BestValue'].Text  = $data.Best
        $script:UI['lblOPS_BestSource'].Text = "Source: $($data.BestSource)   Model class: $(if ($data.ExpectedPrefix) { $data.ExpectedPrefix } else { 'n/a' })"
        $script:UI['lblOPS_Confidence'].Text = "Confidence: $($data.Confidence)"
        $script:UI['borOPSNone'].Visibility  = 'Collapsed'
        if ($data.PossiblyTruncated) {
            $script:OPSTruncationNote = "Serial '$($data.Best)' is only $($data.Best.Length) chars"
            $script:UI['borOPSTrunc'].Visibility = 'Visible'
        } else {
            $script:OPSTruncationNote = ''
            $script:UI['borOPSTrunc'].Visibility = 'Collapsed'
        }
    } else {
        $script:OPSSerial = 'UNKNOWN'
        $script:UI['lblOPS_BestValue'].Text  = 'UNKNOWN'
        $script:UI['lblOPS_BestSource'].Text = 'No usable serial found'
        $script:UI['lblOPS_Confidence'].Text = 'Confidence: None'
        $script:UI['borOPSNone'].Visibility  = 'Visible'
        $script:UI['borOPSTrunc'].Visibility = 'Collapsed'
        $script:OPSTruncationNote = ''
    }
    # Editable override pre-filled with the detected value
    $script:UI['txtOPSOverride'].Text = if ($data.Best) { $data.Best } else { '' }
    # Suspicious-serial warning (model says one family but serial does not match)
    if ($data.ValidationStatus -eq 'Suspicious') {
        $script:UI['lblOPSSuspicious'].Text = $data.ValidationNote
        $script:UI['borOPSSuspicious'].Visibility = 'Visible'
        $script:UI['lblOPS_Confidence'].Foreground = New-Brush '#F0B030'
    } else {
        $script:UI['borOPSSuspicious'].Visibility = 'Collapsed'
        $script:UI['lblOPS_Confidence'].Foreground = New-Brush '#4EC994'
    }
    Show-Screen 'pnlOPSSerial'
}

function Set-ScanFlash {
    param([string]$Serial)
    $script:UI['lblScanStatus'].Text       = 'OK'
    $script:UI['lblScanStatus'].Foreground = New-Brush '#4EC994'
    $script:UI['borScanIndicator'].Background = New-Brush '#0F1E10'
    $script:UI['lblScannedSerial'].Text    = $Serial
    $script:UI['borScannedResult'].Visibility = 'Visible'
}

function Prepare-ScanScreen {
    $script:UI['txtBarcodeInput'].Text = ''
    $script:UI['btnScanContinue'].IsEnabled = $false
    $script:UI['borScannedResult'].Visibility = 'Collapsed'
    $script:UI['borMobileHint'].Visibility    = 'Collapsed'
    $script:UI['lblScanStatus'].Text       = 'Ready'
    $script:UI['lblScanStatus'].Foreground = New-Brush '#888888'
    $script:UI['borScanIndicator'].Background = New-Brush '#262626'
    $showMissing = ($script:CurrentMode -eq 7)
    $script:UI['btnPanelSerialMissing'].Visibility = if ($showMissing) { 'Visible' } else { 'Collapsed' }
    $script:UI['lblPanelSerialMissingHint'].Visibility = if ($showMissing) { 'Visible' } else { 'Collapsed' }
    switch ($script:CurrentMode) {
        { $_ -in @(1,2,9) } {
            $script:UI['lblScanHeader'].Text      = 'Scan Panel Barcode'
            $script:UI['lblScanInstruction'].Text = 'Scan the barcode label on the panel chassis.'
        }
        3 {
            $script:UI['lblScanHeader'].Text      = 'Scan New Panel Barcode'
            $script:UI['lblScanInstruction'].Text = 'Scan the barcode on the chassis the OPS module is being installed into.'
        }
        4 {
            $script:UI['lblScanHeader'].Text      = 'Scan Panel Barcode'
            $script:UI['lblScanInstruction'].Text = 'Scan the barcode label on this panel chassis.'
        }
        5 {
            $script:UI['lblScanHeader'].Text      = 'Scan Replacement Panel Barcode'
            $script:UI['lblScanInstruction'].Text = 'Scan the barcode on the replacement chassis (not the OPS module).'
        }
        7 {
            $script:UI['lblScanHeader'].Text      = 'Scan Panel Barcode'
            $script:UI['lblScanInstruction'].Text = 'Scan the barcode label on the panel chassis to record its serial number.'
        }
    }
    try { $script:UI['txtBarcodeInput'].Focus() | Out-Null } catch {}
}

function Prepare-LocationScreen {
    $script:UI['lblSchoolError'].Visibility     = 'Collapsed'
    $script:UI['lblMfrError'].Visibility        = 'Collapsed'
    $script:UI['lblPanelModelError'].Visibility = 'Collapsed'
    $script:UI['lblRoomError'].Visibility       = 'Collapsed'
    $script:UI['lblRoomTypeError'].Visibility   = 'Collapsed'
    # Missing-serial recovery already established the manufacturer. Keep it visible for context but
    # lock it so the reconciliation evidence cannot accidentally be relabeled later in the visit.
    $script:UI['cboManufacturer'].IsEnabled = $true
    if ($script:PanelSerialStickerStatus -eq 'Missing or Unreadable' -and $script:Manufacturer) {
        for ($i = 0; $i -lt $script:UI['cboManufacturer'].Items.Count; $i++) {
            if ("$($script:UI['cboManufacturer'].Items[$i].Content)" -eq $script:Manufacturer) {
                $script:UI['cboManufacturer'].SelectedIndex = $i; break
            }
        }
        $script:UI['cboManufacturer'].IsEnabled = $false
    }
    # v5.3.3 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§3: populate the Room Type dropdown once, with a blank "Select Room Type" placeholder
    # (never auto-select CLASS). Restore the saved value when resuming a ProjectRunId.
    if ($script:UI['cboRoomType'].Items.Count -eq 0) {
        $ph = [System.Windows.Controls.ComboBoxItem]::new(); $ph.Content = 'Select Room Type'; $ph.Tag = ''
        $script:UI['cboRoomType'].Items.Add($ph) | Out-Null
        foreach ($rt in $script:RoomTypeValues) {
            $it = [System.Windows.Controls.ComboBoxItem]::new(); $it.Content = $rt; $it.Tag = $rt
            $script:UI['cboRoomType'].Items.Add($it) | Out-Null
        }
    }
    $sel = 0
    if ($script:RoomType) {
        for ($i = 0; $i -lt $script:UI['cboRoomType'].Items.Count; $i++) {
            if ("$($script:UI['cboRoomType'].Items[$i].Tag)" -eq $script:RoomType) { $sel = $i; break }
        }
    }
    $script:UI['cboRoomType'].SelectedIndex = $sel
    $isOther = ($script:RoomType -eq 'Other')
    $script:UI['lblOtherRoomTypeLabel'].Visibility = if ($isOther) { 'Visible' } else { 'Collapsed' }
    $script:UI['txtOtherRoomType'].Visibility      = if ($isOther) { 'Visible' } else { 'Collapsed' }
    $script:UI['txtOtherRoomType'].Text = $script:OtherRoomType
    # Adjust continue button label for inventory modes
    if ($script:CurrentMode -eq 7) {
        $script:UI['btnLocationContinue'].Content = 'Next: Panel Readiness'
    } elseif ($script:CurrentMode -eq 6) {
        $script:UI['btnLocationContinue'].Content = 'Capture Data'
    } else {
        $script:UI['btnLocationContinue'].Content = 'Build Hostname'
    }
}

# v5.4 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§11: preselect the saved values on the location screen so a correction starts from the
# CURRENT record rather than a blank form (technicians correct, they do not re-enter).
function Prefill-LocationScreen {
    for ($i = 0; $i -lt $script:UI['cboSchool'].Items.Count; $i++) {
        if ("$($script:UI['cboSchool'].Items[$i].Tag)" -eq $script:SchoolCode) { $script:UI['cboSchool'].SelectedIndex = $i; break }
    }
    for ($i = 0; $i -lt $script:UI['cboManufacturer'].Items.Count; $i++) {
        if ("$($script:UI['cboManufacturer'].Items[$i].Content)" -eq $script:Manufacturer) { $script:UI['cboManufacturer'].SelectedIndex = $i; break }
    }
    if ($script:PanelModel) {
        for ($i = 0; $i -lt $script:UI['cboPanelModel'].Items.Count; $i++) {
            if ("$($script:UI['cboPanelModel'].Items[$i].Content)" -eq $script:PanelModel) { $script:UI['cboPanelModel'].SelectedIndex = $i; break }
        }
    }
    $script:UI['txtRoomNumber'].Text = $script:RoomNumber
    if ($script:MountType -eq 'Mobile') { $script:UI['rdoMobile'].IsChecked = $true } else { $script:UI['rdoWallMounted'].IsChecked = $true }
    for ($i = 0; $i -lt $script:UI['cboRoomType'].Items.Count; $i++) {
        if ("$($script:UI['cboRoomType'].Items[$i].Tag)" -eq $script:RoomType) { $script:UI['cboRoomType'].SelectedIndex = $i; break }
    }
    $script:UI['txtOtherRoomType'].Text = $script:OtherRoomType
}
# v5.4 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§13: build the before/after diff and show the review screen.
function Show-InventoryReview {
    $b = $script:InvBeforeSnapshot
    if ($script:UI['cboInvCorrType'].Items.Count -eq 0) {
        foreach ($t in @('Data-entry correction','Panel was physically relocated','Existing record belongs to another panel','Version backfill/enrichment','Not sure')) {
            $it = [System.Windows.Controls.ComboBoxItem]::new(); $it.Content = $t
            $script:UI['cboInvCorrType'].Items.Add($it) | Out-Null
        }
    }
    if ($script:UI['cboInvCorrReason'].Items.Count -eq 0) {
        foreach ($t in @('Data-entry typo','Missing information','Incorrect school','Incorrect room','Incorrect Room Type',
                         'Incorrect panel manufacturer','Incorrect panel model','Incorrect mount type','Incorrect install type',
                         'Hostname/location mismatch','Previous record was incomplete','Physical inventory verification',
                         'Version backfill/enrichment','Windows image-policy correction','Incorrect reimage recommendation',
                         'Incorrect manufacturer recovery method','Firmware-status correction','Other')) {
            $it = [System.Windows.Controls.ComboBoxItem]::new(); $it.Content = $t
            $script:UI['cboInvCorrReason'].Items.Add($it) | Out-Null
        }
    }
    $script:UI['cboInvCorrType'].SelectedIndex = -1
    $script:UI['cboInvCorrReason'].SelectedIndex = -1
    $script:UI['txtInvNotes'].Text = ''
    $script:UI['lblInvReviewError'].Visibility = 'Collapsed'
    $rows = @(('{0,-16} {1,-24} {2}' -f 'Field','Current Value','New Value'),
              ('{0,-16} {1,-24} {2}' -f '---------------','-----------------------','-----------------------'))
    foreach ($f in @(
        @{n='School';        old="$($b.SchoolCode)";    new=$script:SchoolCode},
        @{n='Room';          old="$($b.Room)";          new=$script:RoomNumber},
        @{n='Room Type';     old="$($b.RoomType)";      new=$script:RoomType},
        @{n='Other Room Type';old="$($b.OtherRoomType)";new=$script:OtherRoomType},
        @{n='Manufacturer';  old="$($b.Manufacturer)";  new=$script:Manufacturer},
        @{n='Panel Model';   old="$($b.PanelModel)";    new=$script:PanelModel},
        @{n='Mount Type';    old="$($b.MountType)";     new=$script:MountType})) {
        $mark = if ("$($f.old)" -ne "$($f.new)") { ' *' } else { '' }
        $rows += ('{0,-16} {1,-24} {2}{3}' -f $f.n, $f.old, $f.new, $mark)
    }
    $rows += ''
    $rows += "Panel serial : $($b.PanelSerial)  (identity - not editable here)"
    $rows += "OPS serial   : $($b.CurrentOPSSerial)  (identity - not editable here)"
    $rows += '* = changed'
    $script:UI['lblInvDiff'].Text = ($rows -join "`n")
    Show-Screen 'pnlInvReview'
    try { $script:UI['cboInvCorrType'].Focus() | Out-Null } catch {}
}
function Set-Mode {
    param([int]$Mode, [string]$Label)
    $script:CurrentMode  = $Mode
    $script:ModeLabel    = $Label
    $script:UI['lblModeDisplay'].Text = "Mode $Mode - $Label"
    Write-Log "Mode: $Mode - $Label"
}

# ================================================================
#  EXECUTION HELPERS (shared runspace script block fragments)
# ================================================================
$script:RunnerDefs = {
    function Log { param($m, $l='INFO')
        $line = "[$(Get-Date -f 'HH:mm:ss')][$l] $m"
        try { Add-Content -Path $s.LogFile -Value $line -Encoding UTF8 } catch {}
        if ($l -eq 'ERROR') {
            $s.RunFlags.HadError = $true
            try { Add-Content -Path $s.ErrorLog -Value $line -Encoding UTF8 } catch {}
        }
        try { $s.UI['txtProgressLog'].Dispatcher.Invoke([action]{
            $s.UI['txtProgressLog'].AppendText("$line`n")
            $s.UI['txtProgressLog'].ScrollToEnd() }) } catch {}
    }
    function Status { param($m) Log $m
        try { $s.UI['lblProgressStatus'].Dispatcher.Invoke([action]{
            $s.UI['lblProgressStatus'].Text = $m }) } catch {}
    }
    function Done { param($m, [bool]$reboot=$false)
        try { $s.UI['pbarProgress'].Dispatcher.Invoke([action]{
            $s.UI['pbarProgress'].IsIndeterminate = $false
            $s.UI['pbarProgress'].Value = 100
            $s.UI['lblProgressStatus'].Text = $m
            $s.UI['lblProgressStatus'].Foreground = [System.Windows.Media.SolidColorBrush](
                [System.Windows.Media.ColorConverter]::ConvertFromString('#4EC994'))
            if ($reboot) { $s.UI['btnProgressReboot'].Visibility = [System.Windows.Visibility]::Visible }
            else         { $s.UI['btnProgressDone'].Visibility   = [System.Windows.Visibility]::Visible }
            # Phase A (only) offers an abort before the tech commits to the Phase B reboot.
            if ($reboot -and $s.ShowAbort) { $s.UI['btnAbortProvision'].Visibility = [System.Windows.Visibility]::Visible }
        }) } catch {}
    }
    # $CleanupState (optional) is the v5.4 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§29 Phase A cleanup summary shown to the tech, and it
    # also enables the Retry Phase A button (a Phase A failure is retryable once cleanup is done).
    function Fail { param($m, $CleanupState = '')
        try { $s.UI['pbarProgress'].Dispatcher.Invoke([action]{
            $s.UI['pbarProgress'].IsIndeterminate = $false
            $s.UI['lblProgressStatus'].Text = "ERROR: $m"
            $s.UI['lblProgressStatus'].Foreground = [System.Windows.Media.SolidColorBrush](
                [System.Windows.Media.ColorConverter]::ConvertFromString('#EF5B5B'))
            $s.UI['btnProgressDone'].Content    = 'Return to Menu'
            $s.UI['btnProgressDone'].Visibility = [System.Windows.Visibility]::Visible
            if ($s.UI['btnProgressReportIssue']) { $s.UI['btnProgressReportIssue'].Visibility = [System.Windows.Visibility]::Visible }
            if ($CleanupState) {
                $s.UI['lblPhaseAFailureState'].Text  = $CleanupState
                $s.UI['borPhaseAFailure'].Visibility = [System.Windows.Visibility]::Visible
                $s.UI['btnProgressRetry'].Visibility = [System.Windows.Visibility]::Visible
                try { $s.UI['borPhaseAFailure'].BringIntoView() } catch {}
            }
        }) } catch {}
    }
    # r9: a permanently REJECTED write means the spreadsheet holds nothing for this panel.
    # The runspace must never paint a green "complete" over that - the work has to be redone
    # or escalated, and a tech who sees "Complete" walks away from an unrecorded panel.
    function Stop-IfRejected {
        param($Result, [string]$What)
        if (-not $Result -or -not $Result.Rejected) { return $false }
        $code = if ($Result.Parsed) { "$($Result.Parsed.ErrorCode)" } else { 'REJECTED' }
        $msg  = if ($Result.Parsed) { "$($Result.Parsed.Message)" } else { 'The spreadsheet rejected this entry.' }
        Log "$What was PERMANENTLY REJECTED ($code) - not reporting completion." 'ERROR'
        Fail "NOT RECORDED - the spreadsheet rejected this entry ($code): $msg  Report this to a lead before moving on."
        return $true
    }
    # v5.5 review finding #1: the runspace no longer has its own POST or queue writer.
    # Everything goes through the SHARED Send-PanelAppEvent injected from $script:SenderDefs,
    # so background work (Summer assessment, RedoRescue gate, Phase A, inventory modes)
    # gets EventId idempotency, sequencing, canonical identity, revision expectations and
    # retryable-vs-permanent handling exactly like the main thread.
    function Get-RunnerSenderContext {
        if ($s.QueueDir)                              { $dir = "$($s.QueueDir)" }
        elseif ($s.ProvisioningDir)                 { $dir = Join-Path $s.ProvisioningDir 'OfflineQueue' }
        else                                        { $dir = Join-Path $s.ScriptDir 'APS\OfflineQueue' }
        return @{
            Url = $s.AppScriptUrl; QueueDir = $dir
            FallbackQueueDir = $(if ($s.ProvisioningDir) { Join-Path $s.ProvisioningDir 'OfflineQueue' } else { $dir })
            SessionId = "$($s.ClientSessionId)"; DeviceName = "$($s.ClientDeviceName)"
            ScriptVersion = "$($s.ScriptVersion)"; RunId = $s.RunId
            Sequence = [int]$s.EventSequence
            Revision = "$($s.ProjectStateRevision)"; RevisionFor = "$($s.ProjectStateRevisionFor)"
            Online = $true
        }
    }
    function Sync-RunnerSenderContext { param([hashtable]$Ctx)
        $s.EventSequence           = [int]$Ctx['Sequence']
        $s.ProjectStateRevision    = "$($Ctx['Revision'])"
        $s.ProjectStateRevisionFor = "$($Ctx['RevisionFor'])"
    }
    function Queue-Event { param([hashtable]$Payload, $EventType='Event')
        $ctx = Get-RunnerSenderContext
        $fp = Write-QueuedEvent -Payload $Payload -EventType $EventType -Ctx $ctx
        Sync-RunnerSenderContext $ctx
        if ($fp) { Log "Event queued offline: $fp" 'WARN' } else { Log 'Queue failed.' 'ERROR' }
    }
    # $EventType is the LIFECYCLE event name (SummerAssessmentCaptured, PhaseAFailed, ...).
    # Routing is by LogSheet, so naming the lifecycle here is what drives the backend's
    # revision increment and current-inventory synchronization (review finding #3).
    # r14 16-20 (field concern): the Windows Update pause can hang on a wedged wuauserv, and
    # PanelApp must never sit frozen on it. The pause work runs in a child job with a hard
    # timeout; the check-first makes a retry idempotent - a partially applied first attempt
    # reports "Already Paused" instead of stacking a second conflicting configuration.
    function Test-WUPaused {
        $svc = Get-Service wuauserv -ErrorAction SilentlyContinue
        $pol = (Get-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name NoAutoUpdate -ErrorAction SilentlyContinue).NoAutoUpdate
        return ($svc -and $svc.StartType -eq 'Disabled' -and $pol -eq 1)
    }
    function Invoke-WUPauseWithTimeout {
        param([int]$TimeoutSeconds = 60)
        if ($TimeoutSeconds -le 0) { $TimeoutSeconds = 60 }
        $startedAt = Get-Date
        $out = @{ Status = 'Failed'; StartedAt = $startedAt.ToString('yyyy-MM-dd HH:mm:ss')
                  CompletedAt = ''; DurationSeconds = 0; Error = '' }
        try {
            if (Test-WUPaused) {
                $out.Status = 'Already Paused'
                $out.CompletedAt = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
                return $out
            }
            $job = Start-Job -ScriptBlock {
                Stop-Service  wuauserv -Force -ErrorAction SilentlyContinue
                Set-Service   wuauserv -StartupType Disabled -ErrorAction SilentlyContinue
                $p = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU'
                if (-not (Test-Path $p)) { New-Item -Path $p -Force | Out-Null }
                Set-ItemProperty $p -Name NoAutoUpdate -Value 1 -Type DWord -ErrorAction SilentlyContinue
            }
            $done = Wait-Job -Job $job -Timeout $TimeoutSeconds
            if (-not $done) {
                try { Stop-Job $job -ErrorAction SilentlyContinue; Remove-Job $job -Force -ErrorAction SilentlyContinue } catch {}
                $out.Status = 'Timed Out'
                $out.Error  = "Pause did not finish within $TimeoutSeconds seconds."
            } else {
                try { Receive-Job $job -ErrorAction SilentlyContinue | Out-Null; Remove-Job $job -Force -ErrorAction SilentlyContinue } catch {}
                if (Test-WUPaused) { $out.Status = 'Success' }
                else { $out.Status = 'Failed'; $out.Error = 'Pause commands ran but the paused state could not be verified.' }
            }
        } catch { $out.Status = 'Failed'; $out.Error = "$_" }
        $out.CompletedAt = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
        $out.DurationSeconds = [int]((Get-Date) - $startedAt).TotalSeconds
        return $out
    }
    # r12 finding #2: a runspace must respect a hold the MAIN THREAD created before it started,
    # a hold this runspace created on an earlier event, and anything already sitting in the queue
    # for the project. Sharing a ProjectRunId does not order events by itself - the sender has to
    # deliberately queue the later one.
    function Test-RunnerProjectHold {
        param([string]$Project, [hashtable]$Ctx)
        if (-not $Project) { return $false }
        if ("$($s.PendingQueuedProjectRunId)" -eq $Project) { return $true }
        $dirs = @($Ctx['QueueDir'])
        if ($s.UsbRoot)         { $dirs += (Join-Path $s.UsbRoot 'APS\OfflineQueue') }
        if ($s.ProvisioningDir) { $dirs += (Join-Path $s.ProvisioningDir 'OfflineQueue') }
        if (Test-QueuedWorkInDirs -Dirs $dirs -ProjectRunId $Project) {
            $s.PendingQueuedProjectRunId = $Project   # sticky for the rest of this runspace
            return $true
        }
        return $false
    }
    function Post-Log { param([hashtable]$data, [Parameter(Mandatory)][string]$EventType)
        if (-not $data.ContainsKey('Timestamp')) { $data['Timestamp'] = Get-Date -Format 'yyyy-MM-dd HH:mm:ss' }
        if (-not $data.ContainsKey('TechName'))  { $data['TechName']  = $s.TechName }
        if ($s.RunId -and -not $data.ContainsKey('RunId')) { $data['RunId'] = $s.RunId }
        $ctx = Get-RunnerSenderContext
        $projRun = "$($data['ProjectRunId'])"
        if (-not $projRun) { $projRun = "$($data['RelatedSummerProjectRunId'])" }
        if (Test-RunnerProjectHold $projRun $ctx) {
            Log "Project $projRun has queued work - queueing $EventType behind it to preserve order." 'WARN'
            $ctx['Online'] = $false
            $ctx['QueueHoldReason'] = 'Waiting for earlier saved events in this project to synchronize in order.'
        }
        $res = Send-PanelAppEvent -Payload $data -EventType $EventType -Ctx $ctx
        Sync-RunnerSenderContext $ctx
        if ($res.Sent) {
            Log "Sheets OK ($EventType)$(if ($res.Parsed -and $res.Parsed.Duplicate) { ' - already applied' })."
            # r9: applied, but the current-inventory layer needs a lead to reconcile it.
            if ($res.Parsed -and $res.Parsed.InventoryReviewRequired) {
                Log ("Applied, but current inventory needs review ($($res.Parsed.WarningCode)): $($res.Parsed.WarningMessage)") 'WARN'
            }
        } elseif ($res.Rejected) {
            Log "Apps Script PERMANENTLY rejected ($EventType / $($res.Parsed.ErrorCode)): $($res.Parsed.Message)" 'ERROR'
        } else {
            Log "Event not delivered ($EventType): $($res.Reason) -- saved for synchronization." 'WARN'
            # r6 finding #2: tell the MAIN THREAD this project now has queued work, so a later
            # live event (closeout) cannot reach the backend before this queued one.
            $pendRun = "$($data['ProjectRunId'])"
            if (-not $pendRun) { $pendRun = "$($data['RelatedSummerProjectRunId'])" }
            if ($pendRun) { $s.PendingQueuedProjectRunId = $pendRun }
        }
        # r5 finding #3: callers that gate irreversible steps need the delivery status.
        return [pscustomobject]@{
            Status    = $(if ($res.Sent) {
                              if ($res.Parsed -and $res.Parsed.InventoryReviewRequired) { 'Applied - Inventory Review Required' }
                              elseif ($res.Parsed -and $res.Parsed.Duplicate) { 'Duplicate' }
                              else { 'Applied' }
                          } elseif ($res.Rejected) { 'Rejected' } else { 'Queued' })
            Delivered = [bool]$res.Sent
            Queued    = (-not $res.Sent -and -not $res.Rejected)
            Rejected  = [bool]$res.Rejected
            Parsed    = $res.Parsed
        }
    }
}

function Start-ProvisionJob {
    param([scriptblock]$Work, [hashtable]$Sync)
    # v5.5 finding #2: stamp the sender context centrally. Individually hand-copying a subset
    # into each $sync is what left most runspaces posting with a blank AppVersion.
    Add-SenderContextToSync $Sync | Out-Null
    # v5.5 finding #1 (round 3): keep a handle on the LIVE sync so the sequence/revision the
    # runspace advances is merged back before the next main-thread send. Without this the main
    # thread keeps a stale revision and the FOLLOWING event is rejected as STALE_PROJECT_REVISION.
    $script:ActiveSenderSync = $Sync
    $rs = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace()
    $rs.ApartmentState = [System.Threading.ApartmentState]::STA
    $rs.ThreadOptions  = [System.Management.Automation.Runspaces.PSThreadOptions]::ReuseThread
    $rs.Open()
    $rs.SessionStateProxy.SetVariable('s', $Sync)
    $ps = [System.Management.Automation.PowerShell]::Create()
    $ps.Runspace = $rs
    # Root-cause fix: PanelApp launches from a removable drive. A background job that inherits the
    # USB (or a disconnected-share) path as its working directory cannot launch external commands
    # like powercfg.exe. Force a local Windows directory BEFORE any RunnerDefs/Work runs.
    [void]$ps.AddScript({
        $safeWorkingDirectory = Join-Path $env:SystemRoot 'System32'
        if (-not (Test-Path -LiteralPath $safeWorkingDirectory)) {
            throw "Safe working directory was not found: $safeWorkingDirectory"
        }
        Set-Location -LiteralPath $safeWorkingDirectory -ErrorAction Stop
        [System.Environment]::CurrentDirectory = $safeWorkingDirectory
    })
    [void]$ps.AddScript($script:SenderDefs)          # v5.5: ONE shared sender (finding #1)
    [void]$ps.AddScript($script:RunnerDefs)
    [void]$ps.AddScript($script:ImageDecisionDefs)   # v5.4: ONE shared image matrix (defect #5)
    [void]$ps.AddScript($Work)
    [void]$ps.BeginInvoke()
}

function Reset-ProgressScreen {
    param([string]$Header)
    $script:ProgressAction = ''
    $script:UI['pbarProgress'].IsIndeterminate = $true
    $script:UI['pbarProgress'].Value           = 0
    $script:UI['btnProgressDone'].Visibility    = 'Collapsed'
    $script:UI['btnProgressDone'].Content       = 'Close'
    $script:UI['btnProgressReboot'].Visibility  = 'Collapsed'
    $script:UI['btnProgressReportIssue'].Visibility = 'Collapsed'
    $script:UI['btnAbortProvision'].Visibility   = 'Collapsed'
    $script:UI['btnProgressRetry'].Visibility    = 'Collapsed'
    $script:UI['borPhaseAFailure'].Visibility    = 'Collapsed'
    $script:UI['txtProgressLog'].Text           = ''
    $script:UI['lblProgressHeader'].Text        = $Header
    $script:UI['lblProgressStatus'].Text        = 'Starting...'
    $script:UI['lblProgressStatus'].Foreground  = New-Brush '#C8102E'
    Show-Screen 'pnlProgress'
}

# ================================================================
#  EXECUTE PHASE A  (Modes 1 & 2 - full provisioning)
# ================================================================
function Execute-PhaseA {
    Reset-ProgressScreen 'Phase A - Provisioning'

    # Write state file and register the Phase B scheduled task on the MAIN thread.
    # ScheduledTasks cmdlets require their module to be imported, which is not
    # guaranteed in a background runspace.  These two operations are fast and safe
    # to run synchronously before the slow work starts.
    # Review fix #1: every setup step below is REQUIRED. If any fails, Phase A stops BEFORE
    # the rename and before Windows Update is touched - no half-provisioned device, and we
    # never rely on the 8-hour recovery task to fix a failed start.
    $setupFailed = ''
    # v5.6.1: silently make the temporary local provisioning account survive the reboot sequence.
    # Technicians are never asked to change password-expiration settings themselves.
    $acctPreflight = Invoke-ProvisioningAccountPreflight
    if (-not $acctPreflight.Success) {
        $setupFailed = 'The local provisioning account could not be prepared automatically. Do not reboot this device. Contact a lead.'
    }
    if (-not $setupFailed) {
        try {
            Write-StateFile
            Write-Log 'State file written (main thread).'
        } catch { $setupFailed = "Could not write the provisioning state file: $_" }
    }
    if (-not $setupFailed) {
        try {
            Register-PhaseBTask
            Write-Log 'Phase B task registered (main thread).'
        } catch { $setupFailed = "Could not register the Phase B scheduled task: $_" }
    }
    if (-not $setupFailed) {
        try { Register-WURecoveryTask }
        catch { $setupFailed = "Could not register the Windows Update recovery task: $_" }
    }
    if ($setupFailed) {
        Write-Log "Phase A setup failed - stopping before rename: $setupFailed" 'ERROR'
        # Undo any partial setup so nothing fires after an accidental reboot
        Remove-PhaseBTask
        Remove-WURecoveryTask
        Remove-StateFile
        Update-ProgressStatus 'Phase A stopped - setup failed.'
        try { $script:UI['pbarProgress'].IsIndeterminate = $false } catch {}
        $script:UI['btnProgressDone'].Visibility = 'Visible'
        $script:UI['btnProgressReportIssue'].Visibility = 'Visible'
        [System.Windows.MessageBox]::Show(
            "PanelApp could not prepare the provisioning continuation. Provisioning cannot safely continue.`n`n$setupFailed`n`nDo not reboot from this workflow. Review the error or try again.",
            'Phase A Stopped', 'OK', 'Error') | Out-Null
        Send-Event -Payload @{ Mode=$script:ModeLabel; RunId=$script:RunId; PanelSerial=$script:PanelSerial
            OPSSerial=$script:OPSSerial; Hostname=$script:Hostname; PhaseAStatus='Failed'
            SchoolCode=$script:SchoolCode; Room=$script:RoomNumber; RoomType=$script:RoomType; OtherRoomType=$script:OtherRoomType
            Result='Failed - Phase A'; ProvisioningOutcome=$setupFailed; TechName=$script:TechName
            Timestamp=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') } -EventType 'PhaseAFailed' | Out-Null
        return
    }

    $sync = [hashtable]::Synchronized(@{
        UI           = $script:UI
        ShowAbort    = $true   # reveal the Abort button only when Phase A work finishes (not during)
        LogFile      = $script:LogFile
        TechName     = $script:TechName
        Hostname     = $script:Hostname
        School       = $script:SchoolCode
        SchoolName   = $script:SchoolName
        Room         = $script:RoomNumber
        RoomType     = $script:RoomType
        OtherRoomType = $script:OtherRoomType
        MountType    = $script:MountType
        Manufacturer = $script:Manufacturer
        PanelSerial  = $script:PanelSerial
        OPSSerial    = $script:OPSSerial
        OPSTruncNote = $script:OPSTruncationNote
        ModeLabel    = $script:ModeLabel
        KMSKey       = $script:Config.KMSKey
        NTPServer    = $script:Config.NTPServer
        Timezone     = $script:Config.Timezone
        WUPauseTimeoutSeconds = $(try { [int]$script:Config.WindowsUpdatePauseTimeoutSeconds } catch { 60 })
        AppScriptUrl = $script:Config.AppScriptUrl
        ScriptDir    = $script:ScriptDir
        ErrorLog     = $script:ErrorLog
        RunFlags     = $script:RunFlags
        UsbRoot      = $script:UsbRoot
        RunId        = $script:RunId
        ProvisioningDir = $script:ProvisioningDir
        RelatedSummerRunId = $script:RelatedSummerRunId
        TechName2    = $script:TechName
    })
    Start-ProvisionJob -Sync $sync -Work {
        try {
            Status "Renaming computer to $($s.Hostname)..."
            # Review fix #5: a Phase A retry may run on a device that was already renamed before
            # the previous failure. Renaming to the current name errors, so skip when identical.
            if ($env:COMPUTERNAME -ieq $s.Hostname) {
                Log "Computer is already named $($s.Hostname) - rename skipped."
            } else {
                Rename-Computer -NewName $s.Hostname -Force -ErrorAction Stop
                $configuredName = ''
                try { $configuredName = "$((Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName' -Name ComputerName -ErrorAction Stop).ComputerName)" } catch {}
                if ($configuredName -ine $s.Hostname) {
                    throw "Rename-Computer returned without staging the requested hostname. Expected '$($s.Hostname)', configured name is '$configuredName'."
                }
                Log "Rename staged successfully: active=$env:COMPUTERNAME, configured=$configuredName."
            }

            Status 'Removing Sysprep / cached unattend files...'
            # Windows can cache the answer file in Panther as well as System32\Sysprep. Leaving a
            # cached ComputerName/AutoLogon answer file behind can undo provisioning changes on reboot.
            $unattendPaths = @(
                "$env:SystemRoot\System32\Sysprep\unattend.xml",
                "$env:SystemRoot\System32\Sysprep\Panther\unattend.xml",
                "$env:SystemRoot\Panther\unattend.xml",
                "$env:SystemRoot\Panther\Unattend\unattend.xml"
            )
            foreach ($unattendPath in $unattendPaths) {
                if (Test-Path -LiteralPath $unattendPath) {
                    try {
                        Remove-Item -LiteralPath $unattendPath -Force -ErrorAction Stop
                        Log "Removed cached unattend file: $unattendPath"
                    } catch {
                        throw "Could not remove cached unattend file '$unattendPath': $($_.Exception.Message)"
                    }
                }
            }

            Status 'Activating Windows (KMS)...'
            if ($s.KMSKey) {
                & cscript //NoLogo "$env:SystemRoot\System32\slmgr.vbs" /ipk $s.KMSKey 2>&1 |
                    ForEach-Object { Log "$_" }
                & cscript //NoLogo "$env:SystemRoot\System32\slmgr.vbs" /ato 2>&1 |
                    ForEach-Object { Log "$_" }
            } else { Log 'KMS key not set - skipping.' 'WARN' }

            Status 'Setting timezone and NTP...'
            Set-TimeZone -Name $s.Timezone -ErrorAction SilentlyContinue
            & w32tm /config /manualpeerlist:$s.NTPServer /syncfromflags:manual /reliable:YES /update 2>&1 |
                ForEach-Object { Log "$_" }
            Restart-Service w32tm -Force -ErrorAction SilentlyContinue
            & w32tm /resync /force 2>&1 | ForEach-Object { Log "$_" }

            Status 'Applying power configuration...'
            # Call powercfg by FULL PATH (a background job's working dir may be a removable/invalid
            # drive), and treat a non-zero exit as a real Phase A failure now that the root cause
            # (working directory) is fixed.
            $powerCfgExe = Join-Path $env:SystemRoot 'System32\powercfg.exe'
            if (-not (Test-Path -LiteralPath $powerCfgExe)) { throw "powercfg.exe was not found at $powerCfgExe" }
            Set-Location -LiteralPath (Split-Path -Path $powerCfgExe -Parent) -ErrorAction Stop
            [System.Environment]::CurrentDirectory = (Split-Path -Path $powerCfgExe -Parent)
            function Invoke-RequiredPowerCfg { param([string[]]$PowerArguments, [string]$Description)
                $output = & $powerCfgExe @PowerArguments 2>&1
                $exitCode = $LASTEXITCODE
                if ($exitCode -ne 0) { throw "$Description failed with exit code $exitCode. $(($output | Out-String).Trim())" }
                Log "$Description completed."
            }
            switch ($s.Manufacturer) {
                'Boxlight' {
                    Invoke-RequiredPowerCfg -PowerArguments @('/setacvalueindex','SCHEME_CURRENT','SUB_BUTTONS','PBUTTONACTION','3') -Description 'Boxlight AC power-button shutdown setting'
                    Invoke-RequiredPowerCfg -PowerArguments @('/setdcvalueindex','SCHEME_CURRENT','SUB_BUTTONS','PBUTTONACTION','3') -Description 'Boxlight DC power-button shutdown setting'
                    Invoke-RequiredPowerCfg -PowerArguments @('/setactive','SCHEME_CURRENT') -Description 'Reactivate current power scheme'
                    $hb = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power'
                    if (-not (Test-Path -LiteralPath $hb)) { New-Item -Path $hb -Force | Out-Null }
                    Set-ItemProperty -Path $hb -Name HiberbootEnabled -Value 0 -Type DWord -ErrorAction Stop
                    Log 'Boxlight: shutdown button configured and Fast Startup disabled.'
                }
                'SMART' {
                    Invoke-RequiredPowerCfg -PowerArguments @('/setacvalueindex','SCHEME_CURRENT','SUB_BUTTONS','PBUTTONACTION','3') -Description 'SMART AC power-button shutdown setting'
                    Invoke-RequiredPowerCfg -PowerArguments @('/setdcvalueindex','SCHEME_CURRENT','SUB_BUTTONS','PBUTTONACTION','3') -Description 'SMART DC power-button shutdown setting'
                    Invoke-RequiredPowerCfg -PowerArguments @('/setactive','SCHEME_CURRENT') -Description 'Reactivate current power scheme'
                    Log 'SMART: shutdown button configured.'
                }
                'Promethean' { Log 'Promethean: power configuration skipped by design.' }
                default { Log "Unknown manufacturer '$($s.Manufacturer)' - power configuration skipped." 'WARN' }
            }

            Status 'Pausing Windows Update...'
            $wuPause = Invoke-WUPauseWithTimeout -TimeoutSeconds ([int]$s.WUPauseTimeoutSeconds)
            $s.WUPauseResult = $wuPause
            Log "Windows Update pause: $($wuPause.Status) ($($wuPause.DurationSeconds)s)$(if ($wuPause.Error) { " - $($wuPause.Error)" })"
            if ($wuPause.Status -notin @('Success','Already Paused')) {
                # ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§19: NEVER continue Phase A when the WU safety state is unconfirmed. This throw
                # routes into the Phase A failure path: tasks removed, WU restored, and the tech
                # gets Retry Phase A (the retry re-checks and reports Already Paused) / Return to
                # Menu / Report an Issue.
                throw ("WINDOWS UPDATE PAUSE $($wuPause.Status.ToUpper()): PanelApp could not confirm that " +
                       "Windows Update was safely paused. The device has NOT continued into the next " +
                       "provisioning step. Retry Phase A (the retry first checks whether the pause " +
                       "already took), or Report an Issue.")
            }

            # v5.3 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§11: only NOW mark Phase A complete in the state file. Phase B refuses to run
            # unless PhaseAStatus = Complete. If this write FAILS, the reboot button must not
            # appear - rebooting would strand the device (review fix #1).
            $phaseAMarked = $false
            try {
                $sf = "$($s.ProvisioningDir)\state.json"
                if (Test-Path $sf) {
                    $st = Get-Content $sf -Raw | ConvertFrom-Json
                    $st | Add-Member -NotePropertyName PhaseAStatus    -NotePropertyValue 'Complete' -Force
                    $st | Add-Member -NotePropertyName PhaseACompletedAt -NotePropertyValue (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') -Force
                if ($s.WUPauseResult) {
                    $st | Add-Member -NotePropertyName WindowsUpdatePauseStatus          -NotePropertyValue "$($s.WUPauseResult.Status)" -Force
                    $st | Add-Member -NotePropertyName WindowsUpdatePauseStartedAt       -NotePropertyValue "$($s.WUPauseResult.StartedAt)" -Force
                    $st | Add-Member -NotePropertyName WindowsUpdatePauseCompletedAt     -NotePropertyValue "$($s.WUPauseResult.CompletedAt)" -Force
                    $st | Add-Member -NotePropertyName WindowsUpdatePauseDurationSeconds -NotePropertyValue $s.WUPauseResult.DurationSeconds -Force
                }
                    $st | ConvertTo-Json | Set-Content -Path $sf -Encoding UTF8
                    $phaseAMarked = $true
                    Log 'State file updated: PhaseAStatus = Complete.'
                }
            } catch { Log "Could not update PhaseAStatus: $_" 'ERROR' }
            if (-not $phaseAMarked) { throw 'PhaseAStatus could not be set to Complete - do not reboot; Phase B would be blocked.' }

            # No Sheets log here - Phase B will write the single combined row after domain join
            Log 'Phase A provisioning complete. Phase B will write the Sheets log entry.'

            Done 'Phase A complete - reboot to continue' $true
        } catch {
            $phaseAErr = $_
            Log ("Phase A error [{0}]: {1}`nStack: {2}" -f $phaseAErr.Exception.GetType().FullName,$phaseAErr.Exception.Message,$phaseAErr.ScriptStackTrace) 'ERROR'
            # v5.3 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§11.3: Phase A failed -> record it, remove the pending Phase B task, and do not
            # continue into Phase B or recovery. schtasks.exe is reliable from a background runspace.
            try {
                $sf = "$($s.ProvisioningDir)\state.json"
                if (Test-Path $sf) {
                    $st = Get-Content $sf -Raw | ConvertFrom-Json
                    $st | Add-Member -NotePropertyName PhaseAStatus -NotePropertyValue 'Failed' -Force
                    $st | Add-Member -NotePropertyName PhaseAFailedAt -NotePropertyValue (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') -Force
                    $st | Add-Member -NotePropertyName PhaseAError -NotePropertyValue "$_" -Force
                    $st | ConvertTo-Json | Set-Content -Path $sf -Encoding UTF8
                }
            } catch {}
            # Immediate cleanup (review fix #1): remove continuation + recovery tasks and restore
            # Windows Update NOW - never rely on the 8-hour recovery task after a failure.
            & schtasks.exe /delete /tn 'APSPanelPhaseB' /f 2>&1 | Out-Null
            & schtasks.exe /delete /tn 'APSPanelWURecovery' /f 2>&1 | Out-Null
            Set-Service  wuauserv -StartupType Automatic -ErrorAction SilentlyContinue
            Start-Service wuauserv -ErrorAction SilentlyContinue
            $wup = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU'
            if (Test-Path $wup) { Remove-ItemProperty $wup -Name NoAutoUpdate -ErrorAction SilentlyContinue }
            # v5.4 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§29: VERIFY the cleanup and show it to the tech so they know what state the
            # device is in and whether a retry is safe.
            $pbGone   = -not (Get-ScheduledTask -TaskName 'APSPanelPhaseB' -ErrorAction SilentlyContinue)
            $wuTGone  = -not (Get-ScheduledTask -TaskName 'APSPanelWURecovery' -ErrorAction SilentlyContinue)
            $wuSvcNow = Get-Service wuauserv -ErrorAction SilentlyContinue
            $wuPolNow = (Get-ItemProperty $wup -Name NoAutoUpdate -ErrorAction SilentlyContinue).NoAutoUpdate
            $wuOk     = ($wuSvcNow -and $wuSvcNow.StartType -ne 'Disabled' -and -not $wuPolNow)
            $renamed  = ($env:COMPUTERNAME -ieq "$($s.Hostname)")
            $renamePending = -not $renamed
            $cleanupState =
                "Reason        : $_`n" +
                "Phase B task  : $(if ($pbGone)  { 'removed' } else { 'STILL PRESENT - remove before rebooting' })`n" +
                "WU recovery   : $(if ($wuTGone) { 'removed' } else { 'STILL PRESENT' })`n" +
                "Windows Update: $(if ($wuOk)    { 'restored' } else { 'NOT restored - check wuauserv / NoAutoUpdate' })`n" +
                "Rename        : $(if ($renamed) { "applied ($env:COMPUTERNAME)" } else { "pending - reboot applies $($s.Hostname)" })`n" +
                "Next          : $(if ($pbGone -and $wuOk) { if ($renamePending) { 'reboot to apply the rename, then relaunch and retry Phase A' } else { 'Retry Phase A on this device' } } else { 'resolve the items above before retrying' })"
            Log 'Phase A failure cleanup: tasks removed, Windows Update restored (verified).'
            Post-Log @{ Mode=$s.ModeLabel; RunId=$s.RunId; PanelSerial=$s.PanelSerial; OPSSerial=$s.OPSSerial
                        Hostname=$s.Hostname; SchoolCode=$s.School; Room=$s.Room; RoomType=$s.RoomType; OtherRoomType=$s.OtherRoomType
                        PhaseAStatus='Failed'; Result='Failed - Phase A'; ProvisioningOutcome="Phase A error: $_" } 'PhaseAFailed'
            if ($s.RelatedSummerRunId) {
                Post-Log @{ LogSheet='Summer2026'; ProjectRunId=$s.RelatedSummerRunId
                            ProjectStatus='Failed - Phase A'; PhaseAStatus='Failed'; PhaseAError="$_"
                            WindowsUpdatePauseStatus=$(if ($s.WUPauseResult) { "$($s.WUPauseResult.Status)" } else { '' })
                            WindowsUpdatePauseStartedAt=$(if ($s.WUPauseResult) { "$($s.WUPauseResult.StartedAt)" } else { '' })
                            WindowsUpdatePauseCompletedAt=$(if ($s.WUPauseResult) { "$($s.WUPauseResult.CompletedAt)" } else { '' })
                            WindowsUpdatePauseDurationSeconds=$(if ($s.WUPauseResult) { $s.WUPauseResult.DurationSeconds } else { '' })
                            WindowsUpdatePauseError=$(if ($s.WUPauseResult) { "$($s.WUPauseResult.Error)" } else { '' })
                            PhaseBTaskRemoved=$(if ($pbGone) {'TRUE'} else {'FALSE'})
                            WURecoveryTaskStatus=$(if ($wuTGone) {'Removed'} else {'Failed to Remove'})
                            WindowsUpdateRestored=$(if ($wuOk) {'TRUE'} else {'FALSE'})
                            LastUpdatedBy=$s.TechName; LastUpdatedAt=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') } 'PhaseAFailed'
            }
            Fail "$_" $cleanupState
        }
    }
}

# ================================================================
#  EXECUTE RENAME & LOG  (Modes 3, 4, Mode 5 No)
# ================================================================
function Execute-RenameAndLog {
    $hdr = switch ($script:CurrentMode) {
        2 { 'RMA / Warranty Replacement' }
        3 { 'OPS Module Move' }
        4 { 'Panel Relocation' }
        5 { 'Warranty Replacement (Rebuild)' }
        default { 'Rename and Log' }
    }
    Reset-ProgressScreen $hdr
    $sync = [hashtable]::Synchronized(@{
        UI           = $script:UI
        LogFile      = $script:LogFile
        TechName     = $script:TechName
        Hostname     = $script:Hostname
        OldHostname  = $env:COMPUTERNAME
        School       = $script:SchoolCode
        SchoolName   = $script:SchoolName
        Room         = $script:RoomNumber
        RoomType     = $script:RoomType
        OtherRoomType = $script:OtherRoomType
        MountType    = $script:MountType
        Manufacturer = $script:Manufacturer
        PanelModel   = $script:PanelModel
        StorageGB    = $script:StorageGB
        PanelSerial  = $script:PanelSerial
        OPSSerial    = $script:OPSSerial
        OldOPS       = $script:OldOPSSerial
        RMAAction    = $script:RMAAction
        RMAPreviousPanelSerial = $script:RMAPreviousPanelSerial
        RMAReassignmentConfirmed = $script:RMAReassignmentConfirmed
        InventoryReassignmentConfirmed = $script:InventoryReassignmentConfirmed
        InventoryReassignmentType = $script:InventoryReassignmentType
        InventoryReassignmentReason = $script:InventoryReassignmentReason
        InventoryPreviousPanelSerial = $script:InventoryPreviousPanelSerial
        TemporaryAssignment = $script:TemporaryAssignment
        FollowUpRequired = $script:FollowUpRequired
        TestingObservationOnly = $script:TestingObservationOnly
        M3Disp       = $script:M3OldOPSDisposition
        ModeLabel    = $script:ModeLabel
        AppScriptUrl = $script:Config.AppScriptUrl
        ScriptDir    = $script:ScriptDir
        ErrorLog     = $script:ErrorLog
        RunFlags     = $script:RunFlags
        UsbRoot      = $script:UsbRoot
        RunId        = $script:RunId
        ProvisioningDir = $script:ProvisioningDir
    })
    Start-ProvisionJob -Sync $sync -Work {
        try {
            Status "Renaming computer to $($s.Hostname)..."
            Rename-Computer -NewName $s.Hostname -Force -ErrorAction Stop
            Log "Renamed $($s.OldHostname) -> $($s.Hostname)"

            Status 'Logging to Google Sheets...'
            $notes = if ($s.M3Disp) { "OPS Disposition: $($s.M3Disp)" } else { '' }
            $logRes = Post-Log @{
                Mode         = $s.ModeLabel
                SchoolCode   = $s.School
                Room         = $s.Room
                RoomType     = $s.RoomType
                OtherRoomType = $s.OtherRoomType
                MountType    = $s.MountType
                PanelSerial  = $s.PanelSerial
                OPSSerial    = $s.OPSSerial
                OldOPSSerial = $s.OldOPS
                OldPanelSerial = $(if ($s.InventoryPreviousPanelSerial) { $s.InventoryPreviousPanelSerial } else { $s.RMAPreviousPanelSerial })
                PreviousPanelSerial = $(if ($s.InventoryPreviousPanelSerial) { $s.InventoryPreviousPanelSerial } else { $s.RMAPreviousPanelSerial })
                RMAAction = $s.RMAAction
                InventoryReassignmentConfirmed = $(if ($s.InventoryReassignmentConfirmed -or $s.RMAReassignmentConfirmed) { 'TRUE' } else { 'FALSE' })
                InventoryReassignmentType = $(if ($s.InventoryReassignmentType) { $s.InventoryReassignmentType } elseif ($s.RMAAction) { 'RMAReplacement' } else { '' })
                InventoryReassignmentReason = $(if ($s.InventoryReassignmentReason) { $s.InventoryReassignmentReason } elseif ($s.RMAReassignmentConfirmed) { 'Confirmed physical RMA/warranty panel replacement reusing the OPS' } else { '' })
                TemporaryAssignment = $(if ($s.TemporaryAssignment) { 'TRUE' } else { 'FALSE' })
                FollowUpRequired = $(if ($s.FollowUpRequired) { 'TRUE' } else { 'FALSE' })
                Hostname     = $s.Hostname
                OldHostname  = $s.OldHostname
                Manufacturer = $s.Manufacturer
                PanelModel   = $s.PanelModel
                StorageGB    = $s.StorageGB
                InstallType  = $(if ($s.RMAAction) { 'Warranty Replacement' } else { '' })
                Notes        = $notes
                Result       = 'Complete'
            } $(switch -Wildcard ("$($s.ModeLabel)") {
                  '*OPS Module Move*'                        { 'OPSReplacementCompleted' }
                  '*Warranty Replacement*'                   { 'WarrantyReplacementCompleted' }
                  '*Panel Relocation*'                       { 'PanelReplacementCompleted' }
                  default                                    { 'PanelReplacementCompleted' } })

            if (Stop-IfRejected $logRes "$($s.ModeLabel) log entry") { return }
            Done 'Complete - reboot for rename to take effect' $true
        } catch {
            Log "Error: $_" 'ERROR'
            Fail "$_"
        }
    }
}

# ================================================================
#  v5.6 OPS TESTING OBSERVATION - NO RENAME / NO CURRENT PAIRING CHANGE
# ================================================================
function Execute-OPSTestingObservation {
    Reset-ProgressScreen 'OPS Testing Observation'
    $sync = [hashtable]::Synchronized(@{
        UI=$script:UI; LogFile=$script:LogFile; TechName=$script:TechName; ModeLabel=$script:ModeLabel
        Hostname=$env:COMPUTERNAME; SchoolCode=$script:SchoolCode; SchoolName=$script:SchoolName
        Room=$script:RoomNumber; RoomType=$script:RoomType; OtherRoomType=$script:OtherRoomType; MountType=$script:MountType
        Manufacturer=$script:Manufacturer; PanelModel=$script:PanelModel; PanelSerial=$script:PanelSerial
        OPSSerial=$script:OPSSerial; OldOPS=$script:OldOPSSerial; StorageGB=$script:StorageGB
        PreviousPanel=$script:InventoryPreviousPanelSerial; MoveReason=$script:InventoryReassignmentReason
        AppScriptUrl=$script:Config.AppScriptUrl; ScriptDir=$script:ScriptDir; ErrorLog=$script:ErrorLog
        RunFlags=$script:RunFlags; UsbRoot=$script:UsbRoot; RunId=$script:RunId; ProvisioningDir=$script:ProvisioningDir
    })
    Start-ProvisionJob -Sync $sync -Work {
        try {
            Status 'Recording testing observation without changing authoritative inventory...'
            $res = Post-Log @{
                Mode=$s.ModeLabel; RunId=$s.RunId; SchoolCode=$s.SchoolCode; SchoolName=$s.SchoolName
                Room=$s.Room; RoomType=$s.RoomType; OtherRoomType=$s.OtherRoomType; MountType=$s.MountType
                Manufacturer=$s.Manufacturer; PanelModel=$s.PanelModel; PanelSerial=$s.PanelSerial; OPSSerial=$s.OPSSerial
                OldOPSSerial=$s.OldOPS; Hostname=$s.Hostname; StorageGB=$s.StorageGB
                PreviousPanelSerial=$s.PreviousPanel; OldPanelSerial=$s.PreviousPanel
                InventoryReassignmentConfirmed='FALSE'; InventoryReassignmentType='TestingOnly'
                InventoryReassignmentReason=$s.MoveReason; TemporaryAssignment='FALSE'; FollowUpRequired='FALSE'
                Notes='OPS inserted for testing/troubleshooting only. Current authoritative panel-to-OPS pairing was intentionally not changed.'
                Result='Complete - Testing Observation Only'
            } 'OPSTestingObservation'
            if (Stop-IfRejected $res 'OPS testing observation') { return }
            Done 'Testing observation recorded - current inventory pairing was not changed.'
        } catch { Log "OPS testing observation error: $_" 'ERROR'; Fail "$_" }
    }
}

# ================================================================
#  v5.6 UNIFIED RMA - INVENTORY ONLY
# ================================================================
function Execute-RMAInventoryOnly {
    Reset-ProgressScreen 'RMA Inventory Reconciliation'
    $sync = [hashtable]::Synchronized(@{
        UI=$script:UI; LogFile=$script:LogFile; TechName=$script:TechName; ModeLabel=$script:ModeLabel
        Hostname=$env:COMPUTERNAME; SchoolCode=$script:SchoolCode; SchoolName=$script:SchoolName
        Room=$script:RoomNumber; RoomType=$script:RoomType; OtherRoomType=$script:OtherRoomType
        MountType=$script:MountType; Manufacturer=$script:Manufacturer; PanelModel=$script:PanelModel
        PanelSerial=$script:PanelSerial; OPSSerial=$script:OPSSerial; StorageGB=$script:StorageGB
        RMAAction=$script:RMAAction; RMAPreviousPanelSerial=$script:RMAPreviousPanelSerial
        RMAReassignmentConfirmed=$script:RMAReassignmentConfirmed
        InventoryReassignmentConfirmed=$script:InventoryReassignmentConfirmed
        InventoryReassignmentType=$script:InventoryReassignmentType
        InventoryReassignmentReason=$script:InventoryReassignmentReason
        InventoryPreviousPanelSerial=$script:InventoryPreviousPanelSerial
        TemporaryAssignment=$script:TemporaryAssignment
        FollowUpRequired=$script:FollowUpRequired
        TestingObservationOnly=$script:TestingObservationOnly
        AppScriptUrl=$script:Config.AppScriptUrl; ScriptDir=$script:ScriptDir; ErrorLog=$script:ErrorLog
        RunFlags=$script:RunFlags; UsbRoot=$script:UsbRoot; RunId=$script:RunId; ProvisioningDir=$script:ProvisioningDir
    })
    Start-ProvisionJob -Sync $sync -Work {
        try {
            Status 'Reconciling RMA replacement with current inventory...'
            $res = Post-Log @{
                Mode=$s.ModeLabel; RunId=$s.RunId; SchoolCode=$s.SchoolCode; SchoolName=$s.SchoolName
                Room=$s.Room; RoomType=$s.RoomType; OtherRoomType=$s.OtherRoomType; MountType=$s.MountType
                Manufacturer=$s.Manufacturer; PanelModel=$s.PanelModel; PanelSerial=$s.PanelSerial; OPSSerial=$s.OPSSerial
                StorageGB=$s.StorageGB; Hostname=$s.Hostname; InstallType='Warranty Replacement'
                OldPanelSerial=$(if ($s.InventoryPreviousPanelSerial) { $s.InventoryPreviousPanelSerial } else { $s.RMAPreviousPanelSerial }); PreviousPanelSerial=$(if ($s.InventoryPreviousPanelSerial) { $s.InventoryPreviousPanelSerial } else { $s.RMAPreviousPanelSerial })
                RMAAction=$s.RMAAction
                InventoryReassignmentConfirmed=$(if ($s.InventoryReassignmentConfirmed -or $s.RMAReassignmentConfirmed) { 'TRUE' } else { 'FALSE' })
                InventoryReassignmentType=$(if ($s.InventoryReassignmentType) { $s.InventoryReassignmentType } else { 'RMAReplacement' })
                InventoryReassignmentReason=$(if ($s.InventoryReassignmentReason) { $s.InventoryReassignmentReason } else { 'RMA / warranty panel replacement' })
                TemporaryAssignment='FALSE'; FollowUpRequired='FALSE'
                Result='Complete - RMA Inventory Reconciled'
            } 'WarrantyReplacementCompleted'
            if (Stop-IfRejected $res 'RMA inventory reconciliation') { return }
            Done 'RMA inventory updated - no endpoint provisioning was required.'
        } catch { Log "RMA inventory reconciliation error: $_" 'ERROR'; Fail "$_" }
    }
}

# ================================================================
#  EXECUTE LOG ONLY  (legacy Mode 5 Yes)
# ================================================================
function Execute-LogOnly {
    Reset-ProgressScreen 'Logging Entry'
    $sync = [hashtable]::Synchronized(@{
        UI           = $script:UI
        LogFile      = $script:LogFile
        TechName     = $script:TechName
        ModeLabel    = $script:ModeLabel
        Hostname     = $env:COMPUTERNAME
        PanelSerial  = $script:PanelSerial
        OPSSerial    = $script:OPSSerial
        StorageGB    = $script:StorageGB
        PanelModel   = $script:PanelModel
        AppScriptUrl = $script:Config.AppScriptUrl
        ScriptDir    = $script:ScriptDir
        ErrorLog     = $script:ErrorLog
        RunFlags     = $script:RunFlags
        UsbRoot      = $script:UsbRoot
        RunId        = $script:RunId
        ProvisioningDir = $script:ProvisioningDir
    })
    Start-ProvisionJob -Sync $sync -Work {
        try {
            Status 'Sending log entry to Google Sheets...'
            $logRes = Post-Log @{
                Mode        = $s.ModeLabel
                PanelSerial = $s.PanelSerial
                OPSSerial   = $s.OPSSerial
                StorageGB   = $s.StorageGB
                PanelModel  = $s.PanelModel
                Hostname    = $s.Hostname
                Result      = 'Hostname Verified Correct - Log Only'
            } 'InventoryObserved'
            if (Stop-IfRejected $logRes 'Log-only entry') { return }
            Done 'Log entry complete.'
        } catch {
            Log "Error: $_" 'ERROR'
            Fail "$_"
        }
    }
}

# ================================================================
#  EXECUTE INVENTORY  (Mode 6 - log to InventoryLog sheet only)
# ================================================================
function Execute-Inventory {
    Reset-ProgressScreen 'General Inventory Capture'
    $sync = [hashtable]::Synchronized(@{
        UI           = $script:UI
        LogFile      = $script:LogFile
        TechName     = $script:TechName
        ModeLabel    = $script:ModeLabel
        SchoolCode   = $script:SchoolCode
        SchoolName   = $script:SchoolName
        Room         = $script:RoomNumber
        RoomType     = $script:RoomType
        OtherRoomType = $script:OtherRoomType
        MountType    = $script:MountType
        Manufacturer = $script:Manufacturer
        PanelModel   = $script:PanelModel
        PanelSerial  = $script:PanelSerial
        OPSSerial    = $script:OPSSerial
        StorageGB    = $script:StorageGB
        Hostname     = $script:Hostname
        AppScriptUrl = $script:Config.AppScriptUrl
        ScriptDir    = $script:ScriptDir
        ErrorLog     = $script:ErrorLog
        RunFlags     = $script:RunFlags
        UsbRoot      = $script:UsbRoot
        RunId        = $script:RunId
        ProvisioningDir = $script:ProvisioningDir
    })
    Start-ProvisionJob -Sync $sync -Work {
        try {
            Status 'Sending inventory entry to Google Sheets...'
            $invRes = Post-Log @{
                LogSheet     = 'InventoryLog'
                SchoolCode   = $s.SchoolCode
                Room         = $s.Room
                RoomType     = $s.RoomType
                OtherRoomType = $s.OtherRoomType
                MountType    = $s.MountType
                Manufacturer = $s.Manufacturer
                PanelModel   = $s.PanelModel
                PanelSerial  = $s.PanelSerial
                OPSSerial    = $s.OPSSerial
                StorageGB    = $s.StorageGB
                Hostname     = $s.Hostname
            } 'InventoryObserved'
            if (Stop-IfRejected $invRes 'Inventory entry') { return }
            Done 'Inventory entry logged.'
        } catch {
            Log "Error: $_" 'ERROR'
            Fail "$_"
        }
    }
}

# ================================================================
#  SUMMER 2026 DAY ONE READINESS (Mode 7) + project run id
# ================================================================
function New-PanelObservationId {
    return ('POBS-{0}-{1}-{2}' -f (Get-Date -Format 'yyyyMMdd'), (Get-Date -Format 'HHmmss'), ([guid]::NewGuid().ToString('N').Substring(0,8).ToUpperInvariant()))
}

function New-ProjectRunId {
    # SUM26-YYYYMMDD-HHMMSS-XXXXXXXXXXXXXXXX. Existing 8-character IDs remain valid;
    # new projects use a 16-hex GUID slice to make independent project collisions negligible.
    $g = [guid]::NewGuid().ToString('N').Substring(0,16).ToUpper()
    return "SUM26-$(Get-Date -Format 'yyyyMMdd')-$(Get-Date -Format 'HHmmss')-$g"
}

function Prepare-DayOneScreen {
    # The ProjectRunId must exist before the tech can submit an issue from this screen,
    # so the exception and the Summer assessment row share the same project linkage.
    if (-not $script:ProjectRunId) { $script:ProjectRunId = New-ProjectRunId }
    foreach ($c in @('chkDisplay','chkTouch','chkSound','chkCables','chkNetwork','chkNDMS')) {
        $script:UI[$c].IsChecked = $false
    }
    $script:UI['rdoNetEthernet'].IsChecked = $false
    $script:UI['rdoNetWifi'].IsChecked     = $false
    $script:UI['cboIssueCategory'].SelectedIndex = -1
    $script:UI['txtIssueNote'].Text         = ''
    $script:UI['borIssueForm'].Visibility   = 'Collapsed'
    $script:UI['lblDayOneError'].Visibility  = 'Collapsed'
}

# Reads the current checkbox + network-radio state into script vars.
function Read-DayOneState {
    $script:DayOne_Display = [bool]$script:UI['chkDisplay'].IsChecked
    $script:DayOne_Touch   = [bool]$script:UI['chkTouch'].IsChecked
    $script:DayOne_Sound   = [bool]$script:UI['chkSound'].IsChecked
    $script:DayOne_Cables  = [bool]$script:UI['chkCables'].IsChecked
    $script:DayOne_Network = [bool]$script:UI['chkNetwork'].IsChecked
    $script:DayOne_NDMS    = [bool]$script:UI['chkNDMS'].IsChecked
    $script:NetworkType = if ($script:UI['rdoNetEthernet'].IsChecked) { 'Ethernet' }
                          elseif ($script:UI['rdoNetWifi'].IsChecked) { 'Wi-Fi' }
                          else { '' }
}

# ================================================================
#  SUMMER 2026 INVENTORY (Mode 7)
#  Extended capture + reimage decision + summary + POST.
#  Heavy WMI/CIM calls run in the background runspace; the summary
#  screen is populated and shown from the final dispatcher invoke.
# ================================================================
# r14 ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§14: RecentInventoryWarningDays was reserved in config since v5.5-L; this implements it.
# Returns $true to proceed (AssessmentType/ReassessmentReason set as needed), $false to stop.
function Confirm-RecentAssessment {
    param([string]$PanelSerial)
    $script:AssessmentType       = 'Initial Assessment'
    $script:ReassessmentReason   = ''
    $script:PreviousProjectRunId = ''
    $days = 14
    try { if ($script:Config.RecentInventoryWarningDays) { $days = [int]$script:Config.RecentInventoryWarningDays } } catch {}
    if ($days -le 0) { return $true }
    if (-not $script:IsNetworkAvailable) { return $true }   # offline: cannot check, do not block
    $recent = $null
    try {
        $url = $script:Config.AppScriptUrl
        $sep = if ($url -match '\?') { '&' } else { '?' }
        $recent = Invoke-ResponsiveWebJson -Uri "$url${sep}action=recentAssessmentCheck&panelSerial=$([uri]::EscapeDataString($PanelSerial))&days=$days" -Method GET -TimeoutSeconds 8
    } catch { Write-Log "Recent-assessment check failed (continuing): $_" 'WARN'; return $true }
    if (-not $recent -or -not $recent.found) { return $true }
    # ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§28: four actions. A still-open project is offered for RESUME (the authoritative path);
    # a completed one can only be reassessed, corrected, or cancelled.
    $resumable = ($recent.projectStatus -and $recent.projectStatus -notmatch 'Complete|Closed|Superseded|Abandoned')
    $prompt = "RECENT PANEL RECORD FOUND`n`n" +
        "This panel was assessed $($recent.daysAgo) day(s) ago by $($recent.techName).`n`n" +
        "School: $($recent.schoolCode)    Room: $($recent.room)`n" +
        "Project Status: $($recent.projectStatus)`n" +
        "ProjectRunId: $($recent.projectRunId)`n`n"
    $prompt += if ($resumable) {
        "That project is still OPEN.`n`nYes = RESUME the existing project (recommended).`n" +
        "No = review or correct the existing records in Inventory Lookup.`n" +
        "Cancel = stop and return to the menu."
    } else {
        "Yes = continue as a NEW REASSESSMENT of this panel (you will give a reason).`n" +
        "No = review or correct the existing records in Inventory Lookup.`n" +
        "Cancel = stop and return to the menu."
    }
    $r = [System.Windows.MessageBox]::Show($prompt, 'Recent Panel Record Found', 'YesNoCancel', 'Warning')
    if ($r -eq 'Yes' -and $resumable) {
        # Resume Existing Project: hand off to the authoritative continuation logic.
        Write-Log "Resuming existing project $($recent.projectRunId) from the recent-record warning."
        $found = @(Find-SummerContinuation -PanelSerial $PanelSerial)
        if ($found.Count -eq 1)     { Route-SummerContinuation $found[0] }
        elseif ($found.Count -gt 1) { $script:SummerMatches = $found; Show-MultiActiveBlock $found }
        else {
            [System.Windows.MessageBox]::Show(
                "That project could not be reopened from here (it is no longer returned as active).`n`nUse Inventory Lookup to review it, or start a reassessment.",
                'Cannot Resume', 'OK', 'Warning') | Out-Null
            Show-Screen 'pnlModeSelect'
        }
        return $false
    }
    if ($r -eq 'Yes') {
        Add-Type -AssemblyName Microsoft.VisualBasic -ErrorAction SilentlyContinue
        $reason = ''
        try {
            $reason = [Microsoft.VisualBasic.Interaction]::InputBox(
                "Why is this panel being reassessed $($recent.daysAgo) day(s) after the last assessment?`n`n(Required - this links the new project to $($recent.projectRunId) instead of looking like a duplicate.)",
                'Reassessment Reason', '')
        } catch {}
        if (-not "$reason".Trim()) {
            [System.Windows.MessageBox]::Show('A reason is required to continue a reassessment.','Reason Required','OK','Warning') | Out-Null
            return $false
        }
        $script:AssessmentType       = 'Reassessment'
        $script:ReassessmentReason   = "$reason".Trim()
        $script:PreviousProjectRunId = "$($recent.projectRunId)"
        Write-Log "Reassessment confirmed (prev=$($recent.projectRunId)): $($script:ReassessmentReason)"
        return $true
    }
    if ($r -eq 'No') { Show-Screen 'pnlInvLookup'; Set-Status 'Review the existing records, then restart the assessment if needed.' }
    else { Show-Screen 'pnlModeSelect'; Set-Status 'Assessment cancelled.' }
    return $false
}

function Confirm-SummerProjectStart {
    param([string]$PanelSerial)
    $script:AssessmentType       = 'Initial Assessment'
    $script:ReassessmentReason   = ''
    $script:PreviousProjectRunId = ''

    $cycle = "$($script:InventoryCycleId)".Trim()
    if (-not $script:SummerOfficialRebaselineEnabled -or -not $cycle) {
        return (Confirm-RecentAssessment -PanelSerial $PanelSerial)
    }
    # Offline work is still allowed. The backend carries the same cycle id and will link/supersede
    # pre-project active rows when the queued assessment eventually applies. A duplicate within the
    # current cycle is permanently rejected rather than guessed.
    if (-not $script:IsNetworkAvailable) {
        Write-Log "Official Interactive Inventory cycle check skipped offline; backend will reconcile cycle '$cycle' on replay." 'WARN'
        return $true
    }
    $check = $null
    try {
        $url = $script:Config.AppScriptUrl
        $sep = if ($url -match '\?') { '&' } else { '?' }
        $check = Invoke-ResponsiveWebJson -Uri "$url${sep}action=summerBaselineCheck&panelSerial=$([uri]::EscapeDataString($PanelSerial))&cycleId=$([uri]::EscapeDataString($cycle))" -Method GET -TimeoutSeconds 8
    } catch {
        Write-Log "Official Interactive Inventory baseline check failed; falling back to recent-record protection: $_" 'WARN'
        return (Confirm-RecentAssessment -PanelSerial $PanelSerial)
    }
    if (-not $check) { return (Confirm-RecentAssessment -PanelSerial $PanelSerial) }

    if ($check.currentCycleFound) {
        $rec = if ($check.currentCycleActiveRecord) { $check.currentCycleActiveRecord } else { $check.currentCycleRecord }
        if ($check.currentCycleActive -and $rec) {
            [System.Windows.MessageBox]::Show(
                "This panel already has an OPEN project in the official Interactive Inventory Project cycle.`n`nProject: $($rec.ProjectRunId)`nStatus: $($rec.ProjectStatus)`nSchool/Room: $($rec.SchoolCode) $($rec.Room)`n`nPanelApp will continue that project instead of creating another baseline row.",
                'Official Interactive Inventory Project Found', 'OK', 'Information') | Out-Null
            $script:SummerMatches = @($rec)
            Route-SummerContinuation $rec
            return $false
        }
        $r = [System.Windows.MessageBox]::Show(
            "This panel has ALREADY been completed/recorded in the official Interactive Inventory Project cycle.`n`nProject: $($rec.ProjectRunId)`nStatus: $($rec.ProjectStatus)`nSchool/Room: $($rec.SchoolCode) $($rec.Room)`n`nYes = perform a documented reassessment.`nNo = open Correct Inventory Record.`nCancel = stop.",
            'Official Interactive Inventory Record Already Exists', 'YesNoCancel', 'Warning')
        if ($r -eq 'No') { Show-InventoryLookup; return $false }
        if ($r -ne 'Yes') { Show-Screen 'pnlModeSelect'; return $false }
        Add-Type -AssemblyName Microsoft.VisualBasic -ErrorAction SilentlyContinue
        $reason = ''
        try { $reason = [Microsoft.VisualBasic.Interaction]::InputBox('Why is this official Interactive Inventory record being reassessed? (Required)', 'Reassessment Reason', '') } catch {}
        if (-not "$reason".Trim()) {
            [System.Windows.MessageBox]::Show('A reason is required to create another assessment in the same official cycle.','Reason Required','OK','Warning') | Out-Null
            return $false
        }
        $script:AssessmentType       = 'Reassessment'
        $script:ReassessmentReason   = "$reason".Trim()
        $script:PreviousProjectRunId = "$($rec.ProjectRunId)"
        return $true
    }

    if ($check.priorFound -and $check.priorRecord) {
        $prior = $check.priorRecord
        $script:AssessmentType       = 'Official Inventory Reassessment'
        $script:ReassessmentReason   = 'Official Interactive Inventory Project rebaseline'
        $script:PreviousProjectRunId = "$($prior.ProjectRunId)"
        [System.Windows.MessageBox]::Show(
            "PRE-PROJECT SUMMER RECORD FOUND`n`nThis device was previously captured before the official inventory project began.`n`nPrevious project: $($prior.ProjectRunId)`nPrevious status: $($prior.ProjectStatus)`nPrevious location: $($prior.SchoolCode) $($prior.Room)`n`nPanelApp will create a NEW official baseline record, link it to the previous project, preserve the old history, and let current inventory reflect what the technician physically observes today.",
            'Official Inventory Rebaseline', 'OK', 'Information') | Out-Null
        return $true
    }
    return $true
}

function Start-SummerCapture {
    # The tech entered school / manufacturer / model / mount / room on the Location
    # screen; those drive the inventory. The current hostname is recorded for
    # reference only - it is unreliable and is NOT used to derive any field.
    $hostname = $env:COMPUTERNAME
    # v5.5.1a ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§1: the AS-FOUND name has to be captured HERE, while it is still the factory
    # DESKTOP-* name. Reading it later (Phase B) is too late: by then $script:Hostname holds the
    # APS target name from state.json, which after the rename reboot equals $env:COMPUTERNAME -
    # so "assessment" and "provisioned" would both record the APS name and the before/after
    # PAIR needs would be lost.
    if (-not $script:AssessmentHostname) { $script:AssessmentHostname = $hostname }
    if (-not $script:ProjectRunId) { $script:ProjectRunId = New-ProjectRunId }
    Write-Log "Interactive Inventory capture: RunId=$($script:ProjectRunId) School=$($script:SchoolCode) Mount=$($script:MountType) Room=$($script:RoomNumber) DayOne=$($script:DayOneStatus)"

    Reset-ProgressScreen 'Interactive Inventory Project'
    $sync = [hashtable]::Synchronized(@{
        UI            = $script:UI
        LogFile       = $script:LogFile
        ErrorLog      = $script:ErrorLog
        RunFlags      = $script:RunFlags
        TechName      = $script:TechName
        ScriptVersion = $script:ScriptVersion
        AppScriptUrl  = $script:Config.AppScriptUrl
        ScriptDir     = $script:ScriptDir
        UsbRoot       = $script:UsbRoot
        RunId         = $script:RunId
        ProvisioningDir = $script:ProvisioningDir
        Hostname      = $hostname
        OPSSerial     = $script:OPSSerial
        PanelSerial   = $script:PanelSerial
        PanelSerialStickerStatus      = $script:PanelSerialStickerStatus
        PanelSerialSource             = $script:PanelSerialSource
        PanelSerialVerificationStatus = $script:PanelSerialVerificationStatus
        PanelObservationId            = $script:PanelObservationId
        IdentityResolutionRequired    = $script:IdentityResolutionRequired
        PanelIdentityResolutionStatus = $script:PanelIdentityResolutionStatus
        IIQAssetTag                   = $script:IIQAssetTag
        NDMSName                      = $script:NDMSName
        NDMSDeviceId                  = $script:NDMSDeviceId
        NDMSTags                      = $script:NDMSTags
        OPSClass      = (Get-CurrentOPSClass)
        OPSSerial_BIOS      = $script:OPSSerial_BIOS
        OPSSerial_Product   = $script:OPSSerial_Product
        OPSSerial_BaseBoard = $script:OPSSerial_BaseBoard
        OPSSerial_Registry  = $script:OPSSerial_Registry
        SelectedOPSSerialSource     = $script:SelectedOPSSerialSource
        SelectedOPSSerialConfidence = $script:SelectedOPSSerialConfidence
        OPSSerialValidationStatus   = $script:OPSSerialValidationStatus
        OPSSerialValidationNote     = $script:OPSSerialValidationNote
        SchoolCode    = $script:SchoolCode
        SchoolName    = $script:SchoolName
        MfrCode       = $script:MfrCode
        Manufacturer  = $script:Manufacturer
        PanelModel    = $script:PanelModel
        MountType     = $script:MountType
        Room          = $script:RoomNumber
        # ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§3: the technician's ORIGINAL text. Without this the sender synthesizes RawRoom from the
        # already-normalized Room and the sheet records "B129" as if that is what was typed.
        RawRoom       = $script:RawRoomEntry
        RoomType      = $script:RoomType
        OtherRoomType = $script:OtherRoomType
        # Day One readiness + project lifecycle (v5.2)
        ProjectRunId    = $script:ProjectRunId
        AssessmentType       = $script:AssessmentType
        ReassessmentReason   = $script:ReassessmentReason
        PreviousProjectRunId = $script:PreviousProjectRunId
        InventoryCycleId     = $script:InventoryCycleId
        AssessmentHostname   = $script:AssessmentHostname
        DayOneStatus    = $script:DayOneStatus
        DayOne_Display  = $script:DayOne_Display
        DayOne_Touch    = $script:DayOne_Touch
        DayOne_Sound    = $script:DayOne_Sound
        DayOne_Cables   = $script:DayOne_Cables
        DayOne_Network  = $script:DayOne_Network
        DayOne_NDMS     = $script:DayOne_NDMS
        NetworkType     = $script:NetworkType
        IssueCategory   = $script:ReadinessIssueCategory
        IssueNote       = $script:ReadinessIssueNote
        # Config-driven reimage profiles (v5.2)
        ReimageProfiles = $script:Config.ReimageProfiles
        ClientSessionId = $script:ClientSessionId; ClientDeviceName = $script:ClientDeviceName
        EventSequence = $script:EventSequence
        ProjectStateRevision = $script:ProjectStateRevision; ProjectStateRevisionFor = $script:ProjectStateRevisionFor
        MinAcceptedVer   = $script:Config.MinimumAcceptedOSDisplayVersion
        PreferredVer     = $script:Config.PreferredOSDisplayVersion
    })
    Start-ProvisionJob -Sync $sync -Work {
        try {
            Status 'Collecting device information...'
            $hostname    = $s.Hostname
            $opsSerial   = $s.OPSSerial
            $panelSerial = $s.PanelSerial

            # --- Storage (OS disk) ---
            Status 'Reading storage...'
            $diskSize = 0; $partStyle = ''
            try {
                $sysLetter = $env:SystemDrive.TrimEnd(':')
                $osDisk = Get-Partition -DriveLetter $sysLetter -ErrorAction Stop | Get-Disk -ErrorAction Stop
            } catch {
                # Fallback: largest non-removable disk (exclude USB external drives)
                $osDisk = Get-Disk -ErrorAction SilentlyContinue |
                          Where-Object { $_.BusType -ne 'USB' } |
                          Sort-Object Size -Descending | Select-Object -First 1
            }
            if ($osDisk) { $diskSize = [double]$osDisk.Size; $partStyle = "$($osDisk.PartitionStyle)" }
            $gb = if ($diskSize -gt 0) { [math]::Round($diskSize / 1GB, 0) } else { 0 }
            # Match the reported size to an approved profile range from config (no guessing -
            # unrecognized sizes fall through to Manual Review instead of defaulting to 128GB).
            $matchedProfile = $null
            foreach ($p in $s.ReimageProfiles) {
                if ($gb -ge [int]$p.MinGB -and $gb -le [int]$p.MaxGB) { $matchedProfile = $p; break }
            }
            $tierNum = if ($matchedProfile) { [int]$matchedProfile.StorageTier } else { 0 }
            $storageDisplay = if ($tierNum -gt 0) { "$tierNum GB" } else { "$gb GB (unrecognized)" }
            Log "Disk ${gb}GB -> profile $(if($matchedProfile){$matchedProfile.ProfileId}else{'NONE (manual review)'}) (partition $partStyle)"

            # --- OS (build number is the only reliable Win10/11 signal) ---
            Status 'Reading OS version...'
            $build = 0; $displayVer = ''; $edition = ''; $productName = ''
            try {
                $cv = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -ErrorAction Stop
                $build      = [int]$cv.CurrentBuild
                $displayVer = if ($cv.DisplayVersion) { $cv.DisplayVersion } else { $cv.ReleaseId }
                $edition    = "$($cv.EditionID)"
                $productName = "$($cv.ProductName)"
            } catch { Log "OS registry read failed: $_" 'WARN' }
            # v5.4 (defect #5/#6): call the SHARED image matrix - identical logic to the final
            # recommendation, including the pending-restart check and manufacturer branching.
            $isWin11 = ($build -ge 22000)
            $osShort = "Windows $(if ($isWin11) { '11' } elseif ($build -gt 0) { '10' } else { '?' }) ($displayVer)"
            $firmwareMode = ''
            try { $firmwareMode = "$((Get-ComputerInfo -Property BiosFirmwareType -ErrorAction Stop).BiosFirmwareType)" } catch {}
            $pendingA = Test-PendingRestart
            # v5.4.1 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§1.C: advisory signals are logged for support visibility, never used to block.
            if ($pendingA.AdvisoryDetected -and -not $pendingA.Pending) {
                Log "Pending-restart advisory detected but provisioning was not blocked: $($pendingA.AdvisoryReasons)" 'WARN'
            }
            if ($pendingA.Pending) { Log "Confirmed pending restart: $($pendingA.Reasons)" 'WARN' }
            $minVer  = if ($s.MinAcceptedVer) { "$($s.MinAcceptedVer)" } else { '24H2' }
            $prefVer = if ($s.PreferredVer)   { "$($s.PreferredVer)"   } else { '25H2' }
            $imgA = Get-ImageDecision -Build $build -DisplayVer $displayVer -Manufacturer $s.Manufacturer -OPSClass $s.OPSClass `
                        -PartitionStyle $partStyle -FirmwareMode $firmwareMode -StorageGB $gb `
                        -Profiles $s.ReimageProfiles -MinVer $minVer -PrefVer $prefVer `
                        -PendingRestart ([bool]$pendingA.Pending) -PendingReasons "$($pendingA.Reasons)"
            Log "OS: $osShort (build $build, edition $edition; min $minVer, preferred $prefVer) -> $($imgA.ImageStatus)"

            $imageProfile = "$($imgA.Profile)"; $imageFolder = "$($imgA.Folder)"; $redoFile = ''
            if ($imgA.RedoRescueRequired -and $matchedProfile) { $redoFile = "$($matchedProfile.RedoImageFile)" }
            $decision = $imgA.ImageDecisionReason
            switch ("$($imgA.ImageStatus)") {
                'Accepted'                       { $decisionClass = 'NoReimage';      $reimage = 'No' }
                'Windows Upgrade Required'       { $decisionClass = 'WindowsUpgrade'; $reimage = 'No' }
                'Firmware Configuration Required'{ $decisionClass = 'FirmwareConfig'; $reimage = 'No' }
                'Pending Windows Update Restart' { $decisionClass = 'PendingRestart'; $reimage = 'No' }
                'Recovery Required'              { $decisionClass = 'Reimage';        $reimage = 'Yes' }
                default                          { $decisionClass = 'ManualReview';   $reimage = 'Review' }
            }
            Log "Image decision: $($imgA.ImageStatus) - $decision (profile=$imageProfile)"
            if ([bool]$s.IdentityResolutionRequired) {
                # Preserve the real image/OPS telemetry above, but do not instruct remediation against
                # an unidentified physical panel. The observation is valid; the canonical identity is pending.
                $decisionClass = 'ManualReview'
                $reimage = 'Review'
                $decision = "Panel serial identity requires reconciliation before remediation/provisioning. Observation: $($s.PanelObservationId)."
                Log "Panel identity unresolved - forcing Manual Review for observation $($s.PanelObservationId)." 'WARN'
            }

            # --- Project status follows the required device workflow. A readiness problem is
            # tracked independently through DayOneStatus/ExceptionStatus and does not hide the
            # Windows, firmware, recovery, or provisioning action that must be completed today. ---
            if ($decisionClass -eq 'ManualReview') {
                $projectStatus = 'Manual Review Required'
            } elseif ($decisionClass -eq 'WindowsUpgrade') {
                $projectStatus = 'Windows Upgrade Required'
            } elseif ($decisionClass -eq 'FirmwareConfig') {
                $projectStatus = 'Firmware Configuration Required'
            } elseif ($decisionClass -eq 'PendingRestart') {
                $projectStatus = 'Pending Windows Update Restart'
            } elseif ($decisionClass -eq 'Reimage') {
                $projectStatus = 'Pending RedoRescue Restore'
            } else {
                # Review #6: image is approved, but the final path (Finish / Full Provisioning /
                # Post-RedoRescue) is not decided until the tech confirms on the recommendation
                # screen. Keep the project ACTIVE (resumable) until then; the final action sets the
                # terminal status. Prevents an interrupted new panel from being "lost".
                $projectStatus = 'Assessment Complete - Recommendation Pending'
            }
            Log "Project status: $projectStatus"

            # --- Hardware / firmware (sheet-only, not shown to tech) ---
            Status 'Reading hardware details...'
            $cs=$null; $bb=$null; $bios=$null; $cpu=$null
            try { $cs   = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop } catch {}
            try { $bb   = Get-CimInstance Win32_BaseBoard -ErrorAction Stop } catch {}
            try { $bios = Get-CimInstance Win32_BIOS -ErrorAction Stop } catch {}
            try { $cpu  = Get-CimInstance Win32_Processor -ErrorAction Stop | Select-Object -First 1 } catch {}
            $model       = if ($cs) { "$($cs.Model)" } else { '' }
            $mfrWmi      = if ($cs) { "$($cs.Manufacturer)" } else { '' }
            # v5.3.2 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§4: record domain membership at assessment time (device-state evidence)
            $partOfDomain   = if ($cs) { $cs.PartOfDomain } else { $null }
            $domainStatus   = if ($partOfDomain -eq $true) { 'Domain Joined' } elseif ($partOfDomain -eq $false) { 'Not Domain Joined' } else { 'Unknown' }
            $detectedDomain = if ($cs) { "$($cs.Domain)" } else { '' }
            Log "Domain membership at assessment: $domainStatus ($detectedDomain)"
            $board       = if ($bb) { "$($bb.Product)" } else { '' }
            $ramGB       = if ($cs -and $cs.TotalPhysicalMemory) { [math]::Round($cs.TotalPhysicalMemory / 1GB, 0) } else { 0 }
            $cpuName     = if ($cpu) { "$($cpu.Name)".Trim() } else { '' }
            $biosVendor  = if ($bios) { "$($bios.Manufacturer)" } else { '' }
            $biosVersion = if ($bios) { "$($bios.SMBIOSBIOSVersion)" } else { '' }
            $biosDate    = ''
            if ($bios -and $bios.ReleaseDate) {
                try { $biosDate = ([Management.ManagementDateTimeConverter]::ToDateTime($bios.ReleaseDate)).ToString('yyyy-MM-dd') }
                catch { try { $biosDate = $bios.ReleaseDate.ToString('yyyy-MM-dd') } catch {} }
            }

            # Firmware mode ($firmwareMode) was read above the reimage decision (review #5).

            # TPM present + spec version
            $tpmPresent = ''; $tpmSpec = ''
            try { $tpm = Get-Tpm -ErrorAction Stop; $tpmPresent = "$($tpm.TpmPresent)" } catch {}
            try {
                $tpmCim = Get-CimInstance -Namespace 'root\cimv2\security\microsofttpm' -Class Win32_Tpm -ErrorAction Stop
                if ($tpmCim) { $tpmSpec = "$($tpmCim.SpecVersion)" }
            } catch {}

            # Secure Boot (throws on legacy / non-UEFI)
            $secureBoot = ''
            try { $secureBoot = if (Confirm-SecureBootUEFI -ErrorAction Stop) { 'On' } else { 'Off' } }
            catch { $secureBoot = 'Legacy/Unsupported' }

            # MAC + IP from the active physical adapter
            $mac = ''; $ip = ''
            try {
                $ad = Get-NetAdapter -Physical -ErrorAction Stop | Where-Object { $_.Status -eq 'Up' } | Select-Object -First 1
                if (-not $ad) { $ad = Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Select-Object -First 1 }
                if ($ad) {
                    $mac = "$($ad.MacAddress)"
                    $ipObj = Get-NetIPAddress -InterfaceIndex $ad.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue |
                             Where-Object { $_.IPAddress -notlike '169.254.*' } | Select-Object -First 1
                    if ($ipObj) { $ip = "$($ipObj.IPAddress)" }
                }
            } catch {}

            # Autopilot hardware hash (raw CIM; provisional this pass)
            Status 'Reading Autopilot hardware hash...'
            $hwHash = ''
            try {
                $devDetail = Get-CimInstance -Namespace 'root/cimv2/mdm/dmmap' `
                    -Class 'MDM_DevDetail_Ext01' -Filter "InstanceID='Ext' AND ParentID='./DevDetail'" -ErrorAction Stop
                if ($devDetail) { $hwHash = "$($devDetail.DeviceHardwareData)" }
            } catch { Log "Autopilot hash unavailable: $_" 'WARN' }
            if ($hwHash) { Log "Autopilot hash captured ($($hwHash.Length) chars, provisional)." }
            else { Log 'Autopilot hash not captured.' 'WARN' }

            # --- POST everything to the sheet ---
            Status 'Sending inventory to Google Sheets...'
            $nowStamp = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
            $asmRes = Post-Log @{
                LogSheet        = 'Summer2026'
                ProjectMode     = 'Summer 2026 Inventory Project'
                # Project lifecycle
                ProjectRunId    = $s.ProjectRunId
                ProjectStatus   = $projectStatus
                # Preserve the readiness exception independently from the project workflow status.
                # This lets the technician finish required work while follow-up remains visible.
                ExceptionStatus = $(if ($s.DayOneStatus -eq 'Issue Reported') { 'Open' } else { '' })
                CurrentStage    = 'Summer Assessment'
                AssessmentTechnician  = $s.TechName
                AssessmentCompletedAt = $nowStamp
                LastUpdatedBy   = $s.TechName
                LastUpdatedAt   = $nowStamp
                ProjectOrigin   = 'Summer2026'
                # v5.3.2 domain-state evidence (InstallType is confirmed later at the recommendation)
                DomainMembershipStatus = $domainStatus
                DetectedDomain         = $detectedDomain
                DomainCheckAt          = $nowStamp
                # Day One readiness
                DayOneStatus           = $s.DayOneStatus
                DayOneCheckedBy        = $s.TechName
                DayOneCheckedAt        = $nowStamp
                PanelOPSDisplayWorking = $s.DayOne_Display
                TouchWorking           = $s.DayOne_Touch
                SoundWorking           = $s.DayOne_Sound
                CablesManaged          = $s.DayOne_Cables
                NetworkWorking         = $s.DayOne_Network
                NetworkType            = $s.NetworkType
                NDMSEnrolledOnline     = $s.DayOne_NDMS
                ReadinessIssueCategory = $s.IssueCategory
                ReadinessIssueNote     = $s.IssueNote
                # Device / location
                Hostname        = $hostname
                OPSSerial       = $opsSerial
                OPSClass        = $s.OPSClass
                OriginalOPSSerial = $opsSerial
                CurrentOPSSerial = $opsSerial
                OPSSerial_BIOS      = $s.OPSSerial_BIOS
                OPSSerial_Product   = $s.OPSSerial_Product
                OPSSerial_BaseBoard = $s.OPSSerial_BaseBoard
                OPSSerial_Registry  = $s.OPSSerial_Registry
                SelectedOPSSerialSource     = $s.SelectedOPSSerialSource
                SelectedOPSSerialConfidence = $s.SelectedOPSSerialConfidence
                OPSSerialValidationStatus   = $s.OPSSerialValidationStatus
                OPSSerialValidationNote     = $s.OPSSerialValidationNote
                PanelSerial     = $panelSerial
                PanelSerialStickerStatus      = $s.PanelSerialStickerStatus
                PanelSerialSource             = $s.PanelSerialSource
                PanelSerialVerificationStatus = $s.PanelSerialVerificationStatus
                PanelObservationId            = $s.PanelObservationId
                IdentityResolutionRequired    = $(if ([bool]$s.IdentityResolutionRequired) { 'TRUE' } else { 'FALSE' })
                PanelIdentityResolutionStatus = $s.PanelIdentityResolutionStatus
                NDMSName         = $s.NDMSName
                NDMSDeviceId     = $s.NDMSDeviceId
                NDMSTags         = $s.NDMSTags
                SchoolCode      = $s.SchoolCode
                SchoolName      = $s.SchoolName
                Room            = $s.Room
                RoomType        = $s.RoomType
                OtherRoomType   = $s.OtherRoomType
                MfrCode         = $s.MfrCode
                Manufacturer    = $s.Manufacturer
                ManufacturerWMI = $mfrWmi
                PanelModel      = $s.PanelModel
                MountType       = $s.MountType
                Model           = $model
                BaseBoard       = $board
                StorageActualGB = $gb
                StorageTierGB   = $tierNum
                PartitionStyle  = $partStyle
                OSName          = $osShort
                OSBuild         = $build
                OSDisplayVer    = $displayVer
                OSEdition       = $edition
                IsWindows11     = $isWin11
                TPMPresent      = $tpmPresent
                TPMSpecVersion  = $tpmSpec
                SecureBoot      = $secureBoot
                FirmwareMode    = $firmwareMode
                BIOSVendor      = $biosVendor
                BIOSVersion     = $biosVersion
                BIOSDate        = $biosDate
                RAMGB           = $ramGB
                CPU             = $cpuName
                MAC             = $mac
                IP              = $ip
                AutopilotHash   = $hwHash
                HashProvisional = $true
                # Reimage decision (legacy display fields)
                ReimageDecision = $decision
                ReimageNeeded   = $reimage
                ImageProfile    = $imageProfile
                RedoImageFile   = $redoFile
                ExpectedImageFolder = $imageFolder
                # v5.4: the COMPLETE structured decision from the shared matrix, written here at
                # assessment time. Post-RecommendationDecision is not on every route (Continue-To*
                # paths, or closing PanelApp on the summary screen), so the Summer row must never
                # be left with blank ImageStatus / remediation fields.
                WindowsVersionStatus          = "$($imgA.WindowsVersionStatus)"
                ImageStatus                   = "$($imgA.ImageStatus)"
                ImageDecisionReason           = "$($imgA.ImageDecisionReason)"
                MinimumAcceptedVersion        = "$($imgA.MinimumAcceptedVersion)"
                PreferredVersion              = "$($imgA.PreferredVersion)"
                RemediationMethod             = "$($imgA.RemediationMethod)"
                ReimageReason                 = "$($imgA.ReimageReason)"
                FirmwareConfigurationRequired = [bool]$imgA.FirmwareConfigurationRequired
                WindowsUpdateRequired         = [bool]$imgA.WindowsUpdateRequired
                PendingRestartDetected        = [bool]$imgA.PendingRestartDetected
                PendingRestartReasons         = "$($imgA.PendingRestartReasons)"
                RecoveryRequired              = [bool]$imgA.RecoveryRequired
                RedoRescueAllowed             = [bool]$imgA.RedoRescueAllowed
                RedoRescueRequired            = [bool]$imgA.RedoRescueRequired
                InfrastructureUpdateEligible  = [bool]$imgA.InfrastructureUpdateEligible
                IIQAssetTag     = $s.IIQAssetTag
                FundingSource   = ''
                # r14 ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§15: repeated observations must be legible to PAIR, not look like dupes
                # ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§1: written once, at assessment time - the backend refuses to overwrite it later.
                AssessmentHostname   = "$(if ($s.AssessmentHostname) { $s.AssessmentHostname } else { $env:COMPUTERNAME })"
                RawRoom              = "$($s.RawRoom)"
                AssessmentType       = "$(if ($s.AssessmentType) { $s.AssessmentType } else { 'Initial Assessment' })"
                ReassessmentReason   = "$($s.ReassessmentReason)"
                PreviousProjectRunId = "$($s.PreviousProjectRunId)"
                InventoryCycleId     = "$($s.InventoryCycleId)"
                ScriptVersion   = $s.ScriptVersion
                CaptureTime     = $nowStamp
            } 'SummerAssessmentCaptured'
            # r9 finding #3: another technician may already hold the active project for this panel.
            # Never show 'captured' for an assessment the spreadsheet permanently rejected.
            if ($asmRes -and $asmRes.Rejected) {
                $why = if ($asmRes.Parsed) { "$($asmRes.Parsed.ErrorCode): $($asmRes.Parsed.Message)" } else { 'permanent rejection' }
                Log "Assessment REJECTED by the spreadsheet ($why) - not showing the summary." 'ERROR'
                try { $s.UI['pbarProgress'].Dispatcher.Invoke([action]{
                    $s.UI['pnlProgress'].Visibility = [System.Windows.Visibility]::Collapsed
                    $s.UI['lblGateTitle'].Text = 'Assessment Not Recorded'
                    $s.UI['lblGateMsg'].Text = "This assessment was NOT saved.

$why

Another technician may already have an active project for this panel. Do not continue - check with your lead before working on it."
                    $s.UI['lblGateState'].Text = "Panel serial: $($s.PanelSerial)
OPS serial: $($s.OPSSerial)"
                    $s.UI['pnlRedoGateBlock'].Visibility = [System.Windows.Visibility]::Visible
                }) } catch {}
                return
            }

            # A Boxlight observation with no resolved panel serial is preserved on the Summer row,
            # and also gets a dedicated reconciliation queue item. This is intentionally NOT a fake
            # PanelSerial and does not update the authoritative current-inventory pairing.
            if ([bool]$s.IdentityResolutionRequired) {
                $confRes = Post-Log @{
                    LogSheet='InventoryConflicts'; ConflictType='Panel Serial Missing / Unreadable'; ConflictStatus='New'
                    ProjectRunId=$s.ProjectRunId; RelatedProjectRunIds=$s.ProjectRunId
                    PanelSerial=''; OPSSerial=$opsSerial; CurrentHostname=$hostname; LocalDetectedOPSSerial=$opsSerial
                    SchoolCode=$s.SchoolCode; Room=$s.Room; Manufacturer=$s.Manufacturer; PanelModel=$s.PanelModel; MountType=$s.MountType
                    PanelObservationId=$s.PanelObservationId; PanelSerialStickerStatus=$s.PanelSerialStickerStatus
                    PanelSerialSource=$s.PanelSerialSource; PanelSerialVerificationStatus=$s.PanelSerialVerificationStatus
                    IdentityResolutionRequired='TRUE'; PanelIdentityResolutionStatus=$s.PanelIdentityResolutionStatus
                    IIQAssetTag=$s.IIQAssetTag; NDMSName=$s.NDMSName; NDMSDeviceId=$s.NDMSDeviceId; NDMSTags=$s.NDMSTags
                    TechnicianNotes="Panel serial sticker missing/unreadable. Resolve the canonical serial through NDMS/vendor records before remediation or provisioning."
                    RevisitRequired='No'; CreatedBy=$s.TechName; ScriptVersion=$s.ScriptVersion
                } 'InventoryConflict'
                if ($confRes -and $confRes.Rejected) {
                    Log "Panel identity reconciliation queue item was rejected; Interactive Inventory observation remains recorded." 'WARN'
                } elseif ($confRes -and $confRes.Queued) {
                    Log "Panel identity reconciliation queue item queued offline for observation $($s.PanelObservationId)." 'WARN'
                } else {
                    Log "Panel identity reconciliation queue item recorded for observation $($s.PanelObservationId)."
                }
            }

            # --- Populate and show the summary screen ---
            try { $s.UI['pbarProgress'].Dispatcher.Invoke([action]{
                $s.UI['lblSum_Device'].Text  = "$($s.SchoolName) - Room $($s.Room)"
                $s.UI['lblSum_OPS'].Text     = $opsSerial
                $s.UI['lblSum_Panel'].Text   = if ($panelSerial) { $panelSerial } else { "SERIAL PENDING [$($s.PanelObservationId)]" }
                $s.UI['lblSum_Storage'].Text = $storageDisplay
                $s.UI['lblSum_OS'].Text      = $osShort
                $s.UI['lblSum_Action'].Text  = $decision
                if ($decisionClass -eq 'NoReimage') {
                    $s.UI['borSum_Action'].Background  = [System.Windows.Media.SolidColorBrush]([System.Windows.Media.ColorConverter]::ConvertFromString('#0F1E10'))
                    $s.UI['borSum_Action'].BorderBrush = [System.Windows.Media.SolidColorBrush]([System.Windows.Media.ColorConverter]::ConvertFromString('#2D6A4F'))
                    $s.UI['lblSum_Action'].Foreground  = [System.Windows.Media.SolidColorBrush]([System.Windows.Media.ColorConverter]::ConvertFromString('#4EC994'))
                    $s.UI['lblSum_Next'].Text = 'Image assessment complete. Click Next: Provisioning Options so PanelApp can check domain status and determine the final workflow.'
                } elseif ($decisionClass -eq 'WindowsUpgrade' -or $decisionClass -eq 'FirmwareConfig' -or $decisionClass -eq 'PendingRestart') {
                    # v5.4 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§2: remediation, NOT reimage
                    $s.UI['borSum_Action'].Background  = [System.Windows.Media.SolidColorBrush]([System.Windows.Media.ColorConverter]::ConvertFromString('#1E1200'))
                    $s.UI['borSum_Action'].BorderBrush = [System.Windows.Media.SolidColorBrush]([System.Windows.Media.ColorConverter]::ConvertFromString('#8B6914'))
                    $s.UI['lblSum_Action'].Foreground  = [System.Windows.Media.SolidColorBrush]([System.Windows.Media.ColorConverter]::ConvertFromString('#F0B030'))
                    # Each remediation class needs its OWN instructions - a pending restart is not
                    # a BIOS problem, and sending a tech into the BIOS is actively misleading.
                    $s.UI['lblSum_Next'].Text = switch ($decisionClass) {
                        'WindowsUpgrade' {
                            "This OPS needs a Windows upgrade - NOT a reimage. Target: Windows 11 $prefVer.`n`nClick Next: Provisioning Options for the full remediation details. Complete the approved Windows Update / in-place upgrade, then relaunch PanelApp and resume this same Interactive Inventory project."
                        }
                        'PendingRestart' {
                            "This OPS has a pending Windows Update restart.`n`nClick Next: Provisioning Options for the full remediation details. Complete the required restart, allow Windows servicing to finish, then relaunch PanelApp and resume this same Interactive Inventory project."
                        }
                        'FirmwareConfig' {
                            "This OPS needs a BIOS/UEFI correction - NOT a reimage.`n`nClick Next: Provisioning Options for the full remediation details. Disable CSM/Legacy, set UEFI-only boot, reboot, then relaunch PanelApp and resume this same Interactive Inventory project."
                        }
                        default {
                            "This OPS needs remediation before provisioning - NOT a reimage.`n`nClick Next: Provisioning Options for the full remediation details, then relaunch PanelApp and resume this same Interactive Inventory project."
                        }
                    }
                } elseif ($decisionClass -eq 'Reimage') {
                    $s.UI['borSum_Action'].Background  = [System.Windows.Media.SolidColorBrush]([System.Windows.Media.ColorConverter]::ConvertFromString('#1E1200'))
                    $s.UI['borSum_Action'].BorderBrush = [System.Windows.Media.SolidColorBrush]([System.Windows.Media.ColorConverter]::ConvertFromString('#8B6914'))
                    $s.UI['lblSum_Action'].Foreground  = [System.Windows.Media.SolidColorBrush]([System.Windows.Media.ColorConverter]::ConvertFromString('#F0B030'))
                    $uefiNote = "Before restoring, boot the RedoRescue media in UEFI mode. If the OPS does not boot correctly after restore, check BIOS boot order and make sure CSM/Legacy boot is not being used."
                    $s.UI['lblSum_Next'].Text = if ([string]::IsNullOrWhiteSpace($imageFolder)) {
                        "Reimage this device with RedoRescue, then re-run this script and select Full Provisioning -> Interactive Inventory Project - Post-RedoRescue Provisioning.`n`n$uefiNote"
                    } else {
                        "Use the approved RedoRescue image folder:`n$imageFolder`n`nAfter the restored OPS reaches the local staging account, re-run this script and select Full Provisioning -> Interactive Inventory Project - Post-RedoRescue Provisioning.`n`n$uefiNote"
                    }
                } else {
                    # Manual review
                    $s.UI['borSum_Action'].Background  = [System.Windows.Media.SolidColorBrush]([System.Windows.Media.ColorConverter]::ConvertFromString('#200808'))
                    $s.UI['borSum_Action'].BorderBrush = [System.Windows.Media.SolidColorBrush]([System.Windows.Media.ColorConverter]::ConvertFromString('#7A1515'))
                    $s.UI['lblSum_Action'].Foreground  = [System.Windows.Media.SolidColorBrush]([System.Windows.Media.ColorConverter]::ConvertFromString('#EF5B5B'))
                    $s.UI['lblSum_Next'].Text = if ([bool]$s.IdentityResolutionRequired) {
                        "Panel identity was captured as $($s.PanelObservationId). Do not reimage or provision yet. A lead will resolve the real panel serial using the APS asset / NDMS identifiers, then reconcile this observation."
                    } else {
                        'This device was not recognized automatically. Do not reimage - flag it to your lead for manual review.'
                    }
                }
                $s.UI['pnlProgress'].Visibility      = [System.Windows.Visibility]::Collapsed
                $s.UI['pnlSummerSummary'].Visibility = [System.Windows.Visibility]::Visible
            }) } catch { Log "Summary display error: $_" 'ERROR' }

            Status 'Interactive Inventory Project assessment captured.'
        } catch {
            Log "Interactive Inventory Project capture error: $_" 'ERROR'
            Fail "$_"
        }
    }
}

# ================================================================
#  EXECUTE PHASE B  (domain join after reboot)
# ================================================================
function Execute-PhaseB {
    param([string]$DomainUser, [System.Security.SecureString]$SecurePwd)
    $script:UI['btnJoinDomain'].IsEnabled    = $false
    $script:UI['pbarPhaseB'].IsIndeterminate = $true
    $script:UI['lblPhaseBStatus'].Text       = 'Joining domain...'
    $sync = [hashtable]::Synchronized(@{
        UI              = $script:UI
        LogFile         = $script:LogFile
        TechName        = $script:TechName
        # v5.5.1 ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§7: Phase B runs AFTER the rename reboot, so the live computer name is
        # authoritative. The state file carries the name chosen before the reboot; if the rename
        # succeeded they agree, and if it silently did not, the truth is what Windows reports.
        Hostname        = $env:COMPUTERNAME
        # ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§1: NOT $script:Hostname - after the rename that is the APS name, which would make the
        # "as found" and "provisioned" names identical.
        AssessmentHostname = $script:AssessmentHostname
        ModeLabel       = $script:ModeLabel
        SchoolCode      = $script:SchoolCode
        SchoolName      = $script:SchoolName
        Room            = $script:RoomNumber
        MountType       = $script:MountType
        Manufacturer    = $script:Manufacturer
        PanelModel      = $script:PanelModel
        PanelSerial     = $script:PanelSerial
        OPSSerial       = $script:OPSSerial
        StorageGB       = $script:StorageGB
        OPSTruncNote    = $script:OPSTruncationNote
        DomainUser      = $DomainUser
        SecurePwd       = $SecurePwd
        DomainName      = $script:Config.Domain
        DomainOU        = $script:Config.DomainOU
        AppScriptUrl    = $script:Config.AppScriptUrl
        ScriptDir       = $script:ScriptDir
        ProvisioningDir = $script:ProvisioningDir
        ErrorLog        = $script:ErrorLog
        RunFlags        = $script:RunFlags
        # Summer continuation linkage (v5.2 Phase 3)
        RunId               = $script:RunId
        UsbRoot             = $script:UsbRoot
        RelatedSummerRunId  = $script:RelatedSummerRunId
        SummerImageProfile  = $script:SummerImageProfile
        SummerRedoFile      = $script:SummerRedoFile
        SummerExpectedFolder = $script:SummerExpectedFolder
        OPSReplacementConfirmed = $script:OPSReplacementConfirmed
        RMAAction              = $script:RMAAction
        RMAPreviousPanelSerial = $script:RMAPreviousPanelSerial
        RMAReassignmentConfirmed = $script:RMAReassignmentConfirmed
        InventoryReassignmentConfirmed = $script:InventoryReassignmentConfirmed
        InventoryReassignmentType = $script:InventoryReassignmentType
        InventoryReassignmentReason = $script:InventoryReassignmentReason
        InventoryPreviousPanelSerial = $script:InventoryPreviousPanelSerial
        TemporaryAssignment = $script:TemporaryAssignment
        FollowUpRequired = $script:FollowUpRequired
        TestingObservationOnly = $script:TestingObservationOnly
        NewInstallProvisioning = $script:NewInstallProvisioning
        RecoveryProvisioning   = $script:RecoveryProvisioning
        InstallType            = $script:InstallType
        RoomType               = $script:RoomType
        OtherRoomType          = $script:OtherRoomType
        DomainMembershipStatus = $script:DomainMembershipStatus
        DetectedDomain         = $script:DetectedDomain
        SecureChannelStatus    = $script:SecureChannelStatus
        ProvisioningPathSelected = $script:ProvisioningPathSelected
        PreviousHostname       = $script:PreviousHostname
        PreviousHostnameSource = $script:PreviousHostnameSource
        OldHostnameCheckResult = $script:OldHostnameCheckResult
        NewHostnameCheckResult = $script:NewHostnameCheckResult
        SelectedHostnameSuffix = $script:SelectedHostnameSuffix
        ProvisioningAccount = $script:ProvisioningAccountName
        ProvisioningAccountPreflight = $script:ProvisioningAccountPreflight
        ProvisioningAccountEnabled = $script:ProvisioningAccountEnabled
        ProvisioningAccountPasswordNeverExpires = $script:ProvisioningAccountPasswordNeverExpires
        ProvisioningAccountCheckedAt = $script:ProvisioningAccountCheckedAt
    })
    # v5.5.1 ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§7: adopt the post-reboot name for every later payload (closeout included), while
    # keeping the assessment-time name for the historical record.
    if ($script:Hostname -ne $env:COMPUTERNAME) {
        Write-Log "Phase B: adopting live hostname $env:COMPUTERNAME (state file expected $($script:Hostname))."
        $script:Hostname = $env:COMPUTERNAME
    }
    # v5.5.1b ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§2: NEVER substitute the APS name here. On a legacy state file that predates the
    # early capture, blank is honest; the APS name would be a fabricated "as found" value.
    if (-not $script:AssessmentHostname) {
        Write-Log 'Assessment hostname was not available in the saved provisioning state.' 'WARN'
    }
    Add-SenderContextToSync $sync | Out-Null   # v5.5 finding #2
    $script:ActiveSenderSync = $sync                # v5.5 finding #1 (round 3)
    $rs = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace()
    $rs.ApartmentState = [System.Threading.ApartmentState]::STA
    $rs.ThreadOptions  = [System.Management.Automation.Runspaces.PSThreadOptions]::ReuseThread
    $rs.Open()
    $rs.SessionStateProxy.SetVariable('s', $sync)
    $ps = [System.Management.Automation.PowerShell]::Create()
    $ps.Runspace = $rs
    [void]$ps.AddScript($script:SenderDefs)   # v5.5: Phase B uses the SAME sender (finding #1)
    [void]$ps.AddScript({
        function Log { param($m,$l='INFO')
            $line = "[$(Get-Date -f 'HH:mm:ss')][$l] $m"
            try { Add-Content -Path $s.LogFile -Value $line -Encoding UTF8 } catch {}
            if ($l -eq 'ERROR') {
                $s.RunFlags.HadError = $true
                try { Add-Content -Path $s.ErrorLog -Value $line -Encoding UTF8 } catch {}
            }
            try { $s.UI['txtPhaseBLog'].Dispatcher.Invoke([action]{
                $s.UI['txtPhaseBLog'].AppendText("$line`n")
                $s.UI['txtPhaseBLog'].ScrollToEnd() }) } catch {}
        }
        # Same shared-sender wrappers as the provisioning runspace - no private POST here.
        function Get-RunnerSenderContext {
            if ($s.QueueDir)                              { $dir = "$($s.QueueDir)" }
            elseif ($s.ProvisioningDir)                 { $dir = Join-Path $s.ProvisioningDir 'OfflineQueue' }
            else                                        { $dir = Join-Path $s.ScriptDir 'APS\OfflineQueue' }
            return @{
                Url = $s.AppScriptUrl; QueueDir = $dir
                FallbackQueueDir = $(if ($s.ProvisioningDir) { Join-Path $s.ProvisioningDir 'OfflineQueue' } else { $dir })
                SessionId = "$($s.ClientSessionId)"; DeviceName = "$($s.ClientDeviceName)"
                ScriptVersion = "$($s.ScriptVersion)"; RunId = $s.RunId
                Sequence = [int]$s.EventSequence
                Revision = "$($s.ProjectStateRevision)"; RevisionFor = "$($s.ProjectStateRevisionFor)"
                Online = $true
            }
        }
        # r12 finding #2: a runspace must respect a hold the MAIN THREAD created before it started,
        # a hold this runspace created on an earlier event, and anything already sitting in the queue
        # for the project. Sharing a ProjectRunId does not order events by itself - the sender has to
        # deliberately queue the later one.
        function Test-RunnerProjectHold {
            param([string]$Project, [hashtable]$Ctx)
            if (-not $Project) { return $false }
            if ("$($s.PendingQueuedProjectRunId)" -eq $Project) { return $true }
            $dirs = @($Ctx['QueueDir'])
            if ($s.UsbRoot)         { $dirs += (Join-Path $s.UsbRoot 'APS\OfflineQueue') }
            if ($s.ProvisioningDir) { $dirs += (Join-Path $s.ProvisioningDir 'OfflineQueue') }
            if (Test-QueuedWorkInDirs -Dirs $dirs -ProjectRunId $Project) {
                $s.PendingQueuedProjectRunId = $Project   # sticky for the rest of this runspace
                return $true
            }
            return $false
        }        function Post-Log { param([hashtable]$data, [Parameter(Mandatory)][string]$EventType)
            if (-not $data.ContainsKey('Timestamp')) { $data['Timestamp'] = Get-Date -Format 'yyyy-MM-dd HH:mm:ss' }
            if (-not $data.ContainsKey('TechName'))  { $data['TechName']  = $s.TechName }
            if ($s.RunId -and -not $data.ContainsKey('RunId')) { $data['RunId'] = $s.RunId }
            $ctx = Get-RunnerSenderContext
            $projRunB = "$($data['ProjectRunId'])"
            if (-not $projRunB) { $projRunB = "$($data['RelatedSummerProjectRunId'])" }
            if (Test-RunnerProjectHold $projRunB $ctx) {
                Log "Project $projRunB has queued work - queueing $EventType behind it to preserve order." 'WARN'
                $ctx['Online'] = $false
                $ctx['QueueHoldReason'] = 'Waiting for earlier saved events in this project to synchronize in order.'
            }
            $res = Send-PanelAppEvent -Payload $data -EventType $EventType -Ctx $ctx
            $s.EventSequence = [int]$ctx['Sequence']
            $s.ProjectStateRevision = "$($ctx['Revision'])"; $s.ProjectStateRevisionFor = "$($ctx['RevisionFor'])"
            if ($res.Sent) {
                Log "Sheets OK ($EventType)."
                # r9: applied, but the current-inventory layer needs a lead to reconcile it.
                if ($res.Parsed -and $res.Parsed.InventoryReviewRequired) {
                    Log ("Applied, but current inventory needs review ($($res.Parsed.WarningCode)): $($res.Parsed.WarningMessage)") 'WARN'
                }
            }
            elseif ($res.Rejected) { Log "Apps Script PERMANENTLY rejected ($EventType / $($res.Parsed.ErrorCode)): $($res.Parsed.Message)" 'ERROR' }
            else {
                Log "Event not delivered ($EventType): $($res.Reason) -- saved for synchronization." 'WARN'
                # r6 finding #2: tell the main thread this project now has queued work.
                $pendRunB = "$($data['ProjectRunId'])"
                if (-not $pendRunB) { $pendRunB = "$($data['RelatedSummerProjectRunId'])" }
                if ($pendRunB) { $s.PendingQueuedProjectRunId = $pendRunB }
            }
            # Same shape as the provisioning wrapper so callers rely on ONE contract.
            return [pscustomobject]@{
                Status    = $(if ($res.Sent) {
                                  if ($res.Parsed -and $res.Parsed.InventoryReviewRequired) { 'Applied - Inventory Review Required' }
                                  elseif ($res.Parsed -and $res.Parsed.Duplicate) { 'Duplicate' }
                                  else { 'Applied' }
                              } elseif ($res.Rejected) { 'Rejected' } else { 'Queued' })
                Delivered = [bool]$res.Sent
                Queued    = (-not $res.Sent -and -not $res.Rejected)
                Rejected  = [bool]$res.Rejected
                Parsed    = $res.Parsed
            }


        }
        function PBStatus { param($m,$col='#CCCCCC')
            try { $s.UI['lblPhaseBStatus'].Dispatcher.Invoke([action]{
                $s.UI['lblPhaseBStatus'].Text = $m
                $s.UI['lblPhaseBStatus'].Foreground = [System.Windows.Media.SolidColorBrush](
                    [System.Windows.Media.ColorConverter]::ConvertFromString($col))
            }) } catch {}
        }
        try {
            Log "Joining $($s.DomainName)..."
            Log "Target OU : $($s.DomainOU)"
            if ([string]::IsNullOrWhiteSpace($s.DomainOU)) {
                Log 'WARNING: DomainOU is empty - computer will land in default Computers container.' 'WARN'
            }
            $cred = [System.Management.Automation.PSCredential]::new(
                "$($s.DomainName)\$($s.DomainUser)", $s.SecurePwd)
            if ([string]::IsNullOrWhiteSpace($s.DomainOU)) {
                Add-Computer -DomainName $s.DomainName -Credential $cred -Force -ErrorAction Stop
            } else {
                Add-Computer -DomainName $s.DomainName -OUPath $s.DomainOU `
                             -Credential $cred -Force -ErrorAction Stop
            }
            Log 'Domain join successful.'
            # v5.5.1 ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§11/ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§12: the join has succeeded but the machine has NOT rebooted, so the
            # secure channel cannot be verified yet. Record the RESULT of provisioning separately
            # from the pre-provisioning observation - never keep reporting WORKGROUP afterwards.
            $s.DomainJoinCompletedAt        = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
            $s.DomainJoinTargetDomain       = $s.DomainName
            $s.PostJoinMembershipStatus     = 'Domain Join Pending Reboot'
            $s.PostJoinSecureChannelStatus  = 'Pending Reboot'

            # ================================================================
            #  Disable local build-account autologon + clear sign-in hints
            #  Runs FIRST, right after the join, before any non-critical step
            #  (Windows Update, task removal, Sheets logging). If something
            #  later fails, the device still won't auto-login to the local
            #  build account or show the confusing local-account banner.
            # ================================================================
            Log 'Disabling local build-account autologon and preparing domain sign-in screen...'
            $winlogon  = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'
            $sysPolicy = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'
            $logonUI   = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\LogonUI'
            if (-not (Test-Path $winlogon))  { New-Item -Path $winlogon  -Force | Out-Null }
            if (-not (Test-Path $sysPolicy)) { New-Item -Path $sysPolicy -Force | Out-Null }

            # Turn autologon off and strip every known autologon value
            Set-ItemProperty -Path $winlogon -Name 'AutoAdminLogon' -Value '0' -Type String -Force
            foreach ($n in @('DefaultPassword','AutoLogonCount','ForceAutoLogon')) {
                Remove-ItemProperty -Path $winlogon -Name $n -ErrorAction SilentlyContinue
            }

            # Clear the local image-account hint and prefer the domain on next sign-in
            Set-ItemProperty -Path $winlogon -Name 'DefaultUserName'   -Value ''            -Type String -Force
            Set-ItemProperty -Path $winlogon -Name 'DefaultDomainName' -Value $s.DomainName -Type String -Force

            # Clear any legal-notice banner ("type domain\user or computername\user")
            # stamped by unattend.xml or policy. Windows reads it from two locations.
            foreach ($path in @($sysPolicy, $winlogon)) {
                Set-ItemProperty -Path $path -Name 'LegalNoticeCaption' -Value '' -Type String -Force -ErrorAction SilentlyContinue
                Set-ItemProperty -Path $path -Name 'LegalNoticeText'    -Value '' -Type String -Force -ErrorAction SilentlyContinue
            }

            # Don't surface the local build-account tile after join
            New-ItemProperty -Path $sysPolicy -Name 'DontDisplayLastUserName' -Value 1 -PropertyType DWord -Force | Out-Null
            New-ItemProperty -Path $sysPolicy -Name 'HideFastUserSwitching'   -Value 1 -PropertyType DWord -Force | Out-Null

            # Clear cached LogonUI "last signed-in user" values so the lock screen
            # doesn't default back to COMPUTERNAME\user
            if (Test-Path $logonUI) {
                foreach ($n in @('LastLoggedOnUser','LastLoggedOnSAMUser','LastLoggedOnDisplayName','LastLoggedOnUserSID','SelectedUserSID')) {
                    Remove-ItemProperty -Path $logonUI -Name $n -ErrorAction SilentlyContinue
                }
                $sessionData = Join-Path $logonUI 'SessionData'
                if (Test-Path $sessionData) {
                    Get-ChildItem -Path $sessionData -ErrorAction SilentlyContinue | ForEach-Object {
                        foreach ($n in @('LoggedOnSAMUser','LoggedOnUser','LoggedOnDisplayName','LoggedOnUserSID')) {
                            Remove-ItemProperty -Path $_.PSPath -Name $n -ErrorAction SilentlyContinue
                        }
                    }
                }
            }
            Log 'Autologon disabled, local login hints cleared, and domain sign-in prepared.'

            Log 'Re-enabling Windows Update...'
            Set-Service  wuauserv -StartupType Automatic -ErrorAction SilentlyContinue
            Start-Service wuauserv -ErrorAction SilentlyContinue
            $p = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU'
            if (Test-Path $p) { Remove-ItemProperty $p -Name NoAutoUpdate -ErrorAction SilentlyContinue }
            Log 'Windows Update re-enabled.'

            # Phase B completed, so the 8h WU fail-safe is no longer needed (ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§18.4)
            Unregister-ScheduledTask -TaskName 'APSPanelWURecovery' -Confirm:$false -ErrorAction SilentlyContinue
            Unregister-ScheduledTask -TaskName 'APSPanelPhaseB' -Confirm:$false -ErrorAction SilentlyContinue
            Log 'Phase B task removed.'
            # Review fix #13: VERIFY cleanup instead of assuming it succeeded
            $wuTaskGone  = -not (Get-ScheduledTask -TaskName 'APSPanelWURecovery' -ErrorAction SilentlyContinue)
            $pbTaskGone  = -not (Get-ScheduledTask -TaskName 'APSPanelPhaseB' -ErrorAction SilentlyContinue)
            $wuSvc       = Get-Service wuauserv -ErrorAction SilentlyContinue
            $wuPolicy    = Get-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name NoAutoUpdate -ErrorAction SilentlyContinue
            $wuRestored  = ($wuSvc -and $wuSvc.StartType -ne 'Disabled' -and -not $wuPolicy)
            $wuRemovedAt = if ($wuTaskGone) { Get-Date -Format 'yyyy-MM-dd HH:mm:ss' } else { '' }
            # Review fix #4: keep a small closeout-pending state for Summer-linked runs so a
            # crash/close before closeout can RESUME closeout instead of drifting back to Phase A.
            $sf = "$($s.ProvisioningDir)\state.json"
            $stateAction = 'Missing'
            if ($s.RelatedSummerRunId) {
                try {
                    @{ PhaseAStatus='Complete'; PhaseBStatus='Complete'
                       # r8 finding #1: the LOCAL Phase B step is done, but the backend has not
                       # confirmed it yet. Closeout stays BLOCKED until the response is known -
                       # otherwise a rejected Phase B becomes closeout-eligible after a restart.
                       PhaseBBackendStatus='Pending'; FinalCloseoutStatus='Blocked'
                       RelatedSummerRunId=$s.RelatedSummerRunId; RunId=$s.RunId
                       SummerImageProfile=$s.SummerImageProfile; SummerRedoFile=$s.SummerRedoFile
                       SummerExpectedFolder=$s.SummerExpectedFolder
                       NewInstallProvisioning=$s.NewInstallProvisioning; RecoveryProvisioning=$s.RecoveryProvisioning
                       InstallType=$s.InstallType
                       RoomType=$s.RoomType; OtherRoomType=$s.OtherRoomType
                       DomainMembershipStatus=$s.DomainMembershipStatus; DetectedDomain=$s.DetectedDomain
                       SecureChannelStatus=$s.SecureChannelStatus; ProvisioningPathSelected=$s.ProvisioningPathSelected
                       Hostname=$s.Hostname; PanelSerial=$s.PanelSerial; OPSSerial=$s.OPSSerial
                       UsbRoot=$s.UsbRoot; TechName=$s.TechName
                       # Review fix #2: full context so a resumed closeout writes a complete PanelLog row
                       Mode=$s.ModeLabel; SchoolCode=$s.SchoolCode; SchoolName=$s.SchoolName
                       Room=$s.Room; MountType=$s.MountType; Manufacturer=$s.Manufacturer
                       PanelModel=$s.PanelModel; StorageGB=$s.StorageGB
                       PreviousHostname=$s.PreviousHostname; PreviousHostnameSource=$s.PreviousHostnameSource
                       OldHostnameCheckResult=$s.OldHostnameCheckResult; NewHostnameCheckResult=$s.NewHostnameCheckResult
                       SelectedHostnameSuffix=$s.SelectedHostnameSuffix
                       OPSReplacementConfirmed=$s.OPSReplacementConfirmed
                       # ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§2: without these, a close/crash between Phase B and closeout meant the
                       # resumed closeout re-read the PRE-provisioning values and reported
                       # Not Domain Joined / WORKGROUP for a machine that had already joined.
                       AssessmentHostname=$s.AssessmentHostname
                       ProvisionedHostname=$s.Hostname
                       DomainJoinTargetDomain=$s.DomainJoinTargetDomain
                       DomainJoinCompletedAt=$s.DomainJoinCompletedAt
                       PostJoinMembershipStatus=$s.PostJoinMembershipStatus
                       PostJoinSecureChannelStatus=$s.PostJoinSecureChannelStatus
                       PreProvisionDomainMembershipStatus=$s.DomainMembershipStatus
                       PreProvisionDetectedDomain=$s.DetectedDomain
                       ProvisioningAccount=$s.ProvisioningAccount
                       ProvisioningAccountPreflight=$s.ProvisioningAccountPreflight
                       ProvisioningAccountEnabled=$s.ProvisioningAccountEnabled
                       ProvisioningAccountPasswordNeverExpires=$s.ProvisioningAccountPasswordNeverExpires
                       ProvisioningAccountCheckedAt=$s.ProvisioningAccountCheckedAt
                    } | ConvertTo-Json | Set-Content -Path $sf -Encoding UTF8
                    $stateAction = 'Retained (closeout pending)'
                    Log 'State file rewritten: closeout pending (resume-safe).'
                } catch { $stateAction = 'Failed'; Log "Closeout state write failed: $_" 'WARN' }
            } else {
                if (Test-Path $sf) {
                    Remove-Item $sf -Force -ErrorAction SilentlyContinue
                    $stateAction = if (Test-Path $sf) { 'Failed' } else { 'Removed' }
                    Log "State file removal: $stateAction."
                }
            }

            $now = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
            $isSummerLink = -not [string]::IsNullOrWhiteSpace("$($s.RelatedSummerRunId)")
            if ($isSummerLink) {
                # Summer-linked: do NOT close the record here. Mark it Awaiting Closeout; the
                # final linked PanelLog event (which closes it) is posted from the closeout screen
                # only after the tech confirms all five checks.
                $d = @{
                    LogSheet           = 'Summer2026'
                    ProjectRunId       = $s.RelatedSummerRunId
                    ProjectStatus      = 'Provisioning In Progress'
                    ProvisioningStatus = 'Domain Join Complete - Awaiting Closeout'
                    ReimageStatus      = 'Complete'
                    DomainJoinStatus   = 'Success'
                    PhaseBStatus       = 'Complete'
                    PhaseBCompletedAt  = $now
                    CurrentStage       = 'Provisioning'
                    RunId              = $s.RunId
                    ProvisioningTech   = $s.TechName
                    CurrentOPSSerial   = $s.OPSSerial
                    OPSReplacementConfirmed = $s.OPSReplacementConfirmed
                    # v5.5.1 ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§13: Phase B is the most important observation in the lifecycle - it
                    # happens after the rename reboot and the join. It must carry the full endpoint
                    # state, not just status flags, or the Summer row and current inventory keep
                    # showing the pre-provisioning hostname and WORKGROUP.
                    Hostname           = $s.Hostname          # live post-rename name
                    ProvisionedHostname = $s.Hostname
                    AssessmentHostname = $s.AssessmentHostname
                    PanelSerial        = $s.PanelSerial
                    OPSSerial          = $s.OPSSerial
                    SchoolCode         = $s.SchoolCode
                    SchoolName         = $s.SchoolName
                    Room               = $s.Room
                    RoomType           = $s.RoomType
                    OtherRoomType      = $s.OtherRoomType
                    Manufacturer       = $s.Manufacturer
                    PanelModel         = $s.PanelModel
                    MountType          = $s.MountType
                    InstallType        = $s.InstallType
                    # ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§11 pre-provisioning observation is preserved under its own name
                    PreProvisionDomainMembershipStatus = $s.DomainMembershipStatus
                    PreProvisionDetectedDomain         = $s.DetectedDomain
                    # ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§12 the provisioning RESULT
                    DomainJoinTargetDomain      = $s.DomainJoinTargetDomain
                    DomainJoinCompletedAt       = $s.DomainJoinCompletedAt
                    PostJoinMembershipStatus    = $s.PostJoinMembershipStatus
                    PostJoinSecureChannelStatus = $s.PostJoinSecureChannelStatus
                    DomainMembershipStatus      = $s.PostJoinMembershipStatus
                    DetectedDomain              = $s.DomainJoinTargetDomain
                    SecureChannelStatus         = $s.PostJoinSecureChannelStatus
                    ScriptVersion               = $s.ScriptVersion
                    # ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§38: WU recovery cleanup - VERIFIED results, not assumptions (review fix #13)
                    WURecoveryTaskStatus  = $(if ($wuTaskGone) { 'Removed' } else { 'Failed to Remove' })
                    WURecoveryRemovedAt   = $wuRemovedAt
                    WindowsUpdateRestored = $(if ($wuRestored) { 'TRUE' } else { 'FALSE' })
                    PhaseBTaskRemoved     = $(if ($pbTaskGone) { 'TRUE' } else { 'FALSE' })
                    StateFileFinalAction  = $stateAction
                    ProvisioningAccount = $s.ProvisioningAccount
                    ProvisioningAccountPreflight = $s.ProvisioningAccountPreflight
                    ProvisioningAccountEnabled = $s.ProvisioningAccountEnabled
                    ProvisioningAccountPasswordNeverExpires = $s.ProvisioningAccountPasswordNeverExpires
                    ProvisioningAccountCheckedAt = $s.ProvisioningAccountCheckedAt
                    LastUpdatedBy      = $s.TechName
                    LastUpdatedAt      = $now
                    TechName           = $s.TechName
                    Timestamp          = $now
                }
                $evtType = 'PhaseBCompleted'
            } else {
                $d = @{
                    Mode         = $s.ModeLabel
                    RunId        = $s.RunId
                    SchoolCode   = $s.SchoolCode
                    Room         = $s.Room
                    RoomType     = $s.RoomType
                    OtherRoomType = $s.OtherRoomType
                    MountType    = $s.MountType
                    PanelSerial  = $s.PanelSerial
                    OPSSerial    = $s.OPSSerial
                    OldPanelSerial = $(if ($s.InventoryPreviousPanelSerial) { $s.InventoryPreviousPanelSerial } else { $s.RMAPreviousPanelSerial })
                    PreviousPanelSerial = $(if ($s.InventoryPreviousPanelSerial) { $s.InventoryPreviousPanelSerial } else { $s.RMAPreviousPanelSerial })
                    RMAAction = $s.RMAAction
                    InventoryReassignmentConfirmed = $(if ($s.InventoryReassignmentConfirmed -or $s.RMAReassignmentConfirmed) { 'TRUE' } else { 'FALSE' })
                    InventoryReassignmentType = $(if ($s.InventoryReassignmentType) { $s.InventoryReassignmentType } elseif ($s.RMAAction) { 'RMAReplacement' } else { '' })
                    InventoryReassignmentReason = $(if ($s.InventoryReassignmentReason) { $s.InventoryReassignmentReason } elseif ($s.RMAReassignmentConfirmed) { 'Confirmed physical RMA/warranty panel replacement reusing the OPS' } else { '' })
                    TemporaryAssignment = $(if ($s.TemporaryAssignment) { 'TRUE' } else { 'FALSE' })
                    FollowUpRequired = $(if ($s.FollowUpRequired) { 'TRUE' } else { 'FALSE' })
                    StorageGB    = $s.StorageGB
                    Hostname     = $s.Hostname
                    Manufacturer = $s.Manufacturer
                    PanelModel   = $s.PanelModel
                    Notes        = $s.OPSTruncNote
                    Result       = 'Complete - Domain Joined'
                    OldHostname  = $s.PreviousHostname
                    PreviousHostname       = $s.PreviousHostname
                    PreviousHostnameSource = $s.PreviousHostnameSource
                    OldHostnameCheckResult = $s.OldHostnameCheckResult
                    NewHostnameCheckResult = $s.NewHostnameCheckResult
                    SelectedHostnameSuffix = $s.SelectedHostnameSuffix
                    PhaseBStatus = 'Complete'
                    DomainJoinStatus = 'Success'
                    # v5.5.1 ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§11/ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§12: result fields, and the pre-provisioning observation kept apart
                    PreProvisionDomainMembershipStatus = $s.DomainMembershipStatus
                    PreProvisionDetectedDomain         = $s.DetectedDomain
                    DomainJoinTargetDomain      = $s.DomainJoinTargetDomain
                    DomainJoinCompletedAt       = $s.DomainJoinCompletedAt
                    PostJoinMembershipStatus    = $s.PostJoinMembershipStatus
                    PostJoinSecureChannelStatus = $s.PostJoinSecureChannelStatus
                    DomainMembershipStatus      = $s.PostJoinMembershipStatus
                    DetectedDomain              = $s.DomainJoinTargetDomain
                    SecureChannelStatus         = $s.PostJoinSecureChannelStatus
                    WURecoveryTaskStatus  = $(if ($wuTaskGone) { 'Removed' } else { 'Failed to Remove' })
                    WURecoveryRemovedAt   = $wuRemovedAt
                    WindowsUpdateRestored = $(if ($wuRestored) { 'TRUE' } else { 'FALSE' })
                    PhaseBTaskRemoved     = $(if ($pbTaskGone) { 'TRUE' } else { 'FALSE' })
                    StateFileFinalAction  = $stateAction
                    TechName     = $s.TechName
                    Timestamp    = $now
                }
                $evtType = 'PhaseBCompleted'
            }
            # v5.5 finding #1: one shared sender - it handles the POST, response parsing,
            # retryable-vs-permanent classification and the offline queue write.
            $pbRes = Post-Log $d $evtType
            # v5.5 finding #1 (round 3): persist the revision Phase B just advanced. A relaunch
            # between Phase B and closeout would otherwise restore the PRE-Phase-B revision and
            # the closeout post would be rejected as stale.
            # r8 finding #1: record the BACKEND outcome, not just the local step. The startup
            # closeout route requires PhaseBBackendStatus to be Applied or Queued, so a rejected
            # Phase B can never become closeout-eligible on the next launch.
            try {
                $sf = Join-Path $s.ProvisioningDir 'state.json'
                if (Test-Path $sf) {
                    $st = Get-Content $sf -Raw | ConvertFrom-Json
                    $st | Add-Member -NotePropertyName ProjectStateRevision    -NotePropertyValue "$($s.ProjectStateRevision)"    -Force
                    $st | Add-Member -NotePropertyName ProjectStateRevisionFor -NotePropertyValue "$($s.ProjectStateRevisionFor)" -Force
                    $st | Add-Member -NotePropertyName EventSequence           -NotePropertyValue "$($s.EventSequence)"           -Force
                    $st | Add-Member -NotePropertyName ClientSessionId         -NotePropertyValue "$($s.ClientSessionId)"         -Force
                    if ($pbRes -and $pbRes.Rejected) {
                        $st | Add-Member -NotePropertyName PhaseBBackendStatus -NotePropertyValue 'Rejected' -Force
                        $st | Add-Member -NotePropertyName FinalCloseoutStatus -NotePropertyValue 'Blocked'  -Force
                        $st | Add-Member -NotePropertyName PhaseBBackendErrorCode    -NotePropertyValue "$(if ($pbRes.Parsed) { $pbRes.Parsed.ErrorCode })" -Force
                        $st | Add-Member -NotePropertyName PhaseBBackendErrorMessage -NotePropertyValue "$(if ($pbRes.Parsed) { $pbRes.Parsed.Message })"   -Force
                    } elseif ($pbRes -and $pbRes.Queued) {
                        $st | Add-Member -NotePropertyName PhaseBBackendStatus -NotePropertyValue 'Queued'  -Force
                        $st | Add-Member -NotePropertyName FinalCloseoutStatus -NotePropertyValue 'Pending' -Force
                        $st | Add-Member -NotePropertyName PendingPhaseBEventId -NotePropertyValue "$($d['EventId'])" -Force
                    } else {
                        $st | Add-Member -NotePropertyName PhaseBBackendStatus -NotePropertyValue 'Applied' -Force
                        $st | Add-Member -NotePropertyName FinalCloseoutStatus -NotePropertyValue 'Pending' -Force
                    }
                    $st | ConvertTo-Json -Depth 12 | Set-Content -Path $sf -Encoding UTF8
                }
            } catch { Log "Could not persist the post-Phase-B backend outcome: $_" 'WARN' }

            # r5 finding #3: a PERMANENT rejection means the spreadsheet did NOT record Phase B.
            # Do not advance to closeout and do not touch state.json - the technician needs the
            # local resume state and a lead needs to see the rejection.
            if ($pbRes -and $pbRes.Rejected) {
                $why = if ($pbRes.Parsed) { "$($pbRes.Parsed.ErrorCode): $($pbRes.Parsed.Message)" } else { 'permanent rejection' }
                Log "Phase B was NOT recorded in the spreadsheet ($why). Holding at Phase B." 'ERROR'
                PBStatus 'Domain join done, but the spreadsheet REJECTED the update.' '#EF5B5B'
                try { $s.UI['pbarPhaseB'].Dispatcher.Invoke([action]{
                    $s.UI['pbarPhaseB'].IsIndeterminate = $false; $s.UI['pbarPhaseB'].Value = 100
                    if ($s.UI['btnPhaseBReportIssue']) { $s.UI['btnPhaseBReportIssue'].Visibility = [System.Windows.Visibility]::Visible }
                    [System.Windows.MessageBox]::Show(
                        "The domain join finished, but the spreadsheet did not accept the Phase B update.`n`n$why`n`n" +
                        "This panel's project has NOT been advanced. Do not close it out. Report this to a lead - " +
                        "the local provisioning state has been kept so the work can be resumed.",
                        'Phase B Not Recorded', 'OK', 'Error') | Out-Null
                }) } catch {}
                return
            }
            if ($pbRes -and $pbRes.Queued) {
                Log 'Phase B recorded locally and queued - the spreadsheet has not confirmed it yet.' 'WARN'
                PBStatus 'Domain join complete (spreadsheet update pending sync).' '#F0B030'
            }

            $isSummer = -not [string]::IsNullOrWhiteSpace("$($s.RelatedSummerRunId)")
            try { $s.UI['pbarPhaseB'].Dispatcher.Invoke([action]{
                $s.UI['pbarPhaseB'].IsIndeterminate = $false
                $s.UI['pbarPhaseB'].Value = 100
                if ($isSummer) {
                    # Summer-linked reimage: go to the short reimage closeout instead of the plain reboot
                    $sch = if ($s.SchoolName) { "$($s.SchoolCode) - $($s.SchoolName)" } else { "$($s.SchoolCode)" }
                    $s.UI['lblCloseoutContext'].Text =
                        "School: $sch    Room: $($s.Room)`nPanel serial: $($s.PanelSerial)    Hostname: $($s.Hostname)`nProjectRunId: $($s.RelatedSummerRunId)"
                    $s.UI['lblCloseoutTitle'].Text = if ($s.NewInstallProvisioning) { 'New Install Provisioning Closeout' }
                                                     elseif ($s.RecoveryProvisioning) { 'Post-RedoRescue Closeout' }
                                                     else { 'Existing Panel Provisioning Closeout' }
                    $s.UI['pnlPhaseB'].Visibility = [System.Windows.Visibility]::Collapsed
                    $s.UI['pnlReimageCloseout'].Visibility = [System.Windows.Visibility]::Visible
                } else {
                    $s.UI['btnPhaseBReboot'].Visibility = [System.Windows.Visibility]::Visible
                }
            }) } catch {}
            PBStatus 'Domain join complete.' '#4EC994'
        } catch {
            Log "Phase B error: $_" 'ERROR'
            # v5.3 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§18: map common domain-join failures to clearer technician guidance.
            $errText = "$_"
            $friendly = if ($errText -match 'already exists|account .*exist') { 'Hostname may already exist in AD. Try the alternate hostname option if available. If the same error repeats, escalate.' }
                        elseif ($errText -match 'already .*join|already a member|already in') { 'Device may already be joined. Verify the current domain status before retrying.' }
                        elseif ($errText -match 'Access is denied|access denied|credential|password|logon failure') { 'The account may not have domain-join rights or the AD object may be blocking the join. Try the correct field tech/domain-join account.' }
                        elseif ($errText -match 'network path|could not be found|no logon server|domain controller|DNS|specified domain') { 'Check Ethernet, DNS, and domain reachability, then retry.' }
                        else { "Domain join failed: $errText" }
            try { $s.UI['pbarPhaseB'].Dispatcher.Invoke([action]{
                $s.UI['pbarPhaseB'].IsIndeterminate = $false
                $s.UI['btnJoinDomain'].IsEnabled = $true
                if ($s.UI['btnPhaseBReportIssue']) { $s.UI['btnPhaseBReportIssue'].Visibility = [System.Windows.Visibility]::Visible }
            }) } catch {}
            PBStatus $friendly '#EF5B5B'
            # Record the failure; never close the Summer record on a failed join.
            $now = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
            Post-Log @{ Mode=$s.ModeLabel; RunId=$s.RunId; PanelSerial=$s.PanelSerial; OPSSerial=$s.OPSSerial
                Hostname=$s.Hostname; SchoolCode=$s.SchoolCode; Room=$s.Room; RoomType=$s.RoomType; OtherRoomType=$s.OtherRoomType
                PhaseBStatus='Failed'; DomainJoinStatus='Failed'
                Result='Failed - Domain Join'; ProvisioningOutcome=$friendly; ErrorMessage=$errText; ErrorAt=$now; ErrorBy=$s.TechName } 'PhaseBFailed'
            if ($s.RelatedSummerRunId) {
                Post-Log @{ LogSheet='Summer2026'; ProjectRunId=$s.RelatedSummerRunId
                    ProjectStatus='Exception Open'; PhaseBStatus='Failed'; DomainJoinStatus='Failed'
                    ExceptionStatus='Open'; ErrorMessage=$errText; ErrorAt=$now; ErrorBy=$s.TechName
                    LastUpdatedBy=$s.TechName; LastUpdatedAt=$now } 'PhaseBFailed'
            }
        }
    })
    [void]$ps.BeginInvoke()
}

# ================================================================
#  v5.7 ENDPOINT REPAIR / LOOKUP / CLOSEOUT HELPERS
# ================================================================
function Show-EndpointRepairScreen {
    $script:EndpointRepairAction = ''
    $script:UI['lblModeDisplay'].Text = 'Endpoint Repair'
    Show-Screen 'pnlEndpointRepair'
    Set-Status 'Select the Windows identity repair that is actually required.'
}

function Start-EndpointRepair {
    param([ValidateSet('RenameOnly','DomainJoinOnly','RenameAndJoin')][string]$Action)
    $script:EndpointRepairAction = $Action
    $script:EndpointRepairStage = ''
    $script:EndpointRepairOriginalHostname = $env:COMPUTERNAME.ToUpperInvariant()
    $script:EndpointRepairExpectedHostname = ''
    $script:EndpointRepairDomainState = ''
    $script:InstallType = 'Existing Panel'
    $script:NewInstallProvisioning = $false
    $script:RecoveryProvisioning = $false
    $label = switch ($Action) {
        'RenameOnly'     { 'Endpoint Repair - Rename Device Only' }
        'DomainJoinOnly' { 'Endpoint Repair - Join Domain Only' }
        default          { 'Endpoint Repair - Rename + Join Domain' }
    }
    Set-Mode 9 $label
    Show-OPSScreen
}

function Save-EndpointRepairState {
    param([string]$Stage)
    $script:EndpointRepairStage = $Stage
    $statePath = Join-Path $script:ProvisioningDir 'state.json'
    if (-not (Test-Path $statePath)) { Write-StateFile }
    $st = Get-Content $statePath -Raw | ConvertFrom-Json
    $st | Add-Member -NotePropertyName EndpointRepairAction -NotePropertyValue $script:EndpointRepairAction -Force
    $st | Add-Member -NotePropertyName EndpointRepairStage -NotePropertyValue $Stage -Force
    $st | Add-Member -NotePropertyName EndpointRepairOriginalHostname -NotePropertyValue $script:EndpointRepairOriginalHostname -Force
    $st | Add-Member -NotePropertyName EndpointRepairExpectedHostname -NotePropertyValue $script:EndpointRepairExpectedHostname -Force
    $st | Add-Member -NotePropertyName EndpointRepairDomainState -NotePropertyValue $script:EndpointRepairDomainState -Force
    $st | Add-Member -NotePropertyName PhaseAStatus -NotePropertyValue 'Complete' -Force
    $st | Add-Member -NotePropertyName PhaseACompletedAt -NotePropertyValue (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') -Force
    $st | ConvertTo-Json -Depth 12 | Set-Content -Path $statePath -Encoding UTF8
}

function Restore-EndpointRepairState {
    param($State)
    $script:CurrentMode = 9
    $script:ModeLabel = "$($State.Mode)"
    $script:TechName = "$($State.TechName)"
    $script:SchoolCode = "$($State.SchoolCode)"; $script:SchoolName = "$($State.SchoolName)"
    $script:RoomNumber = "$($State.Room)"; $script:RoomType = "$($State.RoomType)"; $script:OtherRoomType = "$($State.OtherRoomType)"
    $script:Manufacturer = "$($State.Manufacturer)"; $script:PanelModel = "$($State.PanelModel)"; $script:MountType = "$($State.MountType)"
    $script:PanelSerial = "$($State.PanelSerial)"; $script:OPSSerial = "$($State.OPSSerial)"; $script:Hostname = "$($State.Hostname)"
    $script:RunId = "$($State.RunId)"; if ($State.UsbRoot) { $script:UsbRoot = "$($State.UsbRoot)" }
    $script:EndpointRepairAction = "$($State.EndpointRepairAction)"
    $script:EndpointRepairStage = "$($State.EndpointRepairStage)"
    $script:EndpointRepairOriginalHostname = "$($State.EndpointRepairOriginalHostname)"
    $script:EndpointRepairExpectedHostname = "$($State.EndpointRepairExpectedHostname)"
    $script:EndpointRepairDomainState = "$($State.EndpointRepairDomainState)"
    if (-not $script:EndpointRepairExpectedHostname) { $script:EndpointRepairExpectedHostname = "$($State.Hostname)" }
    $script:UI['lblTechDisplay'].Text = "Tech: $($script:TechName)"
    $script:UI['lblModeDisplay'].Text = $script:ModeLabel
}

function Write-EndpointRepairAudit {
    param([string]$Outcome,[string]$Details = '')
    Get-DomainMembership | Out-Null
    $payload = @{
        LogSheet='PanelLog'; Mode=$script:ModeLabel; ActionType=$script:ModeLabel
        RunId=$script:RunId; TechName=$script:TechName; Timestamp=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
        SchoolCode=$script:SchoolCode; Room=$script:RoomNumber; RoomType=$script:RoomType; OtherRoomType=$script:OtherRoomType
        Manufacturer=$script:Manufacturer; PanelModel=$script:PanelModel; MountType=$script:MountType
        PanelSerial=$script:PanelSerial; OPSSerial=$script:OPSSerial
        Hostname=$env:COMPUTERNAME; PreviousHostname=$script:EndpointRepairOriginalHostname
        DomainMembershipStatus=$script:DomainMembershipStatus; DetectedDomain=$script:DetectedDomain; SecureChannelStatus=$script:SecureChannelStatus
        ProvisioningOutcome=$Outcome; Result=$Outcome; Notes=$Details
    }
    return (Send-Event -Payload $payload -EventType 'EndpointRepairCompleted')
}

function Complete-EndpointRepair {
    param([string]$Outcome = 'Endpoint Repair Complete',[string]$Details = '')
    $res = Write-EndpointRepairAudit -Outcome $Outcome -Details $Details
    Remove-PhaseBTask
    $statePath = Join-Path $script:ProvisioningDir 'state.json'
    if (Test-Path $statePath) {
        $suffix = if ($res -and $res.Rejected) { 'rejected' } else { 'complete' }
        Move-Item $statePath (Join-Path $script:ProvisioningDir ("state.endpointrepair_{0}_{1}.json" -f $suffix,(Get-Date -Format 'yyyyMMdd_HHmmss'))) -Force
    }
    $script:UI['lblCompleteTitle'].Text = if ($res -and $res.Rejected) { 'Endpoint Repair Completed - Audit Not Recorded' } else { 'Endpoint Repair Complete' }
    $script:UI['lblCompleteMessage'].Text = if ($res -and $res.Rejected) {
        "The Windows repair completed locally, but the backend rejected the audit record. Do not repeat the repair. Report the audit failure to a lead.`n`n$Details"
    } elseif ($res -and $res.Queued) {
        "The Windows repair is complete. The audit event is safely queued and will synchronize when PanelApp connectivity returns.`n`n$Details"
    } else { "$Outcome`n`n$Details" }
    Show-Screen 'pnlComplete'
    Set-Status $script:UI['lblCompleteTitle'].Text
}

function Show-EndpointRepairReview {
    Get-DomainMembership | Out-Null
    $script:UI['spReviewItems'].Children.Clear()
    $script:UI['lblReviewTitle'].Text = 'Endpoint Repair'
    $script:UI['borReviewWarning'].Visibility = 'Visible'
    $script:UI['lblReviewWarning'].Text = 'Endpoint Repair changes Windows identity/domain state only. It will not reimage the OPS, upgrade Windows, install software, or reassign inventory.'
    Add-ReviewRow 'Repair Action' $script:ModeLabel '#CDBBE3'
    Add-ReviewRow 'Technician' $script:TechName
    Add-ReviewRow 'Panel Serial' $script:PanelSerial
    Add-ReviewRow 'OPS Serial' $script:OPSSerial
    Add-ReviewRow 'School / Room' "$($script:SchoolCode) $($script:RoomNumber)"
    Add-ReviewRow 'Current Hostname' $env:COMPUTERNAME
    Add-ReviewRow 'Expected Hostname' $script:EndpointRepairExpectedHostname '#4EC994'
    Add-ReviewRow 'Domain State' "$($script:DomainMembershipStatus) / $($script:DetectedDomain)"
    Add-ReviewRow 'Secure Channel' $script:SecureChannelStatus
    $script:UI['btnReviewExecute'].Content = 'Start Endpoint Repair'
    Show-Screen 'pnlReview'
}

function Continue-EndpointRepairAfterLocation {
    $script:EndpointRepairExpectedHostname = Build-Hostname -SchoolCode $script:SchoolCode -MfrCode $script:MfrCode -MountType $script:MountType -Room $script:RoomNumber -PanelSerial $script:PanelSerial
    Get-DomainMembership | Out-Null
    if ($script:EndpointRepairAction -eq 'DomainJoinOnly') {
        if ($env:COMPUTERNAME -ine $script:EndpointRepairExpectedHostname) {
            [System.Windows.MessageBox]::Show(
                "Join Domain Only cannot continue because this device is not named as expected for the selected panel/location.`n`nCurrent: $env:COMPUTERNAME`nExpected: $($script:EndpointRepairExpectedHostname)`n`nUse Endpoint Repair -> Rename + Join Domain instead.",
                'Rename Also Required','OK','Warning') | Out-Null
            Show-EndpointRepairScreen
            return
        }
        $script:Hostname = $env:COMPUTERNAME.ToUpperInvariant()
        $script:PreviousHostname = $script:Hostname
        Show-EndpointRepairReview
        return
    }
    Show-HostnameScreen
}

function Prepare-EndpointDomainPrompt {
    Get-DomainMembership | Out-Null
    $target = "$($script:Config.Domain)"
    if ($script:DomainMembershipStatus -eq 'Unknown') {
        [System.Windows.MessageBox]::Show('PanelApp could not determine the current domain membership state. Endpoint Repair stopped before making a domain change.','Domain State Unknown','OK','Warning') | Out-Null
        return
    }
    if ($script:DomainMembershipStatus -eq 'Domain Joined' -and $script:DetectedDomain -and $script:DetectedDomain -ine $target) {
        [System.Windows.MessageBox]::Show("This device is joined to '$($script:DetectedDomain)', not '$target'. PanelApp will not automatically move a computer between domains. Contact a lead for manual review.",'Different Domain Detected','OK','Warning') | Out-Null
        return
    }
    if ($script:DomainMembershipStatus -eq 'Domain Joined' -and $script:SecureChannelStatus -eq 'Healthy') {
        Complete-EndpointRepair -Outcome 'No Repair Required' -Details "This device is already joined to $target and the secure channel is healthy."
        return
    }
    if ($script:DomainMembershipStatus -eq 'Domain Joined') {
        $script:EndpointRepairDomainState = 'Domain Membership Repair Required'
        $script:UI['btnJoinDomain'].Content = 'Repair Domain Membership'
        $script:UI['lblPhaseBStatus'].Text = 'Domain Membership Repair Required'
    } else {
        $script:EndpointRepairDomainState = 'Domain Join Required'
        $script:UI['btnJoinDomain'].Content = 'Join APS Domain'
        $script:UI['lblPhaseBStatus'].Text = 'Ready to join domain.'
    }
    Save-EndpointRepairState -Stage 'DomainAction'
    Register-PhaseBTask
    $script:UI['btnJoinDomain'].Visibility = 'Visible'; $script:UI['btnJoinDomain'].IsEnabled = $true
    $script:UI['btnPhaseBReboot'].Visibility = 'Collapsed'
    $script:UI['btnPhaseBReportIssue'].Visibility = 'Collapsed'
    $script:UI['txtDomainUser'].Text = ''; $script:UI['pwbDomainPass'].Password = ''; $script:UI['txtDomainPassVisible'].Text = ''
    $script:UI['txtPhaseBInfo'].Text = "Endpoint Repair`nAction     : $($script:ModeLabel)`nHostname   : $env:COMPUTERNAME`nExpected   : $($script:EndpointRepairExpectedHostname)`nDomain     : $($script:DomainMembershipStatus) / $($script:DetectedDomain)`nSecure Ch. : $($script:SecureChannelStatus)`nTarget     : $target`nOU         : $($script:Config.DomainOU)"
    Show-Screen 'pnlPhaseB'
}

function Execute-EndpointRepair {
    if ($script:EndpointRepairAction -eq 'DomainJoinOnly') { Prepare-EndpointDomainPrompt; return }
    $desired = "$($script:Hostname)".ToUpperInvariant()
    $script:EndpointRepairExpectedHostname = $desired
    if ($env:COMPUTERNAME -ieq $desired) {
        if ($script:EndpointRepairAction -eq 'RenameOnly') {
            Complete-EndpointRepair -Outcome 'No Repair Required' -Details "The device is already named $desired."
        } else { Prepare-EndpointDomainPrompt }
        return
    }
    $pre = Invoke-ProvisioningAccountPreflight
    if (-not $pre.Success) {
        [System.Windows.MessageBox]::Show("Endpoint Repair stopped before rename because the temporary provisioning account could not be prepared.`n`n$($pre.Error)",'Endpoint Repair Preflight Failed','OK','Error') | Out-Null
        return
    }
    $script:EndpointRepairOriginalHostname = $env:COMPUTERNAME.ToUpperInvariant()
    Save-EndpointRepairState -Stage 'VerifyRename'
    Register-PhaseBTask
    try {
        Write-Log "Endpoint Repair: renaming $env:COMPUTERNAME -> $desired" 'STEP'
        Rename-Computer -NewName $desired -Force -ErrorAction Stop
        $stp = Join-Path $script:ProvisioningDir 'state.json'
        if (Test-Path $stp) {
            $st = Get-Content $stp -Raw | ConvertFrom-Json
            $st | Add-Member -NotePropertyName Hostname -NotePropertyValue $desired -Force
            $st | Add-Member -NotePropertyName EndpointRepairStage -NotePropertyValue 'VerifyRename' -Force
            $st | ConvertTo-Json -Depth 12 | Set-Content $stp -Encoding UTF8
        }
        [System.Windows.MessageBox]::Show("Rename prepared successfully.`n`nCurrent: $($script:EndpointRepairOriginalHostname)`nNew: $desired`n`nPanelApp will restart the OPS and verify the new hostname before continuing.",'Endpoint Repair - Restarting','OK','Information') | Out-Null
        Restart-Computer -Force
    } catch {
        Write-Log "Endpoint Repair rename failed: $_" 'ERROR'
        Remove-PhaseBTask
        [System.Windows.MessageBox]::Show("The rename failed. No domain action was attempted.`n`n$_",'Endpoint Repair Failed','OK','Error') | Out-Null
    }
}

function Execute-EndpointRepairDomainAction {
    param([string]$DomainUser,[System.Security.SecureString]$SecurePwd)
    $script:UI['btnJoinDomain'].IsEnabled = $false
    $script:UI['pbarPhaseB'].IsIndeterminate = $true
    $script:UI['lblPhaseBStatus'].Text = if ($script:EndpointRepairDomainState -eq 'Domain Membership Repair Required') { 'Repairing domain membership...' } else { 'Joining APS domain...' }
    $script:window.Dispatcher.Invoke([action]{},[System.Windows.Threading.DispatcherPriority]::Render)
    try {
        if ($script:EndpointRepairDomainState -eq 'Domain Membership Repair Required') {
            $cred = New-Object System.Management.Automation.PSCredential("$($script:Config.Domain)\$DomainUser",$SecurePwd)
            $ok = Test-ComputerSecureChannel -Repair -Credential $cred -ErrorAction Stop
            if (-not $ok) { throw 'Test-ComputerSecureChannel reported that the repair did not succeed.' }
            Write-Log 'Endpoint Repair: domain secure channel repair command succeeded.' 'STEP'
        } else {
            Join-APSDomain -DomainUser $DomainUser -SecurePwd $SecurePwd
            Write-Log 'Endpoint Repair: Add-Computer domain join command succeeded.' 'STEP'
        }
        Save-EndpointRepairState -Stage 'VerifyDomain'
        $script:UI['pbarPhaseB'].IsIndeterminate = $false
        $script:UI['lblPhaseBStatus'].Text = 'Domain action complete. Reboot to verify membership and secure channel.'
        $script:UI['btnJoinDomain'].Visibility = 'Collapsed'
        $script:UI['btnPhaseBReboot'].Visibility = 'Visible'
        $script:UI['btnPhaseBReboot'].Content = 'Reboot and Verify'
    } catch {
        Write-Log "Endpoint Repair domain action failed: $_" 'ERROR'
        $script:UI['pbarPhaseB'].IsIndeterminate = $false
        $script:UI['btnJoinDomain'].IsEnabled = $true
        $script:UI['lblPhaseBStatus'].Text = "Domain repair failed: $_"
        $script:UI['btnPhaseBReportIssue'].Visibility = 'Visible'
    }
}

function Invoke-EndpointRepairResume {
    param($State)
    Restore-EndpointRepairState $State
    switch ("$($State.EndpointRepairStage)") {
        'VerifyRename' {
            if ($env:COMPUTERNAME -ine "$($State.EndpointRepairExpectedHostname)") {
                $script:UI['lblCompleteTitle'].Text = 'Endpoint Repair Verification Failed'
                $script:UI['lblCompleteMessage'].Text = "The OPS rebooted, but the hostname does not match the requested name.`n`nExpected: $($State.EndpointRepairExpectedHostname)`nCurrent: $env:COMPUTERNAME`n`nThe repair state has been retained. Report this to a lead before trying again."
                Show-Screen 'pnlComplete'; return
            }
            if ($script:EndpointRepairAction -eq 'RenameOnly') {
                Complete-EndpointRepair -Outcome 'Rename Verified' -Details "Hostname changed from $($script:EndpointRepairOriginalHostname) to $env:COMPUTERNAME and was verified after reboot."
            } else {
                Prepare-EndpointDomainPrompt
            }
        }
        'VerifyDomain' {
            Get-DomainMembership | Out-Null
            $target = "$($script:Config.Domain)"
            if ($script:DomainMembershipStatus -eq 'Domain Joined' -and $script:DetectedDomain -ieq $target -and $script:SecureChannelStatus -eq 'Healthy') {
                Complete-EndpointRepair -Outcome 'Domain Membership Verified' -Details "Hostname: $env:COMPUTERNAME`nDomain: $target`nSecure channel: Healthy"
            } else {
                $script:EndpointRepairDomainState = 'Domain Membership Repair Required'
                $script:UI['lblPhaseBStatus'].Text = 'Domain Membership Repair Required'
                $script:UI['txtPhaseBInfo'].Text = "Post-reboot verification did not pass.`n`nHostname: $env:COMPUTERNAME`nDomain: $($script:DetectedDomain)`nMembership: $($script:DomainMembershipStatus)`nSecure channel: $($script:SecureChannelStatus)`n`nThe repair state has been retained. Retry the domain repair only after verifying network/DNS connectivity."
                $script:UI['btnJoinDomain'].Content = 'Repair Domain Membership'
                $script:UI['btnJoinDomain'].Visibility = 'Visible'; $script:UI['btnJoinDomain'].IsEnabled = $true
                $script:UI['btnPhaseBReboot'].Visibility = 'Collapsed'
                Show-Screen 'pnlPhaseB'
            }
        }
        default { Prepare-EndpointDomainPrompt }
    }
}

function Select-InventorySchoolRoomCandidate {
    param([object[]]$Candidates)
    $w = New-Object System.Windows.Window
    $w.Title = 'Select Panel in This Room'; $w.Width = 720; $w.Height = 420; $w.WindowStartupLocation = 'CenterOwner'; $w.Owner = $script:window
    $w.Background = New-Brush '#171717'; $w.Foreground = New-Brush '#FFFFFF'
    $grid = New-Object System.Windows.Controls.Grid
    $grid.Margin = '18'
    $grid.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{Height='Auto'}))
    $grid.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{Height='*'}))
    $grid.RowDefinitions.Add((New-Object System.Windows.Controls.RowDefinition -Property @{Height='Auto'}))
    $title = New-Object System.Windows.Controls.TextBlock
    $title.Text = 'More than one panel is recorded in this school/room. That is valid. Select the physical panel you are correcting.'; $title.TextWrapping='Wrap'; $title.Margin='0,0,0,12'; $title.FontSize=13
    [System.Windows.Controls.Grid]::SetRow($title,0); $grid.Children.Add($title) | Out-Null
    $list = New-Object System.Windows.Controls.ListBox; $list.Background=New-Brush '#222222'; $list.Foreground=New-Brush '#FFFFFF'
    foreach ($c in $Candidates) {
        $it = New-Object System.Windows.Controls.ListBoxItem
        $it.Content = "Panel $($c.PanelSerial)  |  OPS $($c.CurrentOPSSerial)  |  Host $($c.CurrentHostname)  |  $($c.SchoolCode) $($c.Room)"
        $it.Tag = $c; $it.Padding='8'; $list.Items.Add($it) | Out-Null
    }
    [System.Windows.Controls.Grid]::SetRow($list,1); $grid.Children.Add($list) | Out-Null
    $buttons = New-Object System.Windows.Controls.StackPanel; $buttons.Orientation='Horizontal'; $buttons.HorizontalAlignment='Right'; $buttons.Margin='0,12,0,0'
    $cancel = New-Object System.Windows.Controls.Button; $cancel.Content='Cancel'; $cancel.Width=100; $cancel.Margin='0,0,8,0'
    $ok = New-Object System.Windows.Controls.Button; $ok.Content='Use Selected Panel'; $ok.Width=160; $ok.IsDefault=$true
    $selected = $null
    $cancel.Add_Click({ $w.DialogResult=$false; $w.Close() })
    $ok.Add_Click({ if ($list.SelectedItem) { $script:__InvCandidate = $list.SelectedItem.Tag; $w.DialogResult=$true; $w.Close() } })
    $buttons.Children.Add($cancel) | Out-Null; $buttons.Children.Add($ok) | Out-Null
    [System.Windows.Controls.Grid]::SetRow($buttons,2); $grid.Children.Add($buttons) | Out-Null
    $w.Content=$grid; $script:__InvCandidate=$null; [void]$w.ShowDialog(); $selected=$script:__InvCandidate; $script:__InvCandidate=$null
    return $selected
}

function Update-InventoryLookupInputMode {
    $sel = $script:UI['cboInvLookupType'].SelectedItem
    $lt = if ($sel) { "$($sel.Tag)" } else { 'PanelSerial' }
    $isRoom = ($lt -eq 'SchoolRoom')
    $script:UI['txtInvLookupValue'].Visibility = if ($isRoom) { 'Collapsed' } else { 'Visible' }
    $script:UI['lblInvLookupValuePrompt'].Visibility = if ($isRoom) { 'Collapsed' } else { 'Visible' }
    $script:UI['pnlInvSchoolRoom'].Visibility = if ($isRoom) { 'Visible' } else { 'Collapsed' }
    if (-not $isRoom) {
        $script:UI['lblInvLookupValuePrompt'].Text = switch ($lt) {
            'OPSSerial' { 'SCAN OR ENTER OPS SERIAL' }
            'Hostname'  { 'ENTER HOSTNAME' }
            default     { 'SCAN OR ENTER PANEL SERIAL' }
        }
    }
}

function Submit-AndroidEthernetLowException {
    if ($script:AndroidEthernetExceptionReported) { return }
    $now = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $res = Send-Event -Payload @{
        LogSheet='PanelAppExceptions'; RunId=$script:RunId; ProjectRunId=$script:RelatedSummerRunId
        Technician=$script:TechName; TechName=$script:TechName; Mode=$script:ModeLabel
        Phase='Panel Readiness / Final Closeout'; IssueCategory='Android Ethernet'; Severity='Low'
        IssueDescription='Android Ethernet could not be made operational during the visit.'
        Notes='Android Ethernet could not be made operational during the visit. NDMS/Radix and the remaining closeout checks are evaluated separately.'
        SchoolCode=$script:SchoolCode; Room=$script:RoomNumber; PanelSerial=$script:PanelSerial; OPSSerial=$script:OPSSerial; Hostname=$script:Hostname
        ScriptVersion=$script:ScriptVersion; Timestamp=$now
    } -EventType 'Exception'
    if ($res.Rejected) {
        $script:UI['lblCoEthernetException'].Text = 'The low-priority Ethernet exception was rejected and was NOT recorded. Restore sync or report this to a lead before closeout.'
        $script:UI['lblCoEthernetException'].Foreground = New-Brush '#EF5B5B'; $script:UI['lblCoEthernetException'].Visibility='Visible'; return
    }
    $script:AndroidEthernetExceptionReported = $true
    $script:AndroidEthernetExceptionEventId = "$($res.EventId)"
    try {
        $sf = Join-Path $script:ProvisioningDir 'state.json'
        if (Test-Path $sf) {
            $st = Get-Content $sf -Raw | ConvertFrom-Json
            $st | Add-Member -NotePropertyName AndroidEthernetExceptionReported -NotePropertyValue $true -Force
            $st | Add-Member -NotePropertyName AndroidEthernetExceptionEventId -NotePropertyValue "$($res.EventId)" -Force
            $st | ConvertTo-Json -Depth 12 | Set-Content $sf -Encoding UTF8
        }
    } catch { Write-Log "Could not persist Android Ethernet exception state: $_" 'WARN' }
    $script:UI['lblCoEthernetException'].Text = if ($res.Queued) { 'Low-priority Android Ethernet exception saved and queued. Other closeout checks are still required.' } else { 'Low-priority Android Ethernet exception recorded. Other closeout checks are still required.' }
    $script:UI['lblCoEthernetException'].Foreground = New-Brush '#F0B030'; $script:UI['lblCoEthernetException'].Visibility='Visible'
    $script:UI['btnCoEthernetException'].IsEnabled = $false
}
# ================================================================
#  EVENT HANDLERS
# ================================================================


function Show-PanelActionFailure {
    param([string]$Message)
    Set-Status 'Action stopped. Review the error before continuing.'
    [System.Windows.MessageBox]::Show(
        "PanelApp stopped this action.`n`n$Message`n`nKeep the project and saved queue. Contact a lead if the error continues.",
        'PanelApp Action Stopped','OK','Error') | Out-Null
}
function Reset-PanelButtonInput {
    foreach ($entry in @($script:PanelButtonInputState)) {
        $entry.Control.IsHitTestVisible = $entry.HitTest
        $entry.Control.Focusable = $entry.Focusable
    }
    $script:PanelButtonInputState = @()
    $script:PanelButtonBusy = $false
}
function Schedule-PanelButtonRelease {
    # Retain the guard briefly so a second mouse click or scanner Enter cannot hit the next page.
    $script:PanelButtonReleaseTimer = New-Object System.Windows.Threading.DispatcherTimer
    $script:PanelButtonReleaseTimer.Interval = [TimeSpan]::FromMilliseconds(450)
    $script:PanelButtonReleaseTimer.Add_Tick({
        $script:PanelButtonReleaseTimer.Stop()
        Reset-PanelButtonInput
    })
    $script:PanelButtonReleaseTimer.Start()
}
function Invoke-PanelButtonAction {
    param([string]$Name, $Source, $EventArgs)
    if ($script:PanelButtonBusy -or -not $Source.IsEnabled -or -not $Source.IsVisible) {
        if ($EventArgs) { $EventArgs.Handled = $true }
        return
    }
    $script:PanelButtonBusy = $true
    $script:PanelButtonInputState = @()
    $oldLabel = $Source.Content
    try {
        foreach ($key in $script:PanelButtonActions.Keys) {
            $control = $script:UI[$key]
            if ($control) {
                $script:PanelButtonInputState += @{Control=$control;HitTest=$control.IsHitTestVisible;Focusable=$control.Focusable}
                $control.IsHitTestVisible = $false
                $control.Focusable = $false
            }
        }
        $Source.Content = 'Please wait...'
        if ($script:window) { $script:window.Dispatcher.Invoke([action]{}, [System.Windows.Threading.DispatcherPriority]::Render) }
        & $script:PanelButtonActions[$Name] $Source $EventArgs
    } catch {
        $failure = $_.Exception
        while ($failure -and -not $failure.Data['PanelAppPersistenceFailure']) { $failure = $failure.InnerException }
        if ($failure) { throw } # Preserve the existing hard stop for an event that could not be saved.
        Write-Log "Button $Name stopped on screen $script:CurrentScreenName : $_" 'ERROR'
        Show-PanelActionFailure "$_"
    } finally {
        # Do not undo intentional state/label changes made by the action itself.
        if ($Source.Content -eq 'Please wait...') { $Source.Content = $oldLabel }
        Schedule-PanelButtonRelease
    }
}
function Register-PanelButtonAction {
    param([string]$Name, [scriptblock]$Action)
    if (-not $script:PanelButtonActions) { $script:PanelButtonActions = @{} }
    $script:PanelButtonActions[$Name] = $Action
    $script:UI[$Name].Add_Click({
        param($source,$eventArgs)
        Invoke-PanelButtonAction -Name $source.Name -Source $source -EventArgs $eventArgs
    })
}

# -- Username screen --
$script:UI['txtTechName'].Add_KeyDown({
    param($kSender, $kArgs)
    if ($kArgs.Key -eq [System.Windows.Input.Key]::Return) {
        $script:UI['btnContinueUsername'].RaiseEvent(
            [System.Windows.RoutedEventArgs]::new([System.Windows.Controls.Button]::ClickEvent))
    }
})

Register-PanelButtonAction -Name 'btnContinueUsername' -Action {
    # v5.3.4 username standardization: regular APS username only - no email, domain-qualified,
    # shared, admin, or _fieldtech account. Stored lowercase for consistent reporting.
    $rawName = $script:UI['txtTechName'].Text.Trim()

    if ($rawName.Length -lt 2) {
        $script:UI['lblTechNameError'].Text       = 'Enter your regular APS username.'
        $script:UI['lblTechNameError'].Visibility = 'Visible'
        return
    }
    # Reject email addresses (any suffix). Do NOT auto-strip - make the tech correct it.
    if ($rawName -match '@') {
        $script:UI['lblTechNameError'].Text       = 'Enter only your APS username, not your email address. Example: charjohnson'
        $script:UI['lblTechNameError'].Visibility = 'Visible'
        return
    }
    # Reject APSMASTER\username, APSK12\username, COMPUTERNAME\username, and similar.
    if ($rawName -match '[\\/]') {
        $script:UI['lblTechNameError'].Text       = 'Do not include a domain or computer name. Enter only your APS username.'
        $script:UI['lblTechNameError'].Visibility = 'Visible'
        return
    }
    if ($rawName -match '\s') {
        $script:UI['lblTechNameError'].Text       = 'APS usernames cannot contain spaces.'
        $script:UI['lblTechNameError'].Visibility = 'Visible'
        return
    }
    # Allowed characters only (letters, numbers, period, underscore, hyphen).
    if ($rawName -notmatch '^[A-Za-z0-9][A-Za-z0-9._-]{1,59}$') {
        $script:UI['lblTechNameError'].Text       = 'Use only letters, numbers, periods, underscores, or hyphens.'
        $script:UI['lblTechNameError'].Visibility = 'Visible'
        return
    }
    # Store lowercase; reject Service Delivery elevated (_fieldtech) accounts after normalization.
    $normalizedName = $rawName.ToLowerInvariant()
    if ($normalizedName.EndsWith('_fieldtech')) {
        $script:UI['lblTechNameError'].Text       = 'Do not use your field-tech account. Enter your regular APS username instead.'
        $script:UI['lblTechNameError'].Visibility = 'Visible'
        return
    }
    $name = $normalizedName

    $script:UI['lblTechNameError'].Visibility = 'Collapsed'
    $script:UI['txtTechName'].Text = $name
    $script:TechName = $name
    $script:UI['lblTechDisplay'].Text = "Tech: $name"
    # Review fix #2: resumed closeout goes straight to the closeout screen under the
    # CURRENT technician's name (CloseoutTech may differ from the provisioning tech).
    if ($script:ResumeCloseoutPending) {
        $script:ResumeCloseoutPending = $false
        $script:CloseoutIssueReported = $false
        foreach ($c in @('chkCoImage','chkCoTouch','chkCoSound','chkCoNetwork','chkCoNDMS','chkCoAndroidEthernet')) { $script:UI[$c].IsChecked = $false }
        Set-CloseoutContext
        Show-Screen 'pnlReimageCloseout'
        Set-Status "Resuming $(Get-CloseoutPhaseLabel)."
        return
    }
    Show-Screen 'pnlModeSelect'
    Set-Status 'Select a mode to continue.'
}

# -- Mode selection --
Register-PanelButtonAction -Name 'btnModeBack' -Action {
    Show-Screen 'pnlUserEntry'
    try { $script:UI['txtTechName'].Focus() | Out-Null } catch {}
}
$script:OtherModesExpanded = $false
Register-PanelButtonAction -Name 'btnSummer2026' -Action { Set-Mode 7 'Interactive Inventory Project 2026';                       Show-OPSScreen }
Register-PanelButtonAction -Name 'btnOtherModes' -Action {
    $script:OtherModesExpanded = -not $script:OtherModesExpanded
    # v5.6 exposes ONE RMA entry (btnMode2). The legacy same-model button stays collapsed.
    foreach ($b in @('btnMode1','btnMode2','btnMode3','btnMode4','btnMode6','btnModeEndpointRepair','btnModeOPSRequest')) {
        if ($script:UI[$b]) { $script:UI[$b].Visibility = if ($script:OtherModesExpanded) { 'Visible' } else { 'Collapsed' } }
    }
}

Register-PanelButtonAction -Name 'btnModeEndpointRepair' -Action { Show-EndpointRepairScreen }
Register-PanelButtonAction -Name 'btnEndpointBack' -Action { Show-Screen 'pnlModeSelect' }
Register-PanelButtonAction -Name 'btnEndpointRenameOnly' -Action { Start-EndpointRepair 'RenameOnly' }
Register-PanelButtonAction -Name 'btnEndpointDomainOnly' -Action { Start-EndpointRepair 'DomainJoinOnly' }
Register-PanelButtonAction -Name 'btnEndpointRenameJoin' -Action { Start-EndpointRepair 'RenameAndJoin' }
Register-PanelButtonAction -Name 'btnModeOPSRequest' -Action {
    # A request is an operational ticket-like event, not an inventory reassignment.
    $script:UI['cboOPSReqSchool'].SelectedIndex = -1
    $script:UI['txtOPSReqRoom'].Text = ''
    $script:UI['txtOPSReqPanelSerial'].Text = ''
    $script:UI['txtOPSReqCurrentOPS'].Text = ''
    $script:UI['cboOPSReqReason'].SelectedIndex = -1
    $script:UI['cboOPSReqUrgency'].SelectedIndex = -1
    $script:UI['txtOPSReqNotes'].Text = ''
    $script:UI['lblOPSReqError'].Visibility = 'Collapsed'
    $script:UI['lblOPSReqSchoolError'].Visibility = 'Collapsed'
    try {
        $d = Get-OPSSerialData
        if ($d -and "$($d.Best)") { $script:UI['txtOPSReqCurrentOPS'].Text = "$($d.Best)" }
    } catch {}
    Show-Screen 'pnlOPSRequest'
}
Register-PanelButtonAction -Name 'btnOPSReqBack' -Action { Show-Screen 'pnlModeSelect' }
Register-PanelButtonAction -Name 'btnOPSReqSubmit' -Action {
    # The responsive sender pumps WPF messages while waiting on HTTPS. Guard against a
    # second click re-entering this handler and minting a second RequestId/EventId.
    if ($script:OPSRequestSubmissionInProgress) { return }
    $script:UI['lblOPSReqError'].Visibility = 'Collapsed'
    $script:UI['lblOPSReqSchoolError'].Visibility = 'Collapsed'

    $schoolItem = $script:UI['cboOPSReqSchool'].SelectedItem
    $room       = (Get-CanonicalRoom "$($script:UI['txtOPSReqRoom'].Text)")
    $panel      = (Get-CanonicalSerial "$($script:UI['txtOPSReqPanelSerial'].Text)")
    $curOps     = (Get-CanonicalSerial "$($script:UI['txtOPSReqCurrentOPS'].Text)")
    $reasonItem = $script:UI['cboOPSReqReason'].SelectedItem
    $urgItem    = $script:UI['cboOPSReqUrgency'].SelectedItem
    $notes      = "$($script:UI['txtOPSReqNotes'].Text)".Trim()

    if (-not $schoolItem) {
        $script:UI['lblOPSReqSchoolError'].Text = 'Select the school where the OPS is needed.'
        $script:UI['lblOPSReqSchoolError'].Visibility = 'Visible'; return
    }
    if (-not $room) {
        $script:UI['lblOPSReqError'].Text = 'Enter the room where the OPS is needed.'
        $script:UI['lblOPSReqError'].Visibility = 'Visible'; return
    }
    if (-not $panel) {
        $script:UI['lblOPSReqError'].Text = 'Scan or enter the physical panel serial.'
        $script:UI['lblOPSReqError'].Visibility = 'Visible'; return
    }
    if (-not $reasonItem -or -not $urgItem) {
        $script:UI['lblOPSReqError'].Text = 'Select why an OPS is needed and the classroom impact.'
        $script:UI['lblOPSReqError'].Visibility = 'Visible'; return
    }
    if ("$($reasonItem.Content)" -eq 'Other' -and -not $notes) {
        $script:UI['lblOPSReqError'].Text = 'Add a short note when the request reason is Other.'
        $script:UI['lblOPSReqError'].Visibility = 'Visible'; return
    }

    $script:OPSRequestSubmissionInProgress = $true
    $script:UI['btnOPSReqSubmit'].IsEnabled = $false
    $requestId = "OPSREQ-$(Get-Date -Format 'yyyyMMdd-HHmmss')-$(([guid]::NewGuid().ToString('N').Substring(0,8)).ToUpper())"
    $payload = @{
        LogSheet       = 'OPSRequests'
        RequestId      = $requestId
        RequestStatus  = 'New'
        PAIRAlertStatus= 'Pending'
        RequestedBy    = $script:TechName
        TechName       = $script:TechName
        RequestedAt    = (Get-Date).ToString('o')
        SchoolCode     = "$($schoolItem.Tag)"
        SchoolName     = ("$($schoolItem.Content)" -replace '^[^-]+-\s*','')
        Room           = $room
        CanonicalRoom  = $room
        PanelSerial    = $panel
        CurrentOPSSerial = $curOps
        RequestReason  = "$($reasonItem.Content)"
        Urgency        = "$($urgItem.Content)"
        Notes          = $notes
        ScriptVersion  = $script:ScriptVersion
        ClientHostname = $env:COMPUTERNAME
    }
    try {
        $res = Send-Event -Payload $payload -EventType 'OPSRequestSubmitted'
        if ($res.Rejected) {
            $script:UI['lblOPSReqError'].Text = 'The OPS request was not accepted. Contact a lead before submitting another request.'
            $script:UI['lblOPSReqError'].Visibility = 'Visible'
            return
        }
        if ($res.Queued) {
            [System.Windows.MessageBox]::Show(
                "OPS request $requestId was saved and is waiting to sync.`n`nDo not submit a second request for the same panel.",
                'OPS Request Pending Sync','OK','Warning') | Out-Null
        } else {
            [System.Windows.MessageBox]::Show(
                "OPS request $requestId was submitted.`n`nThe request is now in the lead / PAIR request queue.",
                'OPS Request Submitted','OK','Information') | Out-Null
        }
        Show-Screen 'pnlModeSelect'
    } finally {
        $script:OPSRequestSubmissionInProgress = $false
        $script:UI['btnOPSReqSubmit'].IsEnabled = $true
    }
}
Register-PanelButtonAction -Name 'btnMode1' -Action {
    $script:CurrentMode = 1
    $script:ProvPath = ''
    $script:UI['lblModeDisplay'].Text = 'Full Provisioning'
    Show-Screen 'pnlFullProvType'
}
Register-PanelButtonAction -Name 'btnFullProvBack' -Action { Show-Screen 'pnlModeSelect' }
Register-PanelButtonAction -Name 'btnProvStandard' -Action {
    $script:ProvPath = 'Standard'
    Show-Screen 'pnlInstallType'
}
Register-PanelButtonAction -Name 'btnProvPostRedo' -Action {
    $script:ProvPath = 'PostRedo'
    Set-Mode 1 'Post-RedoRescue Provisioning'
    Show-OPSScreen
}
# ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â
#  v5.4 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§4-16  CORRECT / UPDATE INVENTORY RECORD
#  Look up an existing record, correct approved fields, or report a conflict.
#  Never renames, joins the domain, or reimages.
# ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚ÂÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â
$script:InvLookupResult   = $null    # backend response for the current lookup
$script:InvBeforeSnapshot = $null    # values as they were when found (for the diff + audit)

function Get-InventoryUrl {
    param([string]$Query)
    $u = "$($script:Config.AppScriptUrl)"
    if ([string]::IsNullOrWhiteSpace($u) -or $u -like '*YOUR_DEPLOYMENT*') { return '' }
    return "$u`?$Query"
}
# v5.6 unified RMA: use the existing current-inventory layer to learn whether this OPS is
# already assigned to an older panel chassis. This is advisory until the technician scans the
# replacement panel and explicitly confirms that physical reassignment.
function Get-InventoryByOPS {
    param([string]$OPSSerial)
    if (-not $script:IsNetworkAvailable -or [string]::IsNullOrWhiteSpace($OPSSerial)) { return $null }
    $url = Get-InventoryUrl "action=inventoryLookup&lookupType=OPSSerial&value=$([uri]::EscapeDataString($OPSSerial))"
    if (-not $url) { return $null }
    try { return (Invoke-ResponsiveWebJson -Uri $url -Method GET -TimeoutSeconds 8) }
    catch { Write-Log "Current-inventory lookup failed for OPS ${OPSSerial}: $_" 'WARN'; return $null }
}
function Get-RMAInventoryByOPS { param([string]$OPSSerial) return (Get-InventoryByOPS -OPSSerial $OPSSerial) }
function Show-InventoryLookup {
    Set-Mode 8 'Correct / Update Inventory Record'
    if ($script:UI['cboInvLookupType'].Items.Count -eq 0) {
        foreach ($t in @('Panel Serial','OPS Serial','Hostname','School and Room')) {
            $it = [System.Windows.Controls.ComboBoxItem]::new(); $it.Content = $t
            $it.Tag = switch ($t) { 'Panel Serial' {'PanelSerial'} 'OPS Serial' {'OPSSerial'} 'Hostname' {'Hostname'} default {'SchoolRoom'} }
            $script:UI['cboInvLookupType'].Items.Add($it) | Out-Null
        }
    }
    $script:UI['cboInvLookupType'].SelectedIndex = 0
    if ($script:UI['cboInvLookupSchool'].Items.Count -eq 0) {
        foreach ($s in $script:Config.Schools) {
            $it = [System.Windows.Controls.ComboBoxItem]::new(); $it.Content = "$($s.Code) - $($s.Name)"; $it.Tag = "$($s.Code)"
            $script:UI['cboInvLookupSchool'].Items.Add($it) | Out-Null
        }
    }
    $script:UI['cboInvLookupSchool'].SelectedIndex = -1
    $script:UI['txtInvLookupRoom'].Text = ''
    $script:UI['txtInvLookupValue'].Text = ''
    Update-InventoryLookupInputMode
    $script:UI['lblInvLookupError'].Visibility = 'Collapsed'
    $script:UI['borInvResult'].Visibility = 'Collapsed'
    $script:UI['lblInvCrossCheck'].Visibility = 'Collapsed'
    $script:InvLookupResult = $null
    Show-Screen 'pnlInvLookup'
    try { $script:UI['txtInvLookupValue'].Focus() | Out-Null } catch {}
}
# ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§7 compare the spreadsheet record against what THIS device actually reports.
function Get-InventoryCrossCheck {
    param($Rec)
    $warn = @()
    if (-not $Rec) { return '' }
    $localOps = ''
    try { $d = Get-OPSSerialData; $localOps = "$($d.Best)" } catch {}
    if ($Rec.CurrentOPSSerial -and $localOps -and ("$($Rec.CurrentOPSSerial)" -ne $localOps)) {
        $warn += "Recorded OPS serial ($($Rec.CurrentOPSSerial)) does not match the OPS detected on this device ($localOps)."
    }
    if ($Rec.CurrentHostname -and ("$($Rec.CurrentHostname)" -ne "$env:COMPUTERNAME")) {
        $warn += "Recorded hostname ($($Rec.CurrentHostname)) does not match this device's hostname ($env:COMPUTERNAME)."
    }
    if ($warn.Count) { return ("IDENTITY CROSS-CHECK:`n- " + ($warn -join "`n- ") + "`n`nDo not silently replace a panel or OPS serial - use Report a Conflict, or the OPS Move/Swap workflow.") }
    return ''
}
$script:UI['cboInvLookupType'].Add_SelectionChanged({ Update-InventoryLookupInputMode })
$script:UI['txtInvLookupRoom'].Add_LostFocus({
    $v = Get-CanonicalRoom $script:UI['txtInvLookupRoom'].Text
    if ($v) { $script:UI['txtInvLookupRoom'].Text = $v }
})
Register-PanelButtonAction -Name 'btnModeInventory' -Action { if (Require-AuthoritativeBackend 'Correct Inventory Record') { Show-InventoryLookup } }
Register-PanelButtonAction -Name 'btnInvLookupBack' -Action { Show-Screen 'pnlModeSelect'; Set-Status 'Select a mode to continue.' }
Register-PanelButtonAction -Name 'btnInvFind' -Action {
    if (-not (Require-AuthoritativeBackend 'Correct Inventory Record')) { return }
    $sel = $script:UI['cboInvLookupType'].SelectedItem
    $lt  = if ($sel) { "$($sel.Tag)" } else { 'PanelSerial' }
    $val = $script:UI['txtInvLookupValue'].Text.Trim()
    $schoolCode = ''; $room = ''
    if ($lt -eq 'SchoolRoom') {
        $schoolSel = $script:UI['cboInvLookupSchool'].SelectedItem
        $schoolCode = if ($schoolSel) { "$($schoolSel.Tag)" } else { '' }
        $room = Get-CanonicalRoom $script:UI['txtInvLookupRoom'].Text
        if (-not $schoolCode -or -not $room) {
            $script:UI['lblInvLookupError'].Text = 'Select a school and enter a room number.'
            $script:UI['lblInvLookupError'].Visibility = 'Visible'; return
        }
        $script:UI['txtInvLookupRoom'].Text = $room
        $val = "$schoolCode|$room"
    } elseif ([string]::IsNullOrWhiteSpace($val)) {
        $script:UI['lblInvLookupError'].Text = 'Enter the lookup value shown above.'
        $script:UI['lblInvLookupError'].Visibility = 'Visible'; return
    }
    $script:UI['lblInvLookupError'].Visibility = 'Collapsed'
    $script:UI['borInvResult'].Visibility = 'Collapsed'
    $script:UI['lblInvCrossCheck'].Visibility = 'Collapsed'
    if ($val.Length -lt 2) {
        $script:UI['lblInvLookupError'].Text = 'Scan or enter a value to look up.'
        $script:UI['lblInvLookupError'].Visibility = 'Visible'; return
    }
    # ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§27: full inventory correction requires an online lookup - never overwrite blind.
    if (-not $script:IsNetworkAvailable) {
        $script:UI['lblInvLookupError'].Text = 'Inventory lookup is unavailable because PanelApp cannot reach the data service. You can still capture a conflict report, which will submit when connectivity returns.'
        $script:UI['lblInvLookupError'].Visibility = 'Visible'
        $script:InvLookupResult = $null
        $script:UI['lblInvResultTitle'].Text = 'Offline'
        $script:UI['lblInvResultBody'].Text  = "Lookup type: $lt`nValue: $val`n`nA correction cannot be applied offline, but a conflict report can be queued."
        $script:UI['btnInvUpdate'].Visibility  = 'Collapsed'
        $script:UI['btnInvHistory'].Visibility = 'Collapsed'
        $script:UI['borInvResult'].Visibility  = 'Visible'
        try { $script:UI['borInvResult'].BringIntoView() } catch {}
        return
    }
    $url = if ($lt -eq 'SchoolRoom') { Get-InventoryUrl "action=inventoryLookup&lookupType=SchoolRoom&schoolCode=$([uri]::EscapeDataString($schoolCode))&room=$([uri]::EscapeDataString($room))" } else { Get-InventoryUrl "action=inventoryLookup&lookupType=$([uri]::EscapeDataString($lt))&value=$([uri]::EscapeDataString($val))" }
    if (-not $url) {
        $script:UI['lblInvLookupError'].Text = 'Apps Script URL is not configured.'
        $script:UI['lblInvLookupError'].Visibility = 'Visible'; return
    }
    Set-Status 'Looking up inventory record...'
    $res = $null
    try { $res = Invoke-ResponsiveWebJson -Uri $url -Method GET -TimeoutSeconds 8 } catch { Write-Log "Inventory lookup failed: $_" 'WARN' }
    if (-not $res) {
        $script:UI['lblInvLookupError'].Text = 'The lookup did not return a result. Check the connection and try again.'
        $script:UI['lblInvLookupError'].Visibility = 'Visible'; return
    }
    $script:InvLookupResult = $res
    $script:InvLookupType = $lt; $script:InvLookupValue = $val
    if (-not $res.found -or [int]$res.matchCount -eq 0) {
        # ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§6.A no record found
        $script:UI['lblInvResultTitle'].Text = 'No existing inventory record was found'
        $script:UI['lblInvResultBody'].Text  = "Lookup type: $lt`nValue: $val`n`nTry another search, capture this panel with General Inventory, or report a missing record."
        $script:UI['btnInvUpdate'].Visibility  = 'Collapsed'
        $script:UI['btnInvHistory'].Visibility = 'Collapsed'
    } elseif ([int]$res.matchCount -gt 1 -and $lt -eq 'SchoolRoom') {
        $chosen = Select-InventorySchoolRoomCandidate -Candidates @($res.candidates)
        if (-not $chosen) { Set-Status 'School/room lookup cancelled.'; return }
        $panelKey = "$($chosen.PanelSerial)"
        if (-not $panelKey) { $script:UI['lblInvLookupError'].Text = 'The selected candidate has no panel serial. Report an inventory conflict.'; $script:UI['lblInvLookupError'].Visibility='Visible'; return }
        $detailUrl = Get-InventoryUrl "action=inventoryLookup&lookupType=PanelSerial&value=$([uri]::EscapeDataString($panelKey))"
        try { $res = Invoke-ResponsiveWebJson -Uri $detailUrl -Method GET -TimeoutSeconds 8 } catch { $res = $null }
        if (-not $res -or -not $res.found -or [int]$res.matchCount -ne 1) { $script:UI['lblInvLookupError'].Text = 'The selected panel could not be resolved uniquely by panel serial.'; $script:UI['lblInvLookupError'].Visibility='Visible'; return }
        $script:InvLookupResult = $res
        $script:InvLookupType = 'SchoolRoom'; $script:InvLookupValue = $val
        $rec = $res.record
        $script:InvBeforeSnapshot = $rec
        $script:UI['lblInvResultTitle'].Text = 'Inventory record found'
        $script:UI['lblInvResultBody'].Text = "Panel: $($rec.PanelSerial)`nOPS: $($rec.CurrentOPSSerial)`nHostname: $($rec.CurrentHostname)`nSchool / Room: $($rec.SchoolCode) $($rec.Room)`nLast observed: $($rec.LastObservedAt) by $($rec.LastObservedBy)"
        $script:UI['btnInvUpdate'].Visibility = 'Visible'; $script:UI['btnInvHistory'].Visibility = 'Visible'
        $script:UI['lblInvCrossCheck'].Text = Get-InventoryCrossCheck $rec
        $script:UI['lblInvCrossCheck'].Visibility = if ($script:UI['lblInvCrossCheck'].Text) { 'Visible' } else { 'Collapsed' }
    } elseif ([int]$res.matchCount -gt 1) {
        # Identity-key multiple matches remain a conflict; only same-location SchoolRoom matches are selectable.
        $lines = @()
        $i = 0
        foreach ($c in @($res.candidates)) {
            $i++
            $lines += "Candidate $i : $($c.PanelSerial) | OPS $($c.CurrentOPSSerial) | $($c.CurrentHostname) | $($c.SchoolCode) $($c.Room) | updated $($c.LastObservedAt) by $($c.LastObservedBy)"
        }
        $script:UI['lblInvResultTitle'].Text = "Multiple possible records were found ($($res.matchCount))"
        $script:UI['lblInvResultBody'].Text  = (($lines -join "`n") + "`n`nPanelApp will not merge or delete either record. Report a conflict so a lead can verify which is correct.")
        $script:UI['btnInvUpdate'].Visibility  = 'Collapsed'
        $script:UI['btnInvHistory'].Visibility = 'Collapsed'
    } else {
        # ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§6.B exactly one record
        $r = $res.record
        $script:InvBeforeSnapshot = $r
        $rt = if ($r.RoomType -eq 'Other' -and $r.OtherRoomType) { "Other - $($r.OtherRoomType)" } else { "$($r.RoomType)" }
        $script:UI['lblInvResultTitle'].Text = 'Existing Inventory Record Found'
        $script:UI['lblInvResultBody'].Text =
            "Panel Serial    : $($r.PanelSerial)`nOPS Serial      : $($r.CurrentOPSSerial)`nCurrent Hostname: $($r.CurrentHostname)`n" +
            "School          : $($r.SchoolCode) $($r.SchoolName)`nRoom            : $($r.Room)`nRoom Type       : $rt`n" +
            "Manufacturer    : $($r.Manufacturer)`nPanel Model     : $($r.PanelModel)`nMount Type      : $($r.MountType)`n" +
            "Install Type    : $($r.InstallType)`nDomain Status   : $($r.DomainMembershipStatus)`n" +
            "Windows / Image : $($r.WindowsVersionStatus) / $($r.ImageStatus)`nRemediation     : $($r.RemediationMethod)`n" +
            "Last Updated    : $($r.LastObservedAt) by $($r.LastObservedBy) (v$($r.LastScriptVersion))`n" +
            "Completeness    : $($r.DataCompletenessStatus)$(if ($r.MissingFields) { "  [missing: $($r.MissingFields)]" })`n" +
            "Open Conflict   : $(if ($r.ActiveConflictId) { $r.ActiveConflictId } else { 'none' })"
        $cross = Get-InventoryCrossCheck $r
        if ($cross) {
            $script:UI['lblInvCrossCheck'].Text = $cross
            $script:UI['lblInvCrossCheck'].Visibility = 'Visible'
            $script:UI['btnInvUpdate'].Visibility = 'Collapsed'   # ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§9 identity mismatch blocks a normal edit
        } else {
            $script:UI['btnInvUpdate'].Visibility = 'Visible'
        }
        if ($r.ActiveConflictId) { $script:UI['btnInvUpdate'].Visibility = 'Collapsed' }
        $script:UI['btnInvHistory'].Visibility = 'Visible'
    }
    $script:UI['borInvResult'].Visibility = 'Visible'
    Set-Status 'Lookup complete.'
    try { $script:UI['borInvResult'].BringIntoView() } catch {}   # ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§11 auto-scroll
}
# Update This Record -> prefill the standard location screen, then review the diff.
Register-PanelButtonAction -Name 'btnInvUpdate' -Action {
    $r = $script:InvBeforeSnapshot
    if (-not $r) { return }
    $script:PanelSerial  = "$($r.PanelSerial)"
    $script:OPSSerial    = "$($r.CurrentOPSSerial)"
    $script:SchoolCode   = "$($r.SchoolCode)"; $script:SchoolName = "$($r.SchoolName)"
    $script:RoomNumber   = "$($r.Room)";       $script:RoomType   = "$($r.RoomType)"
    $script:OtherRoomType = "$($r.OtherRoomType)"
    $script:Manufacturer = "$($r.Manufacturer)"; $script:PanelModel = "$($r.PanelModel)"
    $script:MountType    = "$($r.MountType)";  $script:InstallType = "$($r.InstallType)"
    $script:InvEditing   = $true
    Prepare-LocationScreen
    Prefill-LocationScreen
    $script:UI['btnLocationContinue'].Content = 'Review Changes'
    Show-Screen 'pnlLocation'
    Set-Status 'Correct the approved fields, then review the changes.'
}
Register-PanelButtonAction -Name 'btnInvHistory' -Action {
    $r = $script:InvBeforeSnapshot
    if (-not $r -or -not $script:IsNetworkAvailable) { return }
    $url = Get-InventoryUrl "action=inventoryHistory&panelSerial=$([uri]::EscapeDataString("$($r.PanelSerial)"))&limit=15"
    $h = $null
    try { $h = Invoke-ResponsiveWebJson -Uri $url -Method GET -TimeoutSeconds 8 } catch { Write-Log "Inventory history failed: $_" 'WARN' }
    $txt = if ($h -and @($h.events).Count) {
        (@($h.events) | ForEach-Object { "$($_.EventTimestamp)  $($_.EventType)  $($_.ChangeSummary) ($($_.TechName))" }) -join "`n"
    } else { 'No history events recorded for this panel yet.' }
    $pair = if ($h -and @($h.pairings).Count) {
        "`n`nPANEL / OPS PAIRINGS:`n" + ((@($h.pairings) | ForEach-Object { "$($_.PairingStartAt) -> $(if ($_.PairingEndAt) { $_.PairingEndAt } else { 'current' })  OPS $($_.OPSSerial)  ($($_.PairingAction))" }) -join "`n")
    } else { '' }
    [System.Windows.MessageBox]::Show("$txt$pair", "Inventory History - $($r.PanelSerial)", 'OK', 'Information') | Out-Null
}
# ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§15 Report a Conflict (reachable from lookup + review screens)
function Show-InventoryConflict {
    if ($script:UI['cboInvConflictType'].Items.Count -eq 0) {
        foreach ($t in @('Multiple Panel Records','Multiple OPS Records','Panel Serial Conflict','OPS Serial Conflict',
                         'Panel-to-OPS Pairing Conflict','Hostname Conflict','Location Conflict','Duplicate Record',
                         'Recent Record Mismatch','Current Device Does Not Match Record',
                         'Windows Image Policy Misclassification','Incorrect Reimage Recommendation',
                         'Manufacturer Recovery Policy Conflict','Firmware Configuration Conflict','Unknown Inventory Conflict')) {
            $it = [System.Windows.Controls.ComboBoxItem]::new(); $it.Content = $t
            $script:UI['cboInvConflictType'].Items.Add($it) | Out-Null
        }
    }
    $script:UI['cboInvConflictType'].SelectedIndex = -1
    $script:UI['txtInvConflictNotes'].Text = ''
    $script:UI['lblInvConflictError'].Visibility = 'Collapsed'
    $localOps = ''
    try { $d = Get-OPSSerialData; $localOps = "$($d.Best)" } catch {}
    $r = $script:InvBeforeSnapshot
    $cand = if ($script:InvLookupResult -and [int]$script:InvLookupResult.matchCount -gt 1) {
        "Candidates: " + ((@($script:InvLookupResult.candidates) | ForEach-Object { "$($_.PanelSerial)/$($_.CurrentOPSSerial)" }) -join '  |  ')
    } else { '' }
    $script:UI['lblInvConflictContext'].Text =
        "Lookup        : $($script:InvLookupType) = $($script:InvLookupValue)`n" +
        "Record panel  : $(if ($r) { $r.PanelSerial } else { '(none)' })`n" +
        "Record OPS    : $(if ($r) { $r.CurrentOPSSerial } else { '(none)' })`n" +
        "This device   : hostname $env:COMPUTERNAME, OPS $localOps`n" +
        "$cand"
    Show-Screen 'pnlInvConflict'
    try { $script:UI['cboInvConflictType'].Focus() | Out-Null } catch {}
}
Register-PanelButtonAction -Name 'btnInvConflict' -Action { Show-InventoryConflict }
Register-PanelButtonAction -Name 'btnInvReviewConflict' -Action { Show-InventoryConflict }
Register-PanelButtonAction -Name 'btnInvConflictBack' -Action { Show-Screen 'pnlInvLookup' }
Register-PanelButtonAction -Name 'btnInvConflictSubmit' -Action {
    $sel = $script:UI['cboInvConflictType'].SelectedItem
    $notes = $script:UI['txtInvConflictNotes'].Text.Trim()
    if (-not $sel) {
        $script:UI['lblInvConflictError'].Text = 'Select a conflict type.'
        $script:UI['lblInvConflictError'].Visibility = 'Visible'; return
    }
    if ($notes.Length -lt 5) {
        $script:UI['lblInvConflictError'].Text = 'Describe what you observed so a lead can resolve it.'
        $script:UI['lblInvConflictError'].Visibility = 'Visible'; return
    }
    $script:UI['lblInvConflictError'].Visibility = 'Collapsed'
    $localOps = ''
    try { $d = Get-OPSSerialData; $localOps = "$($d.Best)" } catch {}
    $r = $script:InvBeforeSnapshot
    $conflictId = "INV-CONFLICT-$(Get-Date -Format 'yyyyMMdd-HHmmss')-$(([guid]::NewGuid().ToString('N').Substring(0,6)).ToUpper())"
    $cands = @($script:InvLookupResult.candidates)
    $payload = @{
        LogSheet='InventoryConflicts'; ConflictId=$conflictId
        CreatedBy=$script:TechName; ConflictStatus='New'; ConflictType="$($sel.Content)"
        LookupType=$script:InvLookupType; LookupValue=$script:InvLookupValue
        PanelSerial=$(if ($r) { "$($r.PanelSerial)" } else { '' })
        OPSSerial=$(if ($r) { "$($r.CurrentOPSSerial)" } else { '' })
        CurrentHostname=$env:COMPUTERNAME; LocalDetectedOPSSerial=$localOps
        CandidateARecordId=$(if ($cands.Count -ge 1) { "$($cands[0].PanelRecordId)" } else { '' })
        CandidateBRecordId=$(if ($cands.Count -ge 2) { "$($cands[1].PanelRecordId)" } else { '' })
        CandidateASummary=$(if ($cands.Count -ge 1) { "$($cands[0].PanelSerial) / OPS $($cands[0].CurrentOPSSerial) / $($cands[0].SchoolCode) $($cands[0].Room)" } else { '' })
        CandidateBSummary=$(if ($cands.Count -ge 2) { "$($cands[1].PanelSerial) / OPS $($cands[1].CurrentOPSSerial) / $($cands[1].SchoolCode) $($cands[1].Room)" } else { '' })
        CandidateASnapshotJson=$(if ($cands.Count -ge 1) { ($cands[0] | ConvertTo-Json -Compress -Depth 5) } else { '' })
        CandidateBSnapshotJson=$(if ($cands.Count -ge 2) { ($cands[1] | ConvertTo-Json -Compress -Depth 5) } else { '' })
        SchoolCode=$(if ($r) { "$($r.SchoolCode)" } else { '' }); Room=$(if ($r) { "$($r.Room)" } else { '' })
        RelatedProjectRunIds=$script:RelatedSummerRunId
        TechnicianNotes=$notes; RevisitRequired='Unknown'
        ScriptVersion=$script:ScriptVersion
    }
    $sent = (Send-Event -Payload $payload -EventType 'InventoryConflict').Delivered
    [System.Windows.MessageBox]::Show(
        "Conflict Reported`n`nConflict ID:`n$conflictId`n`nThe existing records were NOT changed. A lead or inventory reviewer must verify and resolve this from the spreadsheet.$(if (-not $sent) { "`n`n(Queued offline - it will submit when connectivity returns.)" })",
        'Conflict Reported', 'OK', 'Information') | Out-Null
    Write-Log "Inventory conflict reported: $conflictId ($($sel.Content))"
    $script:InvEditing = $false
    Show-InventoryLookup
}
# ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§13 before-and-after review + submit
Register-PanelButtonAction -Name 'btnInvReviewBack' -Action { Show-Screen 'pnlLocation' }
Register-PanelButtonAction -Name 'btnInvSubmit' -Action {
    $selT = $script:UI['cboInvCorrType'].SelectedItem
    $selR = $script:UI['cboInvCorrReason'].SelectedItem
    $notes = $script:UI['txtInvNotes'].Text.Trim()
    if (-not $selT -or -not $selR) {
        $script:UI['lblInvReviewError'].Text = 'Select a correction type and reason.'
        $script:UI['lblInvReviewError'].Visibility = 'Visible'; return
    }
    # ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§13: notes required for Other / school / room / manufacturer / model changes
    $b = $script:InvBeforeSnapshot
    $needNotes = ("$($selR.Content)" -eq 'Other') -or
                 ($b -and (("$($b.SchoolCode)" -ne $script:SchoolCode) -or ("$($b.Room)" -ne $script:RoomNumber) -or
                           ("$($b.Manufacturer)" -ne $script:Manufacturer) -or ("$($b.PanelModel)" -ne $script:PanelModel)))
    if ($needNotes -and $notes.Length -lt 5) {
        $script:UI['lblInvReviewError'].Text = 'Notes are required for this kind of change - explain what happened.'
        $script:UI['lblInvReviewError'].Visibility = 'Visible'; return
    }
    # v5.4 (review defect #7): image-policy / recovery-method / firmware corrections change
    # controlled fields the normal correction payload does not carry. Route them to the reviewer
    # conflict queue instead of producing an "Applied Automatically" row that changed nothing.
    $policyReasons = @('Windows image-policy correction','Incorrect reimage recommendation',
                       'Incorrect manufacturer recovery method','Firmware-status correction')
    if ("$($selR.Content)" -in $policyReasons) {
        [System.Windows.MessageBox]::Show(
            "'$($selR.Content)' changes controlled image-policy fields.`n`nPanelApp will submit this as an inventory CONFLICT so a lead can apply the corrected Windows/image values from the spreadsheet. The existing records are not changed here.",
            'Routed to Conflict Review', 'OK', 'Information') | Out-Null
        # Show-InventoryConflict CLEARS the notes/selection, so pre-fill AFTER it renders or the
        # selected correction reason is lost.
        Show-InventoryConflict
        $script:UI['txtInvConflictNotes'].Text = "$($selR.Content): $notes"
        foreach ($it in $script:UI['cboInvConflictType'].Items) {
            if ("$($it.Content)" -eq 'Windows Image Policy Misclassification') { $script:UI['cboInvConflictType'].SelectedItem = $it; break }
        }
        return
    }
    $script:UI['lblInvReviewError'].Visibility = 'Collapsed'
    $changed = @()
    foreach ($f in @(
        @{n='SchoolCode';   old="$($b.SchoolCode)";    new=$script:SchoolCode},
        @{n='SchoolName';   old="$($b.SchoolName)";    new=$script:SchoolName},
        @{n='Room';         old="$($b.Room)";          new=$script:RoomNumber},
        @{n='RoomType';     old="$($b.RoomType)";      new=$script:RoomType},
        @{n='OtherRoomType';old="$($b.OtherRoomType)"; new=$script:OtherRoomType},
        @{n='Manufacturer'; old="$($b.Manufacturer)";  new=$script:Manufacturer},
        @{n='PanelModel';   old="$($b.PanelModel)";    new=$script:PanelModel},
        @{n='MountType';    old="$($b.MountType)";     new=$script:MountType})) {
        if ("$($f.old)" -ne "$($f.new)") { $changed += $f.n }
    }
    $after = @{ SchoolCode=$script:SchoolCode; SchoolName=$script:SchoolName; Room=$script:RoomNumber
                RoomType=$script:RoomType; OtherRoomType=$script:OtherRoomType
                Manufacturer=$script:Manufacturer; PanelModel=$script:PanelModel; MountType=$script:MountType }
    $correctionId = "INV-CORR-$(Get-Date -Format 'yyyyMMdd-HHmmss')-$(([guid]::NewGuid().ToString('N').Substring(0,6)).ToUpper())"
    $payload = @{
        LogSheet='InventoryCorrections'; CorrectionId=$correctionId
        SubmittedBy=$script:TechName; ScriptVersion=$script:ScriptVersion
        LookupType=$script:InvLookupType; LookupValue=$script:InvLookupValue
        PanelSerial="$($b.PanelSerial)"; OPSSerial="$($b.CurrentOPSSerial)"
        TargetPanelRecordId="$($b.PanelRecordId)"; TargetProjectRunId=$script:RelatedSummerRunId
        CorrectionType="$($selT.Content)"; CorrectionReason="$($selR.Content)"; CorrectionNotes=$notes
        ChangedFields=($changed -join ', ')
        BeforeSnapshotJson=($b | ConvertTo-Json -Compress -Depth 5)
        AfterSnapshotJson=($after | ConvertTo-Json -Compress -Depth 5)
        CurrentHostname=$env:COMPUTERNAME
        SchoolCode=$script:SchoolCode; SchoolName=$script:SchoolName; Room=$script:RoomNumber
        RoomType=$script:RoomType; OtherRoomType=$script:OtherRoomType
        Manufacturer=$script:Manufacturer; PanelModel=$script:PanelModel; MountType=$script:MountType
        InstallType=$script:InstallType
    }
    $sent = (Send-Event -Payload $payload -EventType 'InventoryCorrection').Delivered
    [System.Windows.MessageBox]::Show(
        "Correction submitted.`n`nCorrection ID:`n$correctionId`n`nChanged: $(if ($changed.Count) { ($changed -join ', ') } else { '(no field changes - recorded as verification)' })`n`nThe original source rows were not modified.$(if (-not $sent) { "`n`n(Queued offline - it will submit when connectivity returns.)" })",
        'Inventory Correction Submitted', 'OK', 'Information') | Out-Null
    Write-Log "Inventory correction submitted: $correctionId (changed: $($changed -join ', '))"
    $script:InvEditing = $false
    Show-InventoryLookup
}
Register-PanelButtonAction -Name 'btnInstallTypeBack' -Action { Show-Screen 'pnlFullProvType' }
Register-PanelButtonAction -Name 'btnNewInstall' -Action {
    $script:ProvPath = 'Standard'
    Set-Mode 1 'New Install'
    Show-OPSScreen
}
Register-PanelButtonAction -Name 'btnReimage' -Action {
    $script:ProvPath = 'Standard'
    Set-Mode 1 'Standard Reimage'
    Show-OPSScreen
}
Register-PanelButtonAction -Name 'btnMode2' -Action {
    if (-not (Require-AuthoritativeBackend 'RMA / Warranty Replacement')) { return }
    $script:RMAAction = ''; $script:RMAPreviousPanelSerial = ''; $script:RMAReassignmentConfirmed = $false; $script:RMAInventoryLookup = $null
    $script:InventoryReassignmentConfirmed = $false; $script:InventoryReassignmentType = 'RMAReplacement'; $script:InventoryReassignmentReason = 'RMA / warranty panel replacement'
    $script:InventoryPreviousPanelSerial = ''; $script:TemporaryAssignment = $false; $script:FollowUpRequired = $false; $script:TestingObservationOnly = $false
    $script:InstallType = 'Warranty Replacement'
    Set-Mode 2 'RMA / Warranty Replacement'
    Show-OPSScreen
}
Register-PanelButtonAction -Name 'btnMode3' -Action {
    if (-not (Require-AuthoritativeBackend 'OPS Module Move')) { return }
    $script:InventoryReassignmentConfirmed = $false; $script:InventoryReassignmentType = ''; $script:InventoryReassignmentReason = ''
    $script:InventoryPreviousPanelSerial = ''; $script:TemporaryAssignment = $false; $script:FollowUpRequired = $false; $script:TestingObservationOnly = $false
    foreach ($n in @('rdoM3Permanent','rdoM3Temporary','rdoM3Testing')) { if ($script:UI[$n]) { $script:UI[$n].IsChecked = $false } }
    Set-Mode 3 'OPS Module Move'; Show-OPSScreen
}
Register-PanelButtonAction -Name 'btnMode4' -Action { if (-not (Require-AuthoritativeBackend 'Panel Relocation')) { return }; Set-Mode 4 'Panel Relocation'; Show-OPSScreen }
# Legacy v5.5 RMA branch retained for rollback compatibility but no longer exposed in Other.
Register-PanelButtonAction -Name 'btnMode5' -Action { Set-Mode 5 'Warranty Replacement (Same Model)'; Show-OPSScreen }
Register-PanelButtonAction -Name 'btnMode6' -Action { Set-Mode 6 'General Inventory Capture';                   Show-OPSScreen }

# -- OPS serial screen --
Register-PanelButtonAction -Name 'btnOPSBack' -Action {
    Show-Screen 'pnlModeSelect'
}
Register-PanelButtonAction -Name 'btnOPSConfirm' -Action {
    if ($script:CurrentMode -in @(2,3,4,5)) {
        $authoritativeAction = switch ($script:CurrentMode) { 2 {'RMA / Warranty Replacement'} 3 {'OPS Module Move'} 4 {'Panel Relocation'} 5 {'Warranty Replacement'} }
        if (-not (Require-AuthoritativeBackend $authoritativeAction)) { return }
    }
    $override = $script:UI['txtOPSOverride'].Text.Trim()
    # Review fix #15: a suspicious serial cannot be silently accepted. The tech must either
    # correct it or explicitly state how it was verified (it feeds AutopilotHashes).
    if ($script:OPSSerialValidationStatus -eq 'Suspicious' -and $override -eq $script:OPSSerial) {
        $selR = $script:UI['cboOPSOverrideReason'].SelectedItem
        if (-not $selR) {
            [System.Windows.MessageBox]::Show(
                "This OPS serial was flagged as suspicious.`n`nEither enter the corrected serial from the OPS sticker, or select how you verified this value before continuing.",
                'Verify OPS Serial', 'OK', 'Warning') | Out-Null
            return
        }
        $script:OPSSerialValidationNote = "$($script:OPSSerialValidationNote) Tech verification: $($selR.Content)."
        Write-Log "Suspicious OPS serial accepted with verification: $($selR.Content)"
    }
    if ($override) {
        if ($override -ne $script:OPSSerial) {
            $reason = ''
            $selR = $script:UI['cboOPSOverrideReason'].SelectedItem
            if ($selR) { $reason = "$($selR.Content)" }
            $script:SelectedOPSSerialSource     = 'ManualOverride'
            $script:SelectedOPSSerialConfidence = 'Manual (tech-entered)'
            $script:OPSSerialValidationStatus   = 'Manual'
            $script:OPSSerialValidationNote     = "OPS serial manually entered/confirmed by technician.$(if ($reason) { " Verification: $reason" })"
            Write-Log "OPS serial overridden by tech: '$($script:OPSSerial)' -> '$override' ($reason)"
        }
        $script:OPSSerial = $override
    }
    Prepare-ScanScreen
    Show-Screen 'pnlScanBarcode'
}

# -- Barcode scan screen --
Register-PanelButtonAction -Name 'btnPanelSerialMissing' -Action {
    if ($script:CurrentMode -ne 7) { return }
    $script:PanelSerial = ''
    $script:PanelSerialStickerStatus = 'Missing or Unreadable'
    $script:PanelSerialSource = ''
    $script:PanelSerialVerificationStatus = ''
    $script:PanelObservationId = ''
    $script:IdentityResolutionRequired = $false
    $script:PanelIdentityResolutionStatus = ''
    $script:IIQAssetTag = ''; $script:NDMSName = ''; $script:NDMSDeviceId = ''; $script:NDMSTags = ''
    $script:UI['cboMissingPanelManufacturer'].SelectedIndex = -1
    $script:UI['pnlMissingPromethean'].Visibility = 'Collapsed'
    $script:UI['pnlMissingBoxlight'].Visibility = 'Collapsed'
    $script:UI['txtMissingPrometheanSerial'].Text = ''
    $script:UI['txtMissingAssetTag'].Text = ''; $script:UI['txtMissingNDMSName'].Text = ''
    $script:UI['txtMissingNDMSDeviceId'].Text = ''; $script:UI['txtMissingNDMSTags'].Text = ''
    $script:UI['lblMissingPanelManufacturerError'].Visibility = 'Collapsed'
    $script:UI['lblMissingPanelSerialError'].Visibility = 'Collapsed'
    Show-Screen 'pnlMissingPanelSerial'
}
$script:UI['cboMissingPanelManufacturer'].Add_SelectionChanged({
    $sel = $script:UI['cboMissingPanelManufacturer'].SelectedItem
    $name = if ($sel) { "$($sel.Content)" } else { '' }
    $script:UI['pnlMissingPromethean'].Visibility = if ($name -eq 'Promethean') { 'Visible' } else { 'Collapsed' }
    $script:UI['pnlMissingBoxlight'].Visibility = if ($name -eq 'Boxlight') { 'Visible' } else { 'Collapsed' }
    $script:UI['lblMissingPanelManufacturerError'].Visibility = 'Collapsed'
    $script:UI['lblMissingPanelSerialError'].Visibility = 'Collapsed'
})
Register-PanelButtonAction -Name 'btnMissingPanelSerialBack' -Action {
    $script:PanelSerialStickerStatus = ''; $script:PanelSerialSource = ''; $script:PanelSerialVerificationStatus = ''
    $script:PanelObservationId = ''; $script:IdentityResolutionRequired = $false; $script:PanelIdentityResolutionStatus = ''
    $script:IIQAssetTag = ''; $script:NDMSName = ''; $script:NDMSDeviceId = ''; $script:NDMSTags = ''
    Prepare-ScanScreen; Show-Screen 'pnlScanBarcode'
}
Register-PanelButtonAction -Name 'btnMissingPanelSerialContinue' -Action {
    $sel = $script:UI['cboMissingPanelManufacturer'].SelectedItem
    if (-not $sel) {
        $script:UI['lblMissingPanelManufacturerError'].Text = 'Select Boxlight or Promethean.'
        $script:UI['lblMissingPanelManufacturerError'].Visibility = 'Visible'; return
    }
    $script:Manufacturer = "$($sel.Content)"; $script:MfrCode = "$($sel.Tag)"
    if ($script:Manufacturer -eq 'Promethean') {
        $serial = $script:UI['txtMissingPrometheanSerial'].Text.Trim()
        if (-not $serial) {
            $script:UI['lblMissingPanelSerialError'].Text = 'Enter the actual Promethean panel serial from Android settings.'
            $script:UI['lblMissingPanelSerialError'].Visibility = 'Visible'; return
        }
        $script:PanelSerialStickerStatus = 'Missing or Unreadable'
        $script:PanelSerialSource = 'Promethean Android Settings'
        $script:PanelSerialVerificationStatus = 'Verified'
        $script:PanelIdentityResolutionStatus = 'Resolved'
        $script:IdentityResolutionRequired = $false
        $script:PanelObservationId = ''
        $script:IIQAssetTag = ''; $script:NDMSName = ''; $script:NDMSDeviceId = ''; $script:NDMSTags = ''
        $script:UI['txtBarcodeInput'].Text = $serial
        & $script:PanelButtonActions['btnScanContinue'] # Internal continuation stays inside the existing guarded action.
        return
    }
    if ($script:Manufacturer -eq 'Boxlight') {
        $asset = $script:UI['txtMissingAssetTag'].Text.Trim()
        $ndmsName = $script:UI['txtMissingNDMSName'].Text.Trim()
        $ndmsId = $script:UI['txtMissingNDMSDeviceId'].Text.Trim()
        $ndmsTags = $script:UI['txtMissingNDMSTags'].Text.Trim()
        if (-not ($asset -or $ndmsName -or $ndmsId -or $ndmsTags)) {
            $script:UI['lblMissingPanelSerialError'].Text = 'Enter at least one reconciliation identifier: APS asset tag, NDMS name, NDMS Device ID, or NDMS tags.'
            $script:UI['lblMissingPanelSerialError'].Visibility = 'Visible'; return
        }
        $script:PanelSerial = ''
        $script:PanelSerialStickerStatus = 'Missing or Unreadable'
        $script:PanelSerialSource = 'Pending Reconciliation'
        $script:PanelSerialVerificationStatus = 'Pending Reconciliation'
        if (-not $script:PanelObservationId) { $script:PanelObservationId = New-PanelObservationId }
        $script:IdentityResolutionRequired = $true
        $script:PanelIdentityResolutionStatus = 'Pending'
        $script:IIQAssetTag = $asset; $script:NDMSName = $ndmsName; $script:NDMSDeviceId = $ndmsId; $script:NDMSTags = $ndmsTags
        Prepare-LocationScreen
        Show-Screen 'pnlLocation'
        return
    }
}
$script:UI['txtBarcodeInput'].Add_TextChanged({
    $txt = $script:UI['txtBarcodeInput'].Text.Trim()
    if ($txt.Length -gt 0) {
        $script:UI['btnScanContinue'].IsEnabled = $true
        Set-ScanFlash $txt
    } else {
        $script:UI['btnScanContinue'].IsEnabled   = $false
        $script:UI['borScannedResult'].Visibility  = 'Collapsed'
        $script:UI['lblScanStatus'].Text           = 'Ready'
        $script:UI['lblScanStatus'].Foreground     = New-Brush '#888888'
        $script:UI['borScanIndicator'].Background  = New-Brush '#262626'
    }
})
$script:UI['txtBarcodeInput'].Add_KeyDown({
    param($kSender, $kArgs)
    if ($kArgs.Key -eq [System.Windows.Input.Key]::Return -and
        $script:UI['btnScanContinue'].IsEnabled) {
        $script:UI['btnScanContinue'].RaiseEvent(
            [System.Windows.RoutedEventArgs]::new([System.Windows.Controls.Button]::ClickEvent))
    }
})
Register-PanelButtonAction -Name 'btnScanBack' -Action {
    Show-Screen 'pnlOPSSerial'
}
Register-PanelButtonAction -Name 'btnScanContinue' -Action {
    $script:PanelSerial = $script:UI['txtBarcodeInput'].Text.Trim()
    if ($script:PanelSerialStickerStatus -ne 'Missing or Unreadable') {
        $script:PanelSerialStickerStatus = 'Present'
        $script:PanelSerialSource = 'Chassis Sticker / Barcode'
        $script:PanelSerialVerificationStatus = 'Verified'
        $script:PanelIdentityResolutionStatus = 'Resolved'
        $script:PanelObservationId = ''
        $script:IdentityResolutionRequired = $false
        $script:IIQAssetTag = ''; $script:NDMSName = ''; $script:NDMSDeviceId = ''; $script:NDMSTags = ''
    }
    # v5.6 unified RMA: if this known OPS is currently assigned to a DIFFERENT panel,
    # require a physical confirmation before the backend is allowed to move the pairing. This
    # turns a legitimate warranty chassis swap into an audited reassignment without weakening the
    # ordinary duplicate-OPS protection for every other workflow.
    if ($script:CurrentMode -eq 2) {
        $script:RMAInventoryLookup = Get-InventoryByOPS -OPSSerial $script:OPSSerial
        $script:RMAPreviousPanelSerial = ''
        $script:RMAReassignmentConfirmed = $false
        $script:InventoryReassignmentLookup = $script:RMAInventoryLookup
        $script:InventoryPreviousPanelSerial = ''
        $script:InventoryReassignmentType = 'RMAReplacement'
        $script:InventoryReassignmentReason = 'RMA / warranty panel replacement'
        $script:InventoryReassignmentConfirmed = $false
        $script:TemporaryAssignment = $false
        $script:FollowUpRequired = $false
        $script:TestingObservationOnly = $false
        if ($script:RMAInventoryLookup -and $script:RMAInventoryLookup.found -and [int]$script:RMAInventoryLookup.matchCount -eq 1 -and $script:RMAInventoryLookup.record) {
            $prevPanel = "$($script:RMAInventoryLookup.record.PanelSerial)".Trim()
            if ($prevPanel -and (Get-CanonicalSerial $prevPanel) -ne (Get-CanonicalSerial $script:PanelSerial)) {
                $rmaConfirm = [System.Windows.MessageBox]::Show(
                    "This OPS is currently recorded on a DIFFERENT panel.`n`nOPS: $($script:OPSSerial)`nCurrent inventory panel: $prevPanel`nReplacement panel scanned: $($script:PanelSerial)`n`nConfirm ONLY if this is the physical RMA/warranty replacement and this same OPS is now installed in the replacement panel.`n`nYes = close the old pairing and move the OPS to the replacement panel in current inventory.`nNo = stop and review inventory instead.",
                    'Confirm RMA Panel Replacement', 'YesNo', 'Warning')
                if ($rmaConfirm -ne 'Yes') {
                    [System.Windows.MessageBox]::Show(
                        'RMA processing stopped before any inventory change. Use Correct Inventory Record or the appropriate move workflow to reconcile the device.',
                        'RMA Not Confirmed', 'OK', 'Information') | Out-Null
                    Show-Screen 'pnlModeSelect'; return
                }
                $script:RMAPreviousPanelSerial = $prevPanel
                $script:RMAReassignmentConfirmed = $true
                $script:InventoryPreviousPanelSerial = $prevPanel
                $script:InventoryReassignmentConfirmed = $true
                Write-Log "RMA reassignment confirmed: OPS $($script:OPSSerial) from panel $prevPanel to panel $($script:PanelSerial)."
            }
        }
    }
    # v5.6 general OPS reassignment: Mode 3 can be permanent, temporary classroom coverage,
    # or testing only. Look up the OPS so the reason screen can show its recorded panel.
    if ($script:CurrentMode -eq 3) {
        $script:InventoryReassignmentLookup = Get-InventoryByOPS -OPSSerial $script:OPSSerial
        $script:InventoryPreviousPanelSerial = ''
        $script:InventoryReassignmentConfirmed = $false
        $script:InventoryReassignmentType = ''
        $script:InventoryReassignmentReason = ''
        $script:TemporaryAssignment = $false
        $script:FollowUpRequired = $false
        $script:TestingObservationOnly = $false
        if ($script:InventoryReassignmentLookup -and $script:InventoryReassignmentLookup.found -and
            [int]$script:InventoryReassignmentLookup.matchCount -eq 1 -and $script:InventoryReassignmentLookup.record) {
            $recordedPanel = "$($script:InventoryReassignmentLookup.record.PanelSerial)".Trim()
            if ($recordedPanel -and (Get-CanonicalSerial $recordedPanel) -ne (Get-CanonicalSerial $script:PanelSerial)) {
                $script:InventoryPreviousPanelSerial = $recordedPanel
            }
        }
    }
    # Post-RedoRescue Provisioning: look up the active Summer 2026 continuation by panel serial,
    # then run the RedoRescue gate before allowing provisioning (v5.3 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§3).
    if ($script:CurrentMode -eq 1 -and $script:ProvPath -eq 'PostRedo') {
        $found = @(Find-SummerContinuation -PanelSerial $script:PanelSerial)
        if ($found.Count -eq 1) {
            $script:SummerMatches = $found
            Route-SummerContinuation $found[0]; return
        } elseif ($found.Count -gt 1) {
            $script:SummerMatches = $found
            Show-MultiActiveBlock $found; return
        }
        # 0 matches -> no active Summer record; block (never allow silent unlinked provisioning)
        Show-NoSummerRecordBlock; return
    }
    # v5.6: the official Summer inventory cycle owns duplicate/rebaseline behavior. Pre-project
    # rows are linked and preserved; open pre-project rows are superseded by the new official run;
    # an already-started CURRENT-cycle project is resumed instead of duplicated.
    if ($script:CurrentMode -eq 7) {
        if (-not (Confirm-SummerProjectStart -PanelSerial $script:PanelSerial)) { return }
    }
    switch ($script:CurrentMode) {
        { $_ -in @(1,2,3,4,6,7,9) } {
            Prepare-LocationScreen
            Show-Screen 'pnlLocation'
        }
        5 {
            $script:M5HostnameCorrect = $true
            $script:UI['rdoM5Yes'].IsChecked             = $true
            $script:UI['borM5RebuildNote'].Visibility    = 'Collapsed'
            $script:UI['lblM5CurrentHostname'].Text      = $env:COMPUTERNAME
            Show-Screen 'pnlM5HostnameCheck'
        }
    }
}

# -- Location screen --
$script:UI['cboManufacturer'].Add_SelectionChanged({
    $selMfr = $script:UI['cboManufacturer'].SelectedItem
    if ($selMfr) { Update-ModelDropdown -ManufacturerName ($selMfr.Content) }
})
# v5.3.3 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§3: reveal OtherRoomType only for OTHER; clear it when switching away.
$script:UI['cboRoomType'].Add_SelectionChanged({
    $sel = $script:UI['cboRoomType'].SelectedItem
    $val = if ($sel) { "$($sel.Tag)" } else { '' }
    if ($val -eq 'Other') {
        $script:UI['lblOtherRoomTypeLabel'].Visibility = 'Visible'
        $script:UI['txtOtherRoomType'].Visibility      = 'Visible'
    } else {
        $script:UI['lblOtherRoomTypeLabel'].Visibility = 'Collapsed'
        $script:UI['txtOtherRoomType'].Visibility      = 'Collapsed'
        $script:UI['txtOtherRoomType'].Text = ''   # clear when not OTHER
    }
})

# v5.3 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§8: always collect the ACTUAL room number (wall AND mobile). The mobile hostname
# suffix is derived from the panel serial automatically - techs never type a suffix.
$script:UI['rdoMobile'].Add_Checked({
    $script:UI['lblRoomLabel'].Text = 'ROOM NUMBER'
    $script:UI['lblRoomHint'].Text  = 'Enter the actual room number for this panel, even though it is mobile/cart. The hostname suffix comes from the panel serial automatically.'
})
$script:UI['rdoWallMounted'].Add_Checked({
    $script:UI['lblRoomLabel'].Text = 'ROOM NUMBER'
    $script:UI['lblRoomHint'].Text  = 'Enter the actual room number (e.g. 214, GYM, CAFE).'
})
Register-PanelButtonAction -Name 'btnLocationBack' -Action {
    if ($script:CurrentMode -eq 7 -and $script:PanelSerialStickerStatus -eq 'Missing or Unreadable') {
        Show-Screen 'pnlMissingPanelSerial'; return
    }
    switch ($script:CurrentMode) {
        5       { Show-Screen 'pnlM5HostnameCheck' }
        default { Show-Screen 'pnlScanBarcode' }
    }
}
# r14 ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§4: normalize the room as the technician LEAVES the field, so what they see on screen is
# what will be stored - not a silent rewrite at submit time.
$script:UI['txtRoomNumber'].Add_LostFocus({
    # v5.5.1 ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§21: capture what the technician actually typed BEFORE the box is rewritten,
    # otherwise RawRoom just records the normalized value and preserves nothing.
    $raw = "$($script:UI['txtRoomNumber'].Text)".Trim()
    $v = Get-CanonicalRoom $raw
    if ($raw -and $v -ne $raw) {
        $script:RawRoomEntry = $raw
        $script:UI['txtRoomNumber'].Text = $v
    } elseif ($raw) {
        $script:RawRoomEntry = $raw
    }
})
Register-PanelButtonAction -Name 'btnLocationContinue' -Action {
    $ok = $true
    $selSchool = $script:UI['cboSchool'].SelectedItem
    if (-not $selSchool) {
        $script:UI['lblSchoolError'].Text       = 'Please select a school.'
        $script:UI['lblSchoolError'].Visibility = 'Visible'
        $ok = $false
    } else {
        $script:UI['lblSchoolError'].Visibility = 'Collapsed'
        $script:SchoolCode = $selSchool.Tag
        $parts = ($selSchool.Content -as [string]) -split ' - ',2
        $script:SchoolName = if ($parts.Count -ge 2) { $parts[1] } else { $selSchool.Content }
    }
    $selMfr = $script:UI['cboManufacturer'].SelectedItem
    if (-not $selMfr) {
        $script:UI['lblMfrError'].Text       = 'Please select a manufacturer.'
        $script:UI['lblMfrError'].Visibility = 'Visible'
        $ok = $false
    } else {
        $script:UI['lblMfrError'].Visibility = 'Collapsed'
        $script:Manufacturer = $selMfr.Content
        $script:MfrCode      = $selMfr.Tag
    }
    # Model validation - only required when the dropdown is visible (manufacturer has models defined)
    if ($script:UI['cboPanelModel'].Visibility -eq 'Visible') {
        $selModel = $script:UI['cboPanelModel'].SelectedItem
        if (-not $selModel) {
            $script:UI['lblPanelModelError'].Text       = 'Please select a panel model.'
            $script:UI['lblPanelModelError'].Visibility = 'Visible'
            $ok = $false
        } else {
            $script:UI['lblPanelModelError'].Visibility = 'Collapsed'
            $script:PanelModel = $selModel.Content
        }
    }
    # r14 ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§4: normalize BEFORE acceptance - the technician should never need Caps Lock, and
    # lowercase/spaced variants must not reach storage. The raw entry is kept for the record.
    # ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§21: if LostFocus already normalized the visible box, $script:RawRoomEntry still holds the
    # original text; only fall back to the box when nothing was captured earlier.
    $roomShown = "$($script:UI['txtRoomNumber'].Text)".Trim()
    $roomRaw = if ($script:RawRoomEntry -and (Get-CanonicalRoom $script:RawRoomEntry) -eq (Get-CanonicalRoom $roomShown)) {
                   $script:RawRoomEntry
               } else { $roomShown }
    $room = Get-CanonicalRoom $roomRaw
    if ($room.Length -eq 0) {
        $script:UI['lblRoomError'].Text       = 'Please enter a room or suffix.'
        $script:UI['lblRoomError'].Visibility = 'Visible'
        $ok = $false
    } else {
        $script:UI['lblRoomError'].Visibility = 'Collapsed'
        $script:UI['txtRoomNumber'].Text = $room     # show the tech what will be stored
        $script:RawRoomEntry = "$roomRaw"            # what was actually typed
        $script:RoomNumber   = $room
    }
    # v5.3.3 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§3: Room Type must be a real dropdown value; OtherRoomType required only for OTHER.
    $selRoomType = $script:UI['cboRoomType'].SelectedItem
    $rtVal = if ($selRoomType) { "$($selRoomType.Tag)" } else { '' }
    if (-not $rtVal) {
        $script:UI['lblRoomTypeError'].Text       = 'Select a Room Type.'
        $script:UI['lblRoomTypeError'].Visibility = 'Visible'
        $ok = $false
    } elseif ($rtVal -eq 'Other' -and $script:UI['txtOtherRoomType'].Text.Trim().Length -eq 0) {
        $script:UI['lblRoomTypeError'].Text       = 'Describe the room type when Other is selected.'
        $script:UI['lblRoomTypeError'].Visibility = 'Visible'
        $ok = $false
    } else {
        $script:UI['lblRoomTypeError'].Visibility = 'Collapsed'
        $script:RoomType      = $rtVal
        $script:OtherRoomType = if ($rtVal -eq 'Other') { Get-CanonicalFreeText $script:UI['txtOtherRoomType'].Text } else { '' }
    }
    if (-not $ok) { return }
    $script:MountType = if ($script:UI['rdoMobile'].IsChecked) { 'Mobile' } else { 'Wall' }
    # v5.4 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§4-13: inventory-correction mode goes to the before/after review, not provisioning.
    if ($script:InvEditing) { Show-InventoryReview; return }
    if ($script:CurrentMode -eq 9) { Continue-EndpointRepairAfterLocation; return }
    # v5.6 unified RMA routing. The technician no longer chooses "same model" vs "different model".
    # PanelApp looks at the actual OPS endpoint state after the replacement panel/location is known:
    #   domain joined + expected hostname already present -> inventory/pairing only
    #   domain joined + hostname changed               -> rename + inventory
    #   not domain joined                              -> full provisioning
    # Unknown domain state is blocked rather than guessed.
    if ($script:CurrentMode -eq 2) {
        Get-DomainMembership | Out-Null
        $expectedRmaHostname = Build-Hostname -SchoolCode $script:SchoolCode -MfrCode $script:MfrCode `
                                              -MountType $script:MountType -Room $script:RoomNumber `
                                              -PanelSerial $script:PanelSerial
        if ($script:DomainMembershipStatus -eq 'Unknown') {
            [System.Windows.MessageBox]::Show(
                'PanelApp could not determine whether this OPS is domain joined. RMA routing was stopped so the app does not accidentally re-provision a working endpoint. Verify the device/domain state or use Correct Inventory Record.',
                'RMA Domain State Unknown', 'OK', 'Warning') | Out-Null
            return
        }
        if ($script:DomainMembershipStatus -eq 'Domain Joined') {
            if ($env:COMPUTERNAME -ieq $expectedRmaHostname) {
                $script:RMAAction = 'InventoryOnly'
                $script:Hostname = $env:COMPUTERNAME
                Show-ReviewScreen
                return
            }
            $script:RMAAction = 'RenameOnly'
            Show-HostnameScreen
            return
        }
        $script:RMAAction = 'FullProvision'
        Show-HostnameScreen
        return
    }
    # Mode 6 skips hostname builder - capture current hostname and go straight to review
    if ($script:CurrentMode -eq 6) {
        $script:Hostname = $env:COMPUTERNAME
        Show-ReviewScreen
        return
    }
    # Mode 7 (Summer 2026) uses the tech-entered location for inventory. The current
    # hostname is recorded for reference only - it is NOT used to derive any field.
    # Location now leads into the Day One Readiness screen before capture.
    if ($script:CurrentMode -eq 7) {
        $script:Hostname = $env:COMPUTERNAME
        Prepare-DayOneScreen
        Show-Screen 'pnlDayOneCheck'
        return
    }
    Show-HostnameScreen
}

# -- Hostname screen --
$script:UI['txtHostname'].Add_TextChanged({
    $txt = $script:UI['txtHostname'].Text
    $script:UI['lblHostnameLength'].Text = "$($txt.Length) / 15"
    $script:HostnameCheckStatus = 'NotChecked'   # any edit invalidates the previous check (fix #7)
    if ($txt.Length -gt 0) {
        $v = Test-Hostname -Hostname ($txt.ToUpper())
        $script:UI['lblHostnameValidation'].Text = if ($v.Valid) { '' } else { $v.Message }
    } else {
        $script:UI['lblHostnameValidation'].Text = ''
    }
})
# Review smaller fix #5: editing the old hostname invalidates its previous check result
$script:UI['txtOldHostname'].Add_TextChanged({ $script:OldHostnameCheckResult = '' })
Register-PanelButtonAction -Name 'btnCheckHostname' -Action {
    $hn = $script:UI['txtHostname'].Text.Trim().ToUpper()
    if ($hn.Length -eq 0) { return }
    $script:UI['lblHostnameCheck'].Text = 'Checking DNS/AD...'
    $script:UI['lblHostnameCheck'].Visibility = 'Visible'
    $script:UI['borAltHostname'].Visibility = 'Collapsed'
    $lines = @()
    # Old hostname (entered or assumed): existing is EXPECTED - warn only, never block (ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§9.3)
    $old = $script:UI['txtOldHostname'].Text.Trim().ToUpper()
    $script:OldHostnameCheckResult = ''
    if ($old) {
        $oldMsg = Test-HostnameAvailability -Hostname $old
        $script:OldHostnameCheckResult = $oldMsg
        if ($oldMsg -like 'Warning*') {
            $lines += "Previous hostname appears to exist. This may be expected if the old AD object has not been removed. PanelApp will continue using the new temporary hostname."
        }
    }
    # New hostname: conflict -> offer a safe alternate instead of stopping (ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§3).
    # Review fix #7: the result gates Confirm via HostnameCheckStatus.
    $msg = Test-HostnameAvailability -Hostname $hn
    $script:NewHostnameCheckResult = $msg
    # v5.4 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§29: the name already belonging to THIS device / this same project is not a conflict.
    if ($msg -like 'Warning*' -and (Test-HostnameIsSelf -Hostname $hn)) {
        $script:HostnameCheckStatus = 'Available'
        $script:NewHostnameCheckResult = "Hostname already belongs to this device/project - reuse allowed."
        $lines += "$hn is already assigned to THIS device (or this same Interactive Inventory project). Reuse is allowed - no new suffix is needed."
        $script:UI['lblHostnameCheck'].Foreground = New-Brush '#9FE8D8'
        $script:UI['lblHostnameCheck'].Text = ($lines -join "`n")
        try { $script:UI['lblHostnameCheck'].BringIntoView() } catch {}
        return
    }
    if ($msg -like 'Warning*') {
        $script:HostnameCheckStatus = 'Conflict'
        $lines += "Generated hostname ${hn}: $msg"
        $alt = Get-AlternateHostname -Hostname $hn
        if ($alt) {
            $lines += "Select the available alternate hostname below, then continue."
            $script:UI['lblAltHostname'].Text = $alt.Hostname
            $script:UI['borAltHostname'].Visibility = 'Visible'
        } else {
            $lines += "PanelApp could not generate a safe available hostname for this device. Stop here and contact a lead so the spreadsheet and AD records do not become mismatched."
        }
        $script:UI['lblHostnameCheck'].Foreground = New-Brush '#F0B030'
    } else {
        $script:HostnameCheckStatus = if ($msg -like 'DNS check completed*') { 'DNSAvailableADUnavailable' } else { 'Available' }
        $lines += "New hostname ${hn}: $msg"
        $script:UI['lblHostnameCheck'].Foreground = New-Brush '#9FE8D8'
    }
    $script:UI['lblHostnameCheck'].Text = ($lines -join "`n")
    # ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§11: scroll newly revealed results/buttons into view
    try { if ($script:UI['borAltHostname'].Visibility -eq 'Visible') { $script:UI['borAltHostname'].BringIntoView() }
          else { $script:UI['lblHostnameCheck'].BringIntoView() } } catch {}
}
Register-PanelButtonAction -Name 'btnUseAlternate' -Action {
    $alt = $script:UI['lblAltHostname'].Text.Trim()
    if ($alt -and $alt -ne '--') {
        $script:UI['txtHostname'].Text = $alt   # TextChanged resets status; set it after
        $script:HostnameCheckStatus = 'AlternateSelected'   # alternate was checked before being offered
        $script:NewHostnameCheckResult = 'Alternate selected (pre-checked available)'
        $script:UI['borAltHostname'].Visibility = 'Collapsed'
        $script:UI['lblHostnameCheck'].Text = "Using alternate hostname $alt (checked available)."
        $script:UI['lblHostnameCheck'].Foreground = New-Brush '#9FE8D8'
        Write-Log "Alternate hostname selected: $alt"
    }
}
Register-PanelButtonAction -Name 'btnHostnameBack' -Action { Show-Screen 'pnlLocation' }
Register-PanelButtonAction -Name 'btnHostnameConfirm' -Action {
    $hn = $script:UI['txtHostname'].Text.Trim().ToUpper()
    $v  = Test-Hostname -Hostname $hn
    if (-not $v.Valid) {
        $script:UI['lblHostnameValidation'].Text = $v.Message
        return
    }
    # Review fix #7: the AD/DNS check is REQUIRED and a known conflict blocks Confirm.
    if ($script:HostnameCheckStatus -eq 'NotChecked') {
        $script:UI['lblHostnameValidation'].Text = 'Run "Check Hostname in AD/DNS" before confirming.'
        return
    }
    if ($script:HostnameCheckStatus -eq 'Conflict') {
        $script:UI['lblHostnameValidation'].Text = 'This hostname conflicts in DNS/AD. Use the alternate hostname or resolve the conflict.'
        return
    }
    # Review fix #8: persist the old-hostname audit trail
    $oldEntered = $script:UI['txtOldHostname'].Text.Trim().ToUpper()
    $script:PreviousHostname = $oldEntered
    if (-not $oldEntered) { $script:PreviousHostnameSource = 'Unknown' }
    elseif ($oldEntered -ne $script:PrefilledOldHostname) { $script:PreviousHostnameSource = 'Technician Entered' }
    # else: keep the source set when the screen was populated (Summer2026 Record / Assumed Wall Hostname)
    $sfx = [regex]::Match($hn, '(X\d?|XX|Y|Z)$').Value
    $script:SelectedHostnameSuffix = $sfx
    $script:Hostname = $hn
    if ($script:CurrentMode -eq 9) { $script:EndpointRepairExpectedHostname = $hn; Show-EndpointRepairReview; return }
    switch ($script:CurrentMode) {
        3       {
            $script:UI['lblM3MoveReasonError'].Visibility = 'Collapsed'
            if ($script:InventoryPreviousPanelSerial) {
                $script:UI['lblM3ReassignmentContext'].Text = "Current inventory shows OPS $($script:OPSSerial) on panel $($script:InventoryPreviousPanelSerial). You are working on panel $($script:PanelSerial). Select the actual reason before PanelApp changes any pairing."
            } elseif (-not $script:IsNetworkAvailable) {
                $script:UI['lblM3ReassignmentContext'].Text = 'PanelApp is offline, so the prior pairing cannot be verified now. The backend will refuse an unsafe reassignment if the prior identity does not match when this event syncs.'
            } else {
                $script:UI['lblM3ReassignmentContext'].Text = "No different current panel was found for OPS $($script:OPSSerial). Select the reason for the move so the history is explicit."
            }
            Show-Screen 'pnlM3Disposition'
        }
        default { Show-ReviewScreen }
    }
}

# -- Mode 3 disposition --
$script:UI['rdoM3SetAside'].Add_Checked({
    $script:UI['pnlM3OldOPS'].Visibility = 'Visible'
})
$script:UI['rdoM3AnotherPanel'].Add_Checked({
    $script:UI['pnlM3OldOPS'].Visibility = 'Collapsed'
})
$script:UI['txtOldOPSBarcode'].Add_TextChanged({
    $txt = $script:UI['txtOldOPSBarcode'].Text.Trim()
    if ($txt.Length -gt 0) {
        $script:UI['lblOldOPSScanStatus'].Text       = 'OK'
        $script:UI['lblOldOPSScanStatus'].Foreground = New-Brush '#4EC994'
    } else {
        $script:UI['lblOldOPSScanStatus'].Text       = 'Ready'
        $script:UI['lblOldOPSScanStatus'].Foreground = New-Brush '#888888'
    }
})
Register-PanelButtonAction -Name 'btnM3Back' -Action { Show-Screen 'pnlHostname' }
Register-PanelButtonAction -Name 'btnM3Continue' -Action {
    $script:UI['lblM3MoveReasonError'].Visibility = 'Collapsed'
    if ($script:UI['rdoM3Permanent'].IsChecked) {
        $script:InventoryReassignmentType = 'PermanentOPSMove'
        $script:InventoryReassignmentReason = 'Technician confirmed permanent OPS move / swap'
        $script:InventoryReassignmentConfirmed = $true
        $script:TemporaryAssignment = $false; $script:FollowUpRequired = $false; $script:TestingObservationOnly = $false
    } elseif ($script:UI['rdoM3Temporary'].IsChecked) {
        $script:InventoryReassignmentType = 'TemporaryOperationalSwap'
        $script:InventoryReassignmentReason = 'Temporary classroom coverage - follow-up required'
        $script:InventoryReassignmentConfirmed = $true
        $script:TemporaryAssignment = $true; $script:FollowUpRequired = $true; $script:TestingObservationOnly = $false
    } elseif ($script:UI['rdoM3Testing'].IsChecked) {
        $script:InventoryReassignmentType = 'TestingOnly'
        $script:InventoryReassignmentReason = 'Testing / troubleshooting only - authoritative pairing unchanged'
        $script:InventoryReassignmentConfirmed = $false
        $script:TemporaryAssignment = $false; $script:FollowUpRequired = $false; $script:TestingObservationOnly = $true
    } else {
        $script:UI['lblM3MoveReasonError'].Text = 'Select Permanent, Temporary classroom coverage, or Testing only before continuing.'
        $script:UI['lblM3MoveReasonError'].Visibility = 'Visible'; return
    }
    $script:M3OldOPSDisposition = if ($script:TestingObservationOnly) { 'Temporarily removed for testing' }
        elseif ($script:UI['rdoM3AnotherPanel'].IsChecked) { 'Going into another panel' } else { 'Setting aside' }
    $script:OldOPSSerial = $script:UI['txtOldOPSBarcode'].Text.Trim()
    Show-ReviewScreen
}

# -- Mode 5 hostname check --
$script:UI['rdoM5Yes'].Add_Checked({
    $script:M5HostnameCorrect = $true
    $script:UI['borM5RebuildNote'].Visibility = 'Collapsed'
})
$script:UI['rdoM5No'].Add_Checked({
    $script:M5HostnameCorrect = $false
    $script:UI['borM5RebuildNote'].Visibility = 'Visible'
})
Register-PanelButtonAction -Name 'btnM5Back' -Action { Show-Screen 'pnlScanBarcode' }
Register-PanelButtonAction -Name 'btnM5Continue' -Action {
    if ($script:M5HostnameCorrect) {
        $script:Hostname = $env:COMPUTERNAME
        Show-ReviewScreen
    } else {
        Prepare-LocationScreen
        Show-Screen 'pnlLocation'
    }
}

# -- Review screen --
Register-PanelButtonAction -Name 'btnReviewBack' -Action {
    switch ($script:CurrentMode) {
        { $_ -in @(1,4) } { Show-Screen 'pnlHostname' }
        2 { if ($script:RMAAction -eq 'InventoryOnly') { Show-Screen 'pnlLocation' } else { Show-Screen 'pnlHostname' } }
        3                    { Show-Screen 'pnlM3Disposition' }
        6                    { Show-Screen 'pnlLocation' }
        9                    { if ($script:EndpointRepairAction -eq 'DomainJoinOnly') { Show-Screen 'pnlLocation' } else { Show-Screen 'pnlHostname' } }
        5 {
            if ($script:M5HostnameCorrect) { Show-Screen 'pnlM5HostnameCheck' }
            else                           { Show-Screen 'pnlHostname' }
        }
    }
}
Register-PanelButtonAction -Name 'btnReviewExecute' -Action {
    switch ($script:CurrentMode) {
        9 { Execute-EndpointRepair; return }
        1 { Execute-PhaseA }
        2 {
            switch ($script:RMAAction) {
                'InventoryOnly' { Execute-RMAInventoryOnly }
                'RenameOnly'    { Execute-RenameAndLog }
                default         { Execute-PhaseA }
            }
        }
        3 {
            if ($script:TestingObservationOnly -or $script:InventoryReassignmentType -eq 'TestingOnly') { Execute-OPSTestingObservation }
            else { Execute-RenameAndLog }
        }
        4 { Execute-RenameAndLog }
        6                  { Execute-Inventory }
        5 {
            if ($script:M5HostnameCorrect) { Execute-LogOnly }
            else                           { Execute-RenameAndLog }
        }
    }
}

# -- Progress screen --
# v5.4 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§29: a Phase A failure is retryable on the SAME device / same ProjectRunId. Phase A skips
# the rename when the device already carries the target name, so this is safe to re-run.
Register-PanelButtonAction -Name 'btnProgressRetry' -Action {
    $r = [System.Windows.MessageBox]::Show(
        "Retry Phase A on this device?`n`nPanelApp will re-run Phase A using the same project and the same intended hostname. If the rename was already applied, it is skipped automatically.`n`nMake sure the cleanup items above are resolved first.",
        'Retry Phase A', 'OKCancel', 'Question')
    if ($r -ne 'OK') { return }
    Write-Log 'Technician chose Retry Phase A.'
    Execute-PhaseA
}
Register-PanelButtonAction -Name 'btnProgressDone' -Action {
    $upgradeActionReady = ($script:ProgressAction -eq 'StartWindowsUpgrade')
    if (-not $upgradeActionReady -and $script:WindowsUpgradeRunspaceSync) {
        try { $upgradeActionReady = ("$($script:WindowsUpgradeRunspaceSync.ProgressAction)" -eq 'StartWindowsUpgrade') } catch {}
    }
    if ($upgradeActionReady) {
        Start-Windows11UpgradeInstall
        return
    }
    $script:UI['lblCompleteTitle'].Text   = 'Operation Complete'
    $script:UI['lblCompleteMessage'].Text = 'The operation completed successfully. You may close the application or run another operation.'
    Show-Screen 'pnlComplete'
}
Register-PanelButtonAction -Name 'btnProgressReboot' -Action {
    Write-Log 'Rebooting system...'
    Restart-Computer -Force
}
$script:UI['btnAbortProvision'].Add_Click({
    if (-not (Show-AbortConfirm)) { return }   # Cancel = keep provisioning
    $abortRes = Abort-Provisioning
    # Don't let the tech reboot into a continuation that no longer exists. The local abort always
    # succeeded, so these are hidden regardless of what the spreadsheet did with the records.
    $script:UI['btnAbortProvision'].Visibility = 'Collapsed'
    $script:UI['btnProgressReboot'].Visibility  = 'Collapsed'
    $script:UI['btnProgressDone'].Visibility     = 'Visible'
    # r11 finding #2: never report a bare "Provisioning aborted" when the spreadsheet refused the
    # record - the device may be renamed with nothing on the sheet to explain it.
    if ($abortRes -and $abortRes.Rejected) {
        $codes = @()
        if ($abortRes.ProjectResult -and $abortRes.ProjectResult.Rejected)   { $codes += "Interactive Inventory project update: $($abortRes.ProjectResult.Parsed.ErrorCode) - $($abortRes.ProjectResult.Parsed.Message)" }
        if ($abortRes.ExceptionResult -and $abortRes.ExceptionResult.Rejected) { $codes += "Abort exception: $($abortRes.ExceptionResult.Parsed.ErrorCode) - $($abortRes.ExceptionResult.Parsed.Message)" }
        Write-Log "Abort recorded locally but the spreadsheet rejected: $($codes -join ' | ')" 'ERROR'
        Update-ProgressStatus 'Provisioning aborted locally - spreadsheet record NOT accepted.'
        [System.Windows.MessageBox]::Show(
            "Provisioning was aborted locally, but one or more spreadsheet updates were not accepted.`n`n" +
            ($codes -join "`n") + "`n`n" +
            "The device may already be renamed. The aborted state file was preserved.`n`n" +
            "Do not restart provisioning until a lead reconciles the device and spreadsheet records.",
            'Abort Not Fully Recorded', 'OK', 'Error') | Out-Null
    } elseif ($abortRes -and $abortRes.Queued) {
        Update-ProgressStatus 'Provisioning aborted locally - spreadsheet updates pending sync.'
        [System.Windows.MessageBox]::Show(
            "Provisioning was aborted locally.`n`nThe spreadsheet updates are pending synchronization.`n`n" +
            "Windows Update has been restored and pending continuation tasks were removed. The device may already have been renamed during Phase A.`n`n" +
            "Do not restart provisioning until the queued records synchronize and the device state is reviewed.",
            'Provisioning Aborted - Pending Sync', 'OK', 'Warning') | Out-Null
    } else {
        Update-ProgressStatus 'Provisioning aborted.'
        # Only claim the Summer update when there was a Summer project to update.
        $recorded = if ($abortRes -and $abortRes.ProjectResult) {
            'The Interactive Inventory project was marked Manual Review Required and the abort exception was recorded.'
        } else {
            'The abort exception was recorded. This attempt was not linked to an Interactive Inventory Project, so no project record was changed.'
        }
        [System.Windows.MessageBox]::Show(
            "Provisioning was aborted locally.`n`n$recorded`n`nWindows Update has been restored and pending continuation tasks were removed.`n`nThe device may already have been renamed during Phase A. Do not restart the provisioning workflow until the device state has been reviewed.",
            'Provisioning Aborted', 'OK', 'Information') | Out-Null
    }
})

# -- Phase B screen --
# ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§34: Show Password toggle. The visible TextBox mirrors into the PasswordBox, which stays
# the single source of truth (Execute-PhaseB keeps reading SecurePassword unchanged).
$script:UI['chkShowPass'].Add_Checked({
    $script:UI['txtDomainPassVisible'].Text = $script:UI['pwbDomainPass'].Password
    $script:UI['pwbDomainPass'].Visibility = 'Collapsed'
    $script:UI['txtDomainPassVisible'].Visibility = 'Visible'
})
$script:UI['chkShowPass'].Add_Unchecked({
    $script:UI['pwbDomainPass'].Password = $script:UI['txtDomainPassVisible'].Text
    $script:UI['txtDomainPassVisible'].Visibility = 'Collapsed'
    $script:UI['pwbDomainPass'].Visibility = 'Visible'
})
$script:UI['txtDomainPassVisible'].Add_TextChanged({
    if ($script:UI['chkShowPass'].IsChecked) {
        $script:UI['pwbDomainPass'].Password = $script:UI['txtDomainPassVisible'].Text
    }
})
Register-PanelButtonAction -Name 'btnJoinDomain' -Action {
    $user = $script:UI['txtDomainUser'].Text.Trim()
    $pass = $script:UI['pwbDomainPass'].SecurePassword
    if ($user.Length -eq 0) {
        [System.Windows.MessageBox]::Show('Enter a domain username.','Missing Input','OK','Warning') | Out-Null
        return
    }
    if ($script:CurrentMode -eq 9 -and $script:EndpointRepairAction) {
        Execute-EndpointRepairDomainAction -DomainUser $user -SecurePwd $pass
        return
    }
    # Sync the visible mirror back if Show Password is on, then require a non-empty password
    if ($script:UI['chkShowPass'].IsChecked) { $script:UI['pwbDomainPass'].Password = $script:UI['txtDomainPassVisible'].Text }
    if ($script:UI['pwbDomainPass'].Password.Length -eq 0) {
        [System.Windows.MessageBox]::Show('Enter the domain password before joining.','Missing Input','OK','Warning') | Out-Null
        return
    }
    $pass = $script:UI['pwbDomainPass'].SecurePassword
    Execute-PhaseB -DomainUser $user -SecurePwd $pass
}
Register-PanelButtonAction -Name 'btnPhaseBReboot' -Action {
    Write-Log 'Phase B - rebooting to complete domain join...'
    Restart-Computer -Force
}

# -- Complete screen --
$script:UI['btnCloseApp'].Add_Click({ $script:window.Close() })

# -- Version block screen (hard stop) --
$script:UI['btnVersionBlockClose'].Add_Click({ $script:window.Close() })

# -- Summer 2026 Day One Readiness screen --
Register-PanelButtonAction -Name 'btnDayOneBack' -Action { Show-Screen 'pnlLocation' }
Register-PanelButtonAction -Name 'btnReportIssue' -Action {
    $vis = $script:UI['borIssueForm'].Visibility
    $script:UI['borIssueForm'].Visibility = if ($vis -eq 'Visible') { 'Collapsed' } else { 'Visible' }
    # Review fix #12: make the form immediately visible and usable
    if ($script:UI['borIssueForm'].Visibility -eq 'Visible') {
        try { $script:UI['borIssueForm'].BringIntoView() } catch {}
        try { $script:UI['cboIssueCategory'].Focus() | Out-Null } catch {}
    }
}
Register-PanelButtonAction -Name 'btnIssueSubmit' -Action {
    # Issue path: a panel with a problem still gets inventoried and tracked.
    $sel = $script:UI['cboIssueCategory'].SelectedItem
    if (-not $sel) {
        $script:UI['lblDayOneError'].Text       = 'Select an issue category before submitting.'
        $script:UI['lblDayOneError'].Visibility = 'Visible'
        return
    }
    $script:ReadinessIssueCategory = "$($sel.Content)"
    $script:ReadinessIssueNote     = $script:UI['txtIssueNote'].Text.Trim()
    if (-not $script:ProjectRunId) { $script:ProjectRunId = New-ProjectRunId }
    # r11 finding #1: create the PanelAppExceptions record FIRST and only claim 'Issue Reported'
    # once the spreadsheet has accepted (or queued) it. Stamping DayOneStatus before the post let a
    # permanent rejection produce a Summer assessment claiming an exception that does not exist.
    $issueRes = Send-ExceptionEvent -Category $script:ReadinessIssueCategory `
                                    -Note $script:ReadinessIssueNote `
                                    -Phase 'Panel Readiness'
    if ($issueRes.Rejected) {
        $script:DayOneStatus = ''
        $why = if ($issueRes.Parsed) { "$($issueRes.Parsed.ErrorCode): $($issueRes.Parsed.Message)" }
               else { 'The spreadsheet permanently rejected the issue report.' }
        Write-Log "panel readiness issue REJECTED ($why) - assessment not started." 'ERROR'
        $script:UI['lblDayOneError'].Text       = 'The issue was not recorded. The assessment was not started.'
        $script:UI['lblDayOneError'].Visibility = 'Visible'
        [System.Windows.MessageBox]::Show(
            "This panel readiness issue was NOT recorded.`n`n$why`n`n" +
            "PanelApp will remain on this panel. Do not continue the assessment or move to the next panel until the conflict is reviewed.",
            'Panel Readiness Issue Not Recorded', 'OK', 'Error') | Out-Null
        return
    }
    if ($issueRes.Queued) {
        # No separate DayOneStatus value - the event queue carries the true delivery state, and the
        # assessment queues behind this exception because both share the ProjectRunId.
        [System.Windows.MessageBox]::Show(
            "The panel readiness issue was saved to the offline queue. The Interactive Inventory assessment will remain ordered behind it and will synchronize when connectivity returns.",
            'Panel Readiness Issue Pending Sync', 'OK', 'Warning') | Out-Null
    }
    $script:DayOneStatus = 'Issue Reported'
    Read-DayOneState   # capture whatever was actually checked (honest partial state)
    Start-SummerCapture
}
Register-PanelButtonAction -Name 'btnDayOneContinue' -Action {
    # Day One Ready path: every check must be selected and a network type chosen.
    $allChecked = $script:UI['chkDisplay'].IsChecked -and $script:UI['chkTouch'].IsChecked -and
                  $script:UI['chkSound'].IsChecked -and $script:UI['chkCables'].IsChecked -and
                  $script:UI['chkNetwork'].IsChecked -and $script:UI['chkNDMS'].IsChecked
    $netChosen = $script:UI['rdoNetEthernet'].IsChecked -or $script:UI['rdoNetWifi'].IsChecked
    if (-not $allChecked -or -not $netChosen) {
        $script:UI['lblDayOneError'].Text = 'All readiness checks must be selected and a network type chosen - or use Report an Issue.'
        $script:UI['lblDayOneError'].Visibility = 'Visible'
        return
    }
    $script:UI['lblDayOneError'].Visibility = 'Collapsed'
    $script:DayOneStatus           = 'Day One Ready'
    $script:ReadinessIssueCategory = ''
    $script:ReadinessIssueNote     = ''
    Read-DayOneState
    Start-SummerCapture
}

# -- Summer 2026 summary screen --
# ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§5: Finish closes out THIS panel and returns to the menu. It does NOT re-loop into a
# fresh capture (which previously restarted the workflow on the same physical panel).
# v5.3.3 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§1: compute the recommendation when the final assessment screen appears, and label the
# button with the SPECIFIC action (not a generic "Next"). Clicking it runs that action directly.
$script:UI['pnlSummerSummary'].Add_IsVisibleChanged({
    if (-not $script:UI['pnlSummerSummary'].IsVisible) { return }
    try {
        $rec = Get-ProvisioningRecommendation
        $script:UI['btnSummerNext'].Content = $rec.ButtonLabel
        $script:UI['lblSum_Next'].Text = switch ($rec.Action) {
            'finish'   { 'This panel has passed the Interactive Inventory Project assessment. No provisioning work is required. Click Finish This Panel.' }
            'fullprov' { 'New replacement panel on the approved image. Click to continue directly into Full Provisioning on the same Interactive Inventory project.' }
            'existingprov' { 'Existing panel on the approved image, not domain joined. Click to continue provisioning on the same Interactive Inventory project (no RedoRescue restore required).' }
            'redo'     { "RedoRescue restoration is required before provisioning. $($rec.Reason)" }
            'winupgrade'     { "Windows upgrade required (not a reimage). $($rec.Reason)" }
            'pendingrestart' { "A mandatory Windows Update restart is pending. $($rec.Reason)" }
            'firmware'       { "BIOS/UEFI configuration required (not a reimage). $($rec.Reason)" }
            'manual'   { "Manual review required. $($rec.Reason)" }
            'exception'{ 'A panel readiness issue was reported. Review the exception.' }
            'ask'      { 'This device is not domain joined. Click to confirm the installation type so PanelApp can route it correctly.' }
            default    { $rec.Reason }
        }
    } catch { Write-Log "Summary recommendation compute failed: $_" 'WARN' }
})
Register-PanelButtonAction -Name 'btnSummerNext' -Action { Invoke-RecommendationAction }

# -- v5.3.2 provisioning recommendation handlers --
# Fix #2: record who/when confirmed a NEW panel here (not only in Continue-ToFullProvisioning),
# so a new panel routed to RedoRescue still carries the confirmation. Clear it on No / Not Sure.
Register-PanelButtonAction -Name 'btnInstallNew' -Action {
    $script:InstallType           = 'New Replacement Install'
    $script:NewInstallConfirmedBy = $script:TechName
    $script:NewInstallConfirmedAt = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
    Show-ProvRecommendation
}
Register-PanelButtonAction -Name 'btnInstallExisting' -Action {
    $script:InstallType = 'Existing Panel'
    $script:NewInstallConfirmedBy = ''; $script:NewInstallConfirmedAt = ''
    Show-ProvRecommendation
}
Register-PanelButtonAction -Name 'btnInstallUnsure' -Action {
    $script:InstallType = 'Unknown'
    $script:NewInstallConfirmedBy = ''; $script:NewInstallConfirmedAt = ''
    Show-ProvRecommendation
}
Register-PanelButtonAction -Name 'btnProvRecReport' -Action {
    Show-IssueReport 'Provisioning Recommendation' 'pnlProvRecommend'
    # Pre-select the domain-state category so triage/severity are right
    if ($script:ProvRecIssueCategory) {
        foreach ($it in $script:UI['cboExCategory'].Items) {
            if ("$($it.Content)" -eq $script:ProvRecIssueCategory) { $script:UI['cboExCategory'].SelectedItem = $it; break }
        }
    }
}
Register-PanelButtonAction -Name 'btnProvRecAction' -Action { Invoke-RecommendationAction }
# ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§5: explicit, confirmed path to assess a DIFFERENT panel.
# v5.3.2 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§8: btnSummerCaptureAnother and btnSummerClose are collapsed on the summary screen -
# Capture Another / Finish now live on the recommendation screen (after the outcome is recorded),
# so their old handlers were removed to avoid an unreachable path that skipped the write-back.

# -- Summer continuation (reimage mode) --
function Clear-SummerContinuation {
    $script:SummerContinuation      = $false
    $script:RelatedSummerRunId      = ''
    $script:SummerImageProfile      = ''
    $script:SummerRedoFile          = ''
    $script:SummerOriginalOPS       = ''
    $script:SummerOriginalDayOne    = ''
    $script:OPSReplacementConfirmed = ''
}
# ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§4: no skip/bypass of a matched Summer record. Report a Problem instead.
Register-PanelButtonAction -Name 'btnContReportIssue' -Action { Show-IssueReport 'Summer Continuation' 'pnlSummerContinuation' }
Register-PanelButtonAction -Name 'btnSelectReportIssue' -Action { Show-IssueReport 'Summer Continuation' 'pnlSummerSelect' }
# ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§3: RedoRescue gate block screen
Register-PanelButtonAction -Name 'btnGateBack' -Action { Show-Screen 'pnlModeSelect' }
Register-PanelButtonAction -Name 'btnGateReportIssue' -Action { Show-IssueReport 'RedoRescue Gate' 'pnlModeSelect' }
# NOTE: pnlSummerSelect is currently UNREACHABLE - multiple active matches route to
# Show-MultiActiveBlock instead (a tech must never pick the winner). Kept wired correctly so that
# if the selection screen is ever re-enabled it goes through the v5.4.1 continuation router
# rather than asserting RedoRescue.
Register-PanelButtonAction -Name 'btnSelectContinue' -Action {
    $sel = $script:UI['cboSummerMatch'].SelectedItem
    if (-not $sel) { return }
    $rec = $script:SummerMatches | Where-Object { "$($_.ProjectRunId)" -eq "$($sel.Tag)" } | Select-Object -First 1
    if ($rec) { Route-SummerContinuation $rec }
}
Register-PanelButtonAction -Name 'btnContinueSummer' -Action {
    $rec = $script:SummerRecord
    if (-not $rec) { return }
    # ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§36.5: tech must confirm the approved image folder was used (not a substitute for the gate)
    if (-not $script:UI['chkImageConfirm'].IsChecked) {
        $script:UI['lblContError'].Text = 'Confirm the approved RedoRescue image folder above was used before continuing.'
        $script:UI['lblContError'].Visibility = 'Visible'; return
    }
    # OPS mismatch must be resolved if shown
    if ($script:UI['borOPSMismatch'].Visibility -eq 'Visible') {
        if (-not $script:UI['rdoOPSNo'].IsChecked -and -not $script:UI['rdoOPSYes'].IsChecked) {
            $script:UI['lblContError'].Text = 'Answer the OPS replacement question to continue.'
            $script:UI['lblContError'].Visibility = 'Visible'; return
        }
        if ($script:UI['rdoOPSNo'].IsChecked) {
            $script:UI['lblContError'].Text = 'Investigate the OPS difference before continuing (do not proceed).'
            $script:UI['lblContError'].Visibility = 'Visible'; return
        }
        $script:OPSReplacementConfirmed = 'Yes'
    } else {
        $script:OPSReplacementConfirmed = ''
    }
    $script:UI['lblContError'].Visibility = 'Collapsed'
    # Link this provisioning run to the Summer project
    $script:SummerContinuation   = $true
    $script:RelatedSummerRunId   = "$($rec.ProjectRunId)"
    $script:ProjectRunId         = "$($rec.ProjectRunId)"
    $script:SummerImageProfile   = "$($rec.ImageProfile)"
    $script:SummerRedoFile        = "$($rec.RedoImageFile)"
    $script:SummerOriginalOPS     = if ($rec.OriginalOPSSerial) { "$($rec.OriginalOPSSerial)" } else { "$($rec.OPSSerial)" }
    $script:SummerOriginalDayOne  = "$($rec.DayOneStatus)"
    # Fix #3: restore the new-replacement identity so the final record keeps it after RedoRescue
    $script:InstallType                 = "$($rec.InstallType)"
    $script:ProvisioningPathRecommended = if ("$($rec.ProvisioningPathRecommended)") { "$($rec.ProvisioningPathRecommended)" } else { 'Post-RedoRescue Provisioning' }
    $script:ProvisioningPathSelected    = 'Post-RedoRescue Provisioning'
    $script:NewInstallConfirmedBy       = "$($rec.NewInstallConfirmedBy)"
    $script:NewInstallConfirmedAt       = "$($rec.NewInstallConfirmedAt)"
    $script:NewInstallProvisioning      = ("$($rec.InstallType)" -eq 'New Replacement Install')
    # This IS the genuine post-RedoRescue path - it is only reached after the gate confirms the
    # restore, so the recovery wording below is accurate here (review issue #3).
    $script:RecoveryProvisioning        = $true
    Restore-ImageDecisionState $rec
    # Fix #4: restore location/device values from the record - no re-entry, then straight to hostname
    $script:SchoolCode   = "$($rec.SchoolCode)"; $script:SchoolName = "$($rec.SchoolName)"
    $script:RoomNumber   = "$($rec.Room)";       $script:MfrCode    = "$($rec.MfrCode)"
    $script:Manufacturer = "$($rec.Manufacturer)"; $script:PanelModel = "$($rec.PanelModel)"
    $script:MountType    = "$($rec.MountType)"
    $script:RoomType     = "$($rec.RoomType)"; $script:OtherRoomType = "$($rec.OtherRoomType)"
    if ("$($rec.StorageActualGB)") { $script:StorageGB = "$($rec.StorageActualGB)" } elseif ("$($rec.StorageTierGB)") { $script:StorageGB = "$($rec.StorageTierGB)" }
    # Refresh domain state at provisioning time (a restored device is expected to be off-domain)
    Get-DomainMembership | Out-Null
    $script:ProvisioningTech = $script:TechName
    # Bring the gate's acknowledged revision back before selection and preserve its queue hold.
    if ($script:ActiveSenderSync) { Merge-SyncSenderContext $script:ActiveSenderSync }
    # Mark the Summer record as provisioning-in-progress (with restored routing identity)
    $now = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
    $provRes = Send-Event -Payload @{
        LogSheet      = 'Summer2026'
        ProjectRunId  = $script:RelatedSummerRunId
        PanelSerial = $script:PanelSerial; OPSSerial = $script:OPSSerial
        ProjectStatus = 'Provisioning In Progress'
        ProvisioningStatus = $(if ($script:NewInstallProvisioning) { 'New Install - Post-RedoRescue - Provisioning' } else { 'Post-RedoRescue - Provisioning' })
        CurrentStage  = 'Provisioning'
        InstallType   = $script:InstallType
        ProvisioningPathRecommended = $script:ProvisioningPathRecommended
        ProvisioningPathSelected    = 'Post-RedoRescue Provisioning'
        DomainMembershipStatus = $script:DomainMembershipStatus; DetectedDomain = $script:DetectedDomain
        SecureChannelStatus = $script:SecureChannelStatus; DomainCheckAt = $script:DomainCheckAt
        NewInstallConfirmedBy = $script:NewInstallConfirmedBy; NewInstallConfirmedAt = $script:NewInstallConfirmedAt
        ProvisioningTech = $script:TechName
        CurrentOPSSerial       = $script:OPSSerial
        OPSReplacementConfirmed = $script:OPSReplacementConfirmed
        LastUpdatedBy = $script:TechName
        LastUpdatedAt = $now
    } -EventType 'PostRedoRescueProvisioningSelected'
    # r9 finding #2: same protection the other three provisioning paths already have.
    if ($provRes -and $provRes.Rejected) { Stop-OnRejectedProvisioningPath $provRes 'Post-RedoRescue Provisioning'; return }
    Write-Log "Interactive Inventory continuation linked: $($script:RelatedSummerRunId) (InstallType=$($script:InstallType))"
    # A Summer-project resume can still be in mode 7. From here forward this is genuine
    # provisioning work; Confirm and Execute dispatches Phase A only from provisioning mode.
    Set-Mode 1 'Post-RedoRescue Provisioning'
    Show-HostnameScreen
}

# -- Reimage closeout --
Register-PanelButtonAction -Name 'btnCoEthernetException' -Action { Submit-AndroidEthernetLowException }
Register-PanelButtonAction -Name 'btnCloseoutIssue' -Action {
    Show-IssueReport (Get-CloseoutPhaseLabel) 'pnlReimageCloseout'
}
# r13 finding #1: one-click submission control for the closeout. Disabling the button and
# repainting BEFORE any network work is what makes a second click impossible - the guard alone
# cannot help while the UI thread is blocked and the click is sitting in the message queue.

# Classify the exact pending closeout after replay; state-file absence is not acceptance.
function Get-CloseoutSyncOutcome {
    param([string]$ProjectRunId, [string]$EventId)
    $state = Read-StateFile
    if ($state -and "$($state.RelatedSummerRunId)" -eq $ProjectRunId) {
        if ("$($state.CloseoutBackendStatus)" -eq 'Rejected' -or "$($state.PhaseBBackendStatus)" -eq 'Rejected') {
            $code = "$($state.CloseoutBackendErrorCode)"
            $message = "$($state.CloseoutBackendErrorMessage)"
            if (-not $code) { $code = "$($state.PhaseBBackendErrorCode)"; $message = "$($state.PhaseBBackendErrorMessage)" }
            return [pscustomobject]@{Status='Rejected';Message="$code - $message"}
        }
        if ("$($state.CloseoutBackendStatus)" -eq 'Applied' -and "$($state.CompletedCloseoutEventId)" -and
            ((-not $EventId) -or "$($state.CompletedCloseoutEventId)" -eq $EventId)) {
            return [pscustomobject]@{Status='Applied';Message='The backend accepted this closeout.'}
        }
    }
    $receipt = $script:LastSyncedCloseout
    if ($receipt -and "$($receipt.ProjectRunId)" -eq $ProjectRunId -and "$($receipt.EventId)" -and
        ((-not $EventId) -or "$($receipt.EventId)" -eq $EventId)) {
        return [pscustomobject]@{Status='Applied';Message='The backend accepted this closeout.'}
    }
    if ($state -and "$($state.RelatedSummerRunId)" -eq $ProjectRunId -and "$($state.PendingCloseoutEventId)") {
        return [pscustomobject]@{Status='Pending';Message="Backend: $($script:BackendStatus). $($script:BackendStatusDetail) Project: $ProjectRunId. Event: $($state.PendingCloseoutEventId)."}
    }
    return [pscustomobject]@{Status='Unknown';Message='No matching closeout acceptance was found. Keep the workflow data and contact a lead.'}
}

function Retry-PendingCloseoutSync {
    param([string]$ProjectRunId, [string]$EventId)
    $outcome = Get-CloseoutSyncOutcome $ProjectRunId $EventId
    if ($outcome.Status -in @('Applied','Rejected')) { return $outcome }
    $script:IsNetworkAvailable = Test-Network
    if ($script:IsNetworkAvailable) { Flush-OfflineQueue }
    return (Get-CloseoutSyncOutcome $ProjectRunId $EventId)
}

function Set-CloseoutBusy {
    param([bool]$Busy, [string]$Message = '')
    try {
        $btn = $script:UI['btnCloseoutReboot']
        if ($Busy) {
            $btn.IsEnabled = $false
            $btn.Content   = 'Saving Closeout...'
            $script:UI['lblCloseoutBusy'].Text = $Message
            $script:UI['lblCloseoutBusy'].Visibility = 'Visible'
            $script:UI['lblCloseoutError'].Visibility = 'Collapsed'
        } else {
            $btn.IsEnabled = $true
            $btn.Content   = 'Finish and Reboot'
            $script:UI['lblCloseoutBusy'].Visibility = 'Collapsed'
        }
        # Let WPF actually paint the disabled button and the message before the thread blocks.
        $script:window.Dispatcher.Invoke([action]{}, [System.Windows.Threading.DispatcherPriority]::Render)
    } catch { Write-Log "Closeout busy-state update failed: $_" 'WARN' }
}
# Terminal states keep the button disabled: neither a rejected nor an already-sent closeout may
# be submitted a second time from this screen.
function Set-CloseoutTerminal {
    param([string]$ButtonText)
    try {
        $script:UI['btnCloseoutReboot'].IsEnabled = $false
        $script:UI['btnCloseoutReboot'].Content   = $ButtonText
        $script:UI['lblCloseoutBusy'].Visibility  = 'Collapsed'
    } catch {}
}
Register-PanelButtonAction -Name 'btnCloseoutReboot' -Action {
    # r13 finding #1: re-entrancy guard. A queued second click is delivered as soon as the UI
    # thread is free again, so this must be checked before anything else.
    if ($script:CloseoutSubmissionInProgress) {
        Write-Log 'Second closeout click ignored - a submission is already in progress.' 'WARN'
        return
    }
    $script:CloseoutSubmissionInProgress = $true
    $script:CloseoutCommitted            = $false
    $script:CloseoutTerminalState        = $false
    Set-CloseoutBusy $true "Saving closeout and preparing to restart.`n`nPlease do not click again, close PanelApp, or power off the OPS."
    try {
        # r8 finding #3: if a closeout is ALREADY queued, retry the pending sync - never mint a
        # second FinalCloseoutCompleted. Two closeout events have different EventIds, so dedupe
        # cannot catch them and BOTH would apply, appending a duplicate row and double-incrementing.
        $statePathC = Join-Path $script:ProvisioningDir 'state.json'
        $knownCloseout = Get-CloseoutSyncOutcome $script:RelatedSummerRunId ''
        if ($knownCloseout.Status -eq 'Applied') {
            $script:CloseoutCommitted = $true
            Set-CloseoutBusy $true 'Closeout synchronized. Restarting...'
            Restart-Computer -Force
            return
        }
        if (Test-Path $statePathC) {
            $pendC = $null
            try { $pendC = Get-Content $statePathC -Raw | ConvertFrom-Json } catch {}
            if ($pendC -and "$($pendC.CloseoutBackendStatus)" -eq 'Rejected') {
                $script:UI['lblCloseoutError'].Text =
                    "The spreadsheet rejected this closeout ($($pendC.CloseoutBackendErrorCode)). Report it to a lead - do not retry."
                $script:UI['lblCloseoutError'].Visibility = 'Visible'
                $script:CloseoutTerminalState = $true
                Set-CloseoutTerminal 'Closeout Not Recorded'
                return
            }
            if ($pendC -and "$($pendC.PendingCloseoutEventId)") {
                $syncOutcome = Retry-PendingCloseoutSync "$($pendC.RelatedSummerRunId)" "$($pendC.PendingCloseoutEventId)"
                if ($syncOutcome.Status -eq 'Applied') {
                    $script:CloseoutCommitted = $true
                    Set-CloseoutBusy $true 'Closeout synchronized. Restarting...'
                    Write-Log 'Pending closeout accepted on retry - rebooting without another submission.'
                    Restart-Computer -Force
                    return
                }
                if ($syncOutcome.Status -in @('Rejected','Unknown')) {
                    $script:CloseoutTerminalState = $true
                    Set-CloseoutTerminal 'Closeout Needs Review'
                    $script:UI['lblCloseoutError'].Text = $syncOutcome.Message
                    $script:UI['lblCloseoutError'].Visibility = 'Visible'
                    Write-Log "Pending closeout requires review: $($syncOutcome.Message)" 'ERROR'
                    return
                }
                $script:UI['lblCloseoutError'].Text =
                    "Closeout is still pending confirmation. Retry synchronizes the same saved event; it does not submit another closeout.`n$($syncOutcome.Message)"
                $script:UI['lblCloseoutError'].Visibility = 'Visible'
                Write-Log "Closeout retry pending: $($syncOutcome.Message)" 'WARN'
                $script:CloseoutSubmissionInProgress = $false
                Set-CloseoutBusy $false
                $script:UI['btnCloseoutReboot'].Content = 'Retry Pending Sync'
                return
            }
        }
        if (-not $script:CloseoutIssueReported) {
            # All normal checks remain mandatory. Android Ethernet is satisfied only by the
            # dedicated checkbox OR the dedicated low-priority Android Ethernet exception.
            $normalOk = $script:UI['chkCoImage'].IsChecked -and $script:UI['chkCoTouch'].IsChecked -and
                        $script:UI['chkCoSound'].IsChecked -and $script:UI['chkCoNetwork'].IsChecked -and
                        $script:UI['chkCoNDMS'].IsChecked
            $ethernetOk = $script:UI['chkCoAndroidEthernet'].IsChecked -or $script:AndroidEthernetExceptionReported
            $allOk = $normalOk -and $ethernetOk
            if (-not $allOk) {
                $script:UI['lblCloseoutError'].Text = if (-not $normalOk) { 'Confirm Windows boot, touch, sound, Windows network, and NDMS/Radix. A low Android Ethernet exception does not bypass these checks.' } else { 'Confirm Android Ethernet, or record the dedicated Low Android Ethernet exception if Ethernet does not work.' }
                $script:UI['lblCloseoutError'].Visibility = 'Visible'
                return
            }
            $script:UI['lblCloseoutError'].Visibility = 'Collapsed'
            # Final linked PanelLog event -> closes the Summer2026 record.
            # Re-probe the actual backend immediately before the send so a stale startup status does
            # not force a valid connection into the offline queue (or vice versa).
            $script:IsNetworkAvailable = Test-Network
            if ($script:IsNetworkAvailable) { Flush-OfflineQueue }
            if ($script:ActiveSenderSync) { Merge-SyncSenderContext $script:ActiveSenderSync }
            $phaseState = Read-StateFile
            if ($phaseState -and "$($phaseState.RelatedSummerRunId)" -eq $script:RelatedSummerRunId -and
                "$($phaseState.PhaseBBackendStatus)" -eq 'Rejected') {
                $script:CloseoutTerminalState = $true
                Set-CloseoutTerminal 'Phase B Needs Review'
                $script:UI['lblCloseoutError'].Text = "Phase B was rejected: $($phaseState.PhaseBBackendErrorCode). Contact a lead before closeout."
                $script:UI['lblCloseoutError'].Visibility = 'Visible'
                return
            }
            $now = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
            $closeRes = Send-Event -Payload @{
                Mode         = $script:ModeLabel
                RunId        = $script:RunId
                ActionType   = $(if ($script:NewInstallProvisioning -and $script:RecoveryProvisioning) { 'New Replacement Install - Post-RedoRescue Provisioning' }
                                 elseif ($script:NewInstallProvisioning) { 'New Replacement Install - Full Provisioning' }
                                 elseif ($script:RecoveryProvisioning)   { 'Post-RedoRescue Provisioning' }
                                 else { 'Existing Panel Provisioning' })
                ProjectOrigin = 'Summer2026'
                RelatedSummerProjectRunId = $script:RelatedSummerRunId
                InstallType  = $script:InstallType
                ProvisioningPathSelected = $script:ProvisioningPathSelected
                # v5.5.1 12: after a successful join the closeout must not resend the
                # pre-provisioning observation. Originals are preserved under PreProvision*.
                PreProvisionDomainMembershipStatus = $script:DomainMembershipStatus
                PreProvisionDetectedDomain         = $script:DetectedDomain
                DomainMembershipStatus = $(if ($script:PostJoinMembershipStatus) { $script:PostJoinMembershipStatus } else { $script:DomainMembershipStatus })
                DetectedDomain         = $(if ($script:DomainJoinTargetDomain) { $script:DomainJoinTargetDomain } else { $script:DetectedDomain })
                SecureChannelStatus    = $(if ($script:PostJoinSecureChannelStatus) { $script:PostJoinSecureChannelStatus } else { $script:SecureChannelStatus })
                DomainJoinTargetDomain      = $script:DomainJoinTargetDomain
                DomainJoinCompletedAt       = $script:DomainJoinCompletedAt
                PostJoinMembershipStatus    = $script:PostJoinMembershipStatus
                PostJoinSecureChannelStatus = $script:PostJoinSecureChannelStatus
                AssessmentHostname     = $script:AssessmentHostname
                ProvisionedHostname    = $script:Hostname
                ImageProfile = $script:SummerImageProfile
                RedoImageFile = $script:SummerRedoFile
                ExpectedImageFolder = $script:SummerExpectedFolder
                SchoolCode   = $script:SchoolCode
                Room         = $script:RoomNumber
                RoomType     = $script:RoomType
                OtherRoomType = $script:OtherRoomType
                PanelSerial  = $script:PanelSerial
                OPSSerial    = $script:OPSSerial
                Hostname     = $script:Hostname
                Manufacturer = $script:Manufacturer
                PanelModel   = $script:PanelModel
                ProvisioningOutcome = 'Provisioning Complete'
                Result       = 'Provisioning Complete (closeout verified)'
                ProjectStatus       = 'Provisioning Complete'
                ProvisioningStatus  = $(if ($script:NewInstallProvisioning) { 'New Install - Domain Join Complete - Closeout Verified' }
                                        elseif ($script:RecoveryProvisioning) { 'Post-RedoRescue - Domain Joined' }
                                        else { 'Existing Panel - Domain Join Complete - Closeout Verified' })
                FinalCloseoutStatus = 'Complete'
                ReimageStatus       = 'Complete'
                ExceptionStatus     = $(if ($script:DayOneStatus -eq 'Issue Reported' -or $script:SummerOriginalDayOne -eq 'Issue Reported') { 'Open' } else { 'Closed' })
                CurrentOPSSerial    = $script:OPSSerial
                OPSReplacementConfirmed = $script:OPSReplacementConfirmed
                CompletedBy  = $script:TechName
                CompletedAt  = $now
                CloseoutTech = $script:TechName
                ProvisioningAccount = $script:ProvisioningAccountName
                ProvisioningAccountPreflight = $script:ProvisioningAccountPreflight
                ProvisioningAccountEnabled = $script:ProvisioningAccountEnabled
                ProvisioningAccountPasswordNeverExpires = $script:ProvisioningAccountPasswordNeverExpires
                ProvisioningAccountCheckedAt = $script:ProvisioningAccountCheckedAt
                TechName     = $script:TechName
                Timestamp    = $now
            } -EventType 'FinalCloseoutCompleted'
            # r5 finding #3: NEVER claim the record was closed, archive the resume state, or reboot
            # until we know the backend accepted it. Doing all three on a rejection told the tech the
            # panel was finished while the spreadsheet row stayed open - and removed their only way back.
            if ($closeRes.Rejected) {
                $why = if ($closeRes.Parsed) { "$($closeRes.Parsed.ErrorCode): $($closeRes.Parsed.Message)" } else { 'permanent rejection' }
                Write-Log "Closeout was REJECTED by the spreadsheet ($why) - state retained, no reboot." 'ERROR'
                # Guard is released by the finally (nothing committed), but the button stays dead:
                # a rejected closeout goes to reconciliation, it is never submitted again from here.
                $script:CloseoutTerminalState = $true
                Set-CloseoutTerminal 'Closeout Not Recorded'
                $script:UI['lblCloseoutError'].Text = 'The spreadsheet rejected this closeout. Nothing was closed - report this to a lead.'
                $script:UI['lblCloseoutError'].Visibility = 'Visible'
                [System.Windows.MessageBox]::Show(
                    "This panel was NOT closed out in the spreadsheet.`n`n$why`n`n" +
                    "The provisioning state has been kept so the work can be resumed. Do not reimage or move on - report this to a lead.",
                    'Closeout Not Recorded', 'OK', 'Error') | Out-Null
                return
            }
            if ($closeRes.Queued) {
                Write-Log 'Closeout queued offline - the Interactive Inventory record is NOT closed yet.' 'WARN'
                # COMMITTED: this closeout owns an EventId now. The guard is never released, so no
                # second FinalCloseoutCompleted can be minted for the same project.
                $script:CloseoutCommitted = $true
                Set-CloseoutTerminal 'Closeout Pending Sync'
                # r7 finding #1: pin THIS closeout's EventId into state.json. When the queue later
                # replays that exact event, the flush archives the state file - otherwise the next
                # launch reopens closeout for an already-completed project, and a fresh click mints a
                # NEW EventId that EventId dedupe cannot catch.
                try {
                    $sfq = Join-Path $script:ProvisioningDir 'state.json'
                    if (Test-Path $sfq) {
                        $stq = Get-Content $sfq -Raw | ConvertFrom-Json
                        $stq | Add-Member -NotePropertyName PendingCloseoutEventId -NotePropertyValue "$($closeRes.EventId)" -Force
                        $stq | Add-Member -NotePropertyName PendingCloseoutProject -NotePropertyValue "$($script:RelatedSummerRunId)" -Force
                        $stq | ConvertTo-Json -Depth 12 | Set-Content -Path $sfq -Encoding UTF8
                        Write-Log "Pending closeout EventId $($closeRes.EventId) recorded in state.json."
                    }
                } catch { Write-Log "Could not record the pending closeout EventId: $_" 'WARN' }
                $r = [System.Windows.MessageBox]::Show(
                    "This closeout is saved locally but has not been confirmed by the backend. Earlier queued work, a timeout, or a temporary backend error can delay it even with internet access.`n`n" +
                    "The project will close when this SAME queued event synchronizes.`nReason: $($closeRes.Reason)`nSaved at: $($closeRes.QueuePath)`n`n" +
                    "OK = reboot now and let it sync later.`nCancel = stay here and retry synchronization.",
                    'Closeout Pending Sync', 'OKCancel', 'Warning')
                if ($r -ne 'OK') {
                    # The event is committed/queued, but the technician chose to stay. Release only
                    # the click guard and expose Retry Pending Sync; do NOT allow a new event to be minted.
                    $script:CloseoutSubmissionInProgress = $false
                    Set-CloseoutBusy $false
                    $script:UI['btnCloseoutReboot'].Content = 'Retry Pending Sync'
                    $script:UI['btnCloseoutReboot'].IsEnabled = $true
                    return
                }
                # Keep state.json: the project is not confirmed closed.
                Write-Log 'Rebooting with closeout pending sync (state retained).'
                Restart-Computer -Force
                return
            }
            Write-Log 'Reimage closeout verified - Interactive Inventory record closed.'
            $script:CloseoutCommitted = $true
            Set-CloseoutBusy $true 'Closeout recorded. Restarting...'
        } else {
            Write-Log 'Reimage closeout: issue was reported - record left Exception Open.'
            # The exception path skips the closeout post entirely but still archives and reboots.
            $script:CloseoutCommitted = $true
            Set-CloseoutBusy $true 'Restarting...'
        }
        # Review fix #4: closeout reached a CONFIRMED outcome (verified OR exception) - archive the
        # pending state so relaunch does not re-open closeout for a finished device.
        # r12 finding #1: NOT confirmed while a closeout exception is still sitting in the queue.
        # Archiving here destroyed the only record the replay reconciler can update, so a later
        # permanent rejection could never re-block the closeout or raise Issue Report Not Recorded.
        $keepForException = $false
        try {
            $sfChk = "$script:ProvisioningDir\state.json"
            if (Test-Path $sfChk) {
                $stChk = Get-Content $sfChk -Raw | ConvertFrom-Json
                if ("$($stChk.PendingExceptionEventId)") { $keepForException = $true }
            }
        } catch {}
        if ($keepForException) {
            Write-Log 'Closeout exception is still queued - state.json retained so the replay can be reconciled.' 'WARN'
        } else {
            try {
                $sf = "$script:ProvisioningDir\state.json"
                if (Test-Path $sf) {
                    Move-Item -Path $sf -Destination "$script:ProvisioningDir\state.closeout_$(Get-Date -Format 'yyyyMMdd_HHmmss').json" -Force
                    Write-Log 'Closeout state archived.'
                }
            } catch { Write-Log "Closeout state archive failed: $_" 'WARN' }
        }
        Write-Log 'Rebooting after closeout.'
        Restart-Computer -Force
    } finally {
        # Release the guard ONLY when nothing was committed - a delivered or queued closeout must
        # never become clickable again. A rejected closeout clears the guard but stays disabled:
        # it routes to reconciliation, and a second attempt is exactly what must not happen.
        if (-not $script:CloseoutCommitted) {
            $script:CloseoutSubmissionInProgress = $false
            if (-not $script:CloseoutTerminalState) { Set-CloseoutBusy $false }
        }
        $script:CloseoutTerminalState = $false
    }
}

# -- Report an Issue (reusable) --
Register-PanelButtonAction -Name 'btnExCancel' -Action {
    $ret = if ($script:IssueReturnScreen) { $script:IssueReturnScreen } else { 'pnlModeSelect' }
    Show-Screen $ret
}
Register-PanelButtonAction -Name 'btnExSubmit' -Action {
    $exRes = Submit-IssueReport
    if ($null -ne $exRes) {
        $isCloseout = $script:IssueContextPhase -in @('Post-RedoRescue Closeout','New Install Provisioning Closeout','Existing Panel Provisioning Closeout','Provisioning Closeout')
        # r10 finding #2: a PERMANENTLY REJECTED exception recorded nothing. Marking the closeout
        # as issue-reported here would make Finish and Reboot skip the closeout post entirely,
        # archive state.json and reboot a device with no exception and no closeout in the sheet.
        if ($exRes.Rejected) {
            $why = if ($exRes.Parsed) { "$($exRes.Parsed.ErrorCode): $($exRes.Parsed.Message)" } else { 'permanent rejection' }
            Write-Log "Issue report was REJECTED ($why) - CloseoutIssueReported left false, state retained." 'ERROR'
            $script:UI['lblExError'].Text = 'The spreadsheet rejected this issue report. Nothing was recorded.'
            $script:UI['lblExError'].Visibility = 'Visible'
            [System.Windows.MessageBox]::Show(
                "This issue was NOT recorded in the spreadsheet.`n`n$why`n`n" +
                "This panel has NOT been marked Exception Open. Do not reboot or move to the next panel - report this to a lead.",
                'Issue Not Recorded', 'OK', 'Error') | Out-Null
            return
        }
        if ($exRes.Queued -and $isCloseout) {
            # Pin the queued exception the way a queued closeout is pinned, so a later permanent
            # replay rejection can be reconciled against this device's state.json.
            try {
                $sfx = Join-Path $script:ProvisioningDir 'state.json'
                if (Test-Path $sfx) {
                    $stx = Get-Content $sfx -Raw | ConvertFrom-Json
                    $stx | Add-Member -NotePropertyName PendingExceptionEventId -NotePropertyValue "$($exRes.EventId)" -Force
                    $stx | Add-Member -NotePropertyName PendingExceptionProject -NotePropertyValue "$($script:RelatedSummerRunId)" -Force
                    # r12 finding #1: the pin is worthless if Finish and Reboot archives the file
                    # before the exception replays. Mark the state so the archive step keeps it.
                    $stx | Add-Member -NotePropertyName CloseoutExceptionStatus -NotePropertyValue 'Queued'  -Force
                    $stx | Add-Member -NotePropertyName FinalCloseoutStatus     -NotePropertyValue 'Pending' -Force
                    $stx | ConvertTo-Json -Depth 12 | Set-Content -Path $sfx -Encoding UTF8
                    Write-Log "Pending closeout exception EventId $($exRes.EventId) recorded in state.json."
                }
            } catch { Write-Log "Could not record the pending exception EventId: $_" 'WARN' }
        }
        if ($isCloseout) {
            $script:CloseoutIssueReported = $true
            # Closeout-specific guidance: the tech still needs to finish/reboot THIS device.
            $pendNote = if ($exRes.Queued) { "`n`nThis report has NOT reached the spreadsheet yet (PanelApp sync unavailable). It will synchronize from the flash drive." } else { '' }
            [System.Windows.MessageBox]::Show(
                "Issue reported. This project stays Exception Open.$pendNote`n`nFinish on this device: click Finish and Reboot so the panel restarts cleanly. Do not move to the next panel until this device has rebooted.",
                $(if ($exRes.Queued) { 'Issue Pending Sync - Finish This Device' } else { 'Issue Reported - Finish This Device' }), 'OK', 'Information') | Out-Null
        } elseif ($exRes.Queued) {
            [System.Windows.MessageBox]::Show(
                "This issue was saved to the flash drive but has NOT reached the spreadsheet yet (PanelApp sync unavailable).`n`n" +
                "It will sync automatically the next time PanelApp runs with a connection. The panel is not marked Exception Open until it does.",
                'Issue Pending Sync', 'OK', 'Warning') | Out-Null
        } else {
            # ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§31.1: normal report-and-move-on guidance (data-risk stops have their own screens)
            [System.Windows.MessageBox]::Show(
                "Issue reported.`n`nThis panel has been marked Exception Open.`n`nMove to the next panel unless your lead has instructed you to stay with this device.",
                'Issue Reported', 'OK', 'Information') | Out-Null
        }
        $ret = if ($script:IssueReturnScreen) { $script:IssueReturnScreen } else { 'pnlModeSelect' }
        Show-Screen $ret
    }
}
Register-PanelButtonAction -Name 'btnSummerReportIssue' -Action { Show-IssueReport 'Summer Result' 'pnlSummerSummary' }
Register-PanelButtonAction -Name 'btnProgressReportIssue' -Action { Show-IssueReport 'Provisioning' 'pnlProgress' }
Register-PanelButtonAction -Name 'btnPhaseBReportIssue' -Action { Show-IssueReport 'Phase B / Domain Join' 'pnlPhaseB' }

# Preserve session evidence on technician media and outside the disposable working directory.
function Save-PanelAppSessionLog {
    if (-not (Test-Path -LiteralPath $script:LogFile)) { return $false }
    $name = 'PanelApp_SESSION_{0}_{1}.log' -f (Get-Date -Format 'yyyyMMdd_HHmmss'),$PID
    $destinations = @((Join-Path $env:ProgramData 'APS\PanelAppLogs'))
    if ($script:UsbRoot -and (Test-Path -LiteralPath $script:UsbRoot)) {
        $destinations += (Join-Path $script:UsbRoot 'APS\Logs')
    }
    $saved = $false
    foreach ($dir in @($destinations | Select-Object -Unique)) {
        try {
            New-Item -ItemType Directory -Path $dir -Force -ErrorAction Stop | Out-Null
            Copy-Item -LiteralPath $script:LogFile -Destination (Join-Path $dir $name) -ErrorAction Stop
            $saved = $true
        } catch {} # Keep the original TEMP log if neither destination can be written.
    }
    return $saved
}

# -- Window close: retain evidence even when a failure was swallowed or never marked HadError --
$script:window.Add_Closing({
    Write-Log 'Session ending.'
    if (Save-PanelAppSessionLog) {
        Remove-Item -Path $script:LogFile -Force -ErrorAction SilentlyContinue
    }
})

# ================================================================
#  WINDOW LOADED
# ================================================================
$script:window.Add_Loaded({
    Write-Log "Window loaded. Field build: production-5.7.0-20260915. Runtime: $PSCommandPath"
    $script:UI['lblVersionFooter'].Text = "APS Panel App v$script:ScriptVersion | Production"
    # Capture the removable-media (USB) launch path BEFORE any ProgramData copy, and a
    # per-session RunId, so offline/handoff records land on the USB, not in ProgramData (ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§13).
    $script:RunId   = New-RunId
    $script:UsbRoot = $script:ScriptDir
    try {
        $deploymentStatePath = Join-Path $script:ProvisioningDir 'deployment.json'
        if (Test-Path $deploymentStatePath) {
            $deploymentState = Get-Content $deploymentStatePath -Raw | ConvertFrom-Json
            $technicianRoot = "$($deploymentState.technicianRoot)"
            if ($technicianRoot -and (Test-Path $technicianRoot)) {
                $script:UsbRoot = $technicianRoot
                Write-Log "Portable offline queue root restored from launcher: $script:UsbRoot" 'INFO'
            } else {
                Write-Log 'Launcher technician root is unavailable; offline events will fall back to the OPS working directory.' 'WARN'
            }
        }
    } catch {
        Write-Log "Could not restore launcher technician root; offline events will use the OPS fallback queue. $_" 'WARN'
    }
    Populate-Dropdowns

    # Backend health check. The UI remains responsive while HTTPS is outstanding.
    $script:IsNetworkAvailable = Test-Network
    if ($script:IsNetworkAvailable) {
        $script:UI['ellNetStatus'].Fill  = New-Brush '#4EC994'
        $script:UI['lblNetStatus'].Text  = 'PanelApp sync available'
    } else {
        $script:UI['ellNetStatus'].Fill  = New-Brush '#F0B030'
        if ($script:BackendStatus -eq 'BackendUpdateRequired') {
            $script:UI['lblNetStatus'].Text = 'PanelApp backend update required - do not submit project work'
        } else {
            $script:UI['lblNetStatus'].Text = 'PanelApp sync unavailable - entries will be saved safely and retried'
        }
    }
    Set-Status 'Ready.'

    # ---- Flush any queued offline events from a previous run (ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§14) ----
    if ($script:IsNetworkAvailable) { try { Flush-OfflineQueue } catch {} }
    if ($script:LastSyncedCloseout) {
        [System.Windows.MessageBox]::Show(
            "A previously queued final closeout has now synchronized successfully.`n`n" +
            "Project: $($script:LastSyncedCloseout.ProjectRunId)`nPanel: $($script:LastSyncedCloseout.PanelSerial)`n`n" +
            'PanelApp will restart this OPS now to complete provisioning.',
            'Closeout Synchronized', 'OK', 'Information') | Out-Null
        Restart-Computer -Force
        return
    }

    # A minimum-version response alone cannot prove which Apps Script source is deployed.
    # Block normal TEST work when the endpoint lacks this candidate's exact build marker.
    if ($script:BackendStatus -eq 'BackendUpdateRequired' -and -not $PhaseB -and -not $UpgradeResume) {
        Write-Log "BLOCKED: $($script:BackendStatusDetail)" 'WARN'
        $script:UI['lblVersionBlockMsg'].Text =
            "The configured TEST backend is not the required build.`n`n$($script:BackendStatusDetail)`n`n" +
            "Update the existing Apps Script deployment, verify action=version, and relaunch PanelApp."
        Show-Screen 'pnlVersionBlock'
        Set-Status 'Blocked - required TEST backend is not deployed.'
        return
    }

    # ---- Version gate (Change 1) ----
    # Phase B is an automatic post-reboot continuation; never block it or a
    # half-provisioned device would be stranded.
    if (-not $PhaseB -and -not $UpgradeResume) {
        $minVer = if ($script:IsNetworkAvailable) { Get-MinimumVersion } else { $null }
        if ($minVer) {
            $outOfDate = $false
            try { $outOfDate = ((Get-PanelAppComparableVersion $script:ScriptVersion) -lt (Get-PanelAppComparableVersion $minVer)) }
            catch { Write-Log "Version compare failed ('$script:ScriptVersion' vs '$minVer'): $_" 'WARN' }
            if ($outOfDate) {
                Write-Log "BLOCKED: version $script:ScriptVersion is below minimum $minVer." 'WARN'
                $script:UI['lblVersionBlockMsg'].Text =
                    "This copy is version $script:ScriptVersion. The minimum required version is $minVer." + [char]10 +
                    "You cannot continue until you update."
                Show-Screen 'pnlVersionBlock'
                Set-Status "Blocked - version $script:ScriptVersion below required $minVer."
                return
            }
            Write-Log "Version OK: $script:ScriptVersion meets minimum $minVer."
        } else {
            Write-Log 'Minimum version could not be verified (offline or unconfigured) - proceeding.' 'WARN'
        }
    }

    if ($UpgradeResume) {
        Write-Log 'Windows upgrade resume mode detected.'
        Invoke-Windows11UpgradeResume
        return
    }

    if ($PhaseB) {
        Write-Log 'Phase B mode detected.'
        $state = Read-StateFile
        if ($state -and "$($state.EndpointRepairAction)") {
            Invoke-EndpointRepairResume $state
            return
        }
        if ($state) {
            # Restore all Phase A data so Execute-PhaseB can build a complete log row
            $script:TechName            = $state.TechName
            $script:Hostname            = $state.Hostname
            $script:ModeLabel           = $state.Mode
            $script:SchoolCode          = $state.SchoolCode
            $script:SchoolName          = $state.SchoolName
            $script:RoomNumber          = $state.Room
            $script:MountType           = $state.MountType
            $script:Manufacturer        = $state.Manufacturer
            $script:PanelSerial         = $state.PanelSerial
            $script:OPSSerial           = $state.OPSSerial
            $script:PanelModel          = $state.PanelModel
            $script:StorageGB           = $state.StorageGB
            $script:OPSTruncationNote   = $state.OPSTruncationNote
            # Restore Summer continuation linkage + USB path (v5.2 Phase 3)
            if ($state.RunId)              { $script:RunId = $state.RunId }
            if ($state.UsbRoot)            { $script:UsbRoot = $state.UsbRoot }
            $script:RelatedSummerRunId      = "$($state.RelatedSummerRunId)"
            $script:SummerImageProfile      = "$($state.SummerImageProfile)"
            $script:SummerRedoFile          = "$($state.SummerRedoFile)"
            $script:SummerExpectedFolder    = "$($state.SummerExpectedFolder)"
            $script:NewInstallProvisioning  = [bool]$state.NewInstallProvisioning
            $script:RecoveryProvisioning    = [bool]$state.RecoveryProvisioning
            if ("$($state.ProjectStateRevision)")    { $script:ProjectStateRevision    = "$($state.ProjectStateRevision)" }
            if ("$($state.ProjectStateRevisionFor)") { $script:ProjectStateRevisionFor = "$($state.ProjectStateRevisionFor)" }
            if ("$($state.ClientSessionId)")         { $script:ClientSessionId         = "$($state.ClientSessionId)" }
            if ("$($state.EventSequence)")           { [void][int]::TryParse("$($state.EventSequence)", [ref]$script:EventSequence) }
            $script:InstallType             = "$($state.InstallType)"
            $script:RoomType                = "$($state.RoomType)"
            $script:OtherRoomType           = "$($state.OtherRoomType)"
            $script:DomainMembershipStatus  = "$($state.DomainMembershipStatus)"
            $script:DetectedDomain          = "$($state.DetectedDomain)"
            $script:SecureChannelStatus     = "$($state.SecureChannelStatus)"
            $script:DomainCheckAt           = "$($state.DomainCheckAt)"
            $script:ProvisioningPathRecommended = "$($state.ProvisioningPathRecommended)"
            $script:ProvisioningPathSelected    = "$($state.ProvisioningPathSelected)"
            $script:ProvisioningRecommendationReason = "$($state.ProvisioningRecommendationReason)"
            $script:NewInstallConfirmedBy   = "$($state.NewInstallConfirmedBy)"
            $script:NewInstallConfirmedAt   = "$($state.NewInstallConfirmedAt)"
            $script:PreviousHostname        = "$($state.PreviousHostname)"
            $script:PreviousHostnameSource  = "$($state.PreviousHostnameSource)"
            $script:OldHostnameCheckResult  = "$($state.OldHostnameCheckResult)"
            $script:NewHostnameCheckResult  = "$($state.NewHostnameCheckResult)"
            $script:SelectedHostnameSuffix  = "$($state.SelectedHostnameSuffix)"
            $script:SummerOriginalDayOne    = "$($state.SummerOriginalDayOne)"
            $script:OPSReplacementConfirmed = "$($state.OPSReplacementConfirmed)"
            $script:RMAAction = "$($state.RMAAction)"
            $script:RMAPreviousPanelSerial = "$($state.RMAPreviousPanelSerial)"
            try { $script:RMAReassignmentConfirmed = [bool]$state.RMAReassignmentConfirmed } catch { $script:RMAReassignmentConfirmed = $false }
            try { $script:InventoryReassignmentConfirmed = [bool]$state.InventoryReassignmentConfirmed } catch { $script:InventoryReassignmentConfirmed = $false }
            $script:InventoryReassignmentType = "$($state.InventoryReassignmentType)"
            $script:InventoryReassignmentReason = "$($state.InventoryReassignmentReason)"
            $script:InventoryPreviousPanelSerial = "$($state.InventoryPreviousPanelSerial)"
            try { $script:TemporaryAssignment = [bool]$state.TemporaryAssignment } catch { $script:TemporaryAssignment = $false }
            try { $script:FollowUpRequired = [bool]$state.FollowUpRequired } catch { $script:FollowUpRequired = $false }
            try { $script:TestingObservationOnly = [bool]$state.TestingObservationOnly } catch { $script:TestingObservationOnly = $false }
            # v5.5.1b ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§2: without this the capture written before the rename reboot was dropped,
            # and the blank-fill fallback below would have recorded the APS name as the "as found"
            # name - exactly the bug the early capture was added to prevent.
            if ("$($state.AssessmentHostname)") { $script:AssessmentHostname = "$($state.AssessmentHostname)" }
            if ("$($state.RawRoom)")            { $script:RawRoomEntry       = "$($state.RawRoom)" }
            if ("$($state.ProvisioningAccount)") { $script:ProvisioningAccountName = "$($state.ProvisioningAccount)" }
            if ("$($state.ProvisioningAccountPreflight)") { $script:ProvisioningAccountPreflight = "$($state.ProvisioningAccountPreflight)" }
            if ("$($state.ProvisioningAccountEnabled)") { $script:ProvisioningAccountEnabled = "$($state.ProvisioningAccountEnabled)" }
            if ("$($state.ProvisioningAccountPasswordNeverExpires)") { $script:ProvisioningAccountPasswordNeverExpires = "$($state.ProvisioningAccountPasswordNeverExpires)" }
            if ("$($state.ProvisioningAccountCheckedAt)") { $script:ProvisioningAccountCheckedAt = "$($state.ProvisioningAccountCheckedAt)" }
            if ($script:RelatedSummerRunId) { $script:SummerContinuation = $true }
            $script:UI['lblTechDisplay'].Text = "Tech: $($state.TechName)"
            $script:UI['lblModeDisplay'].Text  = $state.Mode
            # Show full join details so the tech can verify the OU before proceeding
            $ouVal = if ($script:Config.DomainOU) { $script:Config.DomainOU } elseif ($state.DomainOU) { $state.DomainOU } else { '(not set - will land in Computers container)' }
            $info  = "Hostname   : $($state.Hostname)`nDomain     : $($state.Domain)`nOU         : $ouVal`nMode       : $($state.Mode)`nTechnician : $($state.TechName)"
            $script:UI['txtPhaseBInfo'].Text = $info
            # The first flush (before restore) only saw the local ProgramData queue. Now that the
            # original USB root is restored, flush again to catch a USB queue if the drive is present.
            if ($script:IsNetworkAvailable) { try { Flush-OfflineQueue } catch {} }
        } else {
            $script:UI['txtPhaseBInfo'].Text = ''   # the Phase A guard below sets the blocked message
        }
        # v5.3 ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§11.2: Phase B may only run if Phase A completed successfully.
        $phaseAOk = ($state -and "$($state.PhaseAStatus)" -eq 'Complete')

        # Weekend field hardening: never join the domain under the wrong hostname. Phase A verifies
        # the pending registry name before reboot; Phase B verifies what Windows actually booted as.
        # If the first reboot did not apply the rename, stage one controlled repair and require a
        # second reboot. A repeated mismatch is blocked instead of looping forever.
        if ($phaseAOk -and $state -and "$($state.Hostname)" -and $env:COMPUTERNAME -ine "$($state.Hostname)") {
            $expectedName = "$($state.Hostname)".ToUpperInvariant()
            $activeName = $env:COMPUTERNAME.ToUpperInvariant()
            $configuredName = ''
            try { $configuredName = "$((Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName' -Name ComputerName -ErrorAction Stop).ComputerName)".ToUpperInvariant() } catch {}
            $repairAttempts = 0
            try { $repairAttempts = [int]$state.RenameRepairAttempts } catch {}
            Write-Log "Phase B hostname verification mismatch: active=$activeName expected=$expectedName configured=$configuredName attempt=$repairAttempts" 'WARN'

            if ($repairAttempts -lt 1) {
                try {
                    if ($configuredName -ine $expectedName) {
                        Rename-Computer -NewName $expectedName -Force -ErrorAction Stop
                        $configuredName = "$((Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName' -Name ComputerName -ErrorAction Stop).ComputerName)".ToUpperInvariant()
                    }
                    if ($configuredName -ine $expectedName) { throw "Configured hostname is '$configuredName' after rename repair." }
                    $state | Add-Member -NotePropertyName RenameRepairAttempts -NotePropertyValue ($repairAttempts + 1) -Force
                    $state | Add-Member -NotePropertyName RenameRepairLastAt -NotePropertyValue (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') -Force
                    $state | ConvertTo-Json -Depth 12 | Set-Content -Path (Join-Path $script:ProvisioningDir 'state.json') -Encoding UTF8
                    $script:UI['btnJoinDomain'].Visibility = 'Collapsed'
                    $script:UI['btnPhaseBReboot'].Visibility = 'Visible'
                    $script:UI['lblPhaseBStatus'].Text = 'Hostname repair staged - reboot once more.'
                    $script:UI['lblPhaseBStatus'].Foreground = New-Brush '#F0B030'
                    $script:UI['txtPhaseBInfo'].Text = "Phase B stopped before domain join because Windows booted with the wrong hostname.`n`nCurrent: $activeName`nExpected: $expectedName`nConfigured for next boot: $configuredName`n`nPanelApp repaired the pending rename. Click Reboot to apply it, then Phase B will reopen automatically."
                    Write-Log "Hostname repair staged successfully; domain join remains blocked until reboot." 'WARN'
                    Show-Screen 'pnlPhaseB'
                    return
                } catch {
                    Write-Log "Phase B hostname repair failed: $($_.Exception.Message)`n$($_.ScriptStackTrace)" 'ERROR'
                }
            }

            $script:UI['btnJoinDomain'].Visibility = 'Collapsed'
            $script:UI['btnPhaseBReboot'].Visibility = 'Collapsed'
            $script:UI['lblPhaseBStatus'].Text = 'Blocked - hostname did not apply.'
            $script:UI['lblPhaseBStatus'].Foreground = New-Brush '#EF5B5B'
            $script:UI['txtPhaseBInfo'].Text = "Phase B cannot continue because Windows did not boot with the hostname Phase A selected.`n`nCurrent: $activeName`nExpected: $expectedName`nConfigured: $configuredName`n`nA rename repair was already attempted or could not be staged. Stop here and report this device to a lead; do not join the domain under the wrong name."
            Show-Screen 'pnlPhaseB'
            return
        }

        if (-not $phaseAOk) {
            $reason = if (-not $state) { 'Phase A state was not found' } else { "Phase A was not completed successfully (status: $($state.PhaseAStatus))" }
            Write-Log "Phase B BLOCKED: $reason." 'WARN'
            $script:UI['btnJoinDomain'].Visibility = 'Collapsed'
            $script:UI['txtPhaseBInfo'].Text = if (-not $state) {
                "Phase B cannot continue because Phase A state was not found. Complete Phase A first, allow the device to reboot, then reopen PanelApp."
            } else {
                "Phase B cannot continue because Phase A was not completed successfully. Complete Phase A first, allow the device to reboot, then reopen PanelApp."
            }
            $script:UI['lblPhaseBStatus'].Text = 'Blocked - Phase A not complete.'
            $script:UI['lblPhaseBStatus'].Foreground = New-Brush '#EF5B5B'
            if ($script:IsNetworkAvailable -and $state) {
                Send-Event -Payload @{ LogSheet='PanelAppExceptions'; RunId=$script:RunId
                    ProjectRunId=$script:RelatedSummerRunId; Technician=$script:TechName; Mode=$script:ModeLabel
                    Phase='Phase B Blocked'; Hostname=$state.Hostname; PanelSerial=$state.PanelSerial; OPSSerial=$state.OPSSerial
                    SchoolCode=$state.SchoolCode; Room=$state.Room; RoomType=$state.RoomType; OtherRoomType=$state.OtherRoomType
                    IssueCategory='OPS / Windows'; IssueDescription=$reason; Severity='Reported'
                    ScriptVersion=$script:ScriptVersion; SyncStatus='Submitted'; Timestamp=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') } -EventType 'Exception' | Out-Null
            }
        }
        Show-Screen 'pnlPhaseB'
    } else {
        # Review fix #4: if Phase B finished but closeout never did (crash/close/power loss),
        # resume the Post-RedoRescue Closeout directly instead of drifting back toward Phase A.
        $pending = Read-StateFile
        # r9 finding #1: a CLOSEOUT the backend rejected must open reconciliation, not the
        # normal checklist - the project is still open and a lead has to look at it.
        if ($pending -and "$($pending.CloseoutBackendStatus)" -eq 'Rejected') {
            Write-Log "A queued closeout was rejected ($($pending.CloseoutBackendErrorCode)) - blocking the checklist." 'ERROR'
            $script:UI['lblGateTitle'].Text = 'Closeout Not Recorded'
            $script:UI['lblGateMsg'].Text =
                "This panel's closeout was sent but the spreadsheet REJECTED it, so the project is still open.`n`n" +
                "$($pending.CloseoutBackendErrorCode): $($pending.CloseoutBackendErrorMessage)`n`n" +
                "Do not close it out again. A lead needs to reconcile the project record first."
            $script:UI['lblGateState'].Text = "ProjectRunId: $($pending.RelatedSummerRunId)`nHostname: $($pending.Hostname)`nPanel serial: $($pending.PanelSerial)"
            Show-Screen 'pnlRedoGateBlock'
            return
        }
        # r12 finding #1: the exception has not reached the spreadsheet yet. Flush first, and if it
        # is still queued show a pending screen - the technician must not file a SECOND issue
        # report or run the closeout checklist against a project that is not yet Exception Open.
        if ($pending -and "$($pending.PendingExceptionEventId)") {
            if ($script:IsNetworkAvailable) { Flush-OfflineQueue }
            $pending = Read-StateFile
            if (-not $pending) {
                [System.Windows.MessageBox]::Show(
                    'The pending issue report has now synced. This panel is Exception Open and no further action is needed here.',
                    'Issue Report Synchronized', 'OK', 'Information') | Out-Null
                Write-Log 'Pending closeout exception synced on relaunch.'
                Reset-PanelWorkflowState
                Show-Screen 'pnlModeSelect'; Set-Status 'Issue report synchronized.'
                return
            }
            if ("$($pending.PendingExceptionEventId)") {
                Write-Log "Closeout exception $($pending.PendingExceptionEventId) is still queued - blocking the checklist." 'WARN'
                $script:UI['lblGateTitle'].Text = 'Issue Report Pending Sync'
                $script:UI['lblGateMsg'].Text =
                    "An issue was reported for this panel during closeout, but it has NOT reached the spreadsheet yet (PanelApp sync unavailable).`n`n" +
                    "Do not report the issue again - a second report would create a duplicate. Restore PanelApp sync connectivity and relaunch PanelApp so the queued report can synchronize."
                $script:UI['lblGateState'].Text = "ProjectRunId: $($pending.RelatedSummerRunId)`nHostname: $($pending.Hostname)`nPanel serial: $($pending.PanelSerial)"
                Show-Screen 'pnlRedoGateBlock'
                return
            }
        }
        # r10 finding #2: the technician was told the panel was Exception Open and rebooted on that
        # basis, but the queued exception was permanently rejected on replay. Nothing was recorded.
        if ($pending -and "$($pending.CloseoutExceptionStatus)" -eq 'Rejected') {
            Write-Log "A queued closeout exception was rejected ($($pending.CloseoutExceptionErrorCode)) - blocking the checklist." 'ERROR'
            $script:UI['lblGateTitle'].Text = 'Issue Report Not Recorded'
            $script:UI['lblGateMsg'].Text =
                "An issue was reported for this panel during closeout, but the spreadsheet REJECTED it, so the project was never marked Exception Open.`n`n" +
                "$($pending.CloseoutExceptionErrorCode): $($pending.CloseoutExceptionErrorMessage)`n`n" +
                "The panel is still open with no exception on record. A lead needs to reconcile it before this device is closed out."
            $script:UI['lblGateState'].Text = "ProjectRunId: $($pending.RelatedSummerRunId)`nHostname: $($pending.Hostname)`nPanel serial: $($pending.PanelSerial)"
            Show-Screen 'pnlRedoGateBlock'
            return
        }
        # r8 finding #1: a Phase B the BACKEND rejected must never reopen as ready for closeout.
        # Route it to manual review instead - the spreadsheet has no record of the phase.
        if ($pending -and "$($pending.PhaseBStatus)" -eq 'Complete' -and
            "$($pending.PhaseBBackendStatus)" -eq 'Rejected') {
            Write-Log "Phase B was rejected by the backend ($($pending.PhaseBBackendErrorCode)) - blocking closeout." 'ERROR'
            $script:UI['lblGateTitle'].Text = 'Phase B Not Recorded'
            $script:UI['lblGateMsg'].Text =
                "The domain join finished on this device, but the spreadsheet REJECTED the Phase B update, so the project was never advanced.`n`n" +
                "$($pending.PhaseBBackendErrorCode): $($pending.PhaseBBackendErrorMessage)`n`n" +
                "Do not close this panel out. A lead needs to reconcile the project record first. The local provisioning state has been kept."
            $script:UI['lblGateState'].Text = "ProjectRunId: $($pending.RelatedSummerRunId)`nHostname: $($pending.Hostname)`nPanel serial: $($pending.PanelSerial)"
            Show-Screen 'pnlRedoGateBlock'
            return
        }
        # v5.6.1 recovery: if local state still says closeout pending but the authoritative Summer
        # project already says Provisioning Complete, reconcile instead of reopening assessment/closeout.
        if ($pending -and "$($pending.PendingCloseoutEventId)" -and $script:IsNetworkAvailable) {
            $remoteClose = Get-SummerProjectStateRemote "$($pending.RelatedSummerRunId)"
            if ($remoteClose -and $remoteClose.found -and
                ("$($remoteClose.projectStatus)" -eq 'Provisioning Complete' -or "$($remoteClose.finalCloseoutStatus)" -eq 'Complete')) {
                try {
                    $sfRemote = Join-Path $script:ProvisioningDir 'state.json'
                    if (Test-Path $sfRemote) {
                        Move-Item $sfRemote (Join-Path $script:ProvisioningDir "state.closeout_synced_remote_$(Get-Date -Format 'yyyyMMdd_HHmmss').json") -Force
                    }
                } catch { Write-Log "Remote-complete state archive failed: $_" 'WARN' }
                [System.Windows.MessageBox]::Show(
                    'The spreadsheet already shows this provisioning project as complete. PanelApp has reconciled the local pending closeout and will restart this OPS now.',
                    'Provisioning Complete', 'OK', 'Information') | Out-Null
                Restart-Computer -Force
                return
            }
        }
        # Closeout requires the backend to have ACCEPTED (or at least queued) Phase B.
        if ($pending -and "$($pending.PhaseBStatus)" -eq 'Complete' -and "$($pending.FinalCloseoutStatus)" -eq 'Pending' -and
            (("$($pending.PhaseBBackendStatus)" -in @('Applied','Queued')) -or -not "$($pending.PhaseBBackendStatus)")) {
            Write-Log "Resuming pending closeout for $($pending.RelatedSummerRunId)."
            $script:Hostname             = "$($pending.Hostname)"
            $script:PanelSerial          = "$($pending.PanelSerial)"
            $script:OPSSerial            = "$($pending.OPSSerial)"
            $script:SummerContinuation   = $true
            $script:RelatedSummerRunId   = "$($pending.RelatedSummerRunId)"
            $script:SummerImageProfile   = "$($pending.SummerImageProfile)"
            $script:SummerRedoFile       = "$($pending.SummerRedoFile)"
            $script:SummerExpectedFolder = "$($pending.SummerExpectedFolder)"
            $script:NewInstallProvisioning = [bool]$pending.NewInstallProvisioning
            $script:RecoveryProvisioning   = [bool]$pending.RecoveryProvisioning
            # r6 finding #3: this branch resumes DIRECTLY at closeout after Phase B (crash, close
            # or restart). Without the sender state the closeout posts with a NEW session,
            # sequence 0 and no revision - silently disabling optimistic concurrency.
            # r7 finding #2: startup already ran Flush-OfflineQueue, which may have applied a
            # queued PhaseBCompleted and advanced the revision. Assigning the state-file values
            # directly would walk it BACK and the closeout would be rejected as stale, so both
            # revision and sequence go through the monotonic path.
            Restore-ProjectRevision ([pscustomobject]@{
                ProjectRunId         = "$($pending.ProjectStateRevisionFor)"
                ProjectStateRevision = "$($pending.ProjectStateRevision)" })
            if ("$($pending.ClientSessionId)")  { $script:ClientSessionId  = "$($pending.ClientSessionId)" }
            if ("$($pending.ClientDeviceName)") { $script:ClientDeviceName = "$($pending.ClientDeviceName)" }
            # ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§2: the post-join result and the as-found name must survive a close/crash between
            # Phase B and closeout, or the resumed closeout regresses to Not Domain Joined/WORKGROUP.
            if ("$($pending.AssessmentHostname)")          { $script:AssessmentHostname          = "$($pending.AssessmentHostname)" }
            if ("$($pending.DomainJoinTargetDomain)")      { $script:DomainJoinTargetDomain      = "$($pending.DomainJoinTargetDomain)" }
            if ("$($pending.DomainJoinCompletedAt)")       { $script:DomainJoinCompletedAt       = "$($pending.DomainJoinCompletedAt)" }
            if ("$($pending.PostJoinMembershipStatus)")    { $script:PostJoinMembershipStatus    = "$($pending.PostJoinMembershipStatus)" }
            if ("$($pending.PostJoinSecureChannelStatus)") { $script:PostJoinSecureChannelStatus = "$($pending.PostJoinSecureChannelStatus)" }
            if ("$($pending.ProvisioningAccount)") { $script:ProvisioningAccountName = "$($pending.ProvisioningAccount)" }
            if ("$($pending.ProvisioningAccountPreflight)") { $script:ProvisioningAccountPreflight = "$($pending.ProvisioningAccountPreflight)" }
            if ("$($pending.ProvisioningAccountEnabled)") { $script:ProvisioningAccountEnabled = "$($pending.ProvisioningAccountEnabled)" }
            if ("$($pending.ProvisioningAccountPasswordNeverExpires)") { $script:ProvisioningAccountPasswordNeverExpires = "$($pending.ProvisioningAccountPasswordNeverExpires)" }
            if ("$($pending.ProvisioningAccountCheckedAt)") { $script:ProvisioningAccountCheckedAt = "$($pending.ProvisioningAccountCheckedAt)" }
            try { $script:AndroidEthernetExceptionReported = [bool]$pending.AndroidEthernetExceptionReported } catch { $script:AndroidEthernetExceptionReported = $false }
            if ("$($pending.AndroidEthernetExceptionEventId)") { $script:AndroidEthernetExceptionEventId = "$($pending.AndroidEthernetExceptionEventId)" }
            if ("$($pending.DomainMembershipStatus)")      { $script:DomainMembershipStatus      = "$($pending.DomainMembershipStatus)" }
            if ("$($pending.DetectedDomain)")              { $script:DetectedDomain              = "$($pending.DetectedDomain)" }
            if ("$($pending.SecureChannelStatus)")         { $script:SecureChannelStatus         = "$($pending.SecureChannelStatus)" }
            if ("$($pending.EventSequence)") {
                $pendSeq = 0; [void][int]::TryParse("$($pending.EventSequence)", [ref]$pendSeq)
                if ($pendSeq -gt $script:EventSequence) { $script:EventSequence = $pendSeq }
            }
            $script:InstallType          = "$($pending.InstallType)"
            $script:RoomType             = "$($pending.RoomType)"
            $script:OtherRoomType        = "$($pending.OtherRoomType)"
            $script:DomainMembershipStatus = "$($pending.DomainMembershipStatus)"
            $script:DetectedDomain       = "$($pending.DetectedDomain)"
            $script:SecureChannelStatus  = "$($pending.SecureChannelStatus)"
            $script:ProvisioningPathSelected = "$($pending.ProvisioningPathSelected)"
            # Review fix #2: restore the full context so the closeout PanelLog row is complete
            $script:ModeLabel            = "$($pending.Mode)"
            $script:SchoolCode           = "$($pending.SchoolCode)"
            $script:SchoolName           = "$($pending.SchoolName)"
            $script:RoomNumber           = "$($pending.Room)"
            $script:MountType            = "$($pending.MountType)"
            $script:Manufacturer         = "$($pending.Manufacturer)"
            $script:PanelModel           = "$($pending.PanelModel)"
            $script:StorageGB            = "$($pending.StorageGB)"
            $script:PreviousHostname       = "$($pending.PreviousHostname)"
            $script:PreviousHostnameSource = "$($pending.PreviousHostnameSource)"
            $script:OldHostnameCheckResult = "$($pending.OldHostnameCheckResult)"
            $script:NewHostnameCheckResult = "$($pending.NewHostnameCheckResult)"
            $script:SelectedHostnameSuffix = "$($pending.SelectedHostnameSuffix)"
            $script:OPSReplacementConfirmed = "$($pending.OPSReplacementConfirmed)"
            if ($pending.RunId)   { $script:RunId = "$($pending.RunId)" }
            if ($pending.UsbRoot) { $script:UsbRoot = "$($pending.UsbRoot)" }
            # Team handoff: a DIFFERENT tech may finish closeout - collect their name first,
            # then open the closeout screen (btnContinueUsername honors this flag).
            $script:ResumeCloseoutPending = $true
            $script:UI['lblModeDisplay'].Text = "$(Get-CloseoutPhaseLabel) (resumed)"
            $script:UI['txtTechName'].Text = "$($pending.TechName)"   # prefill; tech corrects if different
            Show-Screen 'pnlUserEntry'
            try { $script:UI['txtTechName'].Focus() | Out-Null } catch {}
        } else {
            Show-Screen 'pnlUserEntry'
            try { $script:UI['txtTechName'].Focus() | Out-Null } catch {}
        }
    }
})

# ================================================================
#  LAUNCH
# ================================================================
[void]$script:window.ShowDialog()
